# -*- coding: utf-8 -*-
"""종가배팅 클라이언트 (배포용) v2 — 탭 UI + 드래그 카드 + 세련된 차트.
   대시보드 / 계좌 / 설정 3탭. 전략 고정(전체+하이브). 관리자 픽만 사용. 페이퍼 없음.
   실행: run_client.bat (pythonw = cmd창 없음)
"""
# ─────────────────────────────────────────────────────────────────────────────
# ★실행 실패 가시화 — pythonw 는 콘솔이 없어 오류가 어디에도 안 보인다.
#   여기서 sys.excepthook 을 먼저 걸어두면 아래 import 가 깨져도 원인을 알려준다.
#   (모듈 누락·32/64비트 불일치·키움 OCX 미등록 → 예전에는 "아무 반응 없음"이었다)
# ─────────────────────────────────────────────────────────────────────────────
import sys as _sys, os as _os, traceback as _tb

_DIR0 = _os.path.dirname(_os.path.abspath(__file__))
if _DIR0 not in _sys.path:
    _sys.path.insert(0, _DIR0)      # ★_preflight 가 같은 폴더의 kiwoom_ocx 를 쓰려면 먼저 필요
_AUTO = any(str(a).lower() == "auto" for a in _sys.argv[1:])      # 무인모드에선 팝업 금지


def _fatal(msg):
    try:
        with open(_os.path.join(_DIR0, "실행오류.txt"), "w", encoding="utf-8") as f:
            f.write(msg)
    except Exception:
        pass
    if not _AUTO:
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(
                0, msg[-1500:] + "\n\n[진단.bat] 결과와 실행오류.txt 를 관리자에게 보내주세요.",
                "종가배팅 클라이언트 - 실행 오류", 0x10)
        except Exception:
            pass


def _hook(et, ev, tb):
    _fatal("프로그램을 시작하지 못했습니다.\n\n" + "".join(_tb.format_exception(et, ev, tb)))


_sys.excepthook = _hook


def _preflight():
    """자주 나는 3가지 원인을 먼저 한글로 알려준다."""
    bad = []
    import struct
    _b32 = (struct.calcsize("P") * 8 == 32)
    if not _b32:
        bad.append("• 64비트 파이썬으로 실행되었습니다.\n"
                   "  키움 OpenAPI는 32비트 파이썬에서만 동작합니다.\n"
                   "  python.org 에서 'Windows installer (32-bit)' 3.12.x 설치 후\n"
                   "  [2_프로그램설치.bat] 을 다시 실행하세요.")
    try:
        import numpy  # noqa
    except Exception:
        bad.append("• numpy 가 설치되지 않았습니다.  setup.bat 을 다시 실행하세요.")
    try:
        import PyQt5  # noqa
        from PyQt5.QAxContainer import QAxWidget  # noqa
    except Exception:
        bad.append("• PyQt5 가 설치되지 않았습니다.  setup.bat 을 다시 실행하세요.")
    # ★ProgID 만 보면 안 된다 — 옛 OpenAPI 를 폴더째 지운 PC 는 등록만 남아
    #   이 점검을 통과하고, 정작 TradeKiwoom() 에서 OnEventConnect 없이 죽는다.
    #   실제 ocx 파일까지 확인한다. (2026-09-15)
    try:
        import kiwoom_ocx
        _p = kiwoom_ocx.problem() if _b32 else None   # 비트수는 위에서 이미 알렸다(중복 방지)
        if _p:
            bad.append("• " + _p.replace("\n", "\n  "))
    except Exception:
        try:
            import winreg
            winreg.CloseKey(winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, "KHOPENAPI.KHOpenAPICtrl.1"))
        except Exception:
            bad.append("• 키움 OpenAPI(OCX)가 설치/등록되지 않았습니다.\n"
                       "  키움 홈페이지에서 'Open API+' 를 설치한 뒤 다시 실행하세요.")
    if bad:
        _fatal("실행 전 점검에서 문제가 발견되었습니다.\n\n" + "\n\n".join(bad))
        _sys.exit(1)


_preflight()

import sys, os, json, datetime, urllib.request, math, subprocess, threading, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception: pass
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
                             QLabel, QPushButton, QLineEdit, QRadioButton, QButtonGroup, QComboBox,
                             QStackedWidget, QScrollArea, QFrame, QGraphicsDropShadowEffect, QSizePolicy, QMessageBox)
from PyQt5.QtCore import QTimer, QEventLoop, Qt, QRectF, QPointF
from PyQt5.QtGui import QFont, QColor, QPainter, QPen, QBrush, QLinearGradient, QPainterPath, QFontDatabase
from kiwoom_trade import TradeKiwoom
from jongga_scanner import TG_TOKEN, _int
import strategies as st
try: import buy_appeal as ba
except Exception: ba = None

DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG = os.path.join(DIR, "client_config.json")
STATE = os.path.join(DIR, "client_state.json")
LOGF = os.path.join(DIR, "client_log.txt")
RESTART_LOG = os.path.join(DIR, "restart_history.json")   # ★즉시 재시작 이력(폭주 백오프용)
PICKS_URL = "https://hn98201.github.io/apple_paly/picks_latest.json"
MANAGE_OPEN, MANAGE_CLOSE, BUY_HM, CONVERT_HM, RECON_HM, DONE_HM = "09:00", "15:19", "15:25", "15:28", "15:31", "15:35"   # ★관리자 100% 동일 타임라인: 09:00~15:19 손익절 → 15:19 종가청산 → 15:25 지정가매수 → 15:28 미체결 시장가전환 → 15:31 실잔고 보정
OP_START, LOGIN_HM, OP_END = "08:25", "08:30", "17:00"                        # ★운영 생명주기: 평일 08:30 로그인 → 17:00 매매중지(끄지 않고 대기) → 다음 평일 08:30 자동재개
REG_END = "15:30"                          # ★정규장 끝(장마감 동시호가 포함). 이 밖의 틱은 정규장 판정에 쓰지 않는다
AFTP_START, AFTP_END = "16:00", "20:00"    # ★KRX 애프터마켓(2026-09-14 신설·접속매매·지정가만·가격제한 전일종가±30%)
LOCK_PORT = 53137             # ★중복실행 차단용 로컬 포트 — 프로세스 목록 조회보다 5초 빠르다
AUTO = ("auto" in sys.argv)   # ★바탕화면 아이콘(auto)=무인 생명주기 적용 / 인자 없이 직접 실행=보기전용(자동로그인 안 함)
START_CAP = 10_000_000

# ★기본값은 '설정파일이 없거나 키가 빠졌을 때' 쓰인다 — 옛 3%/3% 가 남아 있으면
#   client_config.json 이 지워졌을 때 조용히 다른 전략으로 매매한다. 운영값과 같게 유지할 것.
DEFCFG = {"account": "", "is_mock": True, "tp_pct": 6.0, "sl_pct": -3.5, "fee_pct": 0.15, "principal": 1000, "invest_per_stock": 2000000,
          "telegram_chat_id": "", "nickname": "", "hub_url": "http://127.0.0.1:8770",
          "enabled": False, "pw_registered": False, "card_pos": {},
          # ★관리자와 동일한 사이징·갭컷(2026-09-14 추가). 관리자 admin_config.json 과 같은 값으로 둘 것.
          "cash_buffer": 200000, "size_div": 3, "min_positions": 2, "gapcut_pct": 0.0,
          "float_max": 70, "exclude_upper": True,
          # 🌙 애프터마켓(16:00~20:00) 익절전용 — 켜야 실주문이 나간다(모의는 불가)
          #    aftp_hoga: 키움 거래구분. "00"=지정가. 옛 "62"(시간외단일가)는 2026-09-14 폐지됐다.
          "aftp_live": False, "aftp_hoga": "00"}

MIN_POS_WON = 100000     # ★한 종목 최소 투입금 — 이보다 잘게 쪼개면 호가단위 오차가 커진다

UP, DN, PUR, GOLD = "#ff5468", "#43a6ff", "#9b6cff", "#f5b53d"
CYAN, CY2, GLOWC = "#38e7f2", "#15c4d7", "#0bd3e0"      # ★사이버 HUD 시안 글로우(관리자와 동일 테마)
INK, MUT = "#dce9ee", "#6f8a9a"
FONT_STACK = "'Pretendard','NanumSquareRound','Malgun Gothic','Segoe UI'"


def loadj(p, d):
    try: return json.load(open(p, encoding="utf-8"))
    except Exception: return json.loads(json.dumps(d))


def savej(p, o):
    try: json.dump(o, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    except Exception: pass


def tg_send(chat_id, text):
    if not chat_id: return
    try:
        import urllib.parse
        data = urllib.parse.urlencode({"chat_id": chat_id, "text": text}).encode()
        urllib.request.urlopen(urllib.request.Request(f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage", data=data), timeout=8)
    except Exception: pass


def shadow(w, blur=28, dy=8, alpha=170):
    e = QGraphicsDropShadowEffect(w); e.setBlurRadius(blur); e.setXOffset(0); e.setYOffset(dy)
    e.setColor(QColor(0, 0, 0, alpha)); w.setGraphicsEffect(e); return e


def glow(w, color=None, blur=30, alpha=140):        # ★시안 발광(관리자와 동일)
    e = QGraphicsDropShadowEffect(w); e.setBlurRadius(blur); e.setXOffset(0); e.setYOffset(0)
    c = QColor(color or GLOWC); c.setAlpha(alpha); e.setColor(c); w.setGraphicsEffect(e); return e


# ───────── 세련된 라인 차트 ─────────
class Sparkline(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent); self.vals = []; self.setMinimumHeight(90)
    def setData(self, vals): self.vals = list(vals); self.update()
    def paintEvent(self, _):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height(); pad = 6
        vals = self.vals
        if len(vals) < 2:
            p.setPen(QColor("#5b6472")); p.drawText(self.rect(), Qt.AlignCenter, "거래 데이터 쌓이는 중…"); return
        mn, mx = min(vals + [0]), max(vals + [0]); rng = (mx - mn) or 1
        def X(i): return pad + (w - 2 * pad) * i / (len(vals) - 1)
        def Y(v): return pad + (h - 2 * pad) * (1 - (v - mn) / rng)
        # zero line
        zy = Y(0); p.setPen(QPen(QColor(255, 255, 255, 28), 1, Qt.DashLine)); p.drawLine(pad, int(zy), w - pad, int(zy))
        pos = vals[-1] >= 0; col = QColor(UP if pos else DN)
        # area gradient
        path = QPainterPath(); path.moveTo(X(0), Y(vals[0]))
        for i in range(1, len(vals)): path.lineTo(X(i), Y(vals[i]))
        area = QPainterPath(path); area.lineTo(X(len(vals) - 1), h - pad); area.lineTo(X(0), h - pad); area.closeSubpath()
        g = QLinearGradient(0, 0, 0, h); c2 = QColor(col); c2.setAlpha(90); c3 = QColor(col); c3.setAlpha(0)
        g.setColorAt(0, c2); g.setColorAt(1, c3); p.fillPath(area, QBrush(g))
        p.setPen(QPen(col, 2.4)); p.drawPath(path)
        # glow endpoint
        ex, ey = X(len(vals) - 1), Y(vals[-1])
        gl = QColor(col); gl.setAlpha(70); p.setBrush(gl); p.setPen(Qt.NoPen); p.drawEllipse(QPointF(ex, ey), 7, 7)
        p.setBrush(col); p.drawEllipse(QPointF(ex, ey), 3.5, 3.5)


# ───────── 승률 게이지(도넛) ─────────
class Gauge(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent); self.pct = 0; self.setFixedSize(120, 120)
    def setPct(self, v): self.pct = max(0, min(100, v)); self.update()
    def paintEvent(self, _):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(12, 12, self.width() - 24, self.height() - 24)
        p.setPen(QPen(QColor(255, 255, 255, 24), 11)); p.drawArc(r, 0, 360 * 16)
        col = QColor(UP if self.pct >= 50 else GOLD)
        pen = QPen(col, 11); pen.setCapStyle(Qt.RoundCap); p.setPen(pen)
        p.drawArc(r, 90 * 16, -int(360 * 16 * self.pct / 100))
        p.setPen(QColor("#f0eef8")); f = QFont("Malgun Gothic", 20, QFont.Bold); p.setFont(f)
        p.drawText(self.rect().adjusted(0, -6, 0, -6), Qt.AlignCenter, f"{self.pct:.0f}%")
        p.setPen(QColor("#8b93a7")); p.setFont(QFont("Malgun Gothic", 8))
        p.drawText(self.rect().adjusted(0, 34, 0, 34), Qt.AlignCenter, "승률")


# ───────── 반응형 카드(창 크기 따라 비율대로 커짐) ─────────
class Card(QFrame):
    def __init__(self, title, minw=200, minh=120):
        super().__init__(); self.setObjectName("card")
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding); self.setMinimumSize(minw, minh)
        shadow(self)
        v = QVBoxLayout(self); v.setContentsMargins(15, 11, 15, 13); v.setSpacing(6)
        t = QLabel(title); t.setObjectName("ctitle"); v.addWidget(t)
        self.body = QVBoxLayout(); self.body.setSpacing(4); v.addLayout(self.body, 1)


CSS = f"""
QMainWindow,QWidget{{background:#060a10;color:{INK};font-family:{FONT_STACK};font-size:13px;}}
#appbar{{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #0b141c,stop:1 #070c12);border-bottom:1px solid #123039;}}
#brand{{font-size:18px;font-weight:800;color:#eafcff;letter-spacing:2px;}}
#navbtn{{background:transparent;color:#7d95a3;border:none;padding:9px 15px;font-size:12.5px;font-weight:700;border-radius:12px;letter-spacing:.5px;}}
#navbtn:hover{{color:{CYAN};}}
#navbtn[on="1"]{{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 rgba(56,231,242,.20),stop:1 rgba(21,196,215,.08));color:{CYAN};border:1px solid #1d515c;}}
#card{{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #0e1a22,stop:1 #0a141b);border:1px solid #163540;border-radius:18px;}}
#ctitle{{color:{CYAN};font-size:12.5px;font-weight:800;letter-spacing:1px;}}
#big{{font-size:32px;font-weight:900;letter-spacing:.5px;}}
#statcard{{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #0e1a22,stop:1 #0a141b);border:1px solid #163540;border-radius:18px;}}
QPushButton{{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #10323b,stop:1 #0c2129);color:{CYAN};border:1px solid #1d515c;border-radius:12px;padding:9px 15px;font-weight:800;letter-spacing:.5px;}}
QPushButton:hover{{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #16454f,stop:1 #103038);border:1px solid {CYAN};color:#eafcff;}}
QPushButton:disabled{{background:#0f1720;color:#3f5560;border:1px solid #16242c;}}
QPushButton#seg{{padding:6px 10px;font-size:12px;font-weight:700;letter-spacing:0;min-width:0;}}
QPushButton#seg[on="1"]{{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 rgba(56,231,242,.30),stop:1 rgba(21,196,215,.12));color:#eafcff;border:1px solid {CYAN};}}
#gobtn{{font-size:15px;padding:14px;border-radius:15px;}}
QLineEdit,QComboBox{{background:#0a141b;color:{INK};border:1px solid #1a3742;border-radius:11px;padding:9px 11px;}}
QLineEdit:focus{{border:1px solid {CYAN};}}
QRadioButton{{color:#a9c3cd;font-weight:700;}}
#pill{{background:rgba(56,231,242,.12);color:{CYAN};border:1px solid #1d515c;border-radius:999px;padding:3px 12px;font-weight:800;font-size:11px;}}
#modebtn{{background:#0c161d;color:#82a0ac;border:1px solid #17323c;border-radius:12px;padding:9px 13px;font-weight:800;}}
#stpill{{background:transparent;border:none;padding:0 6px;}}
#trow{{color:#a9c3cd;}} .muted{{color:{MUT};}}
QScrollArea{{border:none;background:transparent;}}
QScrollBar:vertical{{background:transparent;width:9px;margin:2px;}} QScrollBar::handle:vertical{{background:#1d4650;border-radius:4px;}} QScrollBar::handle:vertical:hover{{background:{CY2};}}
"""


class Client(QMainWindow):
    def __init__(self):
        super().__init__()
        # ★중복 실행 차단(2026-09-15) — 아래 enabled=False 가 **돌고 있던 자동매매를 꺼버린다.**
        #   이미 떠 있는데 바탕화면 아이콘으로 하나 더 띄우면 조용히 멈춘다(관리자에서 실제로 당했다).
        #   설정을 건드리기 **전에** 검사하고, 중복이면 아무것도 바꾸지 않고 나간다.
        _dup = self._already_running()
        if _dup:
            self.log(f"⛔ 이미 실행 중입니다(PID {_dup}) — 이 창은 닫습니다. 떠 있는 창을 쓰세요")
            if not AUTO:
                try:
                    self._alert("이미 실행 중입니다",
                                f"종가배팅 클라이언트가 이미 실행 중입니다. (PID {_dup})\n\n"
                                "두 개를 동시에 띄우면 키움 접속이 충돌하고\n"
                                "돌고 있던 자동매매가 꺼집니다.\n\n"
                                "이미 떠 있는 창을 사용하세요.")
                except Exception: pass
            QTimer.singleShot(0, lambda: sys.exit(0))
            self._dup_exit = True
            return
        self.cfg = loadj(CONFIG, DEFCFG)
        for k, v in DEFCFG.items(): self.cfg.setdefault(k, v)   # ★신규 설정키(nickname·hub_url 등) 기본값 병합
        self.state = loadj(STATE, {"date": "", "positions": [], "trades": []})
        try:
            self.kw = TradeKiwoom()
        except Exception as e:      # ★키움 OCX 를 못 올린 경우 — 영문 트레이스백 대신 한글 안내
            try:
                from kiwoom_ocx import KiwoomOcxError, guide
                msg = str(e) if isinstance(e, KiwoomOcxError) else guide("원래 오류 : %s" % e)
            except Exception:
                msg = "키움 OpenAPI 를 사용할 수 없습니다.\n\n원래 오류 : %s" % e
            _fatal(msg)
            _sys.exit(1)
        self.kw.on_log = self.log
        self.connected = False; self.acct = {}
        self.bought_today = (self.state.get("buy_date") == self._t())
        self.converted_today = False; self._recon_date = ""   # ★관리자 동일: 15:28 시장가전환·15:31 실잔고보정 1일1회 가드
        self.cfg["enabled"] = False; savej(CONFIG, self.cfg)   # ★시작 시 항상 정지 상태 — [자동매매 시작] 눌러야 시작(로그인부터)
        self._live_dirty = False; self._real_on = False; self._real_key = ""   # SetRealReg 실시간 상태
        self._disc_since = None; self._disc_alerted = False                    # 미접속 1분↑ 감시
        self._logging_in = False                                               # ★로그인 재진입 가드(중첩 do_login/이벤트루프 방지)
        self._popup_n = 0; self._popup_reported = 0                            # ★키움 모달팝업 자동확인 카운터(무인 언블록)
        self._licensed = False; self._lic_status = "확인전"; self._lic_expiry = None; self._chat_rendered = 0; self._lic_ticks = 0
        self._st_online = True; self._hub_ok = False; self._st_ticks = 0     # 상단 상태표시
        self._picks = {}                                                     # ★깃허브 최근 추천종목(대시보드 표시용)
        self._build()
        st.set_thresholds(self.cfg.get("tp_pct", 3.0), self.cfg.get("sl_pct", -3.0))  # 로그인은 안 함(시작 눌러야)
        st.set_fee(self.cfg.get("fee_pct", 0.15)); self._upper_date = ""              # ★1:1 손절용 수수료·상한가 일일리셋 가드
        self._bg(self.check_license, "license")   # ★기동 때도 기다리지 않는다(결과는 5초 뒤 화면에 뜬다)
        self.timer = QTimer(self); self.timer.timeout.connect(self.tick); self.timer.start(20000)
        self.uitimer = QTimer(self); self.uitimer.timeout.connect(self.refresh); self.uitimer.start(5000)
        self.livetimer = QTimer(self); self.livetimer.timeout.connect(self._live_flush); self.livetimer.start(800)  # ★실시간 틱→UI(HTS처럼 가격/등락 실시간)
        self.hubtimer = QTimer(self); self.hubtimer.timeout.connect(self._refresh_hub); self.hubtimer.start(3000)   # 채팅·라이선스 폴링
        self._fetch_picks_bg()                                              # ★시작 시 추천종목 1회 로드
        self.picktimer = QTimer(self); self.picktimer.timeout.connect(self._fetch_picks_bg); self.picktimer.start(300000)  # 5분마다 깃허브 추천종목 갱신
        threading.Thread(target=self._kiwoom_dialog_watcher, daemon=True).start()   # ★키움 모달팝업 자동확인(무인 필수 — 별도 스레드라 모달이 메인을 막아도 동작)
        if not AUTO:
            self.log("👀 수동 실행(보기 전용) — 자동로그인·자동종료 없음. 매매하려면 [자동매매 시작]")
        if AUTO and self.cfg.get("auto_start"):      # ★아이콘(auto) 실행 후에만 자동 재개 — 로그인은 08:30에(장전 매매대기)
            _rh = [t for t in loadj(RESTART_LOG, []) if time.time() - t < 600]   # 최근 재시작 이력(폭주=지속장애)
            _back = 0 if len(_rh) < 2 else min(300, 30 * (2 ** (len(_rh) - 2)))  # 1회 즉시 후 지속 재시작 시 로그인 지연(30→60→120→240→300초): 레이트차단 방지
            _now = datetime.datetime.now(); _delay = 6 + _back
            _tl = _now.replace(hour=8, minute=30, second=0, microsecond=0)       # ★08:25~08:30 실행 시 → 08:30까지 대기 후 로그인(사용자 지시)
            if _now.weekday() < 5 and OP_START <= _now.strftime("%H:%M") < LOGIN_HM:
                _delay = max(_delay, int((_tl - _now).total_seconds()))
            QTimer.singleShot(_delay * 1000, self._auto_resume)

    def _operating(self):
        """★운영 생명주기: 평일(월~금) 08:25~17:00만 가동. 밖이면 프로그램 종료 대상(야간·주말)."""
        now = datetime.datetime.now()
        return now.weekday() < 5 and OP_START <= now.strftime("%H:%M") < OP_END

    def _night_idle(self):
        """★운영시간 밖(17:00 이후·주말) — 끄지 않고 켜 둔 채 쉰다. (2026-09-16)

        예전엔 여기서 프로그램을 껐고 평일 08:25 예약작업이 다시 켰다.
        예약작업을 없앴으므로(남의 PC 를 깨우고 2분마다 도는 부담) **끄면 아무도 못 켠다.**
        그래서 매매만 멈추고 프로그램은 살려 둔다 — 다음 평일 08:30 에 _daily_resume() 이 깨운다.
        auto_start 는 끄지 않는다. 그게 '다음 날 자동재개' 의 근거다."""
        if self.cfg.get("enabled"):
            self.cfg["enabled"] = False; savej(CONFIG, self.cfg)
            try:
                self.log("🌙 운영시간 종료 — 매매 중지, 프로그램은 켜 둔 채 대기(다음 평일 08:30 자동재개)")
                self.tg("🌙 운영시간 종료(17시/주말) — 대기 상태로 전환. 다음 평일 08:30 자동 재개")
            except Exception: pass
        self._resumed_day = None          # 다음 운영일에 다시 로그인하도록 초기화

    def _daily_resume(self):
        """★예약작업 없이 매일 자동 재개 — 켜 둔 채 밤을 넘겨도 다음 평일 08:30 에 스스로 로그인한다.

        하루 한 번만 시도한다. 로그인이 실패하면 toggle_auto() 가 _restart_process() 로
        프로세스를 새로 띄우고, 새 프로세스가 6초 뒤 _auto_resume() 을 다시 태운다."""
        if self._hm() < LOGIN_HM: return                     # 08:25~08:30 은 대기(로그인은 08:30)
        d = self._t()
        if getattr(self, "_resumed_day", None) == d: return
        self._resumed_day = d
        if not self.cfg.get("auto_start"): return            # 사용자가 [자동매매 중지] 를 눌렀으면 그대로 둔다
        if self.cfg.get("enabled"): return                   # 이미 돌고 있으면 건드리지 않는다
        try: self.connected = int(self.kw.dynamicCall("GetConnectState()")) == 1   # 밤새 끊겼는지 실제로 확인
        except Exception: self.connected = False
        self.log("🔄 운영시간 진입 — 자동 로그인 시작(예약작업 없이 스스로)")
        self._auto_resume()

    def _auto_resume(self):
        """자동 재개 — 운영시간(평일 08:25~17:00)이면 08:30 로그인, 밖이면 대기(_night_idle)."""
        if not self._operating():
            self._night_idle(); return
        if self.cfg.get("auto_start") and not self.cfg.get("enabled"):
            self.check_license()
            if not self._licensed:
                self.log("⚠️ 미승인 — 자동시작 보류(관리자 승인 필요)"); return   # ★알림창 없이 로그만(무인 모달블록 방지)
            self.log("🔄 자동 재개 — 08:30 자동루틴 시작(무인)"); self.toggle_auto()

    def _fetch_picks_bg(self):
        """깃허브 최근 추천종목을 백그라운드로 로드(메인스레드 블로킹 없이) → 대시보드 표시."""
        def _work():
            try:
                pj = self.fetch_picks()
                if pj and pj.get("stocks"): self._picks = pj; self._live_dirty = True
            except Exception: pass
        threading.Thread(target=_work, daemon=True).start()

    def _bg(self, fn, key):
        """★네트워크는 전부 여기로 — 메인스레드에서 기다리면 창이 그대로 얼어붙는다.

        2026-09-16 실측: _update_status 한 번에 2.5초(온라인 3초 + 허브 6초 타임아웃).
        refresh 가 5초마다 도니 25초마다 뚝 끊겼고, 채팅은 3초마다 같은 짓을 했다.
        같은 key 가 아직 돌고 있으면 새로 띄우지 않는다 — 느린 서버에서 스레드가 쌓이는 것 방지."""
        busy = self.__dict__.setdefault("_bg_busy", set())
        if key in busy: return
        busy.add(key)

        def _work():
            try: fn()
            except Exception: pass
            finally: busy.discard(key)
        threading.Thread(target=_work, daemon=True).start()

    def _probe_net(self):
        """온라인·관리자연결 확인(백그라운드 전용). 결과는 다음 갱신(5초) 때 화면에 반영된다."""
        self._st_online = self._check_online()
        self._hub_ok = self._hub_get("/api/ping") is not None

    def _chat_fetch(self):
        """채팅 새 글 받아오기(백그라운드 전용). 화면에 붙이는 건 메인스레드가 한다 — Qt 규칙."""
        self._chat_pending = self._hub_get("/api/chat?since=%d" % self._chat_rendered)

    def _t(self): return datetime.date.today().strftime("%Y-%m-%d")
    def _hm(self): return datetime.datetime.now().strftime("%H:%M")
    def wait(self, ms):
        loop = QEventLoop(); QTimer.singleShot(int(ms), loop.quit); loop.exec_()
    def tg(self, text):
        """★큐에 넣고 바로 돌아온다 — 전송 타임아웃이 8초다. 15:25 매수 중에 그걸 기다리면 안 된다.
        보내는 순서는 지킨다(일꾼 하나가 순서대로 처리)."""
        q = self.__dict__.setdefault("_tgq", [])
        q.append(text)
        if getattr(self, "_tg_worker", False): return
        self._tg_worker = True

        def _work():
            while True:
                if not q:
                    time.sleep(0.4); continue
                m = q.pop(0)
                try: tg_send(self.cfg.get("telegram_chat_id", ""), "🐷[종가배팅] " + m)
                except Exception: pass
        threading.Thread(target=_work, daemon=True).start()
    def log(self, m):
        line = f"[{datetime.datetime.now():%H:%M:%S}] {m}"
        try:
            with open(LOGF, "a", encoding="utf-8") as f: f.write(f"[{datetime.date.today()}] " + line + "\n")
        except Exception: pass
        try: self.logbox.setText(line + "\n" + self.logbox.text()[:600])
        except Exception: pass

    # ═══ GUI ═══
    def _build(self):
        self.setWindowTitle("종가배팅"); self.setStyleSheet(CSS); self.resize(600, 860)
        root = QWidget(); self.setCentralWidget(root); RV = QVBoxLayout(root); RV.setContentsMargins(0, 0, 0, 0); RV.setSpacing(0)
        # appbar + nav
        bar = QWidget(); bar.setObjectName("appbar"); bar.setFixedHeight(58); bh = QHBoxLayout(bar); bh.setContentsMargins(18, 0, 14, 0)
        br = QLabel("⬡ 종가배팅"); br.setObjectName("brand"); glow(br, CYAN, 22, 120); bh.addWidget(br)
        bh.addSpacing(12)
        self.stpills = {}
        for k in ("lic", "hub", "api", "online"):     # 승인·관리자연결·키움접속·온라인
            p = QLabel("—"); p.setObjectName("stpill"); bh.addWidget(p); self.stpills[k] = p
        bh.addStretch()
        self.navbtns = {}
        for k, t in [("dash", "📊 대시보드"), ("acct", "💰 계좌"), ("chat", "💬 채팅"), ("set", "⚙️ 설정")]:
            b = QPushButton(t); b.setObjectName("navbtn"); b.clicked.connect(lambda _, kk=k: self.nav(kk)); bh.addWidget(b); self.navbtns[k] = b
        RV.addWidget(bar)
        self.stack = QStackedWidget(); RV.addWidget(self.stack, 1)
        self.stack.addWidget(self._page_dash())
        self.stack.addWidget(self._page_acct())
        self.stack.addWidget(self._page_chat())
        self.stack.addWidget(self._page_set())
        self.nav("dash")
        self.refresh()
        QTimer.singleShot(400, self._warmup)      # ★창 뜬 뒤 각 탭을 미리 준비(첫 전환 렉 제거)

    def _warmup(self):
        """★탭 첫 전환 렉 제거 — 창이 뜬 뒤 각 탭의 스타일을 미리 해석해 둔다.

        Qt 는 위젯을 처음 그릴 때 스타일시트를 해석한다. 그 비용이 첫 탭 전환에 몰려 튄다.
        유휴 시간에 미리 해 두면 사용자가 누를 땐 이미 준비돼 있다."""
        try:
            for i in range(self.stack.count()):
                p = self.stack.widget(i)
                p.ensurePolished()
                for c in p.findChildren(QWidget): c.ensurePolished()
        except Exception:
            pass

    def nav(self, k):
        idx = {"dash": 0, "acct": 1, "chat": 2, "set": 3}[k]; self.stack.setCurrentIndex(idx)
        for kk, b in self.navbtns.items(): b.setProperty("on", "1" if kk == k else "0"); b.setStyle(b.style())

    # ── 대시보드 (드래그 카드) ──
    def _page_dash(self):
        pg = QWidget(); V = QVBoxLayout(pg); V.setContentsMargins(14, 12, 14, 10); V.setSpacing(10)
        top = QHBoxLayout(); top.setSpacing(10)
        self.btn_go = QPushButton("▶  자동매매 시작"); self.btn_go.setObjectName("gobtn"); self.btn_go.clicked.connect(self.toggle_auto); shadow(self.btn_go, 20, 5, 120)
        self.btn_mock = QPushButton("🟢 모의투자"); self.btn_mock.setObjectName("modebtn"); self.btn_mock.setFixedWidth(118); self.btn_mock.clicked.connect(lambda: self.set_mode(True))
        self.btn_real = QPushButton("🔴 실거래"); self.btn_real.setObjectName("modebtn"); self.btn_real.setFixedWidth(108); self.btn_real.clicked.connect(lambda: self.set_mode(False))
        top.addWidget(self.btn_go, 1); top.addWidget(self.btn_mock); top.addWidget(self.btn_real); V.addLayout(top)
        sa = QScrollArea(); sa.setWidgetResizable(True); inner = QWidget(); sa.setWidget(inner)
        G = QGridLayout(inner); G.setSpacing(11); G.setContentsMargins(2, 2, 2, 2)
        self.c_chart = Card("📈 수익률 추이", 320, 180); self.spark = Sparkline(); self.chart_sub = QLabel(); self.chart_sub.setObjectName("muted")
        self.c_chart.body.addWidget(self.spark, 1); self.c_chart.body.addWidget(self.chart_sub)
        self.c_win = Card("🏆 승률", 150, 180); self.gauge = Gauge(); self.c_win.body.addWidget(self.gauge, 1, Qt.AlignCenter)
        self.c_ret = Card("💹 누적 수익률(라이브)", 200, 110); self.ret_big = QLabel("—"); self.ret_big.setObjectName("big"); glow(self.ret_big, CYAN, 24, 110); self.ret_sub = QLabel(); self.ret_sub.setObjectName("muted")
        self.c_ret.body.addWidget(self.ret_big); self.c_ret.body.addWidget(self.ret_sub); self.c_ret.body.addStretch()
        self.c_hold = Card("🔴 보유중", 200, 150); self.hold_box = QLabel("없음"); self.hold_box.setWordWrap(True); self.hold_box.setAlignment(Qt.AlignTop); self.c_hold.body.addWidget(self.hold_box, 1)
        self.c_today = Card("✅ 오늘 거래", 200, 130); self.today_box = QLabel("없음"); self.today_box.setWordWrap(True); self.today_box.setAlignment(Qt.AlignTop); self.c_today.body.addWidget(self.today_box, 1)
        self.c_all = Card("📜 전체 거래내역", 320, 160); self.all_box = QLabel("없음"); self.all_box.setWordWrap(True); self.all_box.setAlignment(Qt.AlignTop); self.c_all.body.addWidget(self.all_box, 1)
        self.c_routine = Card("📋 루틴 상태 (오늘 진행 체크리스트)", 260, 170); self.routine_box = QLabel("—"); self.routine_box.setWordWrap(True); self.routine_box.setAlignment(Qt.AlignTop); self.routine_box.setTextFormat(Qt.RichText); self.c_routine.body.addWidget(self.routine_box, 1)
        self.c_picks = Card("🎯 오늘 추천 종목 (깃허브 · 매수 전에도 표시)", 320, 200); self.picks_box = QLabel("불러오는 중…"); self.picks_box.setWordWrap(True); self.picks_box.setAlignment(Qt.AlignTop); self.picks_box.setTextFormat(Qt.RichText); self.c_picks.body.addWidget(self.picks_box, 1)
        G.addWidget(self.c_picks, 0, 0, 1, 3)          # ★추천종목 = 맨 위 전체너비(제일 잘 보이게)
        G.addWidget(self.c_chart, 1, 0, 1, 2); G.addWidget(self.c_win, 1, 2, 1, 1)
        G.addWidget(self.c_ret, 2, 0, 1, 1); G.addWidget(self.c_hold, 2, 1, 1, 2)
        G.addWidget(self.c_routine, 3, 0, 1, 1); G.addWidget(self.c_today, 3, 1, 1, 1); G.addWidget(self.c_all, 3, 2, 1, 1)
        for c in range(3): G.setColumnStretch(c, 1)
        G.setRowStretch(0, 0)                          # 추천종목은 내용만큼(고정), 나머지는 신축
        for r in range(1, 4): G.setRowStretch(r, 1)
        V.addWidget(sa, 1)
        return pg

    def set_mode(self, mock):
        # ★실거래 전환은 확인을 받는다 — 버튼 한 번에 바뀌면 안 되는 스위치다.
        if not mock and self.cfg.get("is_mock", True):
            srv = ""
            try: srv = self.kw.server_gubun()
            except Exception: pass
            m = QMessageBox(self); m.setIcon(QMessageBox.Warning)
            m.setWindowTitle("실거래 전환"); m.setText("🔴 실거래 모드로 바꿀까요?")
            m.setInformativeText(
                "현재 키움 접속: " + {"1": "모의투자 서버", "0": "실서버"}.get(srv, "확인 불가") + "\n\n"
                + ("⚠️ 지금 모의투자 서버에 접속돼 있습니다.\n"
                   "   설정만 바꿔도 주문은 모의로 나갑니다 — 키움을 실서버로 다시 로그인해야 합니다.\n\n"
                   if srv == "1" else "")
                + "· 이 설정은 기록에 '실전'으로 남기는 라벨입니다.\n"
                  "· 실제 체결은 키움 로그인 서버가 정합니다.\n"
                  "· 바꾼 뒤 로그인하면 서버와 설정이 맞는지 자동으로 대조합니다.")
            m.setStandardButtons(QMessageBox.Yes | QMessageBox.Cancel)
            m.setDefaultButton(QMessageBox.Cancel)
            m.button(QMessageBox.Yes).setText("실거래로 전환")
            m.button(QMessageBox.Cancel).setText("취소")
            if m.exec_() != QMessageBox.Yes:
                self.log("실거래 전환 취소"); self.refresh(); return
            self.tg("🔴 실거래 모드로 전환됨 — 다음 로그인에서 서버와 대조합니다")
        self.cfg["is_mock"] = mock; savej(CONFIG, self.cfg)
        try: (self.rb_mock if mock else self.rb_real).setChecked(True)
        except Exception: pass
        self.log(("모드 → " + ("🟢 모의투자" if mock else "🔴 실거래")))
        self.refresh()

    def _set_pick_tp(self, v):
        """익절 버튼 → tp_pct 즉시 반영(실시간 손익절·직접입력칸 동기)."""
        self.cfg["tp_pct"] = float(v); savej(CONFIG, self.cfg)
        if hasattr(self, "in_tp"): self.in_tp.setText(f"{float(v):g}")
        st.set_thresholds(self.cfg["tp_pct"], self.cfg.get("sl_pct", -3.0))
        for vv, bt in getattr(self, "set_tpbtns", {}).items(): bt.setProperty("on", "1" if vv == v else "0"); bt.setStyle(bt.style())
        self.log(f"🎯 익절 → +{float(v):g}% (실시간 반영)")

    def _set_pick_sl(self, v):
        """손절 버튼 → sl_pct 즉시 반영(독립·음수 저장·자동 1:1 규칙 없음)."""
        self.cfg["sl_pct"] = -abs(float(v)); savej(CONFIG, self.cfg)
        if hasattr(self, "in_sl"): self.in_sl.setText(f"{self.cfg['sl_pct']:g}")
        st.set_thresholds(self.cfg.get("tp_pct", 3.0), self.cfg["sl_pct"])
        for vv, bt in getattr(self, "set_slbtns", {}).items(): bt.setProperty("on", "1" if vv == v else "0"); bt.setStyle(bt.style())
        self.log(f"🛑 손절 → -{abs(float(v)):g}% (실시간 반영)")

    def _page_acct(self):
        pg = QWidget(); V = QVBoxLayout(pg); V.setContentsMargins(16, 16, 16, 16); V.setSpacing(12)
        row = QHBoxLayout(); row.setSpacing(12)
        self.a_ret = self._statcard("총 수익률", "—", UP)
        self.a_win = self._statcard("승률", "—", GOLD)
        self.a_bal = self._statcard("잔고(추정자산)", "—", "#e9e7f2")
        for c in (self.a_ret, self.a_win, self.a_bal): row.addWidget(c["card"])
        V.addLayout(row)
        c2 = Card("acct_hold", "🔴 보유 종목", None, 100, 100) if False else QFrame(); c2.setObjectName("card"); shadow(c2)
        cv = QVBoxLayout(c2); cv.setContentsMargins(14, 12, 14, 12)
        t = QLabel("🔴 보유 종목"); t.setObjectName("ctitle"); cv.addWidget(t)
        self.acct_hold = QLabel("없음"); self.acct_hold.setWordWrap(True); cv.addWidget(self.acct_hold); V.addWidget(c2)
        c3 = QFrame(); c3.setObjectName("card"); shadow(c3); c3v = QVBoxLayout(c3); c3v.setContentsMargins(14, 12, 14, 12)
        t3 = QLabel("📜 거래내역"); t3.setObjectName("ctitle"); c3v.addWidget(t3)
        self.acct_trades = QLabel("없음"); self.acct_trades.setWordWrap(True); self.acct_trades.setAlignment(Qt.AlignTop); c3v.addWidget(self.acct_trades)
        V.addWidget(c3, 1)
        return pg

    def _statcard(self, label, val, color):
        c = QFrame(); c.setObjectName("statcard"); c.setFixedHeight(96); shadow(c)
        v = QVBoxLayout(c); v.setContentsMargins(14, 12, 14, 12); v.setSpacing(2)
        l = QLabel(label); l.setObjectName("muted"); vv = QLabel(val); vv.setObjectName("big"); vv.setStyleSheet(f"color:{color};font-size:24px")
        v.addWidget(l); v.addWidget(vv)
        return {"card": c, "val": vv}

    # ── 설정 탭 ──
    def _set_aftp(self, on):
        """🌙 애프터마켓 익절 켜기/끄기 — 각자 선택한다(관리자가 강제로 밀지 않는다).

        켜면 16:00~17:00 사이에 보유 종목마다 '매수가 x (1+익절%)' 매도 지정가를 걸어 둔다.
        그 주문은 20:00 까지 살아 있다가 소멸한다. 익절만 걸고 손절은 걸지 않는다."""
        self.cfg["aftp_live"] = bool(on)
        savej(CONFIG, self.cfg)
        if on:
            self.log("🌙 애프터마켓 익절 켬 — 16시 이후 매수가 +%g%% 매도 지정가를 걸어 둡니다(손절은 안 겁니다)"
                     % float(self.cfg.get("tp_pct", 6)))
        else:
            self.log("🌙 애프터마켓 익절 끔 — 정규장(09:00~15:19)에서만 손익절합니다")
        try: self._refresh_aftp()
        except Exception: pass

    def _refresh_aftp(self):
        """스위치 상태·설명을 지금 설정에 맞춘다. 모의투자면 못 켜게 막는다."""
        if not hasattr(self, "aftp_btn"): return
        mock = bool(self.cfg.get("is_mock", True))
        on = bool(self.cfg.get("aftp_live")) and not mock
        tp = float(self.cfg.get("tp_pct", 6))
        _base = "border-radius:11px;padding:10px 14px;font-weight:800;font-size:13px;text-align:left;"
        if mock:                                    # 모의는 애프터마켓 자체가 없다 — 눌리지 않게 하고 이유를 버튼에 쓴다
            self.aftp_btn.setText("🔒 모의투자에서는 쓸 수 없습니다 (실거래 전용)")
            self.aftp_btn.setStyleSheet("background:#141221;color:#4b5563;border:1px dashed #2c2748;" + _base)
            self.aftp_btn.setEnabled(False)
        elif on:
            self.aftp_btn.setText("✅ 켜짐 — 16시 이후 매수가 +%g%% 에 매도 예약   (눌러서 끄기)" % tp)
            self.aftp_btn.setStyleSheet("background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #22c55e,stop:1 #15803d);"
                                        "color:#ffffff;border:1px solid #22c55e;" + _base)
            self.aftp_btn.setEnabled(True)
        else:
            self.aftp_btn.setText("⬜ 꺼짐 — 정규장에서만 매매합니다   (눌러서 켜기)")
            self.aftp_btn.setStyleSheet("background:#171525;color:#8b93a7;border:1px solid #2c2748;" + _base)
            self.aftp_btn.setEnabled(True)
        if mock:
            self.aftp_lbl.setText("모의투자에는 애프터마켓이 없습니다 — 실거래로 바꾸면 쓸 수 있습니다.")
            self.aftp_lbl.setStyleSheet("color:#6f8a9a")
        elif on:
            self.aftp_lbl.setText("켜짐 — 16시 이후 보유 종목에 매수가 +%g%% 매도 지정가를 걸어 둡니다. "
                                  "20시까지 안 팔리면 다음날 정규장에서 평소대로 손익절합니다." % tp)
            self.aftp_lbl.setStyleSheet("color:#22c55e")
        else:
            self.aftp_lbl.setText("꺼짐 — 정규장(09:00~15:19)에서만 손익절합니다.")
            self.aftp_lbl.setStyleSheet("color:#6f8a9a")

    def _page_set(self):
        pg = QWidget(); sa = QScrollArea(); sa.setWidgetResizable(True); inner = QWidget(); sa.setWidget(inner)
        V = QVBoxLayout(inner); V.setContentsMargins(16, 16, 16, 16); V.setSpacing(14)
        outer = QVBoxLayout(pg); outer.setContentsMargins(0, 0, 0, 0); outer.addWidget(sa)
        # 로그인
        g1 = QFrame(); g1.setObjectName("card"); shadow(g1); l1 = QGridLayout(g1); l1.setContentsMargins(16, 14, 16, 14)
        t1 = QLabel("① 로그인 · 계좌 (최초 1회)"); t1.setObjectName("ctitle"); l1.addWidget(t1, 0, 0, 1, 3)
        self.btn_login = QPushButton("🔑 키움 로그인"); self.btn_login.clicked.connect(self.do_login)
        self.cmb_acc = QComboBox(); self.btn_pw = QPushButton("🔒 계좌비밀번호 등록"); self.btn_pw.clicked.connect(self.do_register_pw); self.btn_pw.setEnabled(False)
        self.btn_logout = QPushButton("🚪 로그아웃"); self.btn_logout.clicked.connect(self.do_logout)
        self.btn_logout.setStyleSheet("background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #444055,stop:1 #2b2838);")
        l1.addWidget(self.btn_login, 1, 0); l1.addWidget(QLabel("계좌"), 1, 1); l1.addWidget(self.cmb_acc, 1, 2)
        l1.addWidget(self.btn_pw, 2, 0, 1, 3); l1.addWidget(self.btn_logout, 3, 0, 1, 3); V.addWidget(g1)
        # 매매설정
        g2 = QFrame(); g2.setObjectName("card"); shadow(g2); l2 = QGridLayout(g2); l2.setContentsMargins(16, 14, 16, 14)
        t2 = QLabel("② 매매 설정 (저장 1회 → 다음부터 자동)"); t2.setObjectName("ctitle"); l2.addWidget(t2, 0, 0, 1, 4)
        self.in_tp = QLineEdit(str(self.cfg["tp_pct"])); self.in_sl = QLineEdit(str(self.cfg["sl_pct"]))
        self.in_inv = QLineEdit(str(int(self.cfg["invest_per_stock"]) // 10000)); self.in_tg = QLineEdit(self.cfg.get("telegram_chat_id", ""))
        self.in_prin = QLineEdit(str(int(self.cfg.get("principal", 1000))))   # ★투자원금(만원) — 복리 전략자산 기준(관리자 동일)
        # ★관리자와 동일한 설정칸(2026-09-15) — 값은 예전부터 동작했지만 화면에 없어서 보이지도 고치지도 못했다
        self.in_buf = QLineEdit(str(int(self.cfg.get("cash_buffer", 200000) or 0) // 10000))
        self.in_gap = QLineEdit(str(self.cfg.get("gapcut_pct", 0.0)))
        self.in_fee = QLineEdit(str(self.cfg.get("fee_pct", 0.15)))
        self.rb_real = QRadioButton("실거래"); self.rb_mock = QRadioButton("모의투자")
        (self.rb_mock if self.cfg["is_mock"] else self.rb_real).setChecked(True); bg = QButtonGroup(self); bg.addButton(self.rb_real); bg.addButton(self.rb_mock)
        # ── 🎯익절 / 🛑손절 버튼(독립·10%까지) — 실시간 손익절에 즉시 반영(손절 자동 1:1 규칙 해제·관리자 동일) ──
        self.set_tpbtns = {}; self.set_slbtns = {}
        _curtp = float(self.cfg.get("tp_pct", 3.0)); _cursl = abs(float(self.cfg.get("sl_pct", -3.0)))
        def _btnrow(vals, handler, store, cur):
            row = QHBoxLayout(); row.setSpacing(5)
            for v in vals:
                b = QPushButton(f"{v:g}"); b.setObjectName("seg"); b.setCheckable(True)
                b.setProperty("on", "1" if abs(v - cur) < 1e-9 else "0")
                b.clicked.connect(lambda _, vv=v: handler(vv)); row.addWidget(b); store[v] = b
            row.addStretch(); return row
        l2.addWidget(QLabel("🎯 익절 +%"), 1, 0)
        l2.addLayout(_btnrow([1, 2, 3, 4, 4.5, 5, 6, 7, 8, 10], self._set_pick_tp, self.set_tpbtns, _curtp), 1, 1, 1, 3)
        l2.addWidget(QLabel("🛑 손절 -%"), 2, 0)
        l2.addLayout(_btnrow([1, 2, 3, 4, 4.2, 5, 6, 7, 8, 10], self._set_pick_sl, self.set_slbtns, _cursl), 2, 1, 1, 3)
        l2.addWidget(QLabel("익절%(직접)"), 3, 0); l2.addWidget(self.in_tp, 3, 1); l2.addWidget(QLabel("손절%(직접·음수)"), 3, 2); l2.addWidget(self.in_sl, 3, 3)
        # ★이 값은 '최소'가 아니라 **상한**이다(하한은 가용÷최소보장종목수 로 자동) — 관리자와 동일
        _linv = QLabel("종목당 상한(만원)")
        _linv.setToolTip("한 종목에 넣는 금액의 상한입니다.\n"
                         "하한은 자산이 정합니다 — min(이 값, 가용 ÷ 최소보장종목수).\n"
                         "그래서 자산이 작아도 1종목에 갇히지 않고, 420만 이상에서는 예전과 똑같이 동작합니다.")
        l2.addWidget(_linv, 4, 0); l2.addWidget(self.in_inv, 4, 1)
        l2.addWidget(QLabel("원금(만원)"), 4, 2); l2.addWidget(self.in_prin, 4, 3)
        l2.addWidget(QLabel("현금버퍼(만원)"), 5, 0); l2.addWidget(self.in_buf, 5, 1)
        l2.addWidget(QLabel("갭컷 %(0=끔·음수)"), 5, 2); l2.addWidget(self.in_gap, 5, 3)
        _sd = int(self.cfg.get("size_div", 3) or 3)
        _sz = QLabel("종목당 = max(종목당 최소, (전략자산 − 현금버퍼) ÷ %d) · 최대 %d종목   |   "
                     "갭컷 = 09:00 시가가 매수가보다 그만큼 낮으면 손절선과 무관하게 즉시 시장가" % (_sd, _sd))
        _sz.setObjectName("muted"); _sz.setWordWrap(True); l2.addWidget(_sz, 6, 0, 1, 4)
        l2.addWidget(QLabel("수수료 왕복 %(키움무료고객 0.15)"), 7, 0); l2.addWidget(self.in_fee, 7, 1)
        l2.addWidget(self.rb_real, 7, 2); l2.addWidget(self.rb_mock, 7, 3)
        l2.addWidget(QLabel("텔레그램 chat_id"), 8, 0); l2.addWidget(self.in_tg, 8, 1, 1, 3)
        self.btn_save = QPushButton("💾 저장"); self.btn_save.clicked.connect(self.save_settings); l2.addWidget(self.btn_save, 9, 0, 1, 4)
        V.addWidget(g2)
        # ── 🌙 애프터마켓 익절 (16:00~20:00 · 2026-09-14 신설) ──
        ga = QFrame(); ga.setObjectName("card"); shadow(ga); la = QVBoxLayout(ga); la.setContentsMargins(16, 12, 16, 12); la.setSpacing(8)
        ta = QLabel("🌙 애프터마켓 익절 (16:00~20:00)"); ta.setObjectName("ctitle"); la.addWidget(ta)
        self.aftp_btn = QPushButton("")            # ★버튼 하나 — 지금 상태와 다음 동작을 글자로 말한다
        self.aftp_btn.setMinimumHeight(40)
        self.aftp_btn.clicked.connect(lambda: self._set_aftp(not self.cfg.get("aftp_live")))
        la.addWidget(self.aftp_btn)
        _ah = QLabel("2026-09-14 부터 16~20시에도 주식이 거래됩니다. 켜 두면 보유 종목에 "
                     "'매수가 + 익절%' 매도 주문을 미리 걸어 둬서, 자는 동안 목표가에 닿으면 자동으로 팔립니다.\n"
                     "· 익절만 겁니다 — 손절은 걸지 않습니다(밤에 흔들려 싸게 팔리는 일이 없게).\n"
                     "· 안 팔리면 다음날 정규장에서 평소대로 손익절합니다. 지금 방식이 바뀌는 건 없습니다.\n"
                     "· 모의투자는 애프터마켓이 없어 동작하지 않습니다.")
        _ah.setObjectName("muted"); _ah.setWordWrap(True); la.addWidget(_ah)
        self.aftp_lbl = QLabel(""); self.aftp_lbl.setWordWrap(True); la.addWidget(self.aftp_lbl)
        V.addWidget(ga)
        # ── 사용승인(라이선스) ──
        gl = QFrame(); gl.setObjectName("card"); shadow(gl); ll = QGridLayout(gl); ll.setContentsMargins(16, 12, 16, 12); ll.setSpacing(9)
        tl = QLabel("🪪 사용승인 (닉네임 + 관리자 승인 필요 · 한 달마다 재요청)"); tl.setObjectName("ctitle"); ll.addWidget(tl, 0, 0, 1, 4)
        self.in_nick = QLineEdit(self.cfg.get("nickname", "")); self.in_nick.setPlaceholderText("이름/닉네임")
        self.in_hub = QLineEdit(self.cfg.get("hub_url", ""))
        ll.addWidget(QLabel("닉네임"), 1, 0); ll.addWidget(self.in_nick, 1, 1); ll.addWidget(QLabel("관리자 서버주소"), 1, 2); ll.addWidget(self.in_hub, 1, 3)
        self.lic_lbl = QLabel("—"); self.lic_lbl.setWordWrap(True); ll.addWidget(self.lic_lbl, 2, 0, 1, 2)
        self.btn_req = QPushButton("📨 승인 요청"); self.btn_req.clicked.connect(self.request_license); ll.addWidget(self.btn_req, 2, 2)
        self.btn_save2 = QPushButton("💾 닉/서버 저장"); self.btn_save2.clicked.connect(self.save_settings); ll.addWidget(self.btn_save2, 2, 3)
        V.addWidget(gl)
        g3 = QFrame(); g3.setObjectName("card"); shadow(g3); l3 = QVBoxLayout(g3); l3.setContentsMargins(16, 12, 16, 12)
        t3 = QLabel("ℹ️ 안내"); t3.setObjectName("ctitle"); l3.addWidget(t3)
        info = QLabel("전략은 전체+하이브 고정. 관리자와 100% 동일 매매로직 — 관리자가 15:20 공유한 종목을 유통≤70%·상한가제외 필터 후 매력도 상위 종목을 15:25 지정가(@entry)로 종가매수, 15:28 미체결분 시장가전환, 15:31 실잔고 보정, 다음날 09:00~15:19 실시간 손익절 후 15:19 종가청산. 실거래는 본인 책임(모의로 먼저 테스트). ※사용하려면 관리자 승인 필요.")
        info.setObjectName("muted"); info.setWordWrap(True); l3.addWidget(info); V.addWidget(g3)
        self.logbox = QLabel(""); self.logbox.setObjectName("muted"); self.logbox.setWordWrap(True); V.addWidget(self.logbox)
        V.addStretch()
        return pg

    # ═══ 로직(로그인·매수·관리 — v1과 동일) ═══
    # ═══ 허브(라이선스 승인 + 채팅) ═══
    def _hub(self): return (self.cfg.get("hub_url") or "").rstrip("/")

    def _hub_get(self, path):
        try: return json.loads(urllib.request.urlopen(self._hub() + path, timeout=6).read().decode())
        except Exception: return None

    def _hub_post(self, path, obj):
        try:
            r = urllib.request.urlopen(urllib.request.Request(self._hub() + path, data=json.dumps(obj).encode("utf-8"), headers={"Content-Type": "application/json"}), timeout=6)
            return json.loads(r.read().decode())
        except Exception: return None

    def check_license(self):
        nick = (self.cfg.get("nickname") or "").strip()
        if not nick: self._licensed = False; self._lic_status = "닉네임 미설정"; return
        r = self._hub_get("/api/license?nick=" + urllib.parse.quote(nick))
        if r is None: self._licensed = False; self._lic_status = "서버 연결안됨"; return
        self._licensed = bool(r.get("valid")); self._lic_status = r.get("status"); self._lic_expiry = r.get("expiry")

    def request_license(self):
        nick = (self.cfg.get("nickname") or "").strip()
        if not nick: self.log("⛔ 닉네임 먼저 설정하세요(설정 탭)"); return
        r = self._hub_post("/api/request", {"nick": nick})
        if r: self.log(f"📨 승인요청 전송: {nick} — 관리자 승인 대기")
        else: self.log("승인요청 실패 — 설정 탭 서버주소 확인")
        self.check_license(); self.refresh()

    def _page_chat(self):
        pg = QWidget(); V = QVBoxLayout(pg); V.setContentsMargins(14, 12, 14, 12); V.setSpacing(10)
        head = QLabel("💬 채팅 · 관리자와 대화 (자동매매 중에도 유지 · 스크롤로 과거대화)"); head.setObjectName("brand"); V.addWidget(head)
        self.chat_sa = QScrollArea(); self.chat_sa.setWidgetResizable(True); inner = QWidget(); self.chat_sa.setWidget(inner)
        self.chat_sa.setStyleSheet("QScrollArea{border:1px solid #2c2748;border-radius:14px;background:#0e0c18;}")
        self.chat_box = QVBoxLayout(inner); self.chat_box.setSpacing(7); self.chat_box.setContentsMargins(10, 8, 12, 8); self.chat_box.setAlignment(Qt.AlignTop)
        V.addWidget(self.chat_sa, 1)
        row = QHBoxLayout(); row.setSpacing(8)
        self.chat_in = QLineEdit(); self.chat_in.setPlaceholderText("메시지 입력 후 Enter"); self.chat_in.returnPressed.connect(self._chat_send)
        b = QPushButton("전송"); b.clicked.connect(self._chat_send)
        row.addWidget(self.chat_in, 1); row.addWidget(b); V.addLayout(row)
        return pg

    def _chat_send(self):
        m = self.chat_in.text().strip(); nick = (self.cfg.get("nickname") or "").strip() or "익명"
        if not m: return
        if self._hub_post("/api/chat", {"nick": nick, "msg": m}) is not None:
            self.chat_in.clear(); self._refresh_chat()
        else: self.log("채팅 전송 실패 — 서버주소 확인")

    def _refresh_chat(self):
        if not hasattr(self, "chat_box"): return
        self._bg(self._chat_fetch, "chat")            # ★3초마다 메인스레드를 막던 자리(2026-09-16)
        r = getattr(self, "_chat_pending", None)
        if not r: return
        self._chat_pending = None
        mynick = (self.cfg.get("nickname") or "").strip()
        for m in r.get("msgs", []):
            who = m.get("who", "?"); ts = (m.get("ts", "") or "")[11:16]
            mine = who == mynick; sysm = who == "SYSTEM"; adm = who == "admin"
            c = "#9b6cff" if mine else ("#8b93a7" if sysm else ("#22c55e" if adm else "#c9c4d6"))
            al = Qt.AlignRight if mine else (Qt.AlignHCenter if sysm else Qt.AlignLeft)
            disp = "나" if mine else ("관리자" if adm else who)
            lab = QLabel(f"<span style='color:{c};font-size:10px;font-weight:700'>{disp} · {ts}</span><br>"
                         f"<span style='color:#e9e7f2;font-size:13px'>{m.get('msg','')}</span>")
            lab.setTextFormat(Qt.RichText); lab.setWordWrap(True); lab.setAlignment(al)
            bg = "rgba(155,108,255,.12)" if mine else ("transparent" if sysm else "rgba(255,255,255,.04)")
            lab.setStyleSheet(f"QLabel{{background:{bg};border-radius:9px;padding:5px 9px;}}")
            self.chat_box.addWidget(lab)
        self._chat_rendered = r.get("total", self._chat_rendered)
        if r.get("msgs"):
            QTimer.singleShot(40, lambda: self.chat_sa.verticalScrollBar().setValue(self.chat_sa.verticalScrollBar().maximum()))

    def _refresh_hub(self):
        try: self._refresh_chat()
        except Exception: pass
        self._lic_ticks += 1
        if self._lic_ticks % 10 == 1:   # ~30초마다 라이선스 재확인
            self._bg(self.check_license, "license")   # ★타임아웃 6초 — 메인스레드에서 기다리지 않는다

    def _check_online(self):
        try: urllib.request.urlopen("https://hn98201.github.io/apple_paly/picks_latest.json", timeout=3); return True
        except Exception: return False

    def _update_status(self):
        """상단 상태 점: 승인 · 관리자연결 · 키움접속 · 온라인 (항상 표시)."""
        if not hasattr(self, "stpills"): return
        self._st_ticks += 1
        if self._st_ticks % 5 == 1:
            self._bg(self._probe_net, "netprobe")     # ★여기서 기다리면 25초마다 창이 멈춘다(2026-09-16)
        GRN, RED, GRY = "#22c55e", "#F0455C", "#4b5563"
        def dot(k, col, label):
            self.stpills[k].setText(f"<span style='color:{col};font-size:14px'>●</span> "
                                    f"<span style='color:{col};font-size:10.5px;font-weight:700'>{label}</span>")
        dot("lic", GRN if self._licensed else RED, "승인됨" if self._licensed else "미승인")
        dot("hub", GRN if self._hub_ok else RED, "관리자연결" if self._hub_ok else "관리자끊김")
        dot("api", GRN if self.connected else GRY, "키움접속" if self.connected else "키움대기")
        dot("online", GRN if self._st_online else GRY, "온라인" if self._st_online else "오프라인")

    def _alert(self, title, msg, icon=None):
        m = QMessageBox(self); m.setWindowTitle(title); m.setText(msg); m.setIcon(icon or QMessageBox.Warning)
        m.setStyleSheet("QMessageBox{background:#15131f;} QLabel{color:#e9e7f2;font-size:13px;min-width:340px;} "
                        "QPushButton{background:#7c3aed;color:#fff;border-radius:8px;padding:6px 18px;font-weight:800;}")
        m.exec_()

    def do_login(self):
        if self._logging_in: return                          # ★재진입 차단 — 블로킹 로그인 중 틱의 재호출로 중첩 이벤트루프가 생기는 것 방지
        self._logging_in = True
        try:
            self.log("키움 로그인 시도…"); self.kw.dynamicCall("CommConnect()")
            loop = QEventLoop(); self.kw._login_loop = loop; QTimer.singleShot(120000, loop.quit); loop.exec_()
            self.connected = bool(getattr(self.kw, "connected", False))
            if not self.connected: self.log("❌ 로그인 실패"); return
            accs = self.kw.accounts(); self.cmb_acc.clear(); self.cmb_acc.addItems(accs)
            self.btn_pw.setEnabled(True)
            self.log(f"✅ 로그인 · {self.kw.user_name()} · {'모의' if self.kw.is_mock() else '실서버'} · {accs}")
            if not self._verify_live_env(accs): return      # ★서버·계좌 대조(어긋나면 안전정지)
            if self.cfg.get("account") in accs: self.cmb_acc.setCurrentText(self.cfg["account"])
            try: savej(RESTART_LOG, [])                       # ★접속 성공 → 재시작 백오프 초기화
            except Exception: pass
            self.query_account(); self.refresh()
        finally:
            self._logging_in = False

    def _halt(self, why, detail=""):
        """★안전정지 — 자동매매와 auto_start 를 **둘 다** 끈다.
        enabled 만 끄면 다음 재기동에서 auto_start 를 보고 되살아난다."""
        self.cfg["enabled"] = False; self.cfg["auto_start"] = False; savej(CONFIG, self.cfg)
        self.log(f"🛑 자동매매 안전정지 — {why}")
        for _l in (detail or "").split("\n"):
            if _l.strip(): self.log("     " + _l)
        self.tg(f"🛑 자동매매 안전정지\n{why}" + (f"\n\n{detail}" if detail else "")
                + "\n\n확인 후 [자동매매 시작]을 다시 눌러야 재개됩니다.")
        if not AUTO:                              # ★무인(auto)에서는 모달 금지 — 창 하나가 이벤트루프를 영구히 막는다
            try: self._alert("자동매매 안전정지", f"{why}\n\n{detail}")
            except Exception: pass
        try: self.refresh()
        except Exception: pass

    def _verify_live_env(self, accs):
        """★실계좌 안전점검 — 로그인 직후 '지금 어느 서버·어느 계좌인가'를 설정과 대조한다.

        주문에는 모의/실전 분기가 **없다.** 진짜 체결은 키움 로그인 서버만이 정한다.
        '실서버 접속 + 설정은 모의' 면 진짜 돈이 나가면서 기록은 모의로 쌓인다.
        반환 False = 안전정지했으니 더 진행하지 말 것."""
        srv = ""
        try: srv = self.kw.server_gubun()
        except Exception: pass
        cfg_mock = bool(self.cfg.get("is_mock", True))
        # ★서버 판정(2026-09-15) — server_gubun 이 빈 값을 주는 일이 실제로 있었다.
        #   그때는 **계좌번호로 판정한다**: 모의투자 서버는 모의계좌만, 실서버는 실계좌만 보여준다.
        #   아는 모의계좌가 목록에 있으면 모의서버다.
        srv_mock, how = None, ""
        if srv in ("1", "0"):
            srv_mock, how = (srv == "1"), "서버구분"
        else:
            _mk = str(self.cfg.get("mock_account", "") or "").strip()
            if _mk and accs:
                srv_mock, how = (_mk in accs), "계좌번호"
                self.log(f"⚠️ 서버구분 조회 실패 — 계좌번호로 판정: {'모의투자' if srv_mock else '실서버'}")
            else:
                self.log("⚠️ 서버구분 조회 실패 · 기준 모의계좌도 없어 대조 불가(진행은 계속)")
        if srv_mock is not None:
            if srv_mock and not cfg_mock or (not srv_mock) and cfg_mock:
                self._halt("키움 접속 서버와 프로그램 설정이 다릅니다",
                           f"키움 접속: {'모의투자 서버' if srv_mock else '실서버'}\n"
                           f"프로그램 설정: {'🟢 모의투자' if cfg_mock else '🔴 실거래'}\n\n"
                           f"→ 설정을 {'🟢모의투자' if srv_mock else '🔴실거래'} 로 맞추거나 키움을 다시 로그인하세요.\n"
                           f"   (설정은 라벨일 뿐이고 실제 주문은 접속 서버로 나갑니다)")
                return False
        # ★모의로 붙었으면 그 계좌를 기억해 둔다 — 다음에 서버구분이 안 읽힐 때 판정 기준이 된다
        if srv_mock and accs:
            _cur = self.cfg.get("account")
            _mk = _cur if (_cur in accs) else accs[0]
            if self.cfg.get("mock_account") != _mk:
                self.cfg["mock_account"] = _mk; savej(CONFIG, self.cfg)
                self.log(f"   기준 모의계좌 기억: {_mk}")
        if accs and self.cfg.get("account") not in accs:
            self._halt("설정된 계좌가 이 로그인 계좌목록에 없습니다",
                       f"설정 계좌: {self.cfg.get('account') or '(없음)'}\n"
                       f"접속 계좌: {', '.join(accs)}\n\n"
                       f"→ 설정 탭에서 쓸 계좌를 고르고 저장한 뒤 다시 시작하세요.\n"
                       f"   (예전엔 첫 계좌를 말없이 골랐습니다 — 실계좌가 여러 개면 위험해서 막았습니다)")
            return False
        return True

    def _already_running(self):
        """★나 말고 다른 client.py 가 떠 있으면 그 PID 를 돌려준다(없으면 "").

        `_kiwoom_conflict` 는 [자동매매 시작] 누를 때만 검사한다. 그런데 **프로그램이 뜨는 순간**
        이미 enabled=False 로 설정을 덮어쓰기 때문에, 그 전에 막아야 돌던 매매가 안 꺼진다.

        ★2026-09-16: 예전엔 PowerShell 로 프로세스 목록을 뒤졌다 — 그것만 5.3초여서 기동이 느렸다.
        이제 포트를 잡아 보는 것으로 판단한다. 못 잡았을 때만 옛 방식으로 확실하게 확인한다."""
        import socket
        try:                                     # ★빠른 길 — 포트를 잡으면 내가 유일한 인스턴스다(1ms)
            _s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            _s.bind(("127.0.0.1", LOCK_PORT)); _s.listen(1)
            self._lock_sock = _s                 # 프로세스가 사는 동안 물고 있어야 락이 유지된다
            return ""
        except OSError:
            pass                                 # 포트가 이미 잡혔다 → 아래에서 확실하게 확인
        try:                                     # 느린 길(5초대) — 포트를 못 잡았을 때만 온다
            import subprocess
            me = os.getpid()
            ps = ("Get-CimInstance Win32_Process -Filter \"Name='python.exe' or Name='pythonw.exe'\" "
                  "| Where-Object { $_.CommandLine -match 'client\\.py' } "
                  "| ForEach-Object { $_.ProcessId }")
            out = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                                 capture_output=True, text=True, timeout=15,
                                 creationflags=0x08000000).stdout or ""
            for t in out.split():
                if t.strip().isdigit() and int(t) != me:
                    return t.strip()
        except Exception:
            pass
        return ""

    def _kiwoom_conflict(self):
        """★사고예방 — 이 PC에서 키움 OCX 를 쓰는 다른 파이썬 프로세스를 찾는다.

        키움 OpenAPI 는 **PC당 1세션**이다. 클라이언트를 실수로 두 번 띄우면
        둘이 같은 계좌에 각각 주문을 내 이중매수·이중매도가 된다.
        자기 자신은 제외하고, 두 번째 client.py 부터 충돌로 본다."""
        try:
            ps = ("Get-CimInstance Win32_Process -Filter \"Name='python.exe' or Name='pythonw.exe'\" "
                  "| Select-Object -ExpandProperty CommandLine")
            out = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                                 capture_output=True, text=True, timeout=15,
                                 creationflags=0x08000000).stdout or ""      # CREATE_NO_WINDOW(무창)
        except Exception:
            return None                                                      # 조회 실패는 막지 않는다(오탐으로 매매를 멈추면 더 손해)
        mine = 0
        for line in out.splitlines():
            if "client.py" in line:
                mine += 1
                if mine >= 2: return "client.py (클라이언트가 이미 실행 중)"   # ★자기 자신 1개는 정상
                continue
            for key in ("auto_routine", "paper_auto", "jongga_auto", "live_trader",
                        "trade_hub", "bt_minute", "admin.py"):
                if key in line: return key
        return None

    def do_logout(self):
        self.cfg["enabled"] = False; savej(CONFIG, self.cfg)     # 자동매매 정지
        try: self.kw.clear_real()                                  # 실시간 해제
        except Exception: pass
        try: self.kw.dynamicCall("CommTerminate()")               # 키움 세션 종료
        except Exception: pass
        self._real_on = False; self._real_key = ""
        self.connected = False; self.acct = {}; self.btn_pw.setEnabled(False)
        self.log("🚪 로그아웃됨 · 자동매매 정지 — 재로그인하려면 [🔑 키움 로그인]")
        self.refresh()

    def do_register_pw(self):
        self.kw.show_account_window(); self.cfg["pw_registered"] = True; savej(CONFIG, self.cfg)
        self.log("🔒 비번창 호출 — 비번+AUTO체크+등록 (최초1회)")

    def save_settings(self):
        try:
            self.cfg["tp_pct"] = float(self.in_tp.text())
            self.cfg["sl_pct"] = -abs(float(self.in_sl.text()))   # ★손절 독립(버튼/직접입력값 그대로·음수저장) — 자동 1:1 규칙 해제
            self.in_sl.setText(f"{self.cfg['sl_pct']:g}")
            self.cfg["invest_per_stock"] = int(float(self.in_inv.text()) * 10000); self.cfg["telegram_chat_id"] = self.in_tg.text().strip()
            self.cfg["principal"] = int(float(self.in_prin.text()))   # ★투자원금(만원) 저장
            self.cfg["fee_pct"] = float(self.in_fee.text())
            self.cfg["cash_buffer"] = max(0, int(float(self.in_buf.text()) * 10000))   # ★현금버퍼(만원 입력 → 원 저장)
            _gp = float(self.in_gap.text() or 0)                                       # ★갭컷(0=끔, 음수만 유효)
            self.cfg["gapcut_pct"] = -abs(_gp) if _gp else 0.0
            self.in_gap.setText(f"{self.cfg['gapcut_pct']:g}")
            # ★실거래 전환은 반드시 확인창을 거친다 — 예전엔 이 라디오가 확인창을 그냥 우회했다
            _want = self.rb_mock.isChecked()
            if _want != bool(self.cfg.get("is_mock", True)):
                self.set_mode(_want)                                   # 취소하면 cfg 가 안 바뀐다
                (self.rb_mock if self.cfg.get("is_mock", True) else self.rb_real).setChecked(True)
            self.cfg["nickname"] = self.in_nick.text().strip(); self.cfg["hub_url"] = self.in_hub.text().strip()   # ★닉네임·서버주소
            if self.cmb_acc.currentText(): self.cfg["account"] = self.cmb_acc.currentText()
            savej(CONFIG, self.cfg); st.set_thresholds(self.cfg["tp_pct"], self.cfg["sl_pct"]); st.set_fee(self.cfg.get("fee_pct", 0.15)); self.check_license()
            for vv, bt in getattr(self, "set_tpbtns", {}).items(): bt.setProperty("on", "1" if abs(vv - self.cfg["tp_pct"]) < 1e-9 else "0"); bt.setStyle(bt.style())
            for vv, bt in getattr(self, "set_slbtns", {}).items(): bt.setProperty("on", "1" if abs(vv - abs(self.cfg["sl_pct"])) < 1e-9 else "0"); bt.setStyle(bt.style())
            self.log(f"💾 저장 · 익절 +{self.cfg['tp_pct']:g}%/손절 {self.cfg['sl_pct']:g}% · 원금 {self.cfg.get('principal',1000)}만 "
                     f"· 종목당상한 {self.cfg['invest_per_stock']//10000}만 · 현금버퍼 {self.cfg.get('cash_buffer',0)//10000}만 "
                     f"· {'모의' if self.cfg['is_mock'] else '실거래'}")
            # ★설정이 실제로 얼마로 적용됐는지 바로 보여준다 — 원금연동이라 입력값과 다를 수 있다
            _eq = self._strategy_equity(); _iv, _af = self._size(_eq)
            self.log(f"   └ 전략자산 {_eq//10000:,}만 → 종목당 {_iv//10000}만 × 최대 {_af}종목"
                     + (f" · 갭컷 {self.cfg['gapcut_pct']:g}%" if self.cfg.get("gapcut_pct") else " · 갭컷 끔"))
            self.tg("설정 저장 완료"); self.refresh()
        except Exception as e: self.log(f"저장 오류 {e}")

    def toggle_auto(self):
        if not self.cfg.get("enabled"):                 # ★시작하려는 경우 — 관리자 사용승인 필수
            conf = self._kiwoom_conflict()               # ★사고예방: 다른 키움 매매 프로세스 충돌 검사
            if conf:
                if not AUTO:                      # ★무인에서는 모달 금지(이벤트루프 정지) — 로그·텔레그램으로만 알린다
                    self._alert("키움 프로세스 충돌",
                                f"이 PC에서 키움을 쓰는 다른 프로그램이 실행 중입니다.\n\n{conf}\n\n"
                                "키움 OpenAPI 는 PC당 1세션이라 동시에 돌면\n이중매매·접속불가가 납니다. 먼저 종료하세요.")
                self.log(f"⛔ 시작 취소 — 다른 키움 프로세스({conf}) 실행 중")
                self.tg(f"⛔ 자동매매 시작 취소 — {conf} 실행 중(충돌 방지)"); self.refresh(); return
            self.check_license()
            if not self._licensed:
                nick = (self.cfg.get("nickname") or "").strip()
                if not AUTO:                      # ★무인에서는 모달 금지 — 창 하나가 이벤트루프를 영구히 막는다
                    if not nick:
                        self._alert("사용 권한 없음", "닉네임이 설정되지 않았습니다.\n\n[⚙️ 설정] 탭에서 닉네임을 저장한 뒤\n[📨 승인 요청]을 눌러 관리자 승인을 받아주세요.")
                    elif self._lic_status == "서버 연결안됨":
                        self._alert("관리자 서버 연결 안됨", f"관리자 서버에 연결할 수 없습니다.\n\n[⚙️ 설정] 탭의 '관리자 서버주소'를 확인하세요.\n(관리자 프로그램이 켜져 있어야 합니다)")
                    else:
                        self._alert("관리자 미승인 · 사용 권한 없음", f"닉네임 '{nick}' 은(는) 아직 승인되지 않았습니다. (상태: {self._lic_status})\n\n[⚙️ 설정] 탭에서 [📨 승인 요청]을 누르고\n관리자가 승인하면 자동매매를 시작할 수 있습니다.")
                self.log(f"⛔ 사용승인 필요({self._lic_status}) — 승인 요청 후 시작"); self.refresh(); return
            if not self.cfg.get("account"):       # ★계좌 미설정으로 시작하면 주문 코드가 KeyError 로 죽는다(관리자 동일 가드)
                self.log("⛔ 계좌 미설정 — 설정 탭에서 로그인/계좌 저장 후 시작")
                self.tg("⛔ 자동매매 시작 취소 — 계좌가 설정되지 않았습니다"); self.refresh(); return
        self.cfg["enabled"] = not self.cfg.get("enabled"); self.cfg["auto_start"] = self.cfg["enabled"]; savej(CONFIG, self.cfg)   # ★auto_start=지속(워치독/부팅 후 자동재개용)
        if self.cfg["enabled"]:
            self.log(f"▶ 자동매매 시작(승인됨·만료 {self._lic_expiry}) — 로그인→조회→자동루틴")
            st.set_thresholds(self.cfg.get("tp_pct", 3.0), self.cfg.get("sl_pct", -3.0))
            if not self.connected: self.do_login()      # ★로그인부터
            if self.connected:
                self.query_account()                     # ★조회까지
                _eq = self._strategy_equity()
                _iv, _af = self._size(_eq)
                _gp = float(self.cfg.get("gapcut_pct", 0) or 0)
                self.tg("✅ 자동매매 시작 — 무인 운용(정지 전까지 매일 자동)\n"
                        f"계좌 {'🟢모의' if self.cfg.get('is_mock') else '🔴실거래'} · "
                        f"익절 +{self.cfg.get('tp_pct',6):g}% / 손절 {self.cfg.get('sl_pct',-3.5):g}%"
                        + (f" · 갭컷 {_gp:g}%" if _gp else " · 갭컷 끔") + "\n"
                        f"전략자산 {_eq//10000:,}만 → 종목당 {_iv//10000}만 × 최대 {_af}종목\n"
                        f"유통 ≤{self.cfg.get('float_max',70)}% · 상한가 제외 "
                        f"{'O' if self.cfg.get('exclude_upper',True) else 'X'}")
            elif AUTO and self.cfg.get("auto_start") and self._operating():
                self._restart_process("시작 로그인 실패 — 즉시 재시작")            # ★운영시간(08:25~17:00): 재시도 말고 바로 재시작
            elif self.cfg.get("auto_start"):
                self.log("⚠️ 로그인 실패 — 운영시간 밖, 재시작 보류")              # 야간/주말은 재시작 안 함(폭주 방지)
            else:
                self.log("⚠️ 로그인 실패 — 설정 탭에서 계좌 확인 후 다시 시작")
                self.cfg["enabled"] = False; savej(CONFIG, self.cfg)
        else:
            self.log("⏹ 자동매매 정지"); self.tg("⏹ 자동매매 정지")
        self.refresh()

    def _restart_process(self, why=""):
        """★접속 끊김/로그인 실패 시 재시도 말고 '즉시 프로세스 재시작'(키움 안내 '종료후 재접속'과 동일).
        새 인스턴스 먼저 기동 → 현재 즉시 종료(OCX 완전 초기화 → 새 인스턴스가 깨끗이 재접속).
        지속장애(서버다운) 시엔 새 인스턴스가 restart_history 보고 로그인을 지연(백오프)해 폭주·레이트차단 방지."""
        try:
            hist = [t for t in loadj(RESTART_LOG, []) if time.time() - t < 600]   # 최근 10분 재시작 이력
            spam = len(hist) >= 1                             # 첫 재시작만 텔레그램, 이후 지속장애는 로그만(스팸 방지)
            hist.append(time.time()); savej(RESTART_LOG, hist)
        except Exception:
            spam = False
        try:
            self.log(f"🔁 즉시 재시작 — {why}")
            if not spam: self.tg(f"🔁 클라이언트 재시작(OCX 초기화) — {why}")
        except Exception: pass
        try:                                                 # 새 인스턴스 먼저 기동(★auto 인자로 무인모드 유지) · 디태치(부모 종료해도 생존)
            vbs = os.path.join(DIR, "run_client.vbs")         # ★cmd창 없이 재기동
            bat = os.path.join(DIR, "run_client.bat")
            if os.path.exists(vbs):
                subprocess.Popen(["wscript.exe", vbs, "auto"], cwd=DIR,
                                 creationflags=0x00000008 | 0x00000200, close_fds=True)
            elif os.path.exists(bat):
                subprocess.Popen(["cmd", "/c", bat, "auto"], cwd=DIR,
                                 creationflags=0x00000008 | 0x00000200, close_fds=True)   # DETACHED_PROCESS|CREATE_NEW_PROCESS_GROUP
        except Exception: pass
        os._exit(0)                                          # 현재 프로세스 즉시 종료(OS가 OCX 자동 해제 — CommTerminate는 행 위험이라 생략)

    def _kiwoom_dialog_watcher(self):
        """★무인 필수 — 키움 OCX 모달 팝업('통신 연결이 끊겼습니다 … 프로그램 종료후 재접속' 등)은 메인 스레드를
        모달로 막아 자동재접속을 방해한다. 별도 스레드에서 팝업을 감지해 [확인] 자동 클릭(언블록) → 이후 tick의
        GetConnectState→_restart_process가 재접속. (모달이 메인 Qt 스레드를 막아도 이 스레드는 별개라 동작)."""
        import ctypes
        from ctypes import wintypes
        try: u = ctypes.windll.user32
        except Exception: return
        WM_CLOSE, WM_COMMAND = 0x0010, 0x0111
        # 눌러도 되는 창 — 접속 끊김 알림 + OpenAPI 사용 동의/안내
        KEYS = ("통신 연결", "연결이 끊", "재접속", "종료후",
                "사용 동의", "이용 동의", "동의", "사용자 정보", "OpenAPI", "OPEN API", "허용")
        # ★절대 누르면 안 되는 창 — 돈이 나가는 확인창. 하나라도 걸리면 건너뛴다.
        DANGER = ("매수", "매도", "주문", "체결", "정정", "취소", "청산", "잔고이체", "출금")
        MYPID = os.getpid()
        ENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        def wtext(h):
            try:
                n = u.GetWindowTextLengthW(h); b = ctypes.create_unicode_buffer(n + 2)
                u.GetWindowTextW(h, b, n + 2); return b.value or ""
            except Exception: return ""
        while True:
            try:
                tops = []
                def _top(h, l):
                    if not u.IsWindowVisible(h): return True
                    t = wtext(h)
                    if "khopenapi" in t.lower():
                        tops.append(h); return True
                    # ★제목이 없어도 **우리 프로세스가 띄운 대화상자**면 본다
                    #   (키움 OCX 모달은 우리 프로세스 안에서 뜬다)
                    try:
                        cn = ctypes.create_unicode_buffer(64); u.GetClassNameW(h, cn, 64)
                        if cn.value == "#32770":
                            pid = wintypes.DWORD()
                            u.GetWindowThreadProcessId(h, ctypes.byref(pid))
                            if pid.value == MYPID: tops.append(h)
                    except Exception: pass
                    return True
                u.EnumWindows(ENUMPROC(_top), 0)
                for h in tops:
                    body = []; btns = []
                    def _child(c, l):
                        t = wtext(c); body.append(t)
                        try:
                            cn = ctypes.create_unicode_buffer(32); u.GetClassNameW(c, cn, 32)
                            if cn.value == "Button" and t: btns.append(t)
                        except Exception: pass
                        return True
                    u.EnumChildWindows(h, ENUMPROC(_child), 0)
                    txt = " ".join(body) + " " + wtext(h)
                    if any(d in txt for d in DANGER):        # ★주문 관련이면 손대지 않는다
                        continue
                    if not any(k in txt for k in KEYS):
                        continue
                    btn = None
                    for cap in ("확인", "예", "동의", "계속"):   # 긍정 버튼을 순서대로 찾는다
                        btn = u.FindWindowExW(h, 0, "Button", cap)
                        if btn: break
                    if btn:                                  # ★WM_COMMAND(BN_CLICKED, 확인버튼 ctrlID) — 실검증된 모달 확인 클릭
                        cid = u.GetDlgCtrlID(btn) & 0xFFFF
                        u.PostMessageW(h, WM_COMMAND, cid, btn)
                    else:
                        u.PostMessageW(h, WM_CLOSE, 0, 0)
                    self._popup_n += 1                       # 메인 tick이 보고
                    try:                                     # 무엇을 눌렀는지 남긴다(추적용)
                        _t = (wtext(h) or "(제목없음)")[:40]
                        _b = ", ".join(btns[:4])
                        self.log(f"🧹 팝업 자동확인 — {_t} [{_b}]")
                    except Exception: pass
            except Exception:
                pass
            time.sleep(1.5)

    def _pid_alive(self, pid):
        """PID 생존 확인(Windows)."""
        try:
            import ctypes
            h = ctypes.windll.kernel32.OpenProcess(0x1000, False, int(pid))   # PROCESS_QUERY_LIMITED_INFORMATION
            if h:
                ctypes.windll.kernel32.CloseHandle(h); return True
        except Exception:
            pass
        return False

    def _autostart(self):
        st.set_thresholds(self.cfg.get("tp_pct", 3.0), self.cfg.get("sl_pct", -3.0))
        if self.cfg.get("account") and not self.connected: self.do_login()

    def query_account(self):
        try:
            acc = self.cfg["account"]; hold = self.kw.holdings(acc) or {}
            dep = self.kw.deposit(acc) or {}
            assets = hold.get("assets") or dep.get("cash") or 0
            self.acct = {"assets": assets, "total_ret": hold.get("total_ret", 0.0),
                         "cash": dep.get("cash", 0), "stocks": hold.get("stocks", [])}
            self._adopt_holdings()   # ★실계좌 조회 기준 동기화 — 보유중=실계좌(채택/정리)
        except Exception as e:
            self.log(f"계좌조회 오류 {e}")

    def _adopt_holdings(self):
        """★실계좌 조회 기준 보유 동기화 — 실보유는 채택(손익절 관리 편입), 실계좌에 없는 '허위 보유'는 정리.
        보유중 표시·관리 모두 실계좌와 일치(어제 버그 같은 불일치 방지). 매수/체결 진행중(15:20~15:35)엔 미체결 지정가 오정리 방지로 '정리' 보류."""
        if not getattr(self, "connected", False): return
        real = {s.get("code"): s for s in (self.acct or {}).get("stocks", []) if s.get("qty", 0) > 0}
        pos = self.state.setdefault("positions", [])
        changed = False
        settling = ("15:20" <= self._hm() < "15:35")   # 매수·시장가전환·체결보정 진행중 → 정리 보류(오정리 방지)
        # 1) 정리: state는 '보유중'인데 실계좌엔 없음 → 보유 0 처리(실계좌에 없는 종목 표시/관리/기록 금지)
        if not settling:
            for o in pos:
                if (o.get("filled", 0) - o.get("sold", 0) > 0) and o.get("code") not in real:
                    o["sold"] = o.get("filled", 0); changed = True
        # 2) 채택: 실계좌 보유인데 state에 '보유중' 없음 → 편입(실수량·매입가 반영·손익절 관리)
        # ★중복채택 방지(2026-09-14 · 관리자 2026-09-11 수정분 이식)
        #   예전엔 '잔량>0'인 포지션만 have 에 넣었다. 그래서 매도 직후(sold=filled, 잔량 0)
        #   계좌 반영이 늦으면 같은 종목을 '모르는 보유'로 오인해 다시 편입 → 또 매도 → 원장 중복기록.
        #   관리자에서 실제로 실현손익이 4배로 부풀었던 버그다.
        #   → 잔량과 무관하게 **오늘 한 번이라도 다룬 종목은 다시 채택하지 않는다.**
        have = {o["code"] for o in pos}
        _today = self._t()
        have |= {t.get("code") for t in (self.state.get("trades") or []) if t.get("date") == _today}
        for code, s in real.items():
            if code in have: continue
            buy = s.get("buy") or s.get("cur") or 0
            pos.append({"code": code, "name": s.get("name", code), "qty": s["qty"], "price": buy, "avg": buy,
                        "filled": s["qty"], "sold": 0, "unbuyable": False, "adopted": True,
                        "cur_ret": s.get("ret", 0.0), "cur_px": s.get("cur")})
            changed = True
        if changed:
            if not self.state.get("buy_date"): self.state["buy_date"] = self._t()
            savej(STATE, self.state); self._ensure_real(force=True)
            self.log("📥 실계좌 동기화 — 보유중=실계좌(채택/정리)")

    def fetch_picks(self):
        try:
            url = PICKS_URL + ("&" if "?" in PICKS_URL else "?") + "nc=" + datetime.datetime.now().strftime("%H%M%S")  # ★캐시무효화(최신 픽)
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0", "Cache-Control": "no-cache"})
            return json.loads(urllib.request.urlopen(req, timeout=10).read().decode())
        except Exception as e: self.log(f"픽 로드 실패 {e}"); return None

    def _strategy_equity(self):
        """★전략 자산(복리) = 원금 + 누적 실현손익(수수료 반영) — 관리자와 동일. af=자산÷종목당."""
        base = int(self.cfg.get("principal", 1000)) * 10000
        fee = float(self.cfg.get("fee_pct", 0.15)) / 100.0
        pnl = 0
        want = "모의" if self.cfg.get("is_mock", True) else "실전"   # ★지금 모드의 거래만 센다(2026-09-15)
        for t in self.state.get("trades", []):
            if t.get("mode", "모의") != want: continue                # 모의 성적을 실전 자산으로 이월하지 않는다
            pnl += (t.get("pl") or 0) - round((t.get("buy") or 0) * (t.get("qty") or 0) * fee)   # 왕복 수수료 차감
        return max(int(self.cfg.get("invest_per_stock", 2500000)), base + pnl)   # 최소 1종목치

    def buy_picks(self):
        """★관리자 buy_close와 100% 동일 — 15:25 지정가(@entry) 발주 → 15:28 미체결 시장가전환 → 15:31 실잔고 보정.
        유통≤70% 게이트 + 상한가 제외 후, 복리자산÷종목당=af, 매력도 상위 af만 매수, af 밖=⛔체결안됨(원금부족)."""
        if self.bought_today: return
        pj = self.fetch_picks()
        if not pj or not pj.get("stocks") or pj.get("date") != self._t():
            self.log("오늘 픽 아직 없음/불일치 — 다음 폴링에 재시도(마감 전까지)"); return
        self.bought_today = True; self.converted_today = False       # ★매수 개시(중복발주 방지·관리자 동일)
        picks = [s for s in pj["stocks"] if st.buy_filter(s, "전체")]
        picks.sort(key=lambda s: -(s.get("score") or -1))            # ★매력도 상위(상한가 포함)
        picks = self._float_filter(picks)                            # ★유통비율 ≤70% 게이트(관리자 동일)
        if self.cfg.get("exclude_upper", True):                      # ★상한가 제외(관리자 동일) — 비상한가로 슬롯 채움
            _nup = sum(1 for s in picks if s.get("unbuyable"))
            picks = [s for s in picks if not s.get("unbuyable")]
            if _nup: self.log(f"  🚫 상한가 {_nup}종목 제외(비상한가로 슬롯 채움)")
        acc = self.cfg["account"]
        equity = self._strategy_equity()                             # ★복리 자산(원금+누적)
        # ★실제 주문가능금액을 상한으로(관리자 동일) — 전략자산이 실제 예수금보다 크면
        #   종목당 금액만 커지고 정작 발주는 '예수금 스킵'으로 조용히 빠진다.
        _dep = self.kw.deposit(acc) or {}
        _ord = _dep.get("orderable")
        _cap = int(_ord) if isinstance(_ord, (int, float)) and _ord > 0 else None
        if _cap is None:
            self.log("  ⚠️ 주문가능금액 조회 실패 — 전략자산 기준으로 진행")
        elif _cap < equity:
            self.log(f"  🏦 주문가능 {_cap//10000:,}만 < 전략자산 {equity//10000:,}만 → 주문가능 기준")
            self.tg(f"🏦 예수금 상한 — 전략자산 {equity//10000:,}만 → 주문가능 {_cap//10000:,}만 기준")
            equity = _cap
        invest, af = self._size(equity)                              # ★원금연동 사이징(관리자 동일)
        _buf = int(self.cfg.get("cash_buffer", 0) or 0)
        sel = picks[:af]; skip = picks[af:]                          # ★상위 af만 매수·나머지 체결안됨
        budget = _cap if _cap else equity
        self.log(f"📥 종가매수(지정가) 기준자산 {equity//10000}만 − 버퍼 {_buf//10000}만 → 종목당 {invest//10000}만 × 상위 {af}종목 · 후보 {len(picks)}·체결안됨 {len(skip)}")
        pos = []; pend = []
        for s in sel:
            if s.get("unbuyable"):                                    # ★(exclude_upper=False일 때만) 상한가 → 내일 09:00 시가매수 예약
                pend.append({"code": s["code"], "name": s["name"], "won": invest, "score": s.get("score")})
                self.log(f"  🔴 상한가 {s['name']} → 내일 시가매수 예약"); continue
            code = s["code"]; px = int(s.get("entry") or 0)          # ★지정가 = entry(스캔 종가)
            if px <= 0: continue
            qty = invest // px
            if qty < 1 or qty * px > budget: self.log(f"  💸 {s['name']} 스킵(예수금)"); continue
            self.kw.send_order(acc, code, qty, px, 1, "00"); budget -= qty * px   # ★00=보통(지정가) @entry → 15:28 미체결 시장가전환
            pos.append({"code": code, "name": s["name"], "qty": qty, "price": px, "avg": px, "filled": qty, "sold": 0, "unbuyable": False, "buy_time": self._hm()})
            self.log(f"  📥 종가매수 지정가 {s['name']} {qty}주 @{px:,}(15:28 미체결시 시장가전환)"); self.wait(400)
        self.state = {"date": self._t(), "buy_date": self._t(), "positions": pos, "open_pending": pend, "trades": self.state.get("trades", [])}
        savej(STATE, self.state)
        self._ensure_real(force=True)   # ★매수 즉시 실시간 시세 등록
        self.tg(f"종가매수 지정가 {len(pos)}종목(15:28 미체결 시장가전환)" + (f" · 🔴상한가 예약 {len(pend)}" if pend else "") + (f" · ⛔체결안됨 {len(skip)}" if skip else "") + ((": " + ", ".join(o['name'] for o in pos)) if pos else "")); self.refresh()

    def _report(self, hm):
        """★관리자처럼 때맞춰 알린다(2026-09-14 신설).
        08:30 장전 대기 · 09:00 장 시작 · 매시 정각 상태보고 · 15:35 마감 요약.
        각각 하루 1회만 보낸다(스팸 방지)."""
        today = self._t()
        held = [o for o in self.state.get("positions", []) if o.get("filled", 0) - o.get("sold", 0) > 0]
        # 08:30 장전
        if LOGIN_HM <= hm < MANAGE_OPEN and getattr(self, "_premkt_date", "") != today:
            self._premkt_date = today
            self.tg(f"🟢 [{hm}] 장 시작 전 접속 정상 · 보유 {len(held)}종목 손익절 준비완료")
        # 09:00 장 시작
        if MANAGE_OPEN <= hm and getattr(self, "_open_date", "") != today:
            self._open_date = today
            self.tg(f"☀️ 장 시작 · 보유 {len(held)}종목 실시간 관리 시작(무인)")
        # 매시 정각 상태보고(09~15시)
        if hm.endswith(":00") and "09:00" <= hm <= "15:00" and getattr(self, "_rep_hm", "") != hm:
            self._rep_hm = hm
            if held:
                rs = [o.get("cur_ret", 0.0) for o in held]
                body = " · ".join(f"{o['name']} {o.get('cur_ret',0):+.2f}%" for o in held[:4])
                self.tg(f"🟢 [{hm}] 클라이언트 무인 상태보고\n보유 {len(held)}종목 평균 {sum(rs)/len(rs):+.2f}%\n{body}")
            else:
                self.tg(f"🟢 [{hm}] 클라이언트 무인 상태보고 · 보유 없음 (15:25 종가매수 대기)")
        # 15:35 마감 요약
        if hm >= DONE_HM and getattr(self, "_eod_date", "") != today:
            self._eod_date = today
            tr = [t for t in (self.state.get("trades") or []) if t.get("date") == today]
            if tr:
                pl = sum(t.get("pl") or 0 for t in tr)
                rets = [t.get("ret") or 0 for t in tr]
                wins = sum(1 for r in rets if r > 0)
                body = "\n".join(f"· {t['name']} {t.get('ret',0):+.2f}%" for t in tr[:6])
                self.tg(f"📄 [{hm}] 오늘 마감 · {len(tr)}건 청산 · 승{wins}/패{len(tr)-wins}\n"
                        f"실현손익 {pl:+,}원 · 평균 {sum(rets)/len(rets):+.2f}%\n{body}")
            else:
                self.tg(f"📄 [{hm}] 오늘 마감 · 청산 거래 없음 · 보유 {len(held)}종목")

    def _size(self, equity):
        """★종목당 금액·매수종목수 — 관리자 admin._size() 와 **같은 식**(2026-09-14 이식).

            가용   = 전략자산 − cash_buffer
            하한   = min(invest_per_stock, 가용 ÷ min_positions)   ← 자산에 연동
            종목당 = max(하한, 가용 ÷ size_div)
            종목수 = 가용 ÷ 종목당

        예전엔 invest_per_stock 이 고정 하한이라, 자산이 작으면 1종목에 갇혔다.
        (백테 134일: 원금 300만·하한 200만이면 거래일의 95%가 1종목, +60.6%/MDD -24%.
         하한을 가용의 절반으로 눌러 2종목을 보장하면 +143.5%/MDD -15.6%.)
        자산이 (invest_per_stock × min_positions + 버퍼) 이상이면 예전 식과 완전히 같다.
        ★부동소수점: usable // a 는 a=usable/3 일 때 2.999…→2 가 된다. +1e-9 로 보정."""
        cap = max(1, int(self.cfg.get("invest_per_stock", 2000000)))     # 이제 '상한'
        buf = max(0, int(self.cfg.get("cash_buffer", 0) or 0))
        div = max(1, int(self.cfg.get("size_div", 3) or 3))
        mp = max(1, int(self.cfg.get("min_positions", 2) or 2))
        usable = max(0, int(equity) - buf)
        if usable < MIN_POS_WON:
            return max(1, min(cap, max(1, int(equity)))), 1
        a = max(min(cap, usable / mp), usable / div)
        if a < MIN_POS_WON:
            a = min(MIN_POS_WON, usable)
        return int(a), max(1, int(usable / a + 1e-9))

    def _gapcut(self):
        """★시가 갭컷 — 관리자 admin._gapcut() 과 같은 규칙(2026-09-14 이식).
        09:00 시가가 매수가보다 gapcut_pct% 넘게 낮으면 손절선과 무관하게 즉시 시장가 매도.
        · 판정은 09:00~09:10 첫 시세로 **포지션당 하루 1회**. 09:10을 넘기면 하지 않는다
          (그 시각 가격은 시가가 아니라 장중가라 규칙이 달라진다).
        · gapcut_pct = 0 이면 기능 끔."""
        thr = float(self.cfg.get("gapcut_pct", 0) or 0)
        if thr >= 0: return
        hm = self._hm()
        if not (MANAGE_OPEN <= hm <= "09:10"): return
        today = self._t(); hit = 0
        for o in self.state.get("positions", []):
            if o.get("filled", 0) - o.get("sold", 0) <= 0 or o.get("sell_stuck"): continue
            if o.get("gapcut_date") == today: continue
            base = o.get("avg") or o.get("price") or 0
            px = o.get("cur_px") or (getattr(self.kw, "real_prices", {}) or {}).get(o["code"])
            if not base or not px: continue
            o["gapcut_date"] = today; o["open_px"] = px
            r = (px / base - 1) * 100
            if r < thr:
                self._force_sell(o, f"갭컷(시가 {r:+.2f}%)")
                self.log(f"  ⚡ 갭컷 {o['name']} 시가 {px:,}({r:+.2f}%) < 기준 {thr:g}% → 즉시 시장가")
                self.tg(f"⚡ 갭컷 {o['name']} 시가 {r:+.2f}% 즉시매도"); hit += 1
            else:
                self.log(f"  ⏱ 시가 확인 {o['name']} {r:+.2f}% (기준 {thr:g}%) → 보유 유지")
        if hit: savej(STATE, self.state); self._ensure_real(force=True)

    def _float_filter(self, picks):
        """★유통비율 ≤ float_max(기본70%) 매수 게이트(관리자 동일·매수시점 opt10001 조회). 조회실패/없음=통과(보수). float_max=0이면 끔."""
        fmax = self.cfg.get("float_max", 70)
        if not fmax: return picks
        kept = []
        for s in picks:
            fr = None
            try:
                info = self.kw.basic(s["code"]) or {}
                v = info.get("유통비율")
                if v in (None, "", 0, "0"):
                    us = _int(info.get("유통주식")); ss = _int(info.get("상장주식"))
                    v = round(us / ss * 100, 2) if ss else None
                fr = float(str(v).replace("%", "").replace(",", "").strip()) if v not in (None, "") else None
            except Exception:
                fr = None
            if fr is not None and fr > fmax:
                self.log(f"  🚫 유통 {fr:.0f}% > {fmax}% 제외: {s['name']}"); continue
            kept.append(s)
        if len(kept) < len(picks): self.log(f"  🔎 유통≤{fmax}% 필터: {len(picks)}→{len(kept)}종목")
        return kept

    def _convert_unfilled_market(self):
        """★15:28 미체결 지정가매수 → 시장가 전환(관리자 동일·이중체결 방지: 15:30 컷오프 → 취소 rc=0 확인 → 취소 재확인된 뒤에만 시장가)."""
        if self._hm() >= "15:30":
            self.converted_today = True; self.log("⚠️ 15:30 경과 — 시장가 전환 중단(이중체결 방지)"); return
        acc = self.cfg["account"]
        pend = self.kw.pending(acc)                  # None=조회실패(빈목록과 구분)
        if pend is None:
            self.log("⚠️ 미체결 조회 실패 — 다음 틱 재시도(전환 보류)"); return
        self.converted_today = True
        pmap = {p.get("code"): p for p in pend if "매수" in (p.get("gubun", "") or "") and _int(p.get("unfilled", 0)) > 0}
        nconv = 0
        for o in self.state.get("positions", []):
            if self._hm() >= "15:30": break
            if o.get("mkt") or (o.get("filled", 0) - o.get("sold", 0) <= 0): continue
            p = pmap.get(o["code"])
            if not p: continue                       # 미체결 아님(이미 체결/주문없음) → 손대지 않음
            uq = _int(p.get("unfilled", 0)) or o["qty"]
            rc = self.kw.cancel_buy(acc, o["code"], uq, p.get("order_no", ""))   # 1) 취소 발주 + 반환값 확인
            if rc != 0:
                self.log(f"  ⚠️ {o['name']} 취소발주 실패(rc={rc}) — 시장가 보류(중복방지)"); continue
            self.wait(700)
            if self._hm() >= "15:30":
                self.log(f"  ⚠️ {o['name']} 15:30 경과 — 시장가 보류(중복방지)"); continue
            pend2 = self.kw.pending(acc)             # 2) 취소 확인(조회실패=None이면 보류)
            if pend2 is None:
                self.log(f"  ⚠️ {o['name']} 취소확인 조회실패 — 시장가 보류(중복방지)"); continue
            still = next((q for q in pend2 if q.get("code") == o["code"] and "매수" in (q.get("gubun", "") or "") and _int(q.get("unfilled", 0)) > 0), None)
            if still:                                # 3) 아직 미체결 = 취소 안 됨 → 시장가 보류
                self.log(f"  ⚠️ {o['name']} 취소 미확인 — 시장가 보류(중복방지)"); continue
            self.kw.send_order(acc, o["code"], uq, 0, 1, "03"); o["mkt"] = True; nconv += 1   # 취소확인 후에만 시장가
            self.log(f"  🔄 15:28 미체결→시장가전환 {o['name']} {uq}주(취소확인 후 발주)"); self.wait(500)
        savej(STATE, self.state)
        if nconv: self.tg(f"🔄 15:28 미체결 {nconv}종목 시장가 전환(중복방지·종가 확실체결)")
        self.log(f"15:28 시장가 전환 {nconv}종목")

    def _reconcile_positions(self):
        """★15:31 체결 후 실제 계좌잔고로 positions 보정(관리자 동일) — 안 산 건 제거, 산 건 실수량·매입가 반영(손익절 정확)."""
        self.query_account()
        holds = {s["code"]: s for s in (self.acct or {}).get("stocks", []) if s.get("qty", 0) > 0}
        for o in self.state.get("positions", []):
            h = holds.get(o["code"])
            if h:
                o["filled"] = h["qty"]; o["avg"] = h.get("buy") or o.get("avg")
            elif not o.get("sold"):
                o["filled"] = 0                          # 미체결/취소 → 보유 아님
        self.state["positions"] = [o for o in self.state["positions"] if o.get("filled", 0) - o.get("sold", 0) > 0]
        savej(STATE, self.state); self._ensure_real(force=True)
        held = len([o for o in self.state["positions"] if o.get("filled", 0) - o.get("sold", 0) > 0])
        self.log(f"✅ 15:31 체결 보정 — 실보유 {held}종목")

    def _buy_open_pending(self):
        """★상한가 예약분 → 개장(09:00) 시가 시장가매수 → 실체결가로 즉시 ±3%. 자본제약(원금-보유묶임)·관리자와 동일."""
        pend = self.state.get("open_pending") or []
        if not pend: return
        acc = self.cfg["account"]
        equity = self._strategy_equity()
        held = sum(max(0, (p.get("filled", 0) - p.get("sold", 0))) * (p.get("avg") or 0) for p in self.state.get("positions", []))
        budget = equity - held
        try:
            od = (self.kw.deposit(acc) or {}).get("orderable")
            if od: budget = min(budget, int(od))
        except Exception: pass
        pend = sorted(pend, key=lambda o: -(o.get("score") if o.get("score") is not None else -1))
        done = []; skipped = []
        for o in pend:
            code = o["code"]; px = self.cur(code) or 0
            if px <= 0: continue
            won = o.get("won") or self.cfg["invest_per_stock"]
            qty = won // px
            if qty < 1 or (qty * px > budget and not o.get("force")):   # ★force=강제매수 · 나머지 원금부족 체결안됨
                self.log(f"  ⛔ 상한가 {o['name']} 체결안됨(원금부족·여유 {budget:,.0f}원)")
                skipped.append(o["name"]); done.append(code); continue
            self.kw.send_order(acc, code, qty, 0, 1, "03"); budget -= qty * px
            avg = 0; rqty = 0                                        # ★체결통보로 실체결단가(최대 3초)
            for _ in range(6):
                self.wait(500)
                real = (getattr(self.kw, "positions", {}) or {}).get(code, {})
                if real.get("avg"): avg = real["avg"]; rqty = real.get("qty") or qty; break
            if not avg: avg = px; rqty = qty
            self.state.setdefault("positions", []).append({"code": code, "name": o["name"], "qty": rqty, "price": avg, "avg": avg, "filled": rqty, "sold": 0, "unbuyable": True})
            self.state.setdefault("upper_today", [])
            if code not in self.state["upper_today"]: self.state["upper_today"].append(code)
            self.log(f"  🔵 상한가 시가매수 {o['name']} {rqty}주 @{avg:,} (±{st.UPPER_TP:g}%)"); self.tg(f"🔵 상한가 시가매수 {o['name']} @{avg:,}(±{st.UPPER_TP:g}%)")
            done.append(code)
        self.state["open_pending"] = [o for o in pend if o["code"] not in done]
        if done: savej(STATE, self.state); self._ensure_real(force=True)
        if skipped: self.tg(f"⛔ 상한가 {len(skipped)}종목 원금부족 체결안됨: {', '.join(skipped)}")

    # ═══ 실시간(SetRealReg) — HTS처럼 매 틱 현재가·수익률 반영 + 즉시 ±손익절 ═══
    def _ensure_real(self, force=False):
        """보유종목을 실시간 시세(SetRealReg FID10 현재가)로 등록. 보유가 바뀌면 재등록."""
        if not self.connected: return
        codes = [o["code"] for o in self.state.get("positions", []) if o.get("filled", 0) - o.get("sold", 0) > 0]
        key = ";".join(sorted(codes))
        if not codes:
            if self._real_on:
                try: self.kw.clear_real()
                except Exception: pass
                self._real_on = False; self._real_key = ""
            return
        if force or not self._real_on or self._real_key != key:
            try:
                self.kw.set_real(codes, self._on_realtick); self._real_on = True; self._real_key = key
                self.log(f"📡 실시간 시세 {len(codes)}종목 등록 (매 틱 손익절)")
            except Exception as e:
                self.log(f"실시간등록오류 {e}")

    def _on_realtick(self, code, px):
        """SetRealReg 실시간 틱: 즉시 현재가·수익률 반영 + 장중 ±손익절 즉시 판정."""
        if not self.connected or px <= 0: return
        o = next((o for o in self.state.get("positions", []) if o.get("code") == code and o.get("filled", 0) - o.get("sold", 0) > 0), None)
        if not o: return
        base = o.get("avg") or o.get("price") or px; ret = (px / base - 1) * 100
        if not (MANAGE_OPEN <= self._hm() < REG_END):            # ★정규장(09:00~15:30) 밖 = 시간외종가·애프터마켓(2026-09-16)
            o["aft_px"] = px; o["aft_ret"] = round(ret, 2)       #   따로 담는다. cur_* 를 덮으면 그 값이 STATE 에 남아
            self._live_dirty = True; return                      #   다음날 09:00 첫 틱에 오늘 값으로 오인된다
        o["cur_ret"] = round(ret, 2); o["cur_px"] = px; self._live_dirty = True   # HTS처럼 실시간 변동
        if o.get("sell_stuck"): return                           # ★미체결 매도주문이 살아있음 — 시세만 갱신하고 주문은 금지(이중매도 방지)
        if not self.cfg.get("enabled"): return
        if not (MANAGE_OPEN <= self._hm() < MANAGE_CLOSE): return    # 장중(09:00~15:20)에만 실매도
        tp, acc = self.cfg["tp_pct"], self.cfg["account"]   # ★손익절은 수수료를 넣지 않는다(매수가 기준 순수 등락률)
        otp = st.UPPER_TP if o.get("unbuyable") else tp
        osl = self.cfg.get("sl_pct", -3.0)                           # ★손절 독립(설정값·음수) — 자동 1:1 규칙 해제(관리자 동일)
        rem = o["filled"] - o.get("sold", 0)
        if rem > 0 and ret <= osl:                                   # ★손절 — 정정(즉시 시장체결·이중매도0), 지정가 없으면 시장가
            try:
                self._force_sell(o, "실시간 손절")
                self.log(f"  ⚡실시간손절 {o['name']} {ret:+.2f}%"); self.tg(f"⚡손절 {o['name']} {ret:+.2f}%")
                savej(STATE, self.state); self._ensure_real(force=True)
            except Exception as e:
                self.log(f"실시간손절오류 {e}")
        elif rem > 0 and ret >= otp and not o.get("tp_placed"):      # ★익절 폴백(지정가 미배치 시만)
            try:
                self.kw.send_order(acc, code, rem, 0, 2, "03"); o["sold"] = o["filled"]; o["exit_ret"] = round(ret, 2); self._rec(o, ret, "실시간 익절")
                self.log(f"  ⚡실시간익절(폴백) {o['name']} {ret:+.2f}%"); self.tg(f"⚡익절 {o['name']} {ret:+.2f}%")
                savej(STATE, self.state); self._ensure_real(force=True)
            except Exception as e:
                self.log(f"실시간익절오류 {e}")

    def _live_flush(self):
        if self._live_dirty:
            self._live_dirty = False
            try: self.refresh()
            except Exception: pass

    def _tick_round(self, px):
        """호가단위 반올림(KRX 2023~) — 지정가 주문 거부 방지."""
        px = int(px)
        for lim, t in [(2000, 1), (5000, 5), (20000, 10), (50000, 50), (200000, 100), (500000, 500)]:
            if px < lim: return max(t, (px // t) * t)
        return (px // 1000) * 1000

    def _force_sell(self, o, reason=""):
        """★보유분 즉시 전량매도 — 익절 지정가 있으면 정정(하한가로)해 즉시 시장체결(이중매도0·취소race0), 없으면 시장가. 기록은 _reconcile_sells가 실체결가 보정."""
        acc = self.cfg["account"]; code = o["code"]; rem = o["filled"] - o.get("sold", 0)
        if rem <= 0 or o.get("sell_stuck"): return               # ★최후 방어선 — 미체결 매도주문이 살아있으면 또 내지 않는다
        base = o.get("avg") or o.get("price") or 0; px = o.get("cur_px") or base
        if o.get("tp_placed") and not o.get("tp_ord"):              # 주문번호 미확보 → fills서 재조회
            f = next((x for x in reversed(getattr(self.kw, "fills", []) or []) if x.get("code") == code and "매도" in (x.get("otype", "") or "") and x.get("order_no")), None)
            if f: o["tp_ord"] = f["order_no"]
        if o.get("tp_ord"):
            low = self._tick_round(max(1, round(base * 0.71)))       # 하한가 근처 정정 → 즉시 시장체결
            self.kw.modify_sell(acc, code, rem, low, o["tp_ord"]); o["tp_ord"] = None; o["tp_placed"] = False
        else:
            self.kw.send_order(acc, code, rem, 0, 2, "03")
        o["sold"] = o["filled"]; o["exit_ret"] = round((px / base - 1) * 100, 2) if base else 0.0
        o["sell_pending"] = {"hm": self._hm(), "ts": time.time(), "qty": rem, "warned": False}  # ★체결확인 대기
        self._rec(o, o["exit_ret"], reason)

    def manage(self):
        self._ensure_real()   # 보유종목 실시간 등록 보장(재등록)
        pos = [o for o in self.state.get("positions", [])
               if o.get("filled", 0) - o.get("sold", 0) > 0 and not o.get("sell_stuck")]   # ★미체결 주문 살아있음 → 신규주문 금지
        if not pos: return
        tp, acc = self.cfg["tp_pct"], self.cfg["account"]   # ★손익절은 수수료를 넣지 않는다(매수가 기준 순수 등락률)
        kwpos = getattr(self.kw, "positions", {}) or {}; kwfills = getattr(self.kw, "fills", []) or []
        for o in pos:
            code = o["code"]; base = o.get("avg") or o["price"]; rem = o["filled"] - o.get("sold", 0)
            px = self.cur(code)
            if px: o["cur_ret"] = round((px / base - 1) * 100, 2)
            otp = st.UPPER_TP if o.get("unbuyable") else tp; osl = self.cfg.get("sl_pct", -3.0)   # ★손절 독립(설정값)
            if rem > 0 and not o.get("tp_placed"):                    # ★익절 지정가 예약(포지션당 1회)
                tp_px = self._tick_round(round(base * (1 + otp / 100)))
                if self.kw.send_order(acc, code, rem, tp_px, 2, "00") == 0:
                    o["tp_placed"] = True; o["tp_px"] = tp_px
                    for _ in range(4):                                # 주문번호 즉시확보(정정용)
                        self.wait(300)
                        f2 = next((x for x in reversed(getattr(self.kw, "fills", []) or []) if x.get("code") == code and "매도" in (x.get("otype", "") or "") and x.get("order_no")), None)
                        if f2: o["tp_ord"] = f2["order_no"]; break
                    self.log(f"  🎯 익절 지정가 예약 {o['name']} {rem}주 @{tp_px:,}(+{otp:g}%)")
            if o.get("tp_placed") and not o.get("tp_ord"):
                f = next((x for x in reversed(kwfills) if x.get("code") == code and "매도" in (x.get("otype", "") or "") and x.get("order_no")), None)
                if f: o["tp_ord"] = f["order_no"]
            if rem > 0 and o.get("tp_placed"):                       # ★익절 지정가 체결감지(잔고 감소)
                heldn = kwpos.get(code, {}).get("qty")
                if heldn is not None and heldn < rem:
                    fs = next((x for x in reversed(kwfills) if x.get("code") == code and "매도" in (x.get("otype", "") or "") and (x.get("fill_price") or 0) > 0), None)
                    fp = fs["fill_price"] if fs else o.get("tp_px", px or base)
                    o["sold"] = o.get("sold", 0) + (rem - heldn); o["exit_ret"] = round((fp / base - 1) * 100, 2) if base else 0
                    self._rec(o, o["exit_ret"])
                    self.log(f"  ✅ 익절 지정가 체결 {o['name']} @{fp:,} ({o['exit_ret']:+.2f}%)")
            elif rem > 0 and px and (px / base - 1) * 100 <= osl:     # ★손절(지정가 정정→즉시 시장체결)
                self._force_sell(o, "손절")
                self.log(f"  🛑 손절 {o['name']} {o.get('exit_ret', 0):+.2f}%"); self.tg(f"손절 {o['name']} {o.get('exit_ret', 0):+.2f}%")
        pos2 = [o for o in self.state.get("positions", [])
                if o.get("filled", 0) - o.get("sold", 0) > 0 and not o.get("sell_stuck")]
        rr = [o.get("cur_ret", 0.0) for o in pos2]; acct = round(sum(rr) / len(rr), 2) if rr else 0.0
        if pos2 and acct >= tp:                                       # 계좌평균 도달 → 전량청산(정정 기반)
            for o in pos2: self._force_sell(o, "하이브 계좌청산")
            self.log(f"  🏦 계좌 {acct:+.1f}% 전량청산"); self.tg(f"계좌 {acct:+.1f}% 전량청산")
        savej(STATE, self.state); self.refresh()

    def close_all(self):
        did = False
        for o in self.state.get("positions", []):
            if o.get("filled", 0) - o.get("sold", 0) > 0 and not o.get("sell_stuck"):
                self._force_sell(o, "15:19 종가청산"); did = True                      # ★익절 지정가 있으면 정정→즉시 시장체결
                self.log(f"  🔚 종가청산(어제분) {o['name']} {o.get('exit_ret', 0):+.1f}%")
        if did: savej(STATE, self.state); self.refresh()

    def _rec(self, o, ret, reason=""):
        buy = o.get("avg") or o.get("price") or 0
        rec = {"date": self._t(), "code": o.get("code"), "name": o["name"], "buy": buy,
               "sell": round(buy * (1 + ret / 100)), "ret": round(ret, 2), "qty": o.get("filled", 0),
               "pl": round(buy * o.get("filled", 0) * ret / 100), "real_fill": False,
               "sell_time": self._hm(), "reason": reason,
               "mode": "모의" if self.cfg.get("is_mock", True) else "실전",   # ★전략자산을 모드별로 가르려면 필요

               # ★슬리피지 측정용(관리자 동일) — 백테가 가정한 가격을 남긴다
               "buy_plan": o.get("price") or None,
               "sell_plan": round(buy * (1 + ret / 100)),
               "open_px": o.get("open_px") or None, "adopted": bool(o.get("adopted"))}
        # ★중복기록 차단(2026-09-14 · 관리자 동일) — 마지막 방어선.
        #   ★진짜 분할체결은 수량이나 단가가 다르다. 전부 같은 것만 거부한다.
        _k = (rec["date"], rec["code"], rec["qty"], rec["buy"], rec["sell"], rec["ret"])
        for _t in reversed(self.state.get("trades") or []):
            if _t.get("date") != rec["date"]: break
            if (_t.get("date"), _t.get("code"), _t.get("qty"), _t.get("buy"),
                    _t.get("sell"), _t.get("ret")) == _k:
                self.log(f"  ⛔ 중복기록 차단 {rec['name']} {rec['qty']}주 {rec['ret']:+.2f}%")
                self.tg(f"⛔ 중복기록 차단 {rec['name']} {rec['ret']:+.2f}% (기록 보호)")
                return
        self.state.setdefault("trades", []).append(rec)

    def _clear_sell_stuck(self):
        """★날이 바뀌면 매도잠금을 푼다(2026-09-14 버그수정).

        `sell_stuck` 은 '이미 낸 매도주문이 살아 있으니 또 내지 말라'는 잠금이다.
        그런데 한국 시장의 당일 주문은 **장 마감에 자동 취소**된다 — 다음 날엔 살아있는 주문이 없다.
        안 풀면 그 포지션은 손절·익절·종가청산·갭컷이 전부 막힌 채 계좌에 영원히 남는다."""
        stuck = [o for o in self.state.get("positions", []) if o.get("sell_stuck")]
        if not stuck: return
        for o in stuck:
            o.pop("sell_stuck", None); o.pop("sell_pending", None); o.pop("tp_placed", None); o.pop("tp_ord", None)
            self.log(f"  🔓 매도잠금 해제 {o['name']} — 전일 미체결 주문은 자동취소됨 · 오늘부터 정상 관리")
        self.tg("🔓 전일 매도 미체결분 잠금 해제 — " + ", ".join(o["name"] for o in stuck)
                + "\n오늘부터 손익절·종가청산이 다시 작동합니다.")
        savej(STATE, self.state)

    def _sync_account_ledger(self):
        """★계좌 자동동기화 — 접속이 끊긴 사이 앱/외부(영웅문·MTS)로 청산된 종목을
        당일매매일지(실체결가)로 잡아 기록한다.

        안 하면: 이미 판 종목이 포지션에 유령으로 남아 매일 종가청산을 시도하고,
        실현손익이 안 잡혀 전략자산(=사이징 기준)이 계속 어긋난다.

        ★안전: 당일매매일지가 '실제 매도'로 확인한 것만 기록한다.
          빈 응답은 조회실패일 수 있으므로 아무것도 하지 않는다."""
        if not self.connected: return
        try:
            journal = self.kw.today_journal(self.cfg.get("account", "")) or []
        except Exception as e:
            self.log(f"당일매매일지 조회 오류 {e}"); return
        if not journal: return                               # 빈 응답 = 조회실패/매도없음 → 아무것도 안 함(안전)
        jr = {t["code"]: t for t in journal if t.get("sell_amt")}
        today = self._t()
        recorded = {t.get("code") for t in (self.state.get("trades") or []) if t.get("date") == today}
        changed = False
        for o in self.state.get("positions", []):
            if o.get("open_buy") or o.get("filled", 0) - o.get("sold", 0) <= 0: continue
            if o["code"] in recorded: continue               # 우리가 이미 기록한 매도
            if o.get("sell_pending"): continue               # ★발주 직후 — _verify_sells 가 판정할 몫
            j = jr.get(o["code"])
            if not j: continue                               # 일지에 매도 없음 → 스킵(미확인·안전)
            buy = o.get("avg") or o.get("price") or 0; qty = o.get("filled", 0)
            amt = j.get("sell_amt", 0)
            if amt <= 0 or qty <= 0: continue
            sell = round(amt / qty); ret = round((amt / (buy * qty) - 1) * 100, 2) if (buy and qty) else 0.0
            o["sold"] = qty; o["exit_ret"] = ret; o.pop("sell_stuck", None)   # 중복기록 방지
            self._rec(o, ret, "계좌동기화(당일매매일지)")
            _lt = (self.state.get("trades") or [])[-1:]     # ★일지값이 실체결이다 — 정확한 금액으로 덮고 보정 대상에서 뺀다
            if _lt and _lt[0].get("code") == o["code"]:
                _lt[0]["sell"] = sell; _lt[0]["pl"] = amt - buy * qty; _lt[0]["real_fill"] = True
            self.log(f"🔄 계좌동기화 — {o['name']} 앱/외부 청산 기록(실체결 {sell:,} · {ret:+.2f}%)")
            self.tg(f"🔄 계좌동기화 · {o['name']} 청산 반영 {ret:+.2f}%\n"
                    f"(프로그램 밖에서 매도된 것을 당일매매일지로 확인했습니다)")
            changed = True
        if changed:
            self.state["positions"] = [o for o in self.state["positions"]
                                       if o.get("open_buy") or o.get("filled", 0) - o.get("sold", 0) > 0]
            self.state["date"] = today
            savej(STATE, self.state); self._ensure_real(force=True)

    def _verify_sells(self):
        """★매도 체결확인 — '발주했으니 팔렸다'고 가정한 기록을 실제 잔고로 검증한다.

        _force_sell 은 send_order 직후 sold=filled 로 마킹하고 기록한다.
        모의계좌는 시장가가 늘 즉시 체결돼 문제없지만 **실계좌는 다르다** —
        급등주는 VI(변동성완화장치)가 흔하고, 걸리면 2분 단일가라 시장가가 안 나간다.
        그 사이 기록에는 '없었던 거래'가 남고, 포지션은 잔량 0으로 보여 손익절이 끊긴다.

          3분  — 잔량이 남아 있으면 텔레그램 경고(주문은 살아 있으니 기다린다)
          10분 — 그래도 남으면 **기록을 사실에 맞추고** 포지션 잔량을 되살린다.
                 되살린 포지션엔 `sell_stuck` 을 붙여 **새 주문을 내지 않는다**
                 (살아있는 매도주문 + 새 주문 = 이중매도).

        ★조회 실패(None)와 '보유 없음'(빈 목록)을 반드시 구분한다."""
        if not self.connected: return
        if not (MANAGE_OPEN <= self._hm() <= "15:45"): return
        due = [o for o in self.state.get("positions", [])
               if o.get("sell_pending") and time.time() - (o["sell_pending"].get("ts") or 0) >= 180]
        if not due: return
        try: hd = self.kw.holdings(self.cfg["account"])
        except Exception as e:
            self.log(f"매도 체결확인 조회 오류 {e}"); return
        if not isinstance(hd, dict):
            self.log("⚠️ 매도 체결확인 — 잔고조회 실패, 다음 틱 재시도"); return
        held = {x.get("code"): int(x.get("qty") or 0) for x in (hd.get("stocks") or [])}
        changed = False
        for o in due:
            sp = o["sell_pending"]; h = int(held.get(o["code"], 0) or 0)
            if h <= 0:
                o.pop("sell_pending", None); changed = True; continue
            if time.time() - (sp.get("ts") or 0) < 600:
                if not sp.get("warned"):
                    sp["warned"] = True; changed = True
                    self.log(f"  ⏳ 매도 미체결 {o['name']} — 잔량 {h}주(VI·거래정지 가능 · 주문은 살아있음)")
                    self.tg(f"⏳ 매도 미체결 {o['name']} — {sp.get('qty')}주 중 {h}주 남음\n"
                            f"VI(변동성완화) 등으로 지연 중일 수 있습니다.\n10분 뒤에도 남으면 기록을 되돌립니다.")
                continue
            sold_real = max(0, int(sp.get("qty") or 0) - h)
            self._unrecord_sell(o, sold_real)
            o["sold"] = max(0, o.get("filled", 0) - h)
            o["sell_stuck"] = True; o.pop("sell_pending", None); o.pop("tp_placed", None); changed = True
            self.log(f"  🛑 매도 미체결 확정 {o['name']} — 잔량 {h}주 · 실제매도 {sold_real}주 → 기록 보정 · 신규주문 중지")
            self.tg(f"🛑 매도가 체결되지 않았습니다 — {o['name']}\n"
                    f"잔량 {h}주 (실제 매도 {sold_real}주)\n\n"
                    f"· 기록을 사실에 맞게 고쳤습니다\n"
                    f"· 이미 낸 매도주문이 살아 있을 수 있어 **새 주문은 내지 않습니다**\n"
                    f"· 키움에서 주문 상태를 직접 확인하세요")
        if changed:
            savej(STATE, self.state); self._ensure_real(force=True)

    def _unrecord_sell(self, o, sold_real):
        """★_verify_sells 전용 — 오늘 그 종목의 마지막 기록을 실제 체결수량에 맞춘다(0이면 삭제)."""
        today = self._t(); lst = self.state.setdefault("trades", [])
        for i in range(len(lst) - 1, -1, -1):
            r = lst[i]
            if r.get("date") != today or r.get("code") != o.get("code"): continue
            if sold_real <= 0: del lst[i]
            else:
                r["qty"] = sold_real
                r["pl"] = round((r.get("sell", 0) - r.get("buy", 0)) * sold_real)
            return

    def _reconcile_sells(self):
        """★매도 실체결가 보정 — 라이브 기록가(트리거 시점)를 키움 실제 체결가(chejan FID910)로 갱신(관리자 동일). fills 없으면 no-op."""
        fills = getattr(self.kw, "fills", []) or []
        if not fills: return
        today = self._t(); changed = False
        for rec in self.state.get("trades", []):
            if rec.get("real_fill") or rec.get("date") != today: continue
            f = next((x for x in reversed(fills)
                      if x.get("code") == rec.get("code") and "매도" in (x.get("otype", "") or "") and (x.get("fill_price") or 0) > 0), None)
            if not f: continue
            fp = f["fill_price"]; buy = rec.get("buy") or 0; old = rec.get("sell")
            if buy and fp != old:
                rec["sell"] = fp; rec["ret"] = round((fp / buy - 1) * 100, 2); rec["pl"] = round((fp - buy) * (rec.get("qty") or 0))
                self.log(f"  📝 매도 실체결가 보정 {rec.get('name')} 기록 {old:,}→실제 {fp:,} ({rec['ret']:+.2f}%)")
            rec["real_fill"] = True; changed = True
        if changed: savej(STATE, self.state)

    def cur(self, code):
        try:
            rp = getattr(self.kw, "real_prices", None)
            if rp and rp.get(code): return rp[code]
            info = self.kw.basic(code); return (_int(info.get("현재가")) or None) if info else None
        except Exception: return None

    def _routine_checklist(self):
        """오늘 루틴 진행 체크리스트 HTML — 현재 단계 🔵강조(관리자와 동일 UI)."""
        run = self.cfg.get("enabled"); conn = self.connected; hm = self._hm()
        def item(state, label):
            ic = {"done": "✅", "cur": "🔵", "pend": "⚪", "fail": "⚠️"}[state]
            col = {"done": "#eafcff", "cur": "#22c55e", "pend": "#8b93a7", "fail": "#ef4444"}[state]
            return f"<span style='color:{col}'>{ic} {label}</span>"
        held = [o for o in self.state.get("positions", []) if o.get("filled", 0) - o.get("sold", 0) > 0]
        try: uname = f" · {self.kw.user_name()}" if conn else ""
        except Exception: uname = ""
        L = [
            item("done" if self._licensed else "fail", "관리자 승인" + ("" if self._licensed else f" ({self._lic_status})")),
            item("done" if self._hub_ok else "pend", "관리자 연결(픽 수신)"),
            item("done" if run else "pend", "자동매매 가동" + ("" if run else " (정지)")),
            item("done" if conn else "pend", "키움 로그인" + uname),
            item("done" if self._real_on else "pend", f"실시간 감시 {len(held) if self._real_on else 0}종목 · 보유 {len(held)}"),
            "<span style='color:#163540'>──────────</span>",
        ]
        def stage(label, a, b, done=False):
            if done or hm >= b: return item("done", label)
            if a <= hm < b: return item("cur", label + "  ◀ 진행중")
            return item("pend", label)
        L.append(stage("09:00~15:19 보유 손익절(±3%)", "09:00", "15:19"))
        L.append(stage("15:25 관리자 픽 → 지정가 종가매수(→15:28 시장가전환→15:31 보정)", "15:25", "15:35", done=self.bought_today))
        return "<br>".join(L)

    def _pick_score(self, s):
        sc = s.get("score")
        if sc is None and ba and s.get("feat"):
            try: sc = ba.score(s["feat"])
            except Exception: sc = None
        return sc

    def _picks_html(self):
        """깃허브 최근 추천종목 HTML — 매력도순, 체결강도·상한가·선정 표시(매수 전에도 표시).
        ★오늘 날짜 픽만 표시 — 오래된 픽(어제 이전)은 '오늘 추천 종목 없음' 처리(매수 날짜가드와 일치)."""
        pj = self._picks or {}
        if pj.get("date") != self._t():                       # ★오늘 픽 아니면 stale 종목 표시 안 함
            return f"<span class=muted>📭 오늘 추천 종목 없음 — 관리자 15:20 스캔·깃허브 배포 후 표시<br>(마지막 배포일: {pj.get('date') or '—'})</span>"
        for s in pj.get("stocks", []): s["_sc"] = self._pick_score(s)
        stocks = sorted(pj.get("stocks", []), key=lambda s: -(s.get("_sc") or -1))
        if not stocks:
            return "<span class=muted>추천 종목 대기 중 — 관리자 15:20 스캔 후 깃허브에서 자동 표시</span>"
        L = [f"<span class=muted>{pj.get('date','')} · {len(stocks)}종목 · 매력도순 · 생성 {pj.get('generated','')}</span>"]
        for i, s in enumerate(stocks):
            sc = s.get("_sc"); ub = s.get("unbuyable"); f = s.get("feat") or {}; ch = f.get("chegang")
            sel = " <span style='color:#f5b53d'>★선정</span>" if s.get("kind") == "선정" else ""
            ubt = " · <span style='color:#f5b53d'>🔴상한가(내일 시가매수)</span>" if ub else ""
            grd = "🔥" if (sc or 0) >= 85 else ("👍" if (sc or 0) >= 65 else "")
            cht = (f" · 체결강도 <b style='color:{UP if (ch or 0) >= 100 else DN}'>{ch:.0f}</b>" if ch is not None else "")
            thb = (f" · <span style='color:#f5b53d;font-weight:700'>⭐테마+{s.get('theme_bonus')}</span>"
                   + (f"<span class=muted>({f.get('theme')} {s.get('theme_chg'):+.1f}%·{s.get('theme_rank')}위)</span>" if s.get('theme_chg') is not None and f.get('theme') else "")
                   if s.get('theme_bonus') else "")
            L.append(f"{i+1}. <b>{s.get('name','')}</b> {int(s.get('entry') or 0):,}원 · 매력도 <b style='color:{CYAN}'>{sc if sc is not None else '—'}</b>{grd}{cht}{thb}{sel}{ubt}")
        return "<br>".join(L)

    # ═══ 화면 갱신 ═══
    def refresh(self):
        try: self._update_status()
        except Exception: pass
        run = self.cfg.get("enabled")
        if hasattr(self, "lic_lbl"):
            if self._licensed: self.lic_lbl.setText(f"<b style='color:#22c55e'>✅ 승인됨</b> · 만료 {self._lic_expiry}")
            else: self.lic_lbl.setText(f"<b style='color:#F0455C'>⛔ 미승인</b> · {self._lic_status} — 닉네임/서버 저장 후 [승인 요청]")
        self.btn_go.setText("⏹  자동매매 정지" if run else "▶  자동매매 시작")
        self.btn_go.setStyleSheet("#gobtn{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 %s,stop:1 %s);}" %
                                  (("#22c55e", "#15803d") if run else ("#7c3aed", "#6321c9")))
        mock = self.cfg.get("is_mock", True)
        onm = "#modebtn{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #22c55e,stop:1 #15803d);color:#fff;border:1px solid #22c55e;border-radius:11px;padding:9px 12px;font-weight:800;}"
        onr = "#modebtn{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #ef4444,stop:1 #b91c1c);color:#fff;border:1px solid #ef4444;border-radius:11px;padding:9px 12px;font-weight:800;}"
        off = "#modebtn{background:#171525;color:#8b93a7;border:1px solid #2c2748;border-radius:11px;padding:9px 12px;font-weight:800;}"
        self.btn_mock.setStyleSheet(onm if mock else off)
        try: self._refresh_aftp()          # ★애프터마켓 스위치 상태(모의면 못 켜게)
        except Exception: pass
        self.btn_real.setStyleSheet(onr if not mock else off)
        trades = self.state.get("trades", [])
        fee = float(self.cfg.get("fee_pct", 0.15))                   # ★왕복 수수료 반영(관리자 동일 net)
        cum = 0.0; curve = [0.0]
        for t in trades: cum += t.get("ret", 0) - fee; curve.append(round(cum, 2))
        wins = sum(1 for t in trades if (t.get("ret", 0) - fee) > 0); wr = round(wins / len(trades) * 100) if trades else 0
        self.spark.setData(curve); self.chart_sub.setText(f"{len(trades)}거래 · 누적 {cum:+.1f}%")
        self.gauge.setPct(wr)
        self.ret_big.setText(f"{cum:+.1f}%"); self.ret_big.setStyleSheet(f"color:{UP if cum>=0 else DN};font-size:30px;font-weight:900")
        self.ret_sub.setText(f"{len(trades)}거래 · 승 {wins} / 패 {len(trades)-wins}")
        held = [o for o in self.state.get("positions", []) if o.get("filled", 0) - o.get("sold", 0) > 0]
        rpc = getattr(self.kw, "real_prices", {}) or {}
        def hrow(o):
            r = o.get("cur_ret", 0.0); c = UP if r >= 0 else DN
            px = o.get("cur_px") or rpc.get(o["code"]) or (o.get("avg") or o.get("price") or 0)
            live = " <span style='color:#22c55e'>●</span>" if self._real_on and rpc.get(o["code"]) else ""
            return f"• {o['name']}  {o.get('filled',0)}주  <b>{px:,}</b>  <b style='color:{c}'>{r:+.2f}%</b>{live}"
        rows = [hrow(o) for o in held]; hcodes = {o["code"] for o in held}
        for s in (self.acct or {}).get("stocks", []):        # 실제 계좌보유(state 밖)도 표시
            if s.get("code") not in hcodes and s.get("qty", 0) > 0:
                r = s.get("ret", 0.0); c = UP if r >= 0 else DN
                rows.append(f"• {s.get('name','')}  {s.get('qty',0)}주  <b>{int(s.get('cur') or 0):,}</b>  <b style='color:{c}'>{r:+.2f}%</b> <span style='color:#f5b53d'>(계좌)</span>")
        self.hold_box.setText("<br>".join(rows) or "없음")
        today = [t for t in trades if t.get("date") == self._t()]
        def trow(t): return f"• {t['name']}  {t.get('buy',0):,}→{t.get('sell',0):,}  <b style='color:{UP if t['ret']>=0 else DN}'>{t['ret']:+.2f}%</b>"
        self.today_box.setText("<br>".join(trow(t) for t in reversed(today)) or "없음")
        self.all_box.setText("<br>".join(f"{t.get('date','')[5:]} " + trow(t) for t in reversed(trades[-30:])) or "없음")
        try: self.routine_box.setText(self._routine_checklist())   # ★루틴 체크리스트
        except Exception: pass
        try: self.picks_box.setText(self._picks_html())            # ★추천종목(깃허브)
        except Exception: pass
        # 계좌탭
        if self.acct:
            self.a_ret["val"].setText(f"{self.acct.get('total_ret',0):+.2f}%")
            self.a_bal["val"].setText(f"{self.acct.get('assets',0):,}원")
        self.a_win["val"].setText(f"{wr}%")
        self.acct_hold.setText("\n".join(f"• {s.get('name')}  {s.get('qty')}주  {s.get('ret',0):+.2f}%" for s in self.acct.get("stocks", [])) or "없음")
        self.acct_trades.setText("<br>".join(f"{t.get('date','')[5:]} " + trow(t) for t in reversed(trades[-30:])) or "없음")

    def _watch_disconnect(self):
        """미접속 1분↑ 시 텔레그램 경보(복구는 _restart_process 즉시재시작이 담당)."""
        now = datetime.datetime.now()
        if self._disc_since is None: self._disc_since = now
        elif (now - self._disc_since).total_seconds() >= 60 and not self._disc_alerted:
            self._disc_alerted = True
            self.log("⚠️ 키움 미접속 1분↑ — 텔레그램 경보 + 복구 시도"); self.tg("⚠️ 키움 미접속 1분 경과 — 자동 복구 시도 중")

    def _place_afterhours_tp(self):
        """★애프터마켓 익절 지정가(16:00~20:00) — 관리자 admin._place_afterhours_tp 와 같은 규칙.

        2026-09-14 제도변경: 시간외단일가(16~18시·10분 단일가)가 폐지되고 KRX 애프터마켓
        (16:00~20:00 접속매매 · 가격제한 전일종가 ±30% · 지정가만, 시장가 불가)이 생겼다.

        규칙
          · 익절만 건다. 손절은 걸지 않는다.
          · 익절가는 매수가 기준 설정 익절% (수수료 무관 — 정규장과 같은 목표).
          · 미체결이면 그대로 둔다. 주문은 20:00 소멸, 다음날 정규장에서 평소대로 손익절.
          · 모의계좌는 애프터마켓 불가 → 실서버로 확인될 때만 발주.
        중복발주는 날짜(aftp_day)로 막는다(메모리 플래그는 재기동마다 풀려 이중발주가 난다)."""
        today = self._t()
        pos = [o for o in self.state.get("positions", [])
               if not o.get("open_buy") and (o.get("filled", 0) - o.get("sold", 0)) > 0
               and o.get("aftp_day") != today]
        if not pos: return
        srv = ""
        try: srv = (self.kw.server_gubun() or "")     # '1'=모의 / '0'=실서버 / ''=판정불가
        except Exception: srv = ""
        live = bool(self.cfg.get("aftp_live")) and not self.cfg.get("is_mock") and srv == "0"
        if not live:
            why = ("설정 aftp_live 꺼짐" if not self.cfg.get("aftp_live")
                   else "모의모드" if self.cfg.get("is_mock")
                   else ("서버구분 판정불가(공백) — 발주 보류" if srv == "" else "모의서버 접속중"))
            if getattr(self, "_aftp_log_date", "") != today:      # 하루 한 줄만
                self._aftp_log_date = today
                self.log(f"🌙 애프터마켓 익절: 발주 안 함({why}) — 보유 {len(pos)}종목 관찰만")
            return                                                # ★봉인하지 않는다 — 나중에 켜면 그날 바로 걸린다
        acc = self.cfg["account"]; tp = self.cfg["tp_pct"]
        hoga = str(self.cfg.get("aftp_hoga", "00"))               # "00"=지정가. 옛 "62"는 폐지됐다
        done = 0; changed = False
        for o in pos:
            code = o["code"]; rem = o["filled"] - o.get("sold", 0)
            base = o.get("avg") or o.get("price") or 0
            if base <= 0: continue
            otp = st.UPPER_TP if o.get("unbuyable") else tp
            tp_px = self._tick_round(round(base * (1 + otp / 100)))
            ref = o.get("cur_px") or base                         # 당일 종가 근사 = 정규장 마지막 시세
            if tp_px > ref * 1.3:                                 # ★가격제한(±30%) 밖이면 안 건다
                o["aftp_day"] = today; changed = True
                self.log(f"  🌙 {o['name']} 익절가 {tp_px:,} 가 가격제한 밖 — 안 걸음(내일 정규장에서 처리)")
                continue
            if self.kw.send_order(acc, code, rem, tp_px, 2, hoga) == 0:
                o["aftp_day"] = today; o["aftp_px"] = tp_px; o["aftp_qty"] = rem
                done += 1; changed = True
                self.log(f"  🌙 애프터마켓 익절 예약 {o['name']} {rem}주 @{tp_px:,}(+{otp:g}%·20시까지)")
            else:
                self.log(f"  ⚠️ 애프터마켓 익절 예약 실패 {o['name']} — 다음 틱에 재시도")
        if changed: savej(STATE, self.state)
        if done:
            self.tg(f"🌙 애프터마켓 익절 예약 {done}종목(16~20시 · 오직 익절 · 손절 없음)")

    def tick(self):
        if getattr(self, "_tick_busy", False): return        # ★재진입 방지
        if AUTO:
            if not self._operating():                        # ★평일 08:25~17:00 밖(야간·주말)
                self._night_idle(); return                   #   끄지 않고 대기 — 예약작업이 없어 끄면 아무도 못 켠다
            self._daily_resume()                             # ★운영시간 진입 → 그날 한 번 스스로 로그인
        if not self.cfg.get("enabled"): return
        self._tick_busy = True
        try:
            if self._popup_n > self._popup_reported:               # ★키움 통신끊김 팝업 자동확인 발생 → 보고(끊김 신호)
                self._popup_reported = self._popup_n
                self.log(f"🧹 키움 통신끊김 팝업 자동확인({self._popup_n}회) — 재접속 진행")
                self.tg("🧹 키움 '통신연결 끊김' 팝업 자동처리 → 재접속 시도 중")
            if self.connected:                                     # ★실제 OCX 연결상태 능동 확인(silent disconnect 감지)
                try:
                    if int(self.kw.dynamicCall("GetConnectState()")) != 1: self.connected = False
                except Exception: self.connected = False
            if not self.connected:
                if self._logging_in: return                       # 로그인 진행 중이면 대기(중복 재시작 방지)
                if AUTO: self._restart_process("접속 끊김 — 즉시 재시작")     # ★무인(auto)만: 끊기면 바로 프로세스 재시작
                else: self._watch_disconnect()                    # 수동실행은 경보만(사용자가 직접 재접속)
                return
            self._disc_since = None; self._disc_alerted = False    # 연결 정상 복구
            self._ensure_real()   # ★보유종목 실시간 시세 항상 유지(HTS처럼 실시간 반영)
            self._reconcile_sells()   # ★매도 실체결가로 거래기록 보정(라이브=실제)
            try: self._verify_sells()  # ★매도가 진짜 체결됐는지 잔고로 검증(VI·거래정지 대비)
            except Exception as e: self.log(f"매도 체결확인 오류 {e}")
            if MANAGE_OPEN <= self._hm() <= "15:45" and time.time() - getattr(self, "_sync_ts", 0) >= 300:
                self._sync_ts = time.time()                 # ★5분 간격(TR 제한 보호)
                try: self._sync_account_ledger()            # ★외부(영웅문·MTS) 청산 자동 반영
                except Exception as e: self.log(f"계좌동기화 오류 {e}")
            if self.state.get("buy_date") != self._t(): self.bought_today = False
            if self._upper_date != self._t():
                self._upper_date = self._t(); self.state["upper_today"] = []   # ★상한가 표시 일일리셋
                self._clear_sell_stuck()   # ★미체결 매도잠금 해제(당일 주문은 장 마감에 자동취소되므로 새 날엔 살아있는 주문이 없다)
            hm = self._hm()
            self._report(hm)                                              # ★장전·장시작·매시·마감 텔레그램(관리자 동일)
            if MANAGE_OPEN <= hm < MANAGE_CLOSE:                          # 09:00~15:19 보유 손익절(관리자 동일)
                if self.state.get("open_pending"): self._buy_open_pending()   # ★09:00+ 상한가 예약분 시가매수
                try: self._gapcut()                                       # ★09:00 시가 갭컷(관리자 동일)
                except Exception as e: self.log(f"갭컷 오류 {e}")
                self.manage()
            elif MANAGE_CLOSE <= hm < BUY_HM:                             # 15:19~15:25 어제 보유분 종가청산(오늘 매수 전)
                self.close_all()
            elif BUY_HM <= hm < CONVERT_HM and not self.bought_today:     # 15:25 지정가 매수
                self.buy_picks()
            elif CONVERT_HM <= hm < RECON_HM and self.bought_today and not self.converted_today:  # 15:28 미체결→시장가 전환
                self._convert_unfilled_market()
            elif RECON_HM <= hm < DONE_HM and self._recon_date != self._t():   # 15:31 실잔고 체결보정(1일1회)
                self._recon_date = self._t(); self._reconcile_positions()
            if AFTP_START <= hm < AFTP_END and self.state.get("positions"):
                self._place_afterhours_tp()                               # ★애프터마켓 익절전용(실전만 실주문)
            if hm in ("09:01", "15:18"): self.query_account()
        except Exception as e: self.log(f"루프 오류 {e}")
        finally:
            self._tick_busy = False                          # ★재진입 가드 해제(예외 시에도 반드시)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    try: QFontDatabase()
    except Exception: pass
    w = Client()
    if getattr(w, "_dup_exit", False):      # ★이미 실행 중 — 빈 창을 띄우지 않고 바로 나간다
        sys.exit(0)
    w.show()
    sys.exit(app.exec_())
