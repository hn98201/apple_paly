# -*- coding: utf-8 -*-
"""로그인모드.py — 키움 로그인 창을 띄워 모의/실전을 고를 수 있게 한다. (2026-09-17)

무엇이 문제였나
  무인 운영을 하려고 키움 '자동로그인 설정' 을 켜 두면, `CommConnect()` 가 창 없이
  바로 접속한다. 편하지만 **모의투자 접속 체크를 바꿀 기회가 없다.**
  메인의 [실거래] 버튼은 원장 라벨일 뿐이고 서버를 바꾸지 않는다.

★한 번 틀렸던 접근 (2026-09-17, 기록으로 남긴다)
  처음엔 `C:\\OpenAPI\\system\\Autologin.dat` 을 모드별로 보관했다가 되돌리면 될 줄 알았다.
  실제로 해보니 **안 된다.**
      02:33:38  파일을 '실전' 사본으로 교체
      02:33:47  그래도 모의 서버로 접속
  게다가 키움은 **로그인할 때마다 이 파일을 다시 쓴다**(로그인 직후 md5 가 또 바뀌었다).
  그래서 사본을 되돌리는 방식은 근본적으로 성립하지 않는다.

되는 방법
  자동로그인 정보를 잠시 치우면 다음 로그인에서 **키움 로그인 창이 뜬다.**
  그 창에서
      · '모의투자 접속' 체크를 원하는 대로 (실전이면 해제)
      · '자동로그인 설정' 을 다시 체크
  하고 로그인하면, 키움이 그 상태로 자동로그인을 새로 저장한다 → 이후 다시 무인.

  치운 파일은 보관함에 백업해 두므로 언제든 되돌릴 수 있다.

쓰는 법
  python 로그인모드.py                 지금 상태 보기
  python 로그인모드.py --창띄우기        다음 로그인에서 창이 뜨게 (모드 바꿀 때)
  python 로그인모드.py --되돌리기        마지막 백업으로 복구 (창 띄우기를 취소할 때)

⚠️ 창을 띄워 둔 채로 두면 **무인 자동로그인이 안 된다.** 반드시 한 번 로그인해서
   '자동로그인 설정' 을 다시 체크해 두어야 다음날 아침 08:30 무인 로그인이 된다.
"""
import io, os, sys, shutil, hashlib, datetime, argparse, subprocess

DIR = os.path.dirname(os.path.abspath(__file__))
SYS = r"C:\OpenAPI\system"
LOGIN = os.path.join(SYS, "Autologin.dat")
SNAP = os.path.join(DIR, "_로그인모드")
NOWIN = 0x08000000

try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception: pass


def md5(p):
    try: return hashlib.md5(open(p, "rb").read()).hexdigest()
    except Exception: return ""


def autologin_on():
    """자동로그인이 저장돼 있으면 True — 그러면 로그인 창이 안 뜬다."""
    return os.path.exists(LOGIN) and os.path.getsize(LOGIN) > 0


def backups():
    if not os.path.isdir(SNAP): return []
    return sorted([f for f in os.listdir(SNAP) if f.startswith("Autologin.dat.")], reverse=True)


def open_window():
    """다음 로그인에서 키움 로그인 창이 뜨게 한다. (성공여부, 메시지)"""
    if not autologin_on():
        return True, "이미 자동로그인이 꺼져 있습니다 — 다음 로그인에서 창이 뜹니다"
    try:
        os.makedirs(SNAP, exist_ok=True)
        name = "Autologin.dat.창띄우기전_%s" % datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        shutil.copy2(LOGIN, os.path.join(SNAP, name))
        os.remove(LOGIN)
    except Exception as e:
        return False, "바꾸지 못했습니다(%s) — %s 쓰기 권한을 확인하세요" % (e, SYS)
    return True, ("다음 로그인에서 키움 창이 뜹니다. 창에서 '모의투자 접속' 을 원하는 대로 바꾸고 "
                  "**'자동로그인 설정' 을 반드시 다시 체크**한 뒤 로그인하세요 (백업 %s)" % name)


def restore_last():
    b = backups()
    if not b:
        return False, "되돌릴 백업이 없습니다"
    src = os.path.join(SNAP, b[0])
    try:
        shutil.copy2(src, LOGIN)
    except Exception as e:
        return False, "되돌리지 못했습니다(%s)" % e
    return True, "%s 로 되돌렸습니다 — 다음 로그인은 다시 창 없이 붙습니다" % b[0]


def show():
    print("=" * 64)
    print("  키움 로그인 — 모의/실전 고르기")
    print("=" * 64)
    on = autologin_on()
    print()
    if on:
        print("  지금 : 🔒 자동로그인 켜짐 — 창 없이 바로 접속합니다(무인 운영 가능)")
        print("         이 상태에서는 모의/실전을 바꿀 수 없습니다(창이 안 뜨니까).")
        print("         파일 %s  md5 %s…" % (
            datetime.datetime.fromtimestamp(os.path.getmtime(LOGIN)).strftime("%m-%d %H:%M:%S"), md5(LOGIN)[:10]))
    else:
        print("  지금 : 🪟 자동로그인 꺼짐 — 다음 로그인에서 창이 뜹니다")
        print("         ⚠️ 이대로 두면 **무인 자동로그인이 안 됩니다.**")
        print("            한 번 로그인해서 '자동로그인 설정' 을 다시 체크해 두세요.")
    print()
    print("  모드를 바꾸려면")
    print("    1) python 로그인모드.py --창띄우기")
    print("    2) 프로그램에서 [키움 로그인] → 뜨는 창에서")
    print("         · 실전으로 가려면 '모의투자 접속' **체크 해제**")
    print("         · 모의로 가려면 '모의투자 접속' **체크**")
    print("         · '자동로그인 설정' 은 **반드시 체크** (안 하면 내일 아침 무인 로그인 실패)")
    print("    3) 로그인 → 그 상태로 자동로그인이 새로 저장됩니다")
    b = backups()
    if b:
        print()
        print("  백업 (%s)" % SNAP)
        for f in b[:4]: print("    " + f)
        print("    되돌리기: python 로그인모드.py --되돌리기")
    return 0


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("--창띄우기", action="store_true")
    ap.add_argument("--되돌리기", action="store_true")
    a, _ = ap.parse_known_args()
    if getattr(a, "창띄우기"):
        ok, m = open_window(); print(("  ✅ " if ok else "  ❌ ") + m); return 0 if ok else 2
    if getattr(a, "되돌리기"):
        ok, m = restore_last(); print(("  ✅ " if ok else "  ❌ ") + m); return 0 if ok else 2
    return show()


if __name__ == "__main__":
    sys.exit(main())
