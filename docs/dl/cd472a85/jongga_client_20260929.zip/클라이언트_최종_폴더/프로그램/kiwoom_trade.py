# -*- coding: utf-8 -*-
"""
kiwoom_trade.py — 주문 기능 추가 Kiwoom 서브클래스(TradeKiwoom).
────────────────────────────────────────────────────────────
스캐너용 Kiwoom(읽기전용)에 주문(SendOrder)·계좌·체결(OnReceiveChejanData)을 추가.
★모의투자 판별: KOA_Functions("GetServerGubun") == "1" 이면 모의투자.
주문타입: 1=신규매수 2=신규매도 3=매수취소 4=매도취소. 호가: 00=지정가 03=시장가.
"""
from jongga_scanner import Kiwoom, _int, _dec


class TradeKiwoom(Kiwoom):
    def __init__(self):
        super().__init__()
        self.fills = []          # 체결/주문상태 이벤트
        self.positions = {}      # 잔고 {code: {qty, avg}}
        try:
            self.OnReceiveChejanData.connect(self._on_chejan)
        except Exception:
            pass

    # ── 계좌/서버 ──
    def server_gubun(self):
        """'1'이면 모의투자 서버."""
        try:
            return (self.dynamicCall("KOA_Functions(QString, QString)", "GetServerGubun", "") or "").strip()
        except Exception:
            return ""

    def is_mock(self):
        return self.server_gubun() == "1"

    def accounts(self):
        return [a for a in (self.get("ACCNO") or "").split(";") if a.strip()]

    def user_name(self):
        return self.get("USER_NAME")

    def show_account_window(self):
        """키움 계좌비밀번호 저장창 호출. 사용자가 비번 입력 + 'AUTO(자동)' 체크 후
        '등록'하면 이후 모든 주문이 비번 입력 없이 나감(무인 자동루틴 필수, 최초 1회)."""
        try:
            self.dynamicCall("KOA_Functions(QString, QString)", "ShowAccountWindow", "")
            return True
        except Exception as e:
            if self.on_log:
                self.on_log(f"계좌비번창 호출 오류 {e}")
            return False

    # ── 주문 ──
    def send_order(self, accno, code, qty, price, otype, hoga="00", org=""):
        """SendOrder. otype 1매수/2매도, hoga 00지정가/03시장가. 반환 0=성공."""
        try:
            return self.dynamicCall(
                "SendOrder(QString, QString, QString, int, QString, int, int, QString, QString)",
                ["ord", "9200", accno, int(otype), code, int(qty), int(price), hoga, org])
        except Exception as e:
            if self.on_log:
                self.on_log(f"SendOrder 예외 {e}")
            return -999

    def buy_limit(self, accno, code, qty, price):
        return self.send_order(accno, code, qty, price, 1, "00")

    def buy_market(self, accno, code, qty):
        return self.send_order(accno, code, qty, 0, 1, "03")

    def sell_limit(self, accno, code, qty, price):
        return self.send_order(accno, code, qty, price, 2, "00")

    def sell_market(self, accno, code, qty):
        return self.send_order(accno, code, qty, 0, 2, "03")

    def cancel_buy(self, accno, code, qty, org_no):
        return self.send_order(accno, code, qty, 0, 3, "00", org_no)

    def cancel_sell(self, accno, code, qty, org_no):
        return self.send_order(accno, code, qty, 0, 4, "00", org_no)

    def modify_sell(self, accno, code, qty, price, org_no):
        """매도정정(otype 6) — 낮은가격 정정=즉시 시장체결(손절·이중매도 없음)."""
        return self.send_order(accno, code, qty, price, 6, "00", org_no)

    # ── 계좌 조회: 보유잔고(수익률)·미체결 ──
    def holdings(self, accno):
        """opw00018 계좌평가잔고 — 총계 + 종목별 보유수량/매입가/현재가/수익률."""
        self.dynamicCall("SetInputValue(QString,QString)", "계좌번호", accno)
        self.dynamicCall("SetInputValue(QString,QString)", "비밀번호", "")
        self.dynamicCall("SetInputValue(QString,QString)", "비밀번호입력매체구분", "00")
        self.dynamicCall("SetInputValue(QString,QString)", "조회구분", "2")
        self.tr_data = None
        if self._request("잔고", "opw00018", screen="9110") != 0:
            return None
        return self.tr_data

    def deposit(self, accno, ceiling=None):
        """opw00001 예수금상세 — 예수금(현금)·주문가능·출금가능.

        ceiling = **추정예탁자산**(opw00018 `holdings()["assets"]`). 매수 여력의 천장이다.
          ★반드시 opw00018 의 순수 조회값만 넘겨라. `self.acct["assets"]` 는 조회 실패 때
            예수금으로 대체되는 값이라(`hold.get("assets") or dep.get("cash")`) 그걸 넘기면
            2026-09-28 에 고친 버그가 그대로 되살아난다.
          ★None·0 이면 **천장을 씌우지 않는다** — 조회 한 번 안 와서 그날 매수가 깎이는 게 더 나쁘다."""
        self.dynamicCall("SetInputValue(QString,QString)", "계좌번호", accno)
        self.dynamicCall("SetInputValue(QString,QString)", "비밀번호", "")
        self.dynamicCall("SetInputValue(QString,QString)", "비밀번호입력매체구분", "00")
        self.dynamicCall("SetInputValue(QString,QString)", "조회구분", "2")
        self.tr_data = None
        if self._request("예수금", "opw00001", screen="9112") != 0:
            return None
        d = self.tr_data
        # ★`100%종목주문가능금액` 이 **간헐적으로 빠져서** 온다(2026-09-23 실측).
        #   그 값이 실제 매수 여력이고, 없으면 '주문가능금액'(출금 기준·작은 값)으로 물러나
        #   그날 매수가 작아진다. → 한 번만 다시 물어본다. 두 번째도 없으면 그대로 간다
        #   (작게 사는 건 안전한 실패다).
        #   ★재조회 판정은 **천장을 씌우기 전**에 한다 — 씌운 뒤 `orderable_src` 를 손대므로
        #     순서가 바뀌면 매번 재조회(TR 2배)가 된다.
        if isinstance(d, dict) and d.get("orderable_src") != "100%종목주문가능금액":
            self.tr_data = None
            if self._request("예수금재조회", "opw00001", screen="9112") == 0 and isinstance(self.tr_data, dict):
                if self.tr_data.get("orderable_src") == "100%종목주문가능금액":
                    return self._cap_orderable(self.tr_data, ceiling)
            return self._cap_orderable(d, ceiling)
        return self._cap_orderable(d, ceiling)

    @staticmethod
    def _cap_orderable(d, ceiling):
        """매수 여력의 천장을 **추정예탁자산**으로 씌운다 (2026-09-28).

        예전 천장은 `예수금` 이었는데 그 필드가 계좌에 따라 **출금가능금액과 같은 값**
        (D+2 인출 기준)으로 온다. 그러면 매도 다음 날 매수가 통째로 깎인다
        (관리자 실측: 종목당 140,970 vs 1,302,219 = 9.2배).
        계좌 전체 가치를 넘겨 사지 않는다는 뜻은 남기고, 기준만 인출 → 예탁자산으로 바꾼 것이다.
        ★천장이 없거나(None·0) 실제로 물지 않으면 값을 **하나도 건드리지 않는다.**"""
        if not isinstance(d, dict):
            return d
        try:
            _c = int(ceiling or 0)
        except Exception:
            _c = 0
        if _c <= 0:
            return d                                  # ★천장 미전달·조회 실패 = 깎지 않는다
        _o = int(d.get("orderable") or 0)
        if _o > _c:
            d["orderable"] = _c
            d["orderable_uncapped"] = _o              # 원래 값을 남긴다 — 나중에 왜 깎였는지 보려고
            d["orderable_src"] = (d.get("orderable_src") or "?") + "→추정예탁자산 상한"
        return d

    def pending(self, accno):
        """opt10075 실시간미체결 — 미체결 주문(거래대기) 목록."""
        self.dynamicCall("SetInputValue(QString,QString)", "계좌번호", accno)
        self.dynamicCall("SetInputValue(QString,QString)", "체결구분", "1")   # 1=미체결만
        self.dynamicCall("SetInputValue(QString,QString)", "매매구분", "0")   # 0=전체
        self.tr_data = None
        if self._request("미체결", "opt10075", screen="9111") != 0:
            # ★★조회 실패 = None (2026-09-29 수정). 예전엔 [] 를 돌려줬다.
            #   [] 는 '미체결 없음' 이라는 **사실**이고 None 은 '모른다' 다. 둘을 섞으면
            #   _ensure_closeout 이 "살아있는 주문 없음" 으로 오판해 **시장가를 또 발주**하고,
            #   애프터 이중매도 가드도 "걸어둔 주문 없음" 으로 읽어 같은 물량에 매도가 둘이 된다.
            #   관리자 kiwoom_trade.pending() 은 처음부터 None 이다 — 이제 같아졌다.
            return None
        return self.tr_data or []

    def today_journal(self, accno):
        """opt10170 당일매매일지 → [{code,name,sell_amt}] 오늘 매도완료(실체결가).
        ★계좌 자동동기화용 — 앱/외부(영웅문·MTS) 청산도 실제 체결금액으로 잡는다."""
        self.dynamicCall("SetInputValue(QString,QString)", "계좌번호", accno)
        self.dynamicCall("SetInputValue(QString,QString)", "비밀번호", "")
        self.dynamicCall("SetInputValue(QString,QString)", "단주구분", "1")
        self.dynamicCall("SetInputValue(QString,QString)", "현금신용구분", "1")
        self.tr_data = None
        if self._request("당일매매일지", "opt10170", screen="9170") != 0:
            return []
        return self.tr_data or []

    def minutes(self, code, tick="1"):
        """opt10080 주식분봉 — 오늘 09:00부터 [[HHMMSS, price]] 경로. 백필용."""
        self.dynamicCall("SetInputValue(QString,QString)", "종목코드", code)
        self.dynamicCall("SetInputValue(QString,QString)", "틱범위", tick)
        self.dynamicCall("SetInputValue(QString,QString)", "수정주가구분", "1")
        self.tr_data = None
        if self._request("분봉", "opt10080", screen="9114") != 0:
            return []
        return self.tr_data or []

    def _on_tr(self, scr, rqname, trcode, record, prevnext, *a):
        gi = lambda i, f: self.dynamicCall("GetCommData(QString,QString,int,QString)", trcode, rqname, i, f).strip()
        if trcode == "opt10080":
            cnt = self.dynamicCall("GetRepeatCnt(QString, QString)", trcode, rqname)
            rows = []
            for i in range(cnt):
                t = gi(i, "체결시간")            # YYYYMMDDHHMMSS
                px = abs(_int(gi(i, "현재가")))   # 그 분봉 종가
                op = abs(_int(gi(i, "시가")))     # 그 분봉 시가(첫봉=당일 개장가)
                if t and px:
                    rows.append((t, px, op))
            self.tr_data = rows                  # 최신→과거 순 (t, close, open)
            if self._tr_loop: self._tr_loop.exit()
            return
        if trcode == "opw00018":
            cnt = self.dynamicCall("GetRepeatCnt(QString, QString)", trcode, rqname)
            stocks = []
            for i in range(cnt):
                qty = _int(gi(i, "보유수량")); buy = _int(gi(i, "매입가")); cur = abs(_int(gi(i, "현재가")))
                if qty <= 0:
                    continue
                ret = round((cur / buy - 1) * 100, 2) if buy else 0.0
                stocks.append({"code": gi(i, "종목번호").lstrip("A").strip(), "name": _dec(gi(i, "종목명")),
                               "qty": qty, "buy": buy, "cur": cur, "ret": ret,
                               "pl": (cur - buy) * qty, "eval": cur * qty})
            tb = _int(gi(0, "총매입금액")); te = _int(gi(0, "총평가금액"))
            self.tr_data = {"stocks": stocks, "total_buy": tb, "total_eval": te,
                            "total_pl": te - tb, "total_ret": round((te / tb - 1) * 100, 2) if tb else 0.0,
                            "assets": _int(gi(0, "추정예탁자산"))}
            if self._tr_loop: self._tr_loop.exit()
            return
        if trcode == "opw00001":
            # ★★2026-09-22 실측 — `주문가능금액` 을 매수 여력으로 쓰면 **안 된다.**
            #     예수금 3,055,116 · 출금가능금액 260,841 · **주문가능금액 260,841**(출금가능과 동일)
            #     · 100%종목주문가능금액 2,699,480
            #   즉 '주문가능금액' 은 D+2 **인출** 기준이라 당일 매도대금이 빠진다.
            #   그 값으로 사이징하면 매도 직후 재매수가 막힌다 — 관리자에서 실제로
            #   269만을 쓸 수 있었는데 26만으로 보고 한 종목만 샀다.
            #   우리가 원하는 건 **현금으로 전액 결제 가능한 최대 매수금액**
            #   = 100%종목주문가능금액 이다(증거금 100% 기준이라 미수가 절대 안 난다.
            #     급등주는 대개 증거금 100% 다).
            #   ★안전장치: 예수금을 넘지 못하게 자른다 — 어떤 경우에도 현금보다 많이 사지 않는다.
            _cand = ("예수금", "예수금합계", "d+1추정예수금", "d+2추정예수금", "D+1추정예수금", "D+2추정예수금",
                     "출금가능금액", "주문가능금액", "미수확보금", "대용금",
                     "100%종목주문가능금액", "증거금100%종목주문가능금액",
                     "증거금50%종목주문가능금액", "증거금40%종목주문가능금액", "증거금30%종목주문가능금액",
                     "증거금20%종목주문가능금액")
            raw = {}
            for _f in _cand:
                _v = gi(0, _f)
                if _v not in ("", None):
                    _n = _int(_v)
                    if _n: raw[_f] = _n
            _cash = _int(gi(0, "예수금"))
            _ord = _int(gi(0, "주문가능금액"))
            _wd = _int(gi(0, "출금가능금액"))
            # ★★2026-09-28 — 여기 있던 `min(_c100, 예수금)` 상한을 **없앴다.**
            #   "현금보다 많이 사지 않게" 넣은 안전장치였는데, `예수금` 필드가 계좌에 따라
            #   **출금가능금액과 같은 값**(= D+2 인출 기준)으로 온다. 관리자 계좌 실측:
            #     추정예탁자산 2,804,438 · 100%종목주문가능금액 2,804,438  ← 원 단위 일치
            #     예수금 = 출금가능 = 주문가능 = 481,941  (차액이 5일 전 매도대금이었다)
            #   즉 그 상한이 **인출 기준으로 매수를 깎고** 있었다(종목당 9.2배 차이).
            #   ★미수 걱정은 필요 없다 — `100%종목주문가능금액` 은 증거금 100% 종목 기준이라
            #     증권사가 이미 '현금으로 전액 결제 가능' 을 보장해 계산한 값이다.
            #   ★천장은 `deposit(ceiling=추정예탁자산)` → `_cap_orderable()` 이 씌운다.
            #   ★`_cash > 0` 조건도 뗐다 — 예수금이 0/누락으로 와도 100%값이 있으면 그게 맞다.
            _c100 = raw.get("100%종목주문가능금액") or raw.get("증거금100%종목주문가능금액") or 0
            if _c100 > 0:
                _buy = _c100; _src = "100%종목주문가능금액"
            else:
                _buy = _ord; _src = "주문가능금액"
            self.tr_data = {"cash": _cash, "orderable": _buy, "orderable_src": _src,
                            "orderable_raw": _ord, "withdrawable": _wd, "raw": raw}
            if self._tr_loop: self._tr_loop.exit()
            return
        if trcode == "opt10170":                 # 당일매매일지 → 오늘 매도완료(★실측: 매도금액만 유효, 체결단가 등은 빈값)
            cnt = self.dynamicCall("GetRepeatCnt(QString, QString)", trcode, rqname)
            rows = []
            for i in range(cnt):
                code = gi(i, "종목코드").lstrip("A").strip()
                amt = abs(_int(gi(i, "매도금액")))    # 매도금액(총 매도대금) → sell가 = 금액÷수량
                if not code or amt <= 0:
                    continue
                rows.append({"code": code, "name": _dec(gi(i, "종목명")), "sell_amt": amt})
            self.tr_data = rows
            if self._tr_loop: self._tr_loop.exit()
            return
        if trcode == "opt10075":
            cnt = self.dynamicCall("GetRepeatCnt(QString, QString)", trcode, rqname)
            rows = []
            for i in range(cnt):
                rows.append({"code": gi(i, "종목코드").lstrip("A").strip(), "name": _dec(gi(i, "종목명")),
                             "order_no": gi(i, "주문번호").strip(), "gubun": _dec(gi(i, "주문구분")),
                             "order_qty": _int(gi(i, "주문수량")), "order_px": abs(_int(gi(i, "주문가격"))),
                             "unfilled": _int(gi(i, "미체결수량")), "status": _dec(gi(i, "주문상태"))})
            self.tr_data = rows
            if self._tr_loop: self._tr_loop.exit()
            return
        return super()._on_tr(scr, rqname, trcode, record, prevnext, *a)

    # ── 체결/잔고 이벤트 ──
    def _on_chejan(self, gubun, cnt, fids):
        g = lambda f: (self.dynamicCall("GetChejanData(int)", f) or "").strip()
        try:
            if gubun == "0":                      # 주문체결 통보
                self.fills.append({
                    "code": g(9001).lstrip("A"), "name": g(302), "order_no": g(9203),
                    "status": g(913),             # 접수/체결/확인
                    "order_qty": _int(g(900)), "filled_qty": _int(g(911)),
                    "unfilled": _int(g(902)), "fill_price": _int(g(910)),
                    "otype": g(905),              # 매수/매도
                })
            elif gubun == "1":                    # 잔고 통보
                code = g(9001).lstrip("A")
                self.positions[code] = {"qty": _int(g(930)), "avg": _int(g(931)), "name": g(302)}
        except Exception as e:
            if self.on_log:
                self.on_log(f"chejan 파싱오류 {e}")
