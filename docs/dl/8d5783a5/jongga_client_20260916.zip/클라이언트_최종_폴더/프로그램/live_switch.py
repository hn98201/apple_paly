# -*- coding: utf-8 -*-
"""실전 전환 도우미 — 키움을 혼자 쓸 수 있게 주변을 멈춘다. (2026-09-15)

왜 필요한가 (관리자 PC 에서 2026-09-15 실제로 당했다)
  "프로그램을 끄고 키움에 로그인하세요" 만으로는 부족하다.
  **워치독이 2분마다 프로그램을 되살린다.** 되살아난 프로그램이 로그인하는 도중에
  사람이 또 로그인을 누르면 키움 세션이 꼬여 `opstarter` 가 크래시하고,
  그 과정에서 **자동로그인 정보(Autologin.dat)가 통째로 날아간다.**
  그러면 다음 날 아침 무인 로그인이 안 된다.

쓰는 법  (실전전환_준비.bat 를 더블클릭해도 됩니다)
  python live_switch.py --on     전환 작업 시작 (워치독 정지 + 프로그램 종료)
  python live_switch.py --off    작업 끝 (원래대로 복구)
  python live_switch.py          지금 상태 보기

★--on 상태에서는 자동매매가 전혀 돌지 않습니다. **보유 종목이 없을 때**, 되도록
  **장 마감 후(15:35~)** 에 하세요. 끝나면 반드시 --off 로 되돌리세요.
"""
import io, os, sys, json, time, argparse, subprocess

try: sys.stdout.reconfigure(errors="replace")
except Exception: pass

DIR = os.path.dirname(os.path.abspath(__file__))
STATE = os.path.join(DIR, "client_state.json")
FLAG = os.path.join(DIR, ".live_switch")
# ★2026-09-16: 클라이언트는 예약작업을 쓰지 않는다. 이름만 남긴 건 옛 설치본에 남아 있을 수 있어서다.
T_START, T_WATCH = "종가배팅_클라이언트시작", "종가배팅_클라이언트감시"
LINE = "=" * 58
NOWIN = 0x08000000


def ps(c, timeout=30):
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-Command", c],
                           capture_output=True, timeout=timeout, creationflags=NOWIN)
        return (r.stdout or b"").decode("cp949", "replace").strip()
    except Exception as e:
        return "ERR:%s" % e


def task_state(name):
    return ps("$t=Get-ScheduledTask -TaskName '%s' -EA SilentlyContinue;"
              "if($t){$t.State}else{'NONE'}" % name)


def client_pids():
    out = ps("Get-CimInstance Win32_Process -Filter \"Name='python.exe' or Name='pythonw.exe'\" | "
             "Where-Object { $_.CommandLine -match 'client\\.py' } | ForEach-Object { $_.ProcessId }")
    return [x for x in out.split() if x.strip().isdigit()]


def kiwoom_procs():
    out = ps("Get-Process | Where-Object { $_.ProcessName -match 'opstarter|nkstarter|opversion' } | "
             "ForEach-Object { $_.ProcessName + ':' + $_.Id }")
    return [x for x in out.split() if x.strip()]


def holdings():
    try:
        st = json.load(io.open(STATE, encoding="utf-8"))
    except Exception:
        return []
    return [p for p in st.get("positions", []) if p.get("filled", 0) - p.get("sold", 0) > 0]


def show():
    print(LINE); print("  실전 전환 도우미 — 상태"); print(LINE)
    _w = task_state(T_WATCH)                             # ★옛 설치본이 남겼을 때만 보여 준다
    if _w not in ("NONE", ""):
        print("  옛 예약작업   : %s  ← 남아 있습니다([2_프로그램설치.bat] 이 지웁니다)" % _w)
    print("  프로그램      : %s" % (", ".join(client_pids()) or "꺼짐"))
    print("  키움 잔여     : %s" % (", ".join(kiwoom_procs()) or "없음"))
    h = holdings()
    print("  보유 종목     : %s" % (", ".join("%s %d주" % (p.get("name", "?"), p["filled"] - p.get("sold", 0))
                                             for p in h) or "없음"))
    print("  전환모드      : %s" % ("켜짐 ← 자동매매 안 돕니다" if os.path.exists(FLAG) else "꺼짐(정상 운영)"))
    print(LINE)


def turn_on(force):
    show()
    h = holdings()
    if h and not force:
        print("\n★보유 종목이 있습니다 — 전환모드로 들어가면 손익절이 돌지 않습니다.")
        print(" 장 마감 후에 하거나, 그래도 진행하려면 --force 를 붙이세요.")
        return 1

    print()
    print("① 옛 예약작업 정지 (남아 있으면 프로그램이 되살아나 로그인이 겹칩니다)")
    if task_state(T_WATCH) not in ("NONE", ""):          # ★이제 예약작업을 쓰지 않습니다(2026-09-16)
        ps("Disable-ScheduledTask -TaskName '%s' | Out-Null" % T_WATCH)
        print("   →", task_state(T_WATCH))
    else:
        print("   → 없음 (예약작업을 쓰지 않습니다)")

    print("\n② 프로그램 종료")
    pids = client_pids()
    for p in pids:
        ps("Stop-Process -Id %s -Force -EA SilentlyContinue" % p)
    if pids: time.sleep(2)
    print("   종료: %s → 남은 것: %s" % (", ".join(pids) or "없음", ", ".join(client_pids()) or "없음"))

    print("\n③ 키움 잔여 프로세스")
    k = kiwoom_procs()
    for x in k:
        ps("Stop-Process -Id %s -Force -EA SilentlyContinue" % x.split(":")[1])
    time.sleep(1)
    left = kiwoom_procs()
    if left:
        print("   ★남아 있음:", ", ".join(left))
        print("     작업관리자 → 세부 정보 → 해당 프로세스 → [작업 끝내기]")
    else:
        print("   정리 완료")

    io.open(FLAG, "w", encoding="utf-8").write(time.strftime("%Y-%m-%d %H:%M:%S"))
    print("\n" + LINE)
    print("  전환모드 켜짐 — 이제 키움을 혼자 쓸 수 있습니다")
    print(LINE)
    print("""
  다음 순서
    1. 실계좌에 입금이 됐는지 확인
    2. 프로그램 실행 → [자동매매 시작] → 키움 로그인 창
         · '모의투자 접속'   **체크 해제**
         · '자동로그인 설정' **체크**      ← 빼먹으면 매일 아침 창이 뜹니다
         · [공동인증] 으로 로그인
       ★USB 인증서를 꽂아두지 마세요 — 하드디스크 것과 중복되면 매번 물어봅니다
    3. [설정] 탭 → 실계좌 선택 → 저장 → [계좌비밀번호 등록] + AUTO 체크
    4. **원금(만원)** 을 실제 입금액으로 바꾸세요 — 모의 성적은 이월되지 않습니다
    5. 키움설정_점검.bat 로 ①~⑤ 가 전부 [OK] 인지 확인
    6. python live_switch.py --off    ← 반드시

  ⚠️ 끝나면 반드시 --off 를 하세요. 그래야 정상 운영으로 돌아옵니다.""")
    return 0


def turn_off():
    print("① 옛 예약작업 복구(남아 있을 때만)")
    if task_state(T_WATCH) not in ("NONE", ""):          # ★이제 예약작업을 쓰지 않습니다(2026-09-16)
        ps("Enable-ScheduledTask -TaskName '%s' | Out-Null" % T_WATCH)
        print("   →", task_state(T_WATCH))
    else:
        print("   → 없음 (예약작업을 쓰지 않습니다)")
    try: os.remove(FLAG)
    except Exception: pass
    print()
    print("② 바탕화면 [▶ 종가배팅 클라이언트] 를 눌러 다시 띄우세요.")
    print("\n" + LINE)
    print("  전환모드 꺼짐 — 정상 운영으로 돌아왔습니다")
    print(LINE)
    print("\n  ★확인: [자동매매 시작] 을 눌러야 매매가 돕니다.")
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--on", action="store_true")
    ap.add_argument("--off", action="store_true")
    ap.add_argument("--force", action="store_true")
    a = ap.parse_args()
    if a.on: return turn_on(a.force)
    if a.off: return turn_off()
    show()
    print("\n  python live_switch.py --on    전환 작업 시작")
    print("  python live_switch.py --off   작업 끝 · 정상 복구")
    return 0


if __name__ == "__main__":
    try:
        rc = main()
    except Exception as e:
        print("오류:", e); rc = 1
    try: input("\n엔터를 누르면 닫힙니다...")
    except Exception: pass
    sys.exit(rc)
