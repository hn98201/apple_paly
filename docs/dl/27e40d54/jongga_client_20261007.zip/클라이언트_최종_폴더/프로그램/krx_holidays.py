# -*- coding: utf-8 -*-
"""krx_holidays.py — KRX 평일 휴장일 목록 (2026-10-06 · 사용자 지시 "휴장일을 주말처럼").

왜 필요한가
  이 시스템은 주말만 알았다. 평일 휴장일에도 관리자·클라이언트가 평소처럼 로그인하고 청산·애프터 감시를 돌렸다.
  보유 중이면 15:19 청산이 거부되고 가짜 '15:19 종가청산' 기록·회의록·텔레그램이 생긴다(원장 기록은 10분 뒤 지워지지만
  회의록은 남는다). 그 10분 사이 프로그램이 죽으면 다음 거래일 하루 손절이 멈추고 원장이 이중계상된다(2026-10-06 추적).
  paper_store.next_business_day(= batch test_date)도 휴장일을 '다음 거래일' 로 잡았다(10-02 배치 → 10-05 대체휴일).

목록을 어떻게 만들었나
  지난 날짜 — 네이버 일봉에서 '평일인데 봉이 없는 날'(005930·000660 두 종목 일치 · 2026-10-06 확인).
  앞날짜   — 날짜가 고정된 휴일만: 10-09 한글날 · 12-25 성탄절 · 12-31 연말 휴장 · 2027-01-01 신정.
  ★2027 설·삼일절 이후·부처님오신날·추석·대체공휴일은 **넣지 않았다** — 음력·대체 규칙으로 날짜를 추측하지 않는다.
    KRX 가 매년 12월에 이듬해 휴장일을 공지한다 → 그때 HOLIDAYS 에 더하고 COVER_UNTIL 을 늘린다.
    COVER_UNTIL 이 45일 안으로 다가오면 관리자가 기동 때마다 로그(14일 안이면 텔레그램도)로 알린다.
  ★목록에 빠진 휴장일은 예전처럼 동작한다(평소대로 로그인 · 0종목 스캔). 틀린 날을 넣으면 그날 매매를 통째로 쉰다 —
    그래서 확인된 날짜만 넣는다.
  ★클라이언트는 **이 파일의 바이트 동일 사본**(클라이언트_최종_폴더/프로그램/krx_holidays.py)을 import 한다.
    프로그램_대조점검.py 가 두 파일을 바이트로 비교한다 — 여기를 고치면 사본도 똑같이 고치고 클라이언트를 재배포할 것.

이 모듈은 네트워크·파일을 안 쓴다(관리자 15:20 매매 경로의 paper_store 가 부른다).
"""
import datetime

HOLIDAYS = frozenset({
    # 2026 — 네이버 일봉으로 확인한 지난 휴장일
    "2026-01-01", "2026-02-16", "2026-02-17", "2026-02-18", "2026-03-02", "2026-05-01", "2026-05-05",
    "2026-05-25", "2026-06-03", "2026-07-17", "2026-08-17", "2026-09-24", "2026-09-25", "2026-10-05",
    # 앞날짜 — 날짜가 고정된 휴일만
    "2026-10-09", "2026-12-25", "2026-12-31", "2027-01-01",
})
COVER_UNTIL = "2027-01-01"          # 이 날까지는 목록을 믿는다 — 그 뒤의 평일 휴장일은 아직 모른다


def _iso(d=None):
    if d is None:
        d = datetime.date.today()
    if isinstance(d, str):
        return d[:10]
    return d.strftime("%Y-%m-%d")


def _date(d=None):
    if d is None:
        return datetime.date.today()
    if isinstance(d, str):
        return datetime.date.fromisoformat(d[:10])
    if isinstance(d, datetime.datetime):
        return d.date()
    return d


def is_holiday(d=None):
    """평일 휴장일인가(주말은 False — 주말은 원래 다들 안다)."""
    dd = _date(d)
    return dd.weekday() < 5 and _iso(dd) in HOLIDAYS


def is_closed(d=None):
    """장이 안 열리는 날인가 — 주말 또는 평일 휴장일."""
    dd = _date(d)
    return dd.weekday() >= 5 or _iso(dd) in HOLIDAYS


def next_trading_day(d=None):
    """d 다음 거래일(date). 주말·휴장일을 건너뛴다."""
    nd = _date(d) + datetime.timedelta(days=1)
    while is_closed(nd):
        nd += datetime.timedelta(days=1)
    return nd


def cover_days_left(today=None):
    """목록을 믿을 수 있는 남은 일수(COVER_UNTIL − 오늘)."""
    return (datetime.date.fromisoformat(COVER_UNTIL) - _date(today)).days
