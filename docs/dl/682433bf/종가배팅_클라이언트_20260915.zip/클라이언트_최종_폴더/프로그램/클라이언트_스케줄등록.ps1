﻿# 종가배팅 클라이언트 - 운영 스케줄 자동등록
# 평일 08:25 자동실행 + 2분마다 워치독(운영시간만 재실행)
# 프로그램 자체가 08:30 키움로그인 -> 17:00 종료 -> 야간/주말 종료를 자동 처리.
# ※ 관리자 승인(라이선스)이 되어 있어야 자동매매가 시작됩니다.
$ErrorActionPreference = "Stop"
$d    = $PSScriptRoot
$bat  = Join-Path $d 'run_client.bat'
$vbs  = Join-Path $d 'run_client.vbs'      # cmd창 없이 실행
$wvbs = Join-Path $d 'run_watchdog.vbs'    # ★워치독도 무창(-WindowStyle Hidden 은 깜빡임을 못 막는다)
$wd   = Join-Path $d 'client_watchdog.ps1'

if (-not (Test-Path $bat)) { Write-Host "[오류] run_client.bat 없음: $bat" -ForegroundColor Red; return }
if (-not (Test-Path $wd))  { Write-Host "[오류] client_watchdog.ps1 없음: $wd" -ForegroundColor Red; return }

# 1) 08:25 시작 (월~금) — auto 인자로 무인 생명주기 적용(17:00 종료 등)
schtasks /Create /TN '종가배팅_클라이언트시작' /TR ('wscript.exe "' + $vbs + '" auto') /SC WEEKLY /D MON,TUE,WED,THU,FRI /ST 08:25 /F | Out-Null

# 2) 2분마다 워치독 (운영시간 판정은 client_watchdog.ps1 내부)
if (Test-Path $wvbs) {
    schtasks /Create /TN '종가배팅_클라이언트감시' /TR ('wscript.exe "' + $wvbs + '"') /SC MINUTE /MO 2 /F | Out-Null
} else {
    schtasks /Create /TN '종가배팅_클라이언트감시' /TR ('powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $wd + '"') /SC MINUTE /MO 2 /F | Out-Null
}

# 3) 전원·놓친작업 보정 — 노트북 배터리에서도 돌고, PC가 꺼져 있던 시간은 켜지는 즉시 따라잡는다
foreach ($t in @('종가배팅_클라이언트시작','종가배팅_클라이언트감시')) {
    try {
        $st = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
                -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero)
        Set-ScheduledTask -TaskName $t -Settings $st | Out-Null
    } catch { Write-Host "[경고] $t 전원설정 보정 실패 (동작에는 지장 없음)" -ForegroundColor Yellow }
}

Write-Host ""
Write-Host "[완료] 클라이언트 스케줄 등록됨" -ForegroundColor Green
Write-Host "  - 종가배팅_클라이언트시작 : 평일(월~금) 08:25 자동실행"
Write-Host "  - 종가배팅_클라이언트감시 : 2분마다 감시(운영시간만 재실행)"
Write-Host ""
Write-Host "동작: 08:25 실행 -> 08:30 키움로그인 -> 매매대기 -> 17:00 종료 -> 야간/주말 종료 (전부 자동)"
Write-Host "※ 관리자 승인(라이선스) 필요 + PC 전원 ON + 윈도우 로그인(세션) 유지. 자동로그인 권장."
