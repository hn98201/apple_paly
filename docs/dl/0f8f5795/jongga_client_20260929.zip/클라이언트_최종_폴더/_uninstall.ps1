﻿# 종가배팅 클라이언트 - 기존 설치 정리 (재설치/업그레이드용)
#
# 새 PC 면 이 단계는 필요 없다. 이미 깔려 있던 PC 에서만 1단계 前에 한 번 돌린다.
# 지우지 않고 **이름만 바꾼다** — 잘못돼도 되돌릴 수 있게.
param([switch]$Elevated)

# ── 관리자 권한으로 스스로 올라간다 (2026-09-18) ──────────────────
#    클라이언트가 JonggaClientRun(RunLevel Highest)으로 뜨기 때문에,
#    일반 권한으로는 그 프로세스를 못 죽이고 예약작업도 못 지운다.
#    ★경로를 따옴표로 감싸 넘긴다 — 안 그러면 공백 있는 경로(OneDrive\바탕 화면)에서 잘린다.
#      프로그램\권한지갑_등록.ps1 이 쓰는 검증된 패턴과 같다.
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
           ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

# ── 로그 (2026-09-29 신설) ─────────────────────────────────────────
#    "렉 걸리고 중단됐다 / 안 된다" 신고가 반복됐는데 **아무 기록이 없었다.**
#    이제 스크립트 옆에 `_정리로그.txt` 를 남긴다. 실패하면 이 파일만 보내면 된다.
#    ★권한 상승 **전에** 켜야 한다 — 취소된 경우도 남겨야 하니까.
#    ★쓰기가 막힌 위치(읽기전용 매체)면 TEMP 로 물러난다.
$LOG = Join-Path $PSScriptRoot "_정리로그.txt"
try { Start-Transcript -Path $LOG -Append -Force -ErrorAction Stop | Out-Null }
catch {
    $LOG = Join-Path $env:TEMP "종가배팅_정리로그.txt"
    try { Start-Transcript -Path $LOG -Append -Force -ErrorAction Stop | Out-Null } catch { $LOG = $null }
}
$SW = [Diagnostics.Stopwatch]::StartNew()
function Step($m) {
    # 각 줄에 **누적 초**를 붙인다 — 어디서 오래 걸렸는지 로그만 보면 안다.
    Write-Host ("[{0,6:N1}s] {1}" -f $SW.Elapsed.TotalSeconds, $m)
}
Step ("시작 · 관리자={0} · Elevated={1} · PS={2} · OS={3}" -f $isAdmin, [bool]$Elevated,
      $PSVersionTable.PSVersion, [Environment]::OSVersion.Version)
Step ("스크립트 위치 : " + $PSScriptRoot)
if ($LOG) { Step ("로그 파일     : " + $LOG) }
if (-not $isAdmin -and -not $Elevated) {
    Write-Host ""
    Write-Host "  옛 버전을 지우려면 관리자 권한이 필요합니다." -ForegroundColor Cyan
    Write-Host "  -> 잠시 후 뜨는 창에서 [예] 를 눌러 주세요."
    Write-Host ""
    try {
        Start-Process powershell -Verb RunAs -Wait -ArgumentList @(
            "-NoProfile","-ExecutionPolicy","Bypass","-File","`"$PSCommandPath`"","-Elevated")
    } catch {
        Write-Host "[중단] 권한 상승이 실패했습니다." -ForegroundColor Red
        Write-Host ("        사유: " + $_.Exception.Message) -ForegroundColor Red
        Write-Host "        ※ 이 창을 닫고 [0_기존버전_정리.bat] 을" -ForegroundColor Yellow
        Write-Host "           **마우스 오른쪽 > 관리자 권한으로 실행** 하면 이 단계가 생략됩니다." -ForegroundColor Yellow
        Write-Host "       권한 창에서 [예] 를 눌러야 옛 버전이 제거됩니다. 다시 실행해 주세요." -ForegroundColor Red
        Read-Host "`nEnter 를 눌러 닫기"
    }
    exit 0
}

$ErrorActionPreference = "SilentlyContinue"
$root = $PSScriptRoot
$prg  = Join-Path $root "프로그램"
$keep = Join-Path $prg "_이전설정"          # 여기로 개인설정을 인계한다(설치 2단계가 읽는다)
$TASKS = @('종가배팅_클라이언트시작','종가배팅_클라이언트감시','JonggaClientRun')   # ★JonggaClientRun = 권한지갑(2026-09-17)

# ★★예약작업 조회는 schtasks 로 한다 (2026-09-29 수정 · 실측).
#   `Get-ScheduledTask -TaskName <이름>` 은 **건당 약 2초**다(없는 이름이든 있는 이름이든).
#   예전엔 이걸 9번 불러(탐색3+표시3+삭제전확인3) 탐색 구간이 **19.3초**였고,
#   그 사이 화면에 아무 출력이 없어 "렉 걸리고 한참 있다가 멈췄다" 는 신고가 들어왔다.
#   전체 조회(`Get-ScheduledTask` 인자 없이)도 작업 205개인 PC 에서 **5~9초**다.
#   `schtasks /Query` 는 3개 합쳐 **371ms**, `/XML` 은 **113ms** 다 → 38배 빠르다.
function TaskExists($n) { schtasks /Query /TN $n 2>$null | Out-Null; return ($LASTEXITCODE -eq 0) }
function TaskPaths($n) {
    # 그 작업이 실행하는 것의 경로들(Command·Arguments·WorkingDirectory)을 돌려준다.
    # ★WorkingDirectory 도 본다 — 예전엔 Execute+Arguments 만 봐서 그걸 놓쳤다.
    $x = (schtasks /Query /TN $n /XML 2>$null) -join "`n"
    if (-not $x) { return @() }
    $out = @()
    foreach ($tag in 'Command','Arguments','WorkingDirectory') {
        foreach ($m in [regex]::Matches($x, "<$tag>(.*?)</$tag>", 'Singleline')) { $out += $m.Groups[1].Value }
    }
    return $out
}
Step "예약작업 확인 시작"
Write-Host "예약작업 확인 중... " -NoNewline
$HAVE = @{}
foreach ($t in $TASKS) { $HAVE[$t] = (TaskExists $t) }
$nHave = @($TASKS | Where-Object { $HAVE[$_] }).Count
Write-Host "완료 ($nHave 개 발견)" -ForegroundColor DarkGray

Write-Host "============================================"
Write-Host "  [0단계] 기존 설치 정리 (재설치/업그레이드)" -ForegroundColor Cyan
Write-Host "============================================`n"
Write-Host "새로 설치하는 PC 라면 이 단계는 건너뛰고 [1_PC변형_먼저실행.bat] 부터 하세요.`n"

# ── 1) 옛 설치 폴더 찾기 ───────────────────────────────────────────
#    ★각 단계에 진행 표시를 넣는다 — 예전엔 여기서 20초 가까이 아무 출력이 없어
#      멈춘 것처럼 보였다(2026-09-29).
#    예약작업의 실행경로가 가장 확실하다. 그게 없으면 바로가기·흔한 위치를 본다.
$found = New-Object System.Collections.Generic.List[string]
function AddDir($p) {
    if (-not $p) { return }
    $p = $p.Trim('"').Trim()
    if (-not (Test-Path -LiteralPath $p)) { return }
    $d = (Resolve-Path -LiteralPath $p).Path
    $cp = Join-Path $d "client.py"
    if (-not (Test-Path -LiteralPath $cp)) { return }
    # ★지금 설치하려는 이 키트 안쪽은 건드리지 않는다(자기 자신을 옛 설치로 오인 방지).
    #   예전엔 client.py 내용으로 '최신인지' 판별했는데, 새 버전끼리 갱신할 때
    #   옛 폴더를 '이미 최신'으로 보고 **설정 인계도 폴더 정리도 건너뛰는** 버그가 있었다.
    $kit = (Resolve-Path -LiteralPath $PSScriptRoot).Path
    if ($d -eq $kit -or $d.StartsWith($kit + [IO.Path]::DirectorySeparatorChar)) {
        Write-Host "  (건너뜀·이번에 설치할 폴더) $d" -ForegroundColor DarkGray
    Step "중단(위 사유)"
    try { Stop-Transcript | Out-Null } catch {}
        return
    }
    if ($found -notcontains $d) { $found.Add($d) }
}

Step "옛 설치 폴더 탐색 시작"
Write-Host "옛 설치 폴더 찾는 중... " -NoNewline
foreach ($t in $TASKS) {
    if (-not $HAVE[$t]) { continue }
    foreach ($sv in (TaskPaths $t)) {
        $m = [regex]::Matches($sv, '"?([A-Za-z]:\\[^"]+?\.(vbs|bat|ps1|py))"?')
        foreach ($g in $m) { AddDir (Split-Path -Parent $g.Groups[1].Value) }
        # WorkingDirectory 처럼 확장자 없는 폴더 경로도 후보다
        if ($sv -match '^[A-Za-z]:\\' -and $sv -notmatch '\.\w+$') { AddDir $sv }
    }
}

Step "바로가기·바탕화면 확인 시작"
Write-Host "바로가기·바탕화면 확인... " -NoNewline
$lnk = Join-Path ([Environment]::GetFolderPath('Desktop')) "▶ 종가배팅 클라이언트.lnk"
if (Test-Path -LiteralPath $lnk) {
    $sh = New-Object -ComObject WScript.Shell
    AddDir ($sh.CreateShortcut($lnk)).WorkingDirectory
}
# ★바탕화면은 OneDrive 로 리디렉션돼 있을 수 있다 — 둘 다 본다(한쪽만 보면 못 찾는다)
$desks = @([Environment]::GetFolderPath('Desktop'), "$env:USERPROFILE\Desktop",
           "$env:USERPROFILE\OneDrive\Desktop", "$env:USERPROFILE\OneDrive\바탕 화면") |
         Where-Object { $_ } | Select-Object -Unique
foreach ($dk in $desks) {
    foreach ($sub in @("종가배팅_클라이언트", "클라이언트_최종_폴더\프로그램",
                       "종가배팅클라이언트", "클라이언트")) { AddDir (Join-Path $dk $sub) }
}
foreach ($c in @("$env:USERPROFILE\Documents\종가배팅_클라이언트",
                 "C:\종가배팅_클라이언트", "C:\종가배팅클라이언트")) { AddDir $c }

# 지금 설치하려는 폴더 자신은 대상이 아니다(같은 자리에 덮어쓰는 경우)
Write-Host "완료" -ForegroundColor DarkGray
$self = if (Test-Path -LiteralPath $prg) { (Resolve-Path -LiteralPath $prg).Path } else { "" }
$old = @($found | Where-Object { $_ -ne $self })

Write-Host "── 찾은 것 ──────────────────────────────"
if ($old.Count -gt 0) { foreach ($d in $old) { Write-Host "  옛 설치 폴더 : $d" -ForegroundColor Yellow } }
else                  { Write-Host "  옛 설치 폴더 : 없음(또는 같은 자리에 덮어쓰는 중)" }
foreach ($t in $TASKS) {
    if ($HAVE[$t]) { Write-Host "  예약작업     : $t" -ForegroundColor Yellow }
}
$run = Get-CimInstance Win32_Process -Filter "Name='python.exe' or Name='pythonw.exe'" |
       Where-Object { $_.CommandLine -match 'client\.py' }
if ($run) { Write-Host "  실행 중      : client.py ($($run.Count)개)" -ForegroundColor Yellow }
Write-Host ""

Write-Host "── 할 일 ────────────────────────────────"
Write-Host "  1. 실행 중인 클라이언트 종료   (파일이 잠겨 있으면 못 고친다)"
Write-Host "  2. 옛 예약작업 삭제            (안 지우면 옛 폴더의 옛 코드가 계속 뜬다)"
Write-Host "  3. 계좌·닉네임·거래기록 인계   (_이전설정 폴더로 복사 → 설치 2단계가 읽음)"
Write-Host "  4. 옛 폴더 이름만 변경         (_구버전_날짜 · 지우지 않음)"
Write-Host "  5. 옛 바탕화면 바로가기 삭제"
Write-Host ""
# ★묻지 않고 바로 진행한다(2026-09-18 사용자 지시).
#   이 배치를 실행한 것 자체가 하겠다는 뜻이고, 되돌릴 수 있는 작업만 하기 때문이다:
#   폴더는 **지우지 않고 이름만** 바꾸고(_구버전_날짜), 설정·거래기록은 _이전설정 으로 인계한다.
Write-Host "바로 진행합니다 (폴더는 지우지 않고 _구버전_날짜 로 이름만 바꿉니다)" -ForegroundColor Cyan
Write-Host ""

# ── 2) 옛 예약작업을 **먼저** 삭제 ────────────────────────────────
#    ★순서가 중요하다 (2026-09-29 수정).
#      예전엔 프로세스를 먼저 죽이고 작업을 지웠다. 그런데 옛 `종가배팅_클라이언트감시` 는
#      **2분마다** 클라이언트를 되살린다. 죽인 뒤 작업을 지우는 사이(수 초)에 그게 발화하면
#      클라이언트가 다시 떠서 아래 **폴더 이름 변경이 파일 잠김으로 실패**한다.
#      그러면 옛 폴더가 그대로 남아 실수로 옛 client.py 를 띄울 수 있다(이중매매).
#      → **되살릴 주체를 먼저 없애고, 그 다음에 죽인다.**
Step "예약작업 삭제 시작"
$badtask = @()
foreach ($t in $TASKS) {
    if ($HAVE[$t]) {
        schtasks /Delete /TN $t /F | Out-Null
        Start-Sleep -Milliseconds 300
        if (TaskExists $t) {          # ★지워졌는지 확인(권한 부족이면 그대로 남는다)
            $badtask += $t
            Write-Host "[실패] 예약작업 삭제 실패 : $t" -ForegroundColor Red
        } else {
            Write-Host "[OK] 예약작업 삭제 : $t"
        }
    }
}
if ($badtask.Count -gt 0) {
    Write-Host ""
    Write-Host "[!] 예약작업이 남아 있습니다 — 옛 폴더를 계속 띄울 수 있습니다." -ForegroundColor Red
    Write-Host "    [0_기존버전_정리.bat] 을 마우스 오른쪽 > 관리자 권한으로 실행 해 주세요." -ForegroundColor Red
    Read-Host "확인했으면 Enter"
    Step "중단(위 사유)"
    try { Stop-Transcript | Out-Null } catch {}
    return
}

# ── 3) 실행 중인 클라이언트 종료 ──────────────────────────────────
#    ★작업을 지운 뒤라 이제는 되살아나지 않는다.
#      목록을 **여기서 다시 잡는다** — 위(찾기 단계)에서 잡아 둔 것은 낡았을 수 있다.
Step "실행 중인 클라이언트 조회 시작"
$run = @(Get-CimInstance Win32_Process -Filter "Name='python.exe' or Name='pythonw.exe'" |
         Where-Object { $_.CommandLine -match 'client\.py' })
#    ★먼저 멈춰야 한다 — 메모리의 state 가 파일을 덮어쓰고, 파일도 잠긴다.
$n = 0
foreach ($p in $run) { Stop-Process -Id $p.ProcessId -Force; $n++ }
if ($n -gt 0) { Start-Sleep -Seconds 2 }
# ★진짜 죽었는지 확인한다(2026-09-17).
#   클라이언트는 최고권한으로 뜨므로 일반 권한에서는 Stop-Process 가 조용히 실패한다.
#   $ErrorActionPreference=SilentlyContinue 라 오류도 안 보인다 — 그래서 직접 센다.
$still = @(Get-CimInstance Win32_Process -Filter "Name='pythonw.exe' OR Name='python.exe'" |
           Where-Object { $_.CommandLine -like '*client.py*' })
if ($still.Count -gt 0) {
    Write-Host "[실패] 클라이언트 $($still.Count) 개가 아직 살아 있습니다" -ForegroundColor Red
    Write-Host "       이 창을 닫고 [0_기존버전_정리.bat] 을 **마우스 오른쪽 > 관리자 권한으로 실행** 하세요." -ForegroundColor Red
    Write-Host "       그대로 두면 옛 버전이 계속 매매합니다." -ForegroundColor Red
    Read-Host "확인했으면 Enter"
    Step "중단(위 사유)"
    try { Stop-Transcript | Out-Null } catch {}
    return
}
Write-Host "[OK] 실행 중인 클라이언트 $n 개 종료 (확인 완료)"

# ── 4) 개인설정 인계 ──────────────────────────────────────────────
#    계좌·닉네임·원금·텔레그램·거래기록은 그 사람 것이다. 전략값은 새 것을 쓴다(설치 2단계가 가른다).
$src = if ($old.Count -gt 0) { $old[0] } else { $prg }
if (-not (Test-Path -LiteralPath $keep)) { New-Item -ItemType Directory -Path $keep -Force | Out-Null }
$got = 0
Step "개인설정 인계 시작"
foreach ($f in @("client_config.json","client_state.json","client_log.txt")) {
    $s = Join-Path $src $f
    if (Test-Path -LiteralPath $s) { Copy-Item -LiteralPath $s -Destination (Join-Path $keep $f) -Force; $got++ }
}
if ($got -gt 0) { Write-Host "[OK] 이전 설정 $got 개 인계 → 프로그램\_이전설정\  (설치 2단계가 자동 병합)" }
else            { Write-Host "[--] 인계할 이전 설정 없음 (새로 입력하면 됩니다)" }

# ── 5) 옛 폴더 이름 변경 (삭제 아님) ──────────────────────────────
foreach ($d in $old) {
    $stamp = Get-Date -Format "yyyyMMdd_HHmm"
    $new = "$d`_구버전_$stamp"
    Rename-Item -LiteralPath $d -NewName (Split-Path -Leaf $new) -Force
    if (Test-Path -LiteralPath $new) { Write-Host "[OK] 옛 폴더 보관   : $new" }
    else {
        Write-Host "[경고] 폴더 이름을 못 바꿨습니다 (파일이 열려 있거나 사용 중)" -ForegroundColor Yellow
        Write-Host "       $d" -ForegroundColor Yellow
        Write-Host "       설정 인계와 예약작업 삭제는 이미 끝났습니다." -ForegroundColor Yellow
        Write-Host "       이 폴더를 직접 다른 이름으로 바꾸거나 지우세요 — 그냥 두면" -ForegroundColor Yellow
        Write-Host "       실수로 옛 client.py 를 띄워 이중매매가 날 수 있습니다." -ForegroundColor Yellow
    }
}

# ── 6) 옛 바로가기 삭제 (설치 2단계가 새로 만든다) ────────────────
# ★바탕화면이 OneDrive 로 리디렉션된 PC 는 경로가 둘일 수 있다 — 위 $desks 전부 본다(2026-09-29).
foreach ($dk in $desks) {
    $L2 = Join-Path $dk "▶ 종가배팅 클라이언트.lnk"
    if (Test-Path -LiteralPath $L2) { Remove-Item -LiteralPath $L2 -Force; Write-Host "[OK] 옛 바로가기 삭제 : $L2" }
}

# ── 7) 묵은 파이썬 캐시 ───────────────────────────────────────────
$pc = Join-Path $prg "__pycache__"
if (Test-Path -LiteralPath $pc) { Remove-Item -LiteralPath $pc -Recurse -Force; Write-Host "[OK] 파이썬 캐시 정리" }

# ── 무엇을 했는지 요약 ───────────────────────────────────────────
#    ★"옛 설치 폴더 : 없음" 이 실패처럼 읽힌다는 지적이 있었다(2026-09-18).
#      같은 자리에 덮어쓰면 옛 폴더가 따로 없는 게 정상이다. 한 일을 숫자로 보여 준다.
Write-Host "`n── 한 일 ────────────────────────────────" -ForegroundColor Cyan
Write-Host "  실행 중인 클라이언트 종료 : $n 개"
Write-Host "  예약작업 삭제             : $($TASKS.Count) 개 검사"
Write-Host "  개인설정 인계             : $got 개 → 프로그램\_이전설정\"
if ($old.Count -gt 0) { Write-Host "  옛 폴더 보관              : $($old.Count) 개 (_구버전_날짜)" }
else { Write-Host "  옛 폴더                   : 따로 없음 (같은 자리에 덮어쓰는 경우 — 정상입니다)" }
Write-Host "`n정리 완료! 이제 [1_PC변형_먼저실행.bat] 부터 순서대로 실행하세요." -ForegroundColor Green
Write-Host "옛 폴더는 지우지 않고 '_구버전_날짜' 로 남겨 뒀습니다. 며칠 써 보고 문제 없으면 지우세요."

# ★반드시 멈춘다 — 권한 상승으로 새로 뜬 창은 끝나면 즉시 닫혀서
#   사용자가 결과를 못 읽는다("작동 안 한 듯" 으로 보인다).
Step "끝"
if ($LOG) {
    Write-Host ""
    Write-Host ("기록을 남겼습니다 : " + $LOG) -ForegroundColor Cyan
    Write-Host "  문제가 있으면 이 파일을 그대로 보내 주세요 — 어디서 멈췄는지 시간까지 적혀 있습니다."
}
try { Stop-Transcript | Out-Null } catch {}
Read-Host "`n확인했으면 Enter 를 눌러 창을 닫으세요"
