# -*- coding: utf-8 -*-
"""이전 설치의 개인설정을 새 설정에 병합한다. (_install.ps1 이 호출)

가르는 기준
  개인값  = 그 사람 것    → 이전 값을 **가져온다** (계좌·닉네임·원금·텔레그램…)
  전략값  = 관리자 것     → 새 값을 **강제한다**  (익절·손절·종목당·사이징·게이트)

전략값을 안 덮으면 옛 client_config.json 이 그대로 남아 **익절3%/손절3%** 옛 전략으로 매매한다.
관리자와 다른 전략으로 도는 클라이언트는 밖에서 보이지 않으므로 반드시 여기서 맞춘다.
"""
import io, json, os, sys, datetime

# ★한글 콘솔(cp949)은 — 같은 문자를 못 찍고 print 가 그대로 죽는다 — 마이그레이션이 통째로 안 돌게 된다.
try: sys.stdout.reconfigure(errors="replace")
except Exception: pass

DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG = os.path.join(DIR, "client_config.json")
STATE = os.path.join(DIR, "client_state.json")
KEEP = os.path.join(DIR, "_이전설정")

PERSONAL = ("account", "nickname", "telegram_chat_id", "principal",
            "is_mock", "pw_registered", "hub_url", "card_pos",
            # ★2026-09-17 추가 — 이전엔 어느 쪽에도 없어 재설치 때 조용히 사라졌다
            "telegram_token",        # 각자 만든 봇 토큰 — 잃으면 알림이 끊긴다
            "mock_account",          # ★그 PC 의 모의계좌 번호 — 없으면 server_gubun 공백일 때 서버를 못 가린다
                                     #   (실서버 주문이 나가는데 원장에 '모의' 로 쌓이는 사고로 이어진다)
            "live_start_equity",     # 실전 시작자산 — 잃으면 실전 누적수익률 기준이 초기화된다
            "aftp_live",             # 애프터마켓 익절 스위치 — "켜고 끄기는 각자 한다"(2026-09-16)
            # ★익절은 **사용자가 설정에서 직접 정한다**(2026-09-28 사용자 확정).
            #   예전엔 아래 STRATEGY 에 있어서 재설치 때마다 관리자 값으로 덮였다 —
            #   사용자가 고른 익절이 말없이 날아갔다. 손절·종목당·게이트는 계속 강제한다
            #   (옛 3%/3% 전략이 남으면 위험하고, 그건 사용자가 고른 값이 아니라 옛 기본값이다).
            "tp_pct")
STRATEGY = ("sl_pct", "invest_per_stock", "fee_pct", "cash_buffer",
            "size_div", "min_positions", "gapcut_pct", "float_max", "exclude_upper",
            # ★거래구분은 관리자가 정한다. 옛 값 "62"(폐지된 시간외단일가)가 남으면 주문이 거부된다
            "aftp_hoga")
# ★enabled·auto_start 는 일부러 어느 쪽에도 넣지 않는다 —
#   재설치 후 매매가 저절로 켜지면 안 되고(enabled=False), 자동재개는 기본값 True 가 맞다.


def load(p):
    try: return json.load(io.open(p, encoding="utf-8"))
    except Exception: return None


def save(p, o):
    io.open(p, "w", encoding="utf-8", newline="").write(json.dumps(o, ensure_ascii=False, indent=1))


def main():
    if not os.path.isdir(KEEP):
        print("[--] 이전 설정 없음 - 새로 설치하는 PC 입니다"); return 0

    new = load(CONFIG)
    if new is None:
        print("[오류] client_config.json 을 읽을 수 없습니다"); return 1

    old = load(os.path.join(KEEP, "client_config.json"))
    if old:
        _tp_new = new.get("tp_pct")          # ★배포 기본 익절 — 아래 PERSONAL 루프가 덮기 전에 잡아둔다
        took = []
        for k in PERSONAL:
            v = old.get(k)
            if v in (None, "", {}): continue
            new[k] = v; took.append(k)
        save(CONFIG, new)
        print("[OK] 개인설정 인계 :", ", ".join(took) if took else "(가져올 값 없음)")
        # ★익절은 사용자 값을 이어받으므로 '새 값 유지' 라고 쓰면 거짓이 된다 — 갈라서 적는다.
        print("[OK] 익절 +%g%% — **이전 PC 에서 쓰던 값을 그대로 이어받았습니다**(설정에서 바꾸세요)"
              % new.get("tp_pct", 0))
        # ★익절이 배포 기본보다 **낮으면 크게 알린다** (2026-09-29 · 배포전 검토).
        #   tp_pct 는 사용자 값이라 강제하지 않는다(2026-09-28 확정). 그런데 옛 3%/3% 키트에서
        #   올라오는 사람의 3.0 은 **본인이 고른 값이 아니라 옛 기본값**이다. 손절만 새 값으로
        #   강제되므로 그대로 두면 익절 +3.0 / 손절 -3.5 — 관리자와 손익비가 어긋난 채로 돈다.
        #   밖에서는 안 보이므로 여기서 말하지 않으면 아무도 모른다.
        try:
            _tp_now = float(new.get("tp_pct") or 0)
            if _tp_new is not None and _tp_now < float(_tp_new):
                print("[!!] 익절이 배포 기본값보다 낮습니다 : +%g%% (배포 기본 +%g%%)"
                      % (_tp_now, float(_tp_new)))
                print("       옛 키트의 기본값(+3%)이 그대로 넘어온 것일 수 있습니다.")
                print("       손절은 %g%% 로 강제되므로 이대로 두면 손익비가 관리자와 달라집니다."
                      % new.get("sl_pct", 0))
                print("       그대로 쓰실 거면 두시고, 맞추려면 [설정] 탭에서 익절을 고치세요.")
        except Exception:
            pass
        print("[OK] 전략값은 새 값 강제 : 손절 %g%% / 종목당 %d만 / 갭컷 %g%%"
              % (new.get("sl_pct", 0), int(new.get("invest_per_stock", 0)) // 10000,
                 new.get("gapcut_pct", 0)))
        ch = [k for k in STRATEGY if old.get(k) != new.get(k)]
        if ch:
            print("[!!] 이전 PC 와 달라진 전략값 :")
            for k in ch: print("       %-18s %s -> %s" % (k, old.get(k), new.get(k)))
    else:
        print("[--] 이전 client_config.json 없음")

    # ── 상태파일: 거래기록만 살리고 포지션은 비운다 ──
    #    ★포지션을 그대로 옮기면 이미 판 종목이 유령으로 남아 유령 청산주문을 낸다.
    #      비워 두면 로그인 직후 query_account() -> _adopt_holdings() 가
    #      실제 계좌에서 매입가까지 정확히 다시 채택한다(추측보다 정확).
    ost = load(os.path.join(KEEP, "client_state.json"))
    if ost:
        tr = ost.get("trades") or []
        keep = {"date": datetime.date.today().strftime("%Y-%m-%d"),
                "positions": [], "upper_today": [], "trades": tr}
        save(STATE, keep)
        drop = len(ost.get("positions") or [])
        print("[OK] 거래기록 %d건 인계 · 포지션 %d개는 비움(로그인 때 실계좌에서 다시 채택)" % (len(tr), drop))

    ol = os.path.join(KEEP, "client_log.txt")
    if os.path.isfile(ol) and not os.path.isfile(os.path.join(DIR, "client_log.txt")):
        io.open(os.path.join(DIR, "client_log.txt"), "w", encoding="utf-8").write(
            io.open(ol, encoding="utf-8", errors="replace").read())
        print("[OK] 이전 로그 이어붙임")
    return 0


if __name__ == "__main__":
    sys.exit(main())
