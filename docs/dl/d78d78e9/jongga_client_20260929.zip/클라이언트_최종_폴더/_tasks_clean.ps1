﻿# 옛 설치가 남긴 예약작업을 지운다. (2026-09-17)
#
# 증상: 2분마다 'Windows Script Host — run_watchdog.vbs 을(를) 찾을 수 없습니다' 오류창
# 원인: 2026-09-16 부터 클라이언트는 예약작업을 쓰지 않는다. 그런데 그 전에 깔았던 PC 에는
#       `종가배팅_클라이언트감시`(2분마다)가 남아, 이미 지워진 파일을 계속 찾는다.
$ErrorActionPreference = "Continue"
Write-Host ""
Write-Host "  옛 예약작업 정리" -ForegroundColor Cyan
Write-Host "  ------------------------------------------------"
# ★존재 확인은 `schtasks /Query` 로 한다 — `Get-ScheduledTask -TaskName` 은 **건당 6초**다
#   (2026-09-29 실측: 2건 12,768ms vs schtasks 2건 1,556ms). 이건 "뭔가 안 될 때" 쓰는 도구라
#   빨리 대답하는 게 특히 중요하다. _uninstall.ps1 이 같은 이유로 이미 이 패턴을 쓴다.
function TaskExists($n) { schtasks /Query /TN $n 2>$null | Out-Null; return ($LASTEXITCODE -eq 0) }
$n = 0
foreach ($t in @('종가배팅_클라이언트감시','종가배팅_클라이언트시작')) {
    if (TaskExists $t) {
        schtasks /Delete /TN $t /F | Out-Null
        if (TaskExists $t) {
            Write-Host "  [실패] $t — 관리자 권한이 필요합니다" -ForegroundColor Red
            Write-Host "         이 파일을 마우스 오른쪽 > [관리자 권한으로 실행] 해 주세요" -ForegroundColor Yellow
        } else {
            Write-Host "  [제거] $t" -ForegroundColor Green; $n++
        }
    } else {
        Write-Host "  [없음] $t"
    }
}
Write-Host ""
if ($n -gt 0) {
    Write-Host "  끝났습니다. 이제 그 오류창이 뜨지 않습니다." -ForegroundColor Green
} else {
    Write-Host "  지울 예약작업이 없었습니다." -ForegroundColor Green
}
Write-Host ""
Write-Host "  참고: 지금 클라이언트가 쓰는 예약작업은 JonggaClientRun 하나뿐입니다."
Write-Host "        (평일 08:20 자동실행 · 최고권한 · 2분마다 도는 감시는 없습니다)"
Write-Host "        위에서 지운 둘은 옛 버전 것입니다 - JonggaClientRun 은 지우지 마세요."
Write-Host "        08:20 자동실행 -> 08:30 자동로그인 -> 15:25 종가매수 -> 20:20 종료."
