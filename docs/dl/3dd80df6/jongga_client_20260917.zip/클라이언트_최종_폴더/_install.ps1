﻿$ErrorActionPreference = "Continue"
$root  = $PSScriptRoot
$env0  = Join-Path $root "환경팩"
$prg   = Join-Path $root "프로그램"
$pydir = Join-Path $env:LOCALAPPDATA "Programs\Python\Python312-32"
$py    = Join-Path $pydir "python.exe"
$pyw   = Join-Path $pydir "pythonw.exe"

Write-Host "============================================"
Write-Host "  [2단계] 프로그램 설치 (파이썬+PyQt5+바로가기)" -ForegroundColor Cyan
Write-Host "============================================`n"

# 1) 파이썬 32비트 (키움 OCX 필수) — 번들 설치본 우선, 없으면 온라인
if (Test-Path -LiteralPath $py) {
    Write-Host "[OK] 파이썬 32비트 이미 설치됨"
} else {
    Write-Host "[설치] 파이썬 32비트 설치 중... (1~2분, 창이 잠깐 멈춰도 정상)"
    $setup = Get-ChildItem -LiteralPath $env0 -Filter "python-*-32bit.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $setup) {
        Write-Host "  번들 설치본 없음 → 온라인 다운로드"
        $tmp = Join-Path $env:TEMP "python-32bit.exe"
        Invoke-WebRequest -Uri "https://www.python.org/ftp/python/3.12.10/python-3.12.10.exe" -OutFile $tmp -UseBasicParsing
        $setup = Get-Item $tmp
    }
    Start-Process -FilePath $setup.FullName -ArgumentList "/quiet","InstallAllUsers=0","PrependPath=1","Include_test=0","TargetDir=$pydir" -Wait
    if (Test-Path -LiteralPath $py) { Write-Host "[OK] 파이썬 설치 완료" } else { Write-Host "[경고] 파이썬 설치 확인 실패 — 다시 실행해 보세요." -ForegroundColor Yellow }
}

# 2) PyQt5 — 번들 휠(오프라인) 우선, 실패 시 온라인
Write-Host "[설치] PyQt5 설치 중..."
$wh = Join-Path $env0 "wheels"
if (Test-Path -LiteralPath $wh) { & $py -m pip install --no-index --find-links "$wh" PyQt5 2>&1 | Out-Null }
& $py -c "import PyQt5" 2>$null
if ($LASTEXITCODE -ne 0) { & $py -m pip install "PyQt5==5.15.11" 2>&1 | Out-Null; & $py -c "import PyQt5" 2>$null }
if ($LASTEXITCODE -eq 0) { Write-Host "[OK] PyQt5 설치 확인" } else { Write-Host "[경고] PyQt5 설치 실패 — 인터넷 연결 후 다시 실행하세요." -ForegroundColor Yellow }

# 3) 무창 실행용 파이썬 경로 저장 (BOM 없이)
#    ★확인하고 쓴다 — 예전에는 32비트 설치가 실패해도 경로를 그냥 적어 두었다.
#      그러면 run_client.bat 이 PATH 의 64비트 파이썬으로 떨어지고,
#      키움 OCX 가 안 올라와 영문 AttributeError 로 죽었다. (2026-09-15)
$bits = ""
if (Test-Path -LiteralPath $py) { $bits = (& $py -c "import struct;print(struct.calcsize('P')*8)" 2>$null | Select-Object -First 1) }
if ($bits -ne "32") {
    Write-Host ""
    Write-Host "[중단] 32비트 파이썬을 확인하지 못했습니다 (확인값: '$bits')" -ForegroundColor Red
    Write-Host "       키움 OpenAPI 는 32비트 파이썬에서만 동작합니다." -ForegroundColor Red
    Write-Host "       https://www.python.org/downloads/windows/ 에서" -ForegroundColor Yellow
    Write-Host "       'Windows installer (32-bit)' 3.12.x 를 설치한 뒤 이 파일을 다시 실행하세요." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "       (설치를 여기서 멈춥니다 - 잘못된 경로를 저장하면 나중에 원인을 알 수 없는" -ForegroundColor Yellow
    Write-Host "        오류로 죽습니다)" -ForegroundColor Yellow
    exit 1
}
[System.IO.File]::WriteAllText((Join-Path $prg "python_path.txt"), $pyw, (New-Object System.Text.ASCIIEncoding))
Write-Host "[OK] 파이썬 경로 저장 (32비트 확인됨)"

# 3-1) 이전 설치 설정 병합 — [0_기존버전_정리.bat] 이 남긴 _이전설정 이 있을 때만
#      개인값(계좌·닉네임·원금·텔레그램)은 가져오고, 전략값(익절·손절·종목당)은 새 것을 강제한다.
#      옛 config 를 통째로 두면 익절3%/손절3% 옛 전략으로 조용히 매매한다.
if (Test-Path -LiteralPath (Join-Path $prg "_이전설정")) {
    Write-Host "[인계] 이전 설치 설정 병합 중..."
    & $py (Join-Path $prg "_migrate.py")
}

# 4) 예약작업 제거 (2026-09-16 — 클라이언트는 이제 예약작업을 쓰지 않는다)
#    예전엔 두 개를 등록했다:
#      종가배팅_클라이언트시작 : 평일 08:25 + WakeToRun(자고 있는 PC 를 깨움)
#      종가배팅_클라이언트감시 : 하루 종일 2분마다 powershell 실행
#    남의 PC 에 부담이고 등록할 때 UAC 창까지 떠서 없앴다.
#    대신 프로그램이 켜져 있기만 하면 08:30 로그인 -> 15:25 매수 -> 17:00 대기를 스스로 한다.
Write-Host "[정리] 예전 자동 예약작업 제거..."
$removed = 0
foreach ($t in @('종가배팅_클라이언트시작','종가배팅_클라이언트감시')) {
    if (Get-ScheduledTask -TaskName $t -ErrorAction SilentlyContinue) {
        schtasks /Delete /TN $t /F | Out-Null
        Write-Host "  - 제거: $t"; $removed++
    }
}
if ($removed -eq 0) { Write-Host "[OK] 예약작업 없음 - 부팅/평소에 아무것도 돌지 않습니다" }
else { Write-Host "[OK] 예약작업 없음 - $removed 개 제거했습니다" -ForegroundColor Green }

# 4-1) 전원 옵션 — 전원이 연결돼 있으면 PC 가 혼자 절전에 들지 않게.
#      예약작업이 없어졌으니 절전에 들면 깨울 방법도 없다(모니터는 꺼져도 된다).
try {
    powercfg /setacvalueindex SCHEME_CURRENT SUB_SLEEP STANDBYIDLE 0 2>$null
    powercfg /setacvalueindex SCHEME_CURRENT SUB_SLEEP HIBERNATEIDLE 0 2>$null
    powercfg /setactive SCHEME_CURRENT 2>$null
    Write-Host "[OK] 전원 옵션 - 전원 연결 시 절전 안 함 (모니터는 꺼져도 됩니다)"
} catch {
    Write-Host "[알림] 전원 옵션을 못 바꿨습니다 - [설정 > 전원] 에서" -ForegroundColor Yellow
    Write-Host "       '다음 시간 후 장치를 절전 모드로 전환' 을 '안 함' 으로 바꿔 주세요." -ForegroundColor Yellow
}

# 4-2) 권한지갑 — 키움 UAC 창을 없앤다 (2026-09-17)
#    키움 로그인 실행파일 opstarter.exe 는 매니페스트가 관리자 권한을 요구한다.
#    일반 권한으로 띄우면 로그인할 때마다 파란 UAC 창이 뜨고, 그 창은 프로그램이 대신 못 누른다.
#    -> 트리거 없는 최고권한 작업을 하나 만들어 두고(스스로 도는 일 없음),
#       바탕화면 아이콘이 그 작업을 깨운다. 작업 스케줄러는 UAC 없이 권한을 올려 준다.
Write-Host ""
Write-Host "[권한] 키움 UAC 창 없애기 (권한지갑 등록)..."
$holder = Join-Path $prg "권한지갑_등록.ps1"
if (Test-Path -LiteralPath $holder) {
    & powershell -NoProfile -ExecutionPolicy Bypass -File $holder
} else {
    Write-Host "[경고] 권한지갑_등록.ps1 이 없습니다 - 키움 로그인 때 UAC 창이 뜹니다" -ForegroundColor Yellow
}
$hasHolder = [bool](Get-ScheduledTask -TaskName JonggaClientRun -ErrorAction SilentlyContinue)

# 5) 바탕화면 바로가기 생성
Write-Host "[바로가기] 바탕화면 실행 아이콘 생성..."
$lnk = Join-Path ([Environment]::GetFolderPath('Desktop')) "▶ 종가배팅 클라이언트.lnk"
$w = New-Object -ComObject WScript.Shell
$s = $w.CreateShortcut($lnk)
$s.TargetPath = "C:\Windows\System32\wscript.exe"
if ($hasHolder) {
    # ★권한지갑 경유 — UAC 창 없이 관리자 권한으로 뜬다
    $s.Arguments = '"' + (Join-Path $prg "run_elevated.vbs") + '"'
} else {
    # 권한지갑이 없다 -> 직접 실행. auto 인자가 있어야 08:30 자동로그인/매매까지 한다
    $s.Arguments = '"' + (Join-Path $prg "run_client.vbs") + '" auto'
}
$s.WorkingDirectory = $prg
$s.IconLocation = "$env:SystemRoot\System32\shell32.dll,137"
$s.Description = "종가배팅 클라이언트 실행"
$s.Save()
if (-not $hasHolder) {
    # ★권한지갑이 없으면 바로가기라도 '관리자 권한으로 실행' 으로 만든다
    #   (.lnk 헤더 0x15 바이트의 0x20 비트). 아이콘 누를 때 UAC 가 한 번 뜨고, 그 뒤로는 안 뜬다.
    try {
        $b = [IO.File]::ReadAllBytes($lnk); $b[0x15] = $b[0x15] -bor 0x20
        [IO.File]::WriteAllBytes($lnk, $b)
        Write-Host "[알림] 권한지갑이 없어 바로가기를 '관리자 권한으로 실행' 으로 만들었습니다." -ForegroundColor Yellow
        Write-Host "       아이콘을 누를 때 UAC 창이 한 번 뜹니다. 완전히 없애려면 [2_프로그램설치.bat] 을 다시 실행하세요."
    } catch { }
}
Write-Host "[OK] 바탕화면 바로가기 생성 (▶ 종가배팅 클라이언트)"
if ($hasHolder) {
    Write-Host "     이 아이콘을 누르면 UAC 창 없이 자동매매까지 시작됩니다" -ForegroundColor Cyan
} else {
    Write-Host "     이 아이콘을 누르면 자동매매까지 시작됩니다" -ForegroundColor Cyan
}

Write-Host ""
Write-Host "동작 방식 (예약작업 없이 돕니다)" -ForegroundColor Cyan
Write-Host "  아침에 바탕화면 [▶ 종가배팅 클라이언트] 를 한 번 누르면"
Write-Host "    08:30 키움 자동로그인 -> 장중 매매 -> 15:25 종가매수 -> 17:00 대기"
Write-Host "  그대로 켜 두면 다음 평일 08:30 에 스스로 다시 로그인합니다. 매일 누를 필요 없습니다."
Write-Host "  (PC 를 껐다 켰으면 아이콘을 다시 한 번 눌러 주세요)"
Write-Host ""
Write-Host "`n프로그램 설치 완료! 이제 [3_키움설치.bat] 를 실행하세요." -ForegroundColor Green
