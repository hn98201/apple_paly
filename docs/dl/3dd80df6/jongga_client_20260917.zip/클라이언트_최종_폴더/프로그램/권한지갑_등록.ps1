﻿param([switch]$Elevated)
# 종가배팅 클라이언트 - '권한지갑' 예약작업 등록 (2026-09-17)
#
# 왜 필요한가
#   키움 로그인 실행파일 opstarter.exe 는 **매니페스트가 관리자 권한을 요구**한다
#   (requestedExecutionLevel level='requireAdministrator').
#   그래서 일반 권한으로 프로그램을 띄우면 로그인할 때마다 UAC 창이 뜬다.
#   UAC 는 보안 데스크톱에서 뜨므로 **어떤 프로그램도 대신 눌러줄 수 없다** = 무인 불가.
#
# 어떻게 푸는가
#   시간 트리거가 **없는** 예약작업을 최고 권한으로 하나 만들어 둔다(스스로 도는 일 없음).
#   바탕화면 아이콘은 그 작업을 실행시킨다. 작업 스케줄러는 UAC 없이 권한을 올려주므로
#   프로그램이 관리자 권한으로 뜨고, 키움 로그인도 UAC 없이 지나간다.
#
#   ※ 이 등록 자체는 관리자 권한이 필요해 설치 때 한 번만 허용을 받는다.
$ErrorActionPreference = "Continue"
$d   = $PSScriptRoot
$vbs = Join-Path $d 'run_client.vbs'
$T   = 'JonggaClientRun'

if (-not (Test-Path -LiteralPath $vbs)) {
    Write-Host "[오류] run_client.vbs 없음: $vbs" -ForegroundColor Red
    exit 1
}

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
             [Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin -and -not $Elevated) {
    Write-Host ""
    Write-Host "  키움 로그인 프로그램(NKStarter)은 윈도우에 '관리자 권한'을 요구합니다." -ForegroundColor Yellow
    Write-Host "  그래서 그냥 두면 로그인할 때마다 파란 UAC 창이 뜨고, 사람이 눌러야 진행됩니다."
    Write-Host "  지금 한 번만 허용해 두면 **앞으로 그 창이 아예 안 뜹니다.**" -ForegroundColor Cyan
    Write-Host "  -> 잠시 후 뜨는 창에서 [예] 를 눌러 주세요."
    Write-Host ""
    try {
        Start-Process powershell -Verb RunAs -Wait -ArgumentList @(
            "-NoProfile","-ExecutionPolicy","Bypass","-File","`"$PSCommandPath`"","-Elevated")
    } catch {
        Write-Host "[알림] 권한 상승을 건너뛰었습니다." -ForegroundColor Yellow
    }
    exit 0
}

try {
    $act = New-ScheduledTaskAction -Execute "wscript.exe" -Argument ('"' + $vbs + '" auto') -WorkingDirectory $d
    $pr  = New-ScheduledTaskPrincipal -UserId ([Security.Principal.WindowsIdentity]::GetCurrent().Name) `
             -RunLevel Highest -LogonType Interactive
    $st  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
             -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero) -StartWhenAvailable:$false
    # ★트리거를 주지 않는다 - 스스로 도는 일이 없고, 오직 바탕화면 아이콘이 부를 때만 실행된다
    Register-ScheduledTask -TaskName $T -Action $act -Principal $pr -Settings $st -Force | Out-Null
    $chk = Get-ScheduledTask -TaskName $T -ErrorAction SilentlyContinue
    if ($chk -and "$($chk.Principal.RunLevel)" -eq "Highest") {
        Write-Host "[OK] 권한지갑 등록 완료 - 이제 UAC 창이 뜨지 않습니다" -ForegroundColor Green
        Write-Host "     작업 이름: $T (한글 대신 ASCII — schtasks/VBS 를 오갈 때 한글이 깨진다)  (시간 트리거 없음 = 스스로 돌지 않습니다)"
    } else {
        Write-Host "[경고] 등록은 됐지만 최고 권한이 아닙니다 - UAC 창이 뜰 수 있습니다" -ForegroundColor Yellow
    }
} catch {
    Write-Host "[오류] 권한지갑 등록 실패: $_" -ForegroundColor Red
    exit 1
}
