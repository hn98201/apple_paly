﻿# 종가배팅 클라이언트 - 옛 설치를 가리키는 예약작업 찾기·지우기 (2026-10-01 신설 · 같은 날 검토 반영 b판)
#
# 0단계(_uninstall.ps1) · 2단계(_install.ps1) · 오류났을때(_tasks_clean.ps1) 가 이 파일을 불러 쓴다(. 소스).
#
# 왜 만들었나 — 실사고 (2026-10-01)
#   다른 PC 에서 새 버전(20261001)으로 재설치하자 0단계가 옛 폴더(20260929)의 이름을 바꿨다.
#   그런데 그 PC 에는 사람이 따로 만든 `JonggaClientGuardian`(2분마다 감시) 예약작업이 있었고,
#   이 작업이 사라진 옛 경로의 스크립트를 계속 찾으면서
#   "스크립트 파일을 찾을 수 없습니다" 창을 **2분마다** 띄웠다(사람이 작업을 지워서 멈췄다).
#   우리 정리 스크립트는 **이름을 아는 작업 3개만** 지웠기 때문에 이 작업을 못 봤다.
#   → 이름이 아니라 **실행 경로**로 찾는다. 이름을 모르는 작업도 잡힌다.
#
# '옛 설치를 가리키는 작업' 으로 보는 것 (Kind)
#   1  지금 정리할 옛 설치(폴더·그 키트) 안의 파일을 **실행**하거나, cmd/powershell/wscript 명령 원문에 그 폴더가 들어 있다
#      (곧 이름이 바뀌어 끊어진다 · 그대로 두면 옛 client.py 를 다시 띄울 수도 있다)
#   2  가리키는 경로가 없고, 그 자리의 폴더가 '<이름>_구버전_<날짜>' 로 바뀌어 남아 있다(0단계가 남기는 흔적 · 우리 폴더 표식 확인)
#   3  **실행 대상** 파일이 없고, 그 파일이 run_client.vbs·run_elevated.vbs·run_watchdog.vbs 이거나
#      ('프로그램' 폴더 안의) client.py·run_client.bat 이거나, 작업 이름이 Jongga·종가 이면서 클라이언트 폴더 모양의 경로다
# 건드리지 않는 것 (2026-10-01 검토에서 나온 거짓 양성을 막는다)
#   · \Microsoft\ 아래 윈도우 작업 · 지금 설치하는 키트 안 · 관리자 프로그램 폴더(관리자_전용_나만 · 관리자용종가배팅)를 쓰는 작업
#   · '없음' 판단은 실행 대상에만 한다 — 로그·출력 파일(아직 안 생긴 out.log 등)이나 잘못 잘린 인자 조각으로 판단하지 않는다
#   · * ? < > | " 가 든 조각 · 드라이브가 없거나 준비 안 됨(USB 뺌) · 네트워크 드라이브(멈출 수 있다) — 판단 보류
#   · 이름에 '종가' 가 있어도 우리 클라이언트 폴더 모양이 아니면 지우지 않는다(주식 하는 PC 엔 다른 종가 프로그램이 흔하다)
# 지우기 전에 작업 정의를 XML 로 백업한다 — 복구: schtasks /Create /TN <이름> /XML <백업파일>
# 속도 — `schtasks /Query /XML` **한 번**으로 전부 읽는다(작업 210개 PC 실측 2.2초).
#   Get-ScheduledTask 는 건당 2초라 쓰지 않는다(2026-09-29 '정리하면 렉 걸린다' 신고의 원인).

$JG_MARK_STRONG = @('run_client.vbs', 'run_elevated.vbs', 'run_watchdog.vbs')
$JG_MARK_WEAK   = @('client.py', 'run_client.bat')          # '프로그램' 폴더 안일 때만 우리 것으로 본다
$JG_HOSTS  = @('cmd', 'wscript', 'cscript', 'powershell', 'pwsh', 'python', 'pythonw', 'py', 'pyw', 'conhost')
$JG_RUNEXT = @('vbs', 'vbe', 'js', 'jse', 'wsf', 'ps1', 'bat', 'cmd', 'py', 'pyw', 'exe')
$JG_KITSHAPE = '(?i)\\프로그램(_구버전_[^\\]*)?\\|종가배팅_?클라이언트|jongga_client'
$JG_ADMINSHAPE = '관리자_전용_나만|관리자용종가배팅'
$JG_DRIVE_OK = @{}
$JG_LAST_BACKUP = $null

function Get-JgClean($t) {
    # 경로 조각을 다듬는다. 절대경로가 아니거나 이상한 문자가 있으면 $null(판단 보류).
    if (-not $t) { return $null }
    $t = $t.Trim().Trim('"', "'").TrimEnd(';', ',', ')', '}').Trim()
    if ($t.Length -gt 3) { $t = $t.TrimEnd('\') }
    if ($t -notmatch '^[A-Za-z]:\\') { return $null }
    if ($t.IndexOfAny([char[]]'*?<>|"') -ge 0) { return $null }
    return $t
}

function Split-JgTokens($s) {
    # 인자를 조각낸다. 따옴표("..." · '...') 안이 공백 든 명령이면(cmd /c "cd /d X && ..." · -Command "& 'X'")
    # 그 안도 한 번 더 조각낸다 — 바깥 조각이 먼저 온다(공백 든 경로 하나가 통째로 먼저 잡히게).
    $outer = New-Object System.Collections.Generic.List[string]
    $inner = New-Object System.Collections.Generic.List[string]
    if (-not $s) { return ,@() }
    $re = '"([^"]*)"|''([^'']*)''|([^\s"'']+)'
    foreach ($m in [regex]::Matches($s, $re)) {
        $q = $m.Groups[1].Success -or $m.Groups[2].Success
        $tok = if ($m.Groups[1].Success) { $m.Groups[1].Value } elseif ($m.Groups[2].Success) { $m.Groups[2].Value } else { $m.Groups[3].Value }
        $outer.Add($tok)
        if ($q -and $tok -match '\s') {
            foreach ($m2 in [regex]::Matches($tok, $re)) {
                $t2 = if ($m2.Groups[1].Success) { $m2.Groups[1].Value } elseif ($m2.Groups[2].Success) { $m2.Groups[2].Value } else { $m2.Groups[3].Value }
                $inner.Add($t2)
            }
        }
    }
    $outer.AddRange($inner)
    return ,$outer.ToArray()
}

function Get-JgTaskList {
    # 모든 예약작업: 이름 · Paths(인자·작업폴더에 나온 절대경로 전부) · Targets(실제로 실행하는 파일) · Raw(명령 원문) · Host(cmd 등 셸로 실행하나)
    $raw = (schtasks /Query /XML 2>$null) -join "`n"
    $list = @()
    if (-not $raw) { return ,$list }
    # 출력은 '<!-- \작업이름 -->' 주석 뒤에 그 작업의 XML 이 오는 모양이다.
    $parts = [regex]::Split($raw, '<!--\s*(\\[^>]*?)\s*-->')
    for ($i = 1; $i + 1 -lt $parts.Count; $i += 2) {
        $name = $parts[$i].Trim()
        $body = $parts[$i + 1]
        $paths = New-Object System.Collections.Generic.List[string]
        $targets = New-Object System.Collections.Generic.List[string]
        $rawAll = ''
        $hostRun = $false
        foreach ($ex in [regex]::Matches($body, '<Exec>(.*?)</Exec>', 'Singleline')) {
            $eb = $ex.Groups[1].Value
            $v = @{}
            foreach ($tag in 'Command', 'Arguments', 'WorkingDirectory') {
                $m = [regex]::Match($eb, "<$tag>(.*?)</$tag>", 'Singleline')
                $v[$tag] = if ($m.Success) { [Environment]::ExpandEnvironmentVariables([Net.WebUtility]::HtmlDecode($m.Groups[1].Value)).Trim() } else { '' }
            }
            $rawAll += ' ' + $v['Command'] + ' ' + $v['Arguments'] + ' ' + $v['WorkingDirectory']
            $cmdP = $v['Command'].Trim('"').Trim()
            $wdP = Get-JgClean $v['WorkingDirectory']
            if ($wdP) { $paths.Add($wdP) }
            $cmdAbs = Get-JgClean $cmdP
            if ($cmdAbs) { $paths.Add($cmdAbs) }
            $toks = Split-JgTokens $v['Arguments']
            foreach ($tk in $toks) { $c = Get-JgClean $tk; if ($c) { $paths.Add($c) } }
            # 실행 대상 — 셸(cmd·wscript·powershell·python …)이면 인자 속 첫 스크립트, 아니면 Command 자신
            $leaf = (($cmdP -split '[\\/]')[-1]).ToLower() -replace '\.exe$', ''
            if ($JG_HOSTS -contains $leaf) {
                $hostRun = $true
                foreach ($tk in $toks) {
                    $t = $tk.Trim().Trim('"', "'").TrimEnd(';', ',', ')', '}')
                    if ($t -notmatch '\.([A-Za-z0-9]+)$') { continue }
                    if ($JG_RUNEXT -notcontains $Matches[1].ToLower()) { continue }
                    $tl = (($t -split '[\\/]')[-1]).ToLower() -replace '\.exe$', ''
                    if ($JG_HOSTS -contains $tl) { continue }                       # wscript.exe 같은 셸 이름은 대상이 아니다
                    $abs = Get-JgClean $t
                    if (-not $abs -and $wdP -and $t -notmatch '^[A-Za-z]:' -and $t.IndexOfAny([char[]]'*?<>|"') -lt 0) {
                        try { $abs = Join-Path $wdP $t } catch { $abs = $null }     # 작업폴더 기준 상대경로
                    }
                    if ($abs) { $targets.Add($abs); break }
                }
            } elseif ($cmdAbs) { $targets.Add($cmdAbs) }
        }
        $list += [pscustomobject]@{
            Name = $name; Paths = @($paths | Select-Object -Unique); Targets = @($targets | Select-Object -Unique)
            Raw = $rawAll; Host = $hostRun
        }
    }
    return ,$list
}

function Test-JgUnder($p, $dir) {
    if (-not $p -or -not $dir) { return $false }
    $d = $dir.TrimEnd('\')
    return ($p -ieq $d) -or $p.StartsWith($d + '\', [StringComparison]::OrdinalIgnoreCase)
}

function Test-JgClientDir($d) {
    # 우리 클라이언트 설치 폴더인가 — client.py 하나만으로는 약하다(다른 프로그램도 그 이름을 쓴다).
    if (-not $d -or -not (Test-Path -LiteralPath $d)) { return $false }
    foreach ($f in 'client.py', 'run_client.vbs', 'kiwoom_trade.py') {
        if (-not (Test-Path -LiteralPath (Join-Path $d $f))) { return $false }
    }
    return $true
}

function Test-JgDriveOk($p) {
    # 판단해도 되는 드라이브인가 — 없음 · 준비 안 됨(USB 뺌) · 네트워크(재연결 대기로 멈출 수 있다)면 보류.
    try { $r = [IO.Path]::GetPathRoot($p) } catch { return $false }
    if (-not $r) { return $false }
    $k = $r.ToUpper()
    if (-not $JG_DRIVE_OK.ContainsKey($k)) {
        $ok = $false
        try { $di = New-Object IO.DriveInfo($r); $ok = ($di.DriveType -ne [IO.DriveType]::Network) -and $di.IsReady } catch { $ok = $false }
        $JG_DRIVE_OK[$k] = $ok
    }
    return $JG_DRIVE_OK[$k]
}

function New-JgWhy($kind, $why) { return [pscustomobject]@{ Kind = $kind; Why = $why } }

function Get-JgStaleReason($task, $oldDirs, $kitDir) {
    # 옛 설치를 가리키는 작업이면 {Kind, Why}, 아니면 $null.
    if ($task.Name -like '\Microsoft\*') { return $null }
    if ($task.Raw -match $JG_ADMINSHAPE) { return $null }                  # 관리자 프로그램 작업은 절대 안 건드린다
    $tg = @($task.Targets | Where-Object { -not (Test-JgUnder $_ $kitDir) })
    $onlyKit = ($task.Targets.Count -gt 0 -and $tg.Count -eq 0)             # 지금 키트 안만 실행하는 작업
    # 1 — 옛 설치(폴더·키트) 안
    foreach ($od in @($oldDirs)) {
        if (-not $od) { continue }
        foreach ($t in $tg) { if (Test-JgUnder $t $od) { return (New-JgWhy '1' "옛 설치 안의 파일을 실행함: $t") } }
        if ($task.Host -and -not $onlyKit -and $task.Raw.IndexOf($od.TrimEnd('\'), [StringComparison]::OrdinalIgnoreCase) -ge 0) {
            return (New-JgWhy '1' "명령에 옛 설치 폴더가 들어 있음: $od")
        }
    }
    # 2 — 끊어진 자리의 폴더가 '_구버전_' 으로 이름이 바뀌어 남아 있다(인자·작업폴더 어디에 나와도 본다 — 흔적이 우리 것이라 확실하다)
    foreach ($p in @($task.Paths)) {
        if (Test-JgUnder $p $kitDir) { continue }
        if ($p.Contains('?') -or -not (Test-JgDriveOk $p)) { continue }
        if (Test-Path -LiteralPath $p) { continue }
        $a = $p
        while ($a) {
            $par = Split-Path -Parent $a
            if (-not $par) { break }
            if (Test-Path -LiteralPath $par) {
                $leaf = Split-Path -Leaf $a
                foreach ($r in @(Get-ChildItem -LiteralPath $par -Directory -ErrorAction SilentlyContinue |
                                 Where-Object { $_.Name.StartsWith($leaf + '_구버전_', [StringComparison]::OrdinalIgnoreCase) })) {
                    if ((Test-JgClientDir $r.FullName) -or (Test-JgClientDir (Join-Path $r.FullName '프로그램'))) {
                        return (New-JgWhy '2' "이름이 바뀐 옛 설치 폴더를 가리킴: $p  (지금 이름: $($r.Name))")
                    }
                }
                break
            }
            $a = $par
        }
    }
    # 3 — 실행 대상이 없는 클라이언트 파일
    foreach ($t in $tg) {
        if ($t.Contains('?') -or -not (Test-JgDriveOk $t)) { continue }
        if (Test-Path -LiteralPath $t) { continue }
        $leaf = Split-Path -Leaf $t
        $par = Split-Path -Parent $t
        $parLeaf = if ($par) { Split-Path -Leaf $par } else { '' }
        $kitShape = ($parLeaf -eq '프로그램') -or $parLeaf.StartsWith('프로그램_구버전_')
        if ($JG_MARK_STRONG -contains $leaf) { return (New-JgWhy '3' "없는 클라이언트 실행 파일: $t") }
        if (($JG_MARK_WEAK -contains $leaf) -and $kitShape) { return (New-JgWhy '3' "없는 클라이언트 실행 파일: $t") }
        if (($task.Name -match '(?i)jongga|종가') -and ($t -match $JG_KITSHAPE)) {
            return (New-JgWhy '3' "작업 이름이 Jongga·종가 이고 클라이언트 폴더의 없는 파일을 실행함: $t")
        }
    }
    return $null
}

function Find-JgStaleTasks($all, $oldDirs, $kitDir, $skipNames) {
    # $skipNames: 다른 곳에서 따로 처리하는 작업 이름(앞의 '\' 없이)
    $out = @()
    foreach ($t in @($all)) {
        if (@($skipNames) -contains $t.Name.TrimStart('\')) { continue }
        $w = Get-JgStaleReason $t $oldDirs $kitDir
        if ($w) { $out += [pscustomobject]@{ Name = $t.Name; Kind = $w.Kind; Why = $w.Why } }
    }
    return ,$out
}

function Find-JgLiveOldLaunchers($all, $kitDir, $skipNames) {
    # 키트 밖의 '살아 있는' 우리 설치를 실행하는 작업 — 0단계를 건너뛴 재설치에서 옛 버전을 계속 띄운다.
    $out = @()
    foreach ($t in @($all)) {
        if ($t.Name -like '\Microsoft\*' -or (@($skipNames) -contains $t.Name.TrimStart('\'))) { continue }
        if ($t.Raw -match $JG_ADMINSHAPE) { continue }
        foreach ($g in @($t.Targets)) {
            if (Test-JgUnder $g $kitDir) { continue }
            $d = Split-Path -Parent $g
            if ($d -and ((Test-JgClientDir $d) -or (Test-JgClientDir (Split-Path -Parent $d)))) {
                $out += [pscustomobject]@{ Name = $t.Name; Target = $g }; break
            }
        }
    }
    return ,$out
}

function Remove-JgTask($name, $backupDir) {
    # 백업하고 지운 뒤, 정말 지워졌는지 확인한다(권한이 모자라면 조용히 남는다).
    # ★지우기 전에 조회부터 성공해야 한다 — 이름이 깨졌거나 권한이 없어 조회가 안 되면 '지웠다' 고 하지 않는다.
    $script:JG_LAST_BACKUP = $null
    $x = schtasks /Query /TN "$name" /XML 2>$null
    if ($LASTEXITCODE -ne 0 -or -not $x) { return $false }
    $xml = (@($x) -join "`r`n")
    $fn = ($name.TrimStart('\') -replace '[\\/:*?"<>|]', '_') + '.xml'
    foreach ($bd in @($backupDir, (Join-Path $env:TEMP '종가배팅_예약작업백업'))) {
        if (-not $bd) { continue }
        try {
            if (-not (Test-Path -LiteralPath $bd)) { New-Item -ItemType Directory -Path $bd -Force -ErrorAction Stop | Out-Null }
            $bf = Join-Path $bd $fn
            [IO.File]::WriteAllText($bf, $xml, [Text.Encoding]::Unicode)
            $script:JG_LAST_BACKUP = $bf
            break
        } catch { }
    }
    if (-not $script:JG_LAST_BACKUP) { return $false }                     # 백업을 못 남기면 지우지 않는다
    schtasks /Delete /TN "$name" /F 2>$null | Out-Null
    $del = ($LASTEXITCODE -eq 0)
    Start-Sleep -Milliseconds 300
    schtasks /Query /TN "$name" 2>$null | Out-Null
    return ($del -and ($LASTEXITCODE -ne 0))
}
