# -*- coding: utf-8 -*-
"""종가배팅 클라이언트 (배포용) v2 — 탭 UI + 드래그 카드 + 세련된 차트.
   대시보드 / 계좌 / 설정 3탭. 전략 고정(전체+하이브). 관리자 픽만 사용. 페이퍼 없음.
   실행: run_client.bat (pythonw = cmd창 없음)
"""
# ─────────────────────────────────────────────────────────────────────────────
# ★실행 실패 가시화 — pythonw 는 콘솔이 없어 오류가 어디에도 안 보인다.
#   여기서 sys.excepthook 을 먼저 걸어두면 아래 import 가 깨져도 원인을 알려준다.
#   (모듈 누락·32/64비트 불일치·키움 OCX 미등록 → 예전에는 "아무 반응 없음"이었다)
# ─────────────────────────────────────────────────────────────────────────────
import sys as _sys, os as _os, traceback as _tb

_DIR0 = _os.path.dirname(_os.path.abspath(__file__))
if _DIR0 not in _sys.path:
    _sys.path.insert(0, _DIR0)      # ★_preflight 가 같은 폴더의 kiwoom_ocx 를 쓰려면 먼저 필요
_AUTO = any(str(a).lower() == "auto" for a in _sys.argv[1:])      # 무인모드에선 팝업 금지


def _fatal(msg):
    try:
        with open(_os.path.join(_DIR0, "실행오류.txt"), "w", encoding="utf-8") as f:
            f.write(msg)
    except Exception:
        pass
    if not _AUTO:
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(
                0, msg[-1500:] + "\n\n[진단.bat] 결과와 실행오류.txt 를 관리자에게 보내주세요.",
                "종가배팅 클라이언트 - 실행 오류", 0x10)
        except Exception:
            pass


_UI_READY = [False]          # ★창이 뜬 뒤인가 — 뜬 뒤의 예외로는 프로그램을 끄지 않는다


def _runtime_log(msg):
    """런타임 예외를 파일에 남긴다(덮어쓰지 않고 이어 붙인다 — 여러 번 나도 다 보이게)."""
    try:
        with open(_os.path.join(_DIR0, "실행오류.txt"), "a", encoding="utf-8") as f:
            import datetime as _dt
            f.write("\n[%s] %s\n" % (_dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception:
        pass


def _hook(et, ev, tb):
    """★PyQt5 는 슬롯(버튼·탭) 안에서 난 예외도 여기로 보낸 뒤 프로세스를 끝낸다.

    그래서 예전엔 설정 탭을 누르다 사소한 예외 하나만 나도 프로그램이 꺼졌다(2026-09-17 신고).
    창이 뜬 뒤라면 **끄지 않는다** — 기록만 남기고 계속 돈다.
    무인(auto)에서는 더더욱 끄면 안 된다. 아무도 다시 못 켠다."""
    txt = "".join(_tb.format_exception(et, ev, tb))
    if _UI_READY[0]:
        _runtime_log("실행 중 오류(프로그램은 계속 돕니다)\n" + txt)
        try:
            _w = _GUI[0]
            if _w is not None:
                _w.log("⚠️ 화면 오류 — 계속 진행합니다: %s" % str(ev)[:120])
                _w.log("   자세한 내용은 실행오류.txt 에 적었습니다")
        except Exception:
            pass
        return                              # ★여기서 끝 — 종료하지 않는다
    _fatal("프로그램을 시작하지 못했습니다.\n\n" + txt)


_GUI = [None]                # 창 객체(로그 출력용) — 창이 만들어지면 채운다
_sys.excepthook = _hook


def _preflight():
    """자주 나는 3가지 원인을 먼저 한글로 알려준다."""
    bad = []
    import struct
    _b32 = (struct.calcsize("P") * 8 == 32)
    if not _b32:
        bad.append("• 64비트 파이썬으로 실행되었습니다.\n"
                   "  키움 OpenAPI는 32비트 파이썬에서만 동작합니다.\n"
                   "  python.org 에서 'Windows installer (32-bit)' 3.12.x 설치 후\n"
                   "  [2_프로그램설치.bat] 을 다시 실행하세요.")
    try:
        import numpy  # noqa
    except Exception:
        bad.append("• numpy 가 설치되지 않았습니다.  setup.bat 을 다시 실행하세요.")
    try:
        import PyQt5  # noqa
        from PyQt5.QAxContainer import QAxWidget  # noqa
    except Exception:
        bad.append("• PyQt5 가 설치되지 않았습니다.  setup.bat 을 다시 실행하세요.")
    # ★ProgID 만 보면 안 된다 — 옛 OpenAPI 를 폴더째 지운 PC 는 등록만 남아
    #   이 점검을 통과하고, 정작 TradeKiwoom() 에서 OnEventConnect 없이 죽는다.
    #   실제 ocx 파일까지 확인한다. (2026-09-15)
    try:
        import kiwoom_ocx
        _p = kiwoom_ocx.problem() if _b32 else None   # 비트수는 위에서 이미 알렸다(중복 방지)
        if _p:
            bad.append("• " + _p.replace("\n", "\n  "))
    except Exception:
        try:
            import winreg
            winreg.CloseKey(winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, "KHOPENAPI.KHOpenAPICtrl.1"))
        except Exception:
            bad.append("• 키움 OpenAPI(OCX)가 설치/등록되지 않았습니다.\n"
                       "  키움 홈페이지에서 'Open API+' 를 설치한 뒤 다시 실행하세요.")
    if bad:
        _fatal("실행 전 점검에서 문제가 발견되었습니다.\n\n" + "\n\n".join(bad))
        _sys.exit(1)


_preflight()

import sys, os, json, datetime, urllib.request, math, subprocess, threading, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception: pass
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
                             QLabel, QPushButton, QLineEdit, QRadioButton, QButtonGroup, QComboBox,
                             QStackedWidget, QScrollArea, QFrame, QGraphicsDropShadowEffect, QSizePolicy, QMessageBox)
from PyQt5.QtCore import QTimer, QEventLoop, Qt, QRectF, QPointF
from PyQt5.QtGui import (QFont, QColor, QPainter, QPen, QBrush, QLinearGradient, QPainterPath,
                         QFontDatabase, QFontMetrics)   # ★QFontMetrics = Donut 가운데 숫자 크기 자동조절
from kiwoom_trade import TradeKiwoom
from jongga_scanner import TG_TOKEN, _int
import strategies as st
try: import buy_appeal as ba
except Exception: ba = None

DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG = os.path.join(DIR, "client_config.json")
STATE = os.path.join(DIR, "client_state.json")
LOGF = os.path.join(DIR, "client_log.txt")
RESTART_LOG = os.path.join(DIR, "restart_history.json")   # ★즉시 재시작 이력(폭주 백오프용)
# ★★배포본 식별자 (2026-09-29 신설 · 배포전 검토).
#   왜 필요한가 — **어느 빌드가 깔려 있는지 알아낼 방법이 하나도 없었다.**
#   · zip 파일명은 `jongga_client_<날짜>.zip` 로 **날짜까지만**이라 같은 날 두 번 올리면 이름이 같다.
#     2026-09-29 에 실제로 그랬다: 06:38 배포본에는 `pending()` 의 `or []` 버그(조회 실패를
#     '미체결 없음' 으로 뒤집어 _ensure_closeout 이 시장가를 재발주 = **이중매도**)와
#     `_uninstall.ps1` 의 bare `return`(중단인데 종료코드 0 → 부모가 "[OK] 정리 끝" 을 찍는다)이
#     **남아 있었고**, 같은 날 오후 배포본에서 고쳤다. 파일명만으로는 둘을 구분할 수 없다.
#   · 허브 하트비트(hub_licenses.json)에도 버전이 없다 — 관리자 화면으로도 확인이 안 된다.
#   → 그래서 고친 걸 내보내고도 **그게 도착했는지 확인할 수가 없었다.** 이 프로젝트가 이미 당한
#     실패다(단기과열 필터가 죽은 채 6거래일. "라이브에서 값이 찍히는 것까지 봐야 만든 것이다").
#   확인하는 법 — `진단.bat` 의 `진단결과.txt` 맨 위에 이 값이 찍힌다(jindan.py 가 직접 읽는다).
#   기동할 때 `client_log.txt` 에도 한 줄 남는다. **재배포할 때마다 올릴 것.**
BUILD = "2026-10-01c"   # 10-01c 옛 경로 예약작업 정리 — 검토 반영(실행 대상만 판정 · 지우기 전 XML 백업 · 남의 종가 작업 보호 · cmd/powershell 감싼 형태) · 10-01b 첫 판(JonggaClientGuardian 실사고) · 09-30 사이징 동치 + 10-01 빈 잔고응답 가드(_acct_snapshot_doubt · 정리 보류) · 종목수 보완안(n_cand) · 유통 무음 로그
PICKS_URL = "https://hn98201.github.io/apple_paly/picks_latest.json"
MANAGE_OPEN, MANAGE_CLOSE, BUY_HM, CONVERT_HM, RECON_HM, DONE_HM = "09:00", "15:19", "15:25", "15:28", "15:31", "15:35"   # ★모의(정규장 종가) — 예전 그대로
# ★BUY_HM 15:25 는 관리자(15:26)와 **일부러 다르다** — 맞추지 말 것(2026-09-30 확인).
#   관리자는 2026-09-23 에 15:25 → 15:26 으로 옮겼다. 단기과열 2차 판정을 종가에 더 붙이려는 것이고,
#   관리자에만 있는 그 필터 때문에 생긴 시각이다.
#   · 체결가는 안 바뀐다 — 15:20~15:30 은 종가 동시호가라 지정가·시장가 모두 15:30 단일가에
#     일괄 체결된다. 발주를 1분 늦춰도 받는 값이 같다(실익 0원).
#   · 반면 클라이언트는 관리자가 15:20 에 올린 픽을 **폴링으로 받아야** 산다. 15:26 으로 옮기면
#     발주 창이 CONVERT_HM(15:28)까지 2분으로 줄어, 깃허브 Pages 반영이 늦은 날 픽을 못 받고
#     그날 매수를 통째로 놓칠 수 있다. 얻는 것은 없고 잃을 것만 있는 변경이다.
#   ⛔`프로그램_대조점검` 이 이 값을 불일치로 세지 않는다 — 의도된 차이다.
CLOSE_END = "15:20"      # ★강제청산 창(15:19~15:20). 모드 무관 — 정규장 마감 동시호가가 유동성이 가장 좋다
# ★손절 백업(2026-09-28 · 관리자 2026-09-22 분 이식) — 손절이 _on_realtick 하나에만 걸려 있었다.
#   익절은 지정가가 거래소에 걸려 있어 프로그램이 죽어도 체결되는데 **손절만** 실시간 틱 생존에 의존했다.
#   틱이 끊기면 손절이 아예 안 된다. 그래서 manage() 20초 틱에서 **시세가 낡았을 때만** 직접 조회해 확인한다.
#   정상 상황(틱이 오는 중)에는 추가 TR 이 0 이다.
SL_BACKUP_STALE = 45     # 현재가가 이 초수보다 낡으면 직접 조회
SL_BACKUP_GAP = 20       # 같은 종목 재조회 최소 간격(초) — TR 폭주 방지
# ★실계좌(애프터마켓 종가) 루틴 — 2026-09-17 제도변경. 실질 종가가 20:00 이 됐다.
#   관리자가 19:52 에 스캔·픽 배포 → 클라이언트는 19:55 에 현재가 지정가로 사고,
#   19:58 에 미체결분을 한 호가 위로 정정한다(애프터마켓엔 시장가가 없다).
AF_BUY_HM, AF_CONVERT_HM, AF_RECON_HM, AF_DONE_HM = "19:55", "19:58", "20:01", "20:05"
# ★저녁 루틴 스위치 — 2026-09-17 원복. True 로 바꾸면 실계좌가 다시 19:55~20:05 로 돈다.
#   ★관리자(admin.py) 의 EVENING_ROUTINE 과 반드시 같은 값이어야 한다 — 한쪽만 켜면
#     관리자는 19:52 에 픽을 올리는데 클라이언트는 15:25 에 찾는 식으로 어긋난다.
EVENING_ROUTINE = False
OP_START, LOGIN_HM, OP_END = "08:20", "08:30", "20:20"                        # ★운영 생명주기: 평일 08:20 자동실행 → 08:30 키움로그인 → 09:00 매매개시 → 20:20 매매중지(끄지 않고 대기)
#   ★17:00 → 20:05 (2026-09-17): 애프터마켓(16:00~20:00) 발주와 체결 인지를 위해 늘렸다.
#     예전엔 17:00 에 _night_idle 이 enabled 를 꺼서 발주 창이 16:00~16:59 뿐이었다.
#     프로그램을 끄는 게 아니라 매매만 멈추는 구조라 PC 를 더 붙잡지는 않는다.
BALANCE_SEC = 90                      # ★계좌 잔고 재조회 간격(초) — 실계좌 표시가 아침 숫자로 굳던 문제(2026-09-17)
BALANCE_SKIP = ("15:18", "15:35")     # ★청산·스캔·매수가 TR 을 몰아쓰는 구간은 건너뛴다
BALANCE_SKIP_AF = ("19:53", "20:05")  # ★실계좌 애프터마켓 루틴(19:55 매수~20:01 보정)도 같은 이유로 쉰다
REG_END = "15:30"                          # ★정규장 끝(장마감 동시호가 포함). 이 밖의 틱은 정규장 판정에 쓰지 않는다
AFTP_START, AFTP_END = "16:00", "20:00"    # ★KRX 애프터마켓(2026-09-14 신설·접속매매·지정가만·가격제한 전일종가±30%)
AF_WATCH_SEC, AF_WATCH_END, AF_SELL_TICKS = 20, "19:58", 2   # ★조회 받침주기·중단시각(20:00 주문소멸)·즉시체결용 호가수 (2026-09-18)
AF_FRESH_SEC, AF_MIN_GAP = 90, 2   # ★실시간 시세를 믿는 기간(초) · 연속 판정 최소간격(초·틱 폭주 방지)
LOCK_PORT = 53137             # ★중복실행 차단용 로컬 포트 — 프로세스 목록 조회보다 5초 빠르다
AUTO = ("auto" in sys.argv)   # ★바탕화면 아이콘(auto)=무인 생명주기 적용 / 인자 없이 직접 실행=보기전용(자동로그인 안 함)
LIC_WARN_DAYS = 7             # ★사용승인 만료 며칠 전부터 알릴지 (2026-09-18 사용자 요청)
START_CAP = 10_000_000

# ★기본값은 '설정파일이 없거나 키가 빠졌을 때' 쓰인다 — 옛 3%/3% 가 남아 있으면
#   client_config.json 이 지워졌을 때 조용히 다른 전략으로 매매한다. 운영값과 같게 유지할 것.
DEFCFG = {"account": "", "is_mock": True, "tp_pct": 6.0, "sl_pct": -3.5, "fee_pct": 0.23, "principal": 1000, "invest_per_stock": 2000000,
          "telegram_chat_id": "", "nickname": "", "hub_url": "http://127.0.0.1:8770",
          "enabled": False, "pw_registered": False, "card_pos": {},
          # ★auto_start 는 '무인 운영을 계속한다'는 뜻이다. 이 키가 빠지면 cfg.get() 이 None(=꺼짐)이 되어
          #   08:30 자동재개(_daily_resume)가 조용히 안 돈다 — 설정파일이 지워진 PC 에서 실제로 위험하다.
          #   기본을 True 로 둔다. 사용자가 [자동매매 정지]를 누르거나 안전정지가 걸리면 그때 False 가 된다.
          "auto_start": True,
          # ★관리자와 동일한 사이징·갭컷(2026-09-14 추가). 관리자 admin_config.json 과 같은 값으로 둘 것.
          "cash_buffer": 200000, "size_div": 3, "min_positions": 2, "gapcut_pct": 0.0,
          "float_max": 70, "exclude_upper": True,
          # 🌙 애프터마켓(16:00~20:00) 익절전용 — 켜야 실주문이 나간다(모의는 불가)
          #    aftp_hoga: 키움 거래구분. "00"=지정가. 옛 "62"(시간외단일가)는 2026-09-14 폐지됐다.
          "test_qty": 0,           # 🧪 실계좌 소액 테스트 — 0=평소 / 1↑=종목당 그 수량만 산다(금액 사이징 무시)
          "live_start_equity": 0,   # ★실전 첫 거래 전 계좌 자산(자동 기록). 0=미기록 → 원금으로 물러난다
          "aftp_live": False, "aftp_hoga": "00",
          # 📨 텔레그램 — 토큰을 비워 두면 배포본 기본 봇으로 나간다.
          #    자기 봇(@BotFather 에서 만든 것)이 있으면 그 토큰을 넣으면 그 봇으로 나간다.
          "telegram_token": ""}

MIN_POS_WON = 100000     # ★한 종목 최소 투입금 — 이보다 잘게 쪼개면 호가단위 오차가 커진다

UP, DN, PUR, GOLD = "#ff5468", "#43a6ff", "#9b6cff", "#f5b53d"
CYAN, CY2, GLOWC = "#38e7f2", "#15c4d7", "#0bd3e0"      # ★사이버 HUD 시안 글로우(관리자와 동일 테마)
INK, MUT = "#dce9ee", "#6f8a9a"
FONT_STACK = "'Pretendard','NanumSquareRound','Malgun Gothic','Segoe UI'"


def loadj(p, d):
    try: return json.load(open(p, encoding="utf-8"))
    except Exception: return json.loads(json.dumps(d))


def savej(p, o):
    try: json.dump(o, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    except Exception: pass


def _acct_snapshot_doubt(acct):
    """잔고 스냅샷을 **'계좌에 없다 = 팔렸다' 의 근거로** 믿어도 되는지 → 못 믿을 이유(문자열) · 믿으면 "". (2026-10-01)

    ★관리자 `admin._acct_snapshot_doubt` 와 **판정식이 같아야 한다** — 한쪽만 고치면 같은 응답을 두 프로그램이
      다르게 읽는다(검증 하니스로 대조했다). 부작용 0 · TR 0.
    쓰는 곳 두 곳 — `_aftp_reconcile`(전일 애프터 체결 확인) · `_adopt_holdings` 의 '1) 정리'.
    ☠️ 관리자 09-30 08:30 실사고 — 로그인 직후 opw00018 이 **통째로 빈 응답**(목록 [] · 평가 0 · 추정예탁자산 0)을
      줬고, 그걸 "한켐 110주가 사라졌다 = 어제 애프터에서 팔렸다" 로 읽어 거짓 '+7.29% 익절' 을 기록·알림했다.
      클라이언트는 opw00018 파서가 같아서 같은 응답이 온다.
    ★'진짜 보유 없음' 과 반드시 가른다 — 그걸 막으면 전일 애프터 체결 기록이 영영 안 된다.
        진짜 보유 없음 : 목록 [] · 평가 0 · 추정예탁자산 > 0  ← 믿는다(애프터 매도대금이 결제 전에도 잡힌다)
        빈 응답        : 목록 [] · 평가 0 · 추정예탁자산 0     ← 못 믿는다
        불완전 조회    : 목록 [] 인데 주식평가·총매입 > 0     ← 못 믿는다(관리자 실측 16:19·16:28 · 90초 뒤 정상)
    ★목록에 종목이 **하나라도 있으면** 믿는다(성하지 않은 원소가 섞이면 query_account 가 회차째 건너뛴다)."""
    if not isinstance(acct, dict):
        return "계좌정보가 dict 가 아님"
    if acct.get("stale"):
        return "잔고 재조회 실패(옛 값)"
    if acct.get("stocks_stale"):
        return f"종목목록이 낡음({acct.get('stocks_asof') or '?'} 기준)"
    stk = acct.get("stocks")
    if not isinstance(stk, list):
        return "종목목록 형식 이상"
    if stk:
        return ""
    try:
        ar = int(acct.get("assets_real") or 0)
        te = int(acct.get("total_eval") or 0)
        tb = int(acct.get("total_buy") or 0)
    except Exception:
        return "잔고 숫자를 읽을 수 없음"
    if ar <= 0:
        return "종목목록 [] · 추정예탁자산 0 — 잔고(opw00018) 빈 응답"
    if te > 0 or tb > 0:
        return f"종목목록 [] 인데 주식평가 {te:,} · 총매입 {tb:,} — 불완전 조회"
    return ""


def tg_send(chat_id, text, token=""):
    """★token 을 주면 그 봇으로, 비어 있으면 배포본 기본 봇으로 보낸다. (2026-09-17)

    자기 봇을 쓰면 배포본에 든 토큰이 새도 그 사람 알림은 안전하다."""
    if not chat_id: return
    ok, _ = tg_try(chat_id, text, token)
    return ok


def tg_try(chat_id, text, token=""):
    """실제 전송 + 결과를 알려 준다 — (성공여부, 사람이 읽을 메시지).

    설정 탭의 [테스트 전송] 이 이걸 쓴다. 텔레그램이 돌려주는 영어 사유를
    그대로 보여주면 사용자가 뭘 해야 할지 모르니 한국어로 풀어 준다."""
    import json as _json, urllib.parse
    tok = (token or "").strip() or TG_TOKEN
    if not str(chat_id).strip():
        return False, "chat_id 가 비어 있습니다"
    # ★토큰 형식 먼저 본다(2026-09-17 실제로 당했다) — 앞의 '봇번호:' 를 빼고 뒷부분만 붙여넣으면
    #   텔레그램이 'Not Found' 를 돌려줘서 'chat_id 문제' 로 오해하기 딱 좋다.
    if (token or "").strip():
        t = token.strip()
        if ":" not in t:
            return False, ("봇 토큰 앞부분이 빠졌습니다 — @BotFather 가 준 한 줄 전체를 넣으세요.\n"
                           "   올바른 모양:  123456789:AAE... (숫자 + 콜론 + 문자)\n"
                           "   지금 넣으신 것: 콜론 앞의 숫자가 없습니다")
        if not t.split(":", 1)[0].strip().isdigit():
            return False, "봇 토큰 모양이 이상합니다 — 콜론 앞은 숫자(봇 번호)여야 합니다"
    try:
        data = urllib.parse.urlencode({"chat_id": str(chat_id).strip(), "text": text}).encode()
        urllib.request.urlopen(urllib.request.Request(
            f"https://api.telegram.org/bot{tok}/sendMessage", data=data), timeout=8)
        return True, "보냈습니다 — 텔레그램을 확인하세요"
    except urllib.error.HTTPError as e:
        why = ""
        try: why = (_json.loads(e.read().decode("utf-8", "replace")) or {}).get("description", "")
        except Exception: pass
        if "chat not found" in why:
            return False, ("그 봇과 대화가 없습니다 — 텔레그램에서 **그 봇을 찾아 [시작]** 을 누른 뒤 "
                           "다시 해보세요. (chat_id 가 봇 번호는 아닌지도 확인)")
        if "Unauthorized" in why or e.code == 401:
            return False, ("봇 토큰이 맞지 않습니다 — 콜론 앞 번호와 뒷부분이 한 짝이어야 합니다.\n"
                           "   @BotFather → /mybots → 내 봇 → API Token 에서 **한 줄 전체**를 복사하세요")
        if e.code == 404 or "Not Found" in why:
            return False, ("그런 봇이 없습니다 — 토큰을 다시 확인하세요.\n"
                           "   (앞의 '봇번호:' 를 빼고 뒷부분만 넣으면 이 오류가 납니다)")
        if "blocked" in why:
            return False, "사용자가 그 봇을 차단했습니다 — 차단을 풀어 주세요"
        return False, "실패: %s" % (why or ("HTTP %d" % e.code))
    except Exception as e:
        return False, "실패: %s" % e


def shadow(w, blur=28, dy=8, alpha=170):
    e = QGraphicsDropShadowEffect(w); e.setBlurRadius(blur); e.setXOffset(0); e.setYOffset(dy)
    e.setColor(QColor(0, 0, 0, alpha)); w.setGraphicsEffect(e); return e


def glow(w, color=None, blur=30, alpha=140):        # ★시안 발광(관리자와 동일)
    e = QGraphicsDropShadowEffect(w); e.setBlurRadius(blur); e.setXOffset(0); e.setYOffset(0)
    c = QColor(color or GLOWC); c.setAlpha(alpha); e.setColor(c); w.setGraphicsEffect(e); return e


# ───────── 세련된 라인 차트 ─────────
class Sparkline(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent); self.vals = []; self.setMinimumHeight(90)
    def setData(self, vals): self.vals = list(vals); self.update()
    def paintEvent(self, _):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height(); pad = 6
        vals = self.vals
        if len(vals) < 2:
            p.setPen(QColor("#5b6472")); p.drawText(self.rect(), Qt.AlignCenter, "거래 데이터 쌓이는 중…"); return
        mn, mx = min(vals + [0]), max(vals + [0]); rng = (mx - mn) or 1
        def X(i): return pad + (w - 2 * pad) * i / (len(vals) - 1)
        def Y(v): return pad + (h - 2 * pad) * (1 - (v - mn) / rng)
        # zero line
        zy = Y(0); p.setPen(QPen(QColor(255, 255, 255, 28), 1, Qt.DashLine)); p.drawLine(pad, int(zy), w - pad, int(zy))
        pos = vals[-1] >= 0; col = QColor(UP if pos else DN)
        # area gradient
        path = QPainterPath(); path.moveTo(X(0), Y(vals[0]))
        for i in range(1, len(vals)): path.lineTo(X(i), Y(vals[i]))
        area = QPainterPath(path); area.lineTo(X(len(vals) - 1), h - pad); area.lineTo(X(0), h - pad); area.closeSubpath()
        g = QLinearGradient(0, 0, 0, h); c2 = QColor(col); c2.setAlpha(90); c3 = QColor(col); c3.setAlpha(0)
        g.setColorAt(0, c2); g.setColorAt(1, c3); p.fillPath(area, QBrush(g))
        p.setPen(QPen(col, 2.4)); p.drawPath(path)
        # glow endpoint
        ex, ey = X(len(vals) - 1), Y(vals[-1])
        gl = QColor(col); gl.setAlpha(70); p.setBrush(gl); p.setPen(Qt.NoPen); p.drawEllipse(QPointF(ex, ey), 7, 7)
        p.setBrush(col); p.drawEllipse(QPointF(ex, ey), 3.5, 3.5)


# ───────── 승률 게이지(도넛) ─────────
class Gauge(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent); self.pct = 0; self.setFixedSize(120, 120)
    def setPct(self, v): self.pct = max(0, min(100, v)); self.update()
    def paintEvent(self, _):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(12, 12, self.width() - 24, self.height() - 24)
        p.setPen(QPen(QColor(255, 255, 255, 24), 11)); p.drawArc(r, 0, 360 * 16)
        col = QColor(UP if self.pct >= 50 else GOLD)
        pen = QPen(col, 11); pen.setCapStyle(Qt.RoundCap); p.setPen(pen)
        p.drawArc(r, 90 * 16, -int(360 * 16 * self.pct / 100))
        p.setPen(QColor("#f0eef8")); f = QFont("Malgun Gothic", 20, QFont.Bold); p.setFont(f)
        p.drawText(self.rect().adjusted(0, -6, 0, -6), Qt.AlignCenter, f"{self.pct:.0f}%")
        p.setPen(QColor("#8b93a7")); p.setFont(QFont("Malgun Gothic", 8))
        p.drawText(self.rect().adjusted(0, 34, 0, 34), Qt.AlignCenter, "승률")


# ───────── 반응형 카드(창 크기 따라 비율대로 커짐) ─────────
class Donut(QWidget):
    """원형 비중 그래프 — 조각 비율을 링으로 그리고 가운데에 큰 숫자를 넣는다. (관리자와 동일)

    parts: [(값, 색, 라벨)] · 합이 0이면 회색 링만 그린다.
    숫자가 길면(잔고 등) 폭에 맞춰 글자 크기를 자동으로 줄인다."""

    def __init__(self, size=140, width=18, parent=None):
        super().__init__(parent)
        self.setFixedSize(size, size)
        self._w = width; self.parts = []; self.center = ""; self.sub = ""; self.ccol = INK

    def setData(self, parts, center="", sub="", ccol=None):
        self.parts = [p for p in (parts or []) if p[0] > 0]
        self.center = center; self.sub = sub; self.ccol = ccol or INK
        self.update()

    def paintEvent(self, _):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        m = self._w / 2 + 3
        r = QRectF(m, m, self.width() - 2 * m, self.height() - 2 * m)
        p.setPen(QPen(QColor(255, 255, 255, 18), self._w)); p.drawArc(r, 0, 360 * 16)
        tot = sum(x[0] for x in self.parts)
        if tot > 0:
            start = 90 * 16
            for frac, col, _lab in self.parts:
                span = -int(360 * 16 * (frac / tot))
                pen = QPen(QColor(col), self._w); pen.setCapStyle(Qt.FlatCap)
                p.setPen(pen); p.drawArc(r, start, span)
                start += span
        if self.center:
            inner = int(self.width() - 2 * m - 10)
            fs = 19
            while fs > 9:
                f = QFont("Malgun Gothic", fs, QFont.Bold)
                if QFontMetrics(f).horizontalAdvance(self.center) <= inner: break
                fs -= 1
            p.setPen(QColor(self.ccol)); p.setFont(QFont("Malgun Gothic", fs, QFont.Bold))
            p.drawText(self.rect().adjusted(0, -9 if self.sub else 0, 0, -9 if self.sub else 0),
                       Qt.AlignCenter, self.center)
        if self.sub:
            p.setPen(QColor(MUT)); p.setFont(QFont("Malgun Gothic", 8))
            p.drawText(self.rect().adjusted(0, 24, 0, 24), Qt.AlignCenter, self.sub)


class Card(QFrame):
    def __init__(self, title, minw=200, minh=120):
        super().__init__(); self.setObjectName("card")
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding); self.setMinimumSize(minw, minh)
        shadow(self)
        v = QVBoxLayout(self); v.setContentsMargins(15, 11, 15, 13); v.setSpacing(6)
        t = QLabel(title); t.setObjectName("ctitle"); v.addWidget(t)
        self.body = QVBoxLayout(); self.body.setSpacing(4); v.addLayout(self.body, 1)


CSS = f"""
QMainWindow,QWidget{{background:#060a10;color:{INK};font-family:{FONT_STACK};font-size:13px;}}
#appbar{{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #0b141c,stop:1 #070c12);border-bottom:1px solid #123039;}}
#brand{{font-size:18px;font-weight:800;color:#eafcff;letter-spacing:2px;}}
#navbtn{{background:transparent;color:#7d95a3;border:none;padding:9px 15px;font-size:12.5px;font-weight:700;border-radius:12px;letter-spacing:.5px;}}
#navbtn:hover{{color:{CYAN};}}
#navbtn[on="1"]{{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 rgba(56,231,242,.20),stop:1 rgba(21,196,215,.08));color:{CYAN};border:1px solid #1d515c;}}
#card{{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #0e1a22,stop:1 #0a141b);border:1px solid #163540;border-radius:18px;}}
#ctitle{{color:{CYAN};font-size:12.5px;font-weight:800;letter-spacing:1px;}}
#big{{font-size:32px;font-weight:900;letter-spacing:.5px;}}
#statcard{{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #0e1a22,stop:1 #0a141b);border:1px solid #163540;border-radius:18px;}}
QPushButton{{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #10323b,stop:1 #0c2129);color:{CYAN};border:1px solid #1d515c;border-radius:12px;padding:9px 15px;font-weight:800;letter-spacing:.5px;}}
QPushButton:hover{{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #16454f,stop:1 #103038);border:1px solid {CYAN};color:#eafcff;}}
QPushButton:disabled{{background:#0f1720;color:#3f5560;border:1px solid #16242c;}}
QPushButton#seg{{padding:6px 10px;font-size:12px;font-weight:700;letter-spacing:0;min-width:0;}}
QPushButton#seg[on="1"]{{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 rgba(56,231,242,.30),stop:1 rgba(21,196,215,.12));color:#eafcff;border:1px solid {CYAN};}}
#gobtn{{font-size:15px;padding:14px;border-radius:15px;}}
QLineEdit,QComboBox{{background:#0a141b;color:{INK};border:1px solid #1a3742;border-radius:11px;padding:9px 11px;}}
QLineEdit:focus{{border:1px solid {CYAN};}}
QRadioButton{{color:#a9c3cd;font-weight:700;}}
#pill{{background:rgba(56,231,242,.12);color:{CYAN};border:1px solid #1d515c;border-radius:999px;padding:3px 12px;font-weight:800;font-size:11px;}}
#modebtn{{background:#0c161d;color:#82a0ac;border:1px solid #17323c;border-radius:12px;padding:9px 13px;font-weight:800;}}
#stpill{{background:transparent;border:none;padding:0 6px;}}
#trow{{color:#a9c3cd;}} .muted{{color:{MUT};}}
QScrollArea{{border:none;background:transparent;}}
QScrollBar:vertical{{background:transparent;width:9px;margin:2px;}} QScrollBar::handle:vertical{{background:#1d4650;border-radius:4px;}} QScrollBar::handle:vertical:hover{{background:{CY2};}}
"""


class Client(QMainWindow):
    def __init__(self):
        super().__init__()
        # ★중복 실행 차단(2026-09-15) — 아래 enabled=False 가 **돌고 있던 자동매매를 꺼버린다.**
        #   이미 떠 있는데 바탕화면 아이콘으로 하나 더 띄우면 조용히 멈춘다(관리자에서 실제로 당했다).
        #   설정을 건드리기 **전에** 검사하고, 중복이면 아무것도 바꾸지 않고 나간다.
        _dup = self._already_running()
        if _dup:
            self.log(f"⛔ 이미 실행 중입니다(PID {_dup}) — 이 창은 닫습니다. 떠 있는 창을 쓰세요")
            if not AUTO:
                try:
                    self._alert("이미 실행 중입니다",
                                f"종가배팅 클라이언트가 이미 실행 중입니다. (PID {_dup})\n\n"
                                "두 개를 동시에 띄우면 키움 접속이 충돌하고\n"
                                "돌고 있던 자동매매가 꺼집니다.\n\n"
                                "이미 떠 있는 창을 사용하세요.")
                except Exception: pass
            QTimer.singleShot(0, lambda: sys.exit(0))
            self._dup_exit = True
            return
        self.cfg = loadj(CONFIG, DEFCFG)
        for k, v in DEFCFG.items(): self.cfg.setdefault(k, v)   # ★신규 설정키(nickname·hub_url 등) 기본값 병합
        self.state = loadj(STATE, {"date": "", "positions": [], "trades": []})
        try:
            self.kw = TradeKiwoom()
        except Exception as e:      # ★키움 OCX 를 못 올린 경우 — 영문 트레이스백 대신 한글 안내
            try:
                from kiwoom_ocx import KiwoomOcxError, guide
                msg = str(e) if isinstance(e, KiwoomOcxError) else guide("원래 오류 : %s" % e)
            except Exception:
                msg = "키움 OpenAPI 를 사용할 수 없습니다.\n\n원래 오류 : %s" % e
            _fatal(msg)
            _sys.exit(1)
        self.kw.on_log = self.log
        self.connected = False; self.acct = {}
        self.bought_today = (self.state.get("buy_date") == self._t())
        self.converted_today = False; self._recon_date = ""   # ★관리자 동일: 15:28 시장가전환·15:31 실잔고보정 1일1회 가드
        self.cfg["enabled"] = False; savej(CONFIG, self.cfg)   # ★시작 시 항상 정지 상태 — [자동매매 시작] 눌러야 시작(로그인부터)
        self._live_dirty = False; self._real_on = False; self._real_key = ""   # SetRealReg 실시간 상태
        self._disc_since = None; self._disc_alerted = False                    # 미접속 1분↑ 감시
        self._logging_in = False                                               # ★로그인 재진입 가드(중첩 do_login/이벤트루프 방지)
        self._popup_n = 0; self._popup_reported = 0                            # ★키움 모달팝업 자동확인 카운터(무인 언블록)
        self._licensed = False; self._lic_status = "확인전"; self._lic_expiry = None; self._chat_rendered = 0; self._lic_ticks = 0
        self._st_online = True; self._hub_ok = False; self._st_ticks = 0     # 상단 상태표시
        self._picks = {}                                                     # ★깃허브 최근 추천종목(대시보드 표시용)
        self._build()
        st.set_thresholds(self.cfg.get("tp_pct", 3.0), self.cfg.get("sl_pct", -3.0))  # 로그인은 안 함(시작 눌러야)
        st.set_fee(self.cfg.get("fee_pct", 0.23)); self._upper_date = ""              # ★1:1 손절용 수수료·상한가 일일리셋 가드
        self._bg(self.check_license, "license")   # ★기동 때도 기다리지 않는다(결과는 5초 뒤 화면에 뜬다)
        self.timer = QTimer(self); self.timer.timeout.connect(self.tick); self.timer.start(20000)
        self.uitimer = QTimer(self); self.uitimer.timeout.connect(self.refresh); self.uitimer.start(5000)
        self.livetimer = QTimer(self); self.livetimer.timeout.connect(self._live_flush); self.livetimer.start(800)  # ★실시간 틱→UI(HTS처럼 가격/등락 실시간)
        self.hubtimer = QTimer(self); self.hubtimer.timeout.connect(self._refresh_hub); self.hubtimer.start(3000)   # 채팅·라이선스 폴링
        self._fetch_picks_bg()                                              # ★시작 시 추천종목 1회 로드
        self.picktimer = QTimer(self); self.picktimer.timeout.connect(self._fetch_picks_bg); self.picktimer.start(300000)  # 5분마다 깃허브 추천종목 갱신
        threading.Thread(target=self._kiwoom_dialog_watcher, daemon=True).start()   # ★키움 모달팝업 자동확인(무인 필수 — 별도 스레드라 모달이 메인을 막아도 동작)
        threading.Thread(target=self._drop_legacy_tasks, daemon=True).start()       # ★옛 설치가 남긴 예약작업 제거(run_watchdog.vbs 오류창의 원인)
        # ★빌드를 **매 기동마다** 로그에 남긴다 (2026-09-29) — 어느 배포본이 도는지 확인하려고.
        #   무인(auto)·수동 둘 다 남긴다. `self.log` 는 파일·화면 둘 다 자체 try/except 라 안전하다.
        self.log(f"⚙ 빌드 {BUILD}")
        if not AUTO:
            self.log("👀 수동 실행(보기 전용) — 자동로그인·자동종료 없음. 매매하려면 [자동매매 시작]")
        if AUTO and self.cfg.get("auto_start"):      # ★아이콘(auto) 실행 후에만 자동 재개 — 로그인은 08:30에(장전 매매대기)
            _rh = [t for t in loadj(RESTART_LOG, []) if time.time() - t < 600]   # 최근 재시작 이력(폭주=지속장애)
            _back = 0 if len(_rh) < 2 else min(300, 30 * (2 ** (len(_rh) - 2)))  # 1회 즉시 후 지속 재시작 시 로그인 지연(30→60→120→240→300초): 레이트차단 방지
            _now = datetime.datetime.now(); _delay = 6 + _back
            _tl = _now.replace(hour=8, minute=30, second=0, microsecond=0)       # ★08:25~08:30 실행 시 → 08:30까지 대기 후 로그인(사용자 지시)
            if _now.weekday() < 5 and OP_START <= _now.strftime("%H:%M") < LOGIN_HM:
                _delay = max(_delay, int((_tl - _now).total_seconds()))
            QTimer.singleShot(_delay * 1000, self._auto_resume)

    def _operating(self):
        """★운영 생명주기: 평일(월~금) OP_START~OP_END(08:20~20:20)만 가동. 밖이면 종료 대상(야간·주말)."""
        now = datetime.datetime.now()
        return now.weekday() < 5 and OP_START <= now.strftime("%H:%M") < OP_END

    def _autostart_task_ok(self):
        """★아침에 프로그램을 다시 띄워 줄 예약작업(JonggaClientRun)이 실제로 있나. (2026-09-17)

        이게 없는데 20:20 에 프로그램을 끄면 **다음 날 아무도 못 켠다.**
        설치 때 권한 상승 창에서 [아니오] 를 누르면 등록이 조용히 건너뛰어진다 —
        실제로 일어나는 일이라 끄기 전에 반드시 확인한다."""
        try:
            q = subprocess.run(["schtasks", "/Query", "/TN", "JonggaClientRun"],
                               capture_output=True, timeout=10,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            return q.returncode == 0
        except Exception:
            return False          # 확인 자체가 안 되면 '없다' 로 본다(끄지 않는 쪽이 안전)

    def _night_idle(self):
        """★운영시간 밖(OP_END=20:20 이후·주말) — 프로그램을 끈다. (2026-09-17 사용자 지시)

        사용자 방침: PC 는 켜 두고 절전도 쓰지 않는다. 프로그램만 20:20 에 끝낸다.
        다음 평일 08:20 에 예약작업 JonggaClientRun 이 다시 띄운다.

        ★예약작업이 없으면 끄지 않는다.
          예전(2026-09-16)엔 예약작업이 아예 없어서 '끄면 아무도 못 켠다' 는 이유로
          켜 둔 채 대기했다. 지금은 작업이 있지만, 설치 때 권한 창에서 [아니오] 를 누르면
          등록이 건너뛰어진 채로 남는다. 그 상태에서 끄면 그 사람은 다음 날부터 매매가 멈춘다.
          그래서 확인하고, 없으면 예전 방식(대기)으로 물러나면서 이유를 알린다."""
        if self.cfg.get("enabled"):
            self.cfg["enabled"] = False; savej(CONFIG, self.cfg)
        if not AUTO:
            self._resumed_day = None
            return                        # 수동 실행(보기 전용)은 끄지 않는다 — 사용자가 보고 있다
        # ★운영시간 밖에 **방금 켠** 것이면 끄지 않는다. (2026-09-17 신고)
        #   바탕화면 아이콘은 schtasks /Run 을 거쳐 AUTO 모드로 뜬다.
        #   그래서 밤에 아이콘을 누르면 첫 tick 에서 바로 종료돼 "팅긴다" 로 보였다.
        #   이번 실행에서 운영시간을 한 번도 지나오지 않았다면 = 사람이 지금 연 것이다.
        #   창을 띄워 두고 사용자가 직접 닫게 한다(관리자 수동실행과 같은 느낌).
        if not getattr(self, "_was_op", False):
            if getattr(self, "_idle_warned", "") != self._t():
                self._idle_warned = self._t()
                try:
                    self.log(f"🌙 지금은 운영시간({OP_START}~{OP_END}) 밖입니다 — 매매는 쉬고 화면만 켜 둡니다")
                    self.log("   창은 직접 닫으시면 됩니다. 다음 평일 08:20 에 자동으로 다시 시작합니다")
                except Exception: pass
            self._resumed_day = None
            return
        if self._autostart_task_ok():
            try:
                self.log(f"🌙 운영시간 종료({OP_END}) — 프로그램을 종료합니다. 다음 평일 08:20 자동 재시작")
                self.tg(f"🌙 운영시간 종료({OP_END}) — 프로그램 종료. 다음 평일 08:20 에 자동으로 다시 시작합니다.\n"
                        f"PC 는 켜 두세요(절전은 설치 때 꺼 뒀습니다).")
            except Exception: pass
            savej(STATE, self.state)
            os._exit(0)                   # ★즉시 종료(OS 가 OCX 를 해제한다 — CommTerminate 는 행 위험)
        # 예약작업이 없다 — 끄면 못 켜므로 예전처럼 켜 둔 채 대기한다
        if getattr(self, "_idle_warned", "") != self._t():
            self._idle_warned = self._t()
            try:
                self.log("⚠️ 자동시작 예약작업(JonggaClientRun)이 없습니다 — 끄지 않고 대기합니다")
                self.log("   [2_프로그램설치.bat] 을 다시 실행하고 파란 창이 뜨면 [예] 를 누르세요")
                self.tg("⚠️ 자동시작 예약작업이 없어 프로그램을 끄지 않고 대기합니다.\n"
                        "[2_프로그램설치.bat] 을 다시 실행하고 권한 창에서 [예] 를 눌러 주세요.")
            except Exception: pass
        self._resumed_day = None          # 다음 운영일에 다시 로그인하도록 초기화

    def _daily_resume(self):
        """★예약작업 없이 매일 자동 재개 — 켜 둔 채 밤을 넘겨도 다음 평일 08:30 에 스스로 로그인한다.

        하루 한 번만 시도한다. 로그인이 실패하면 toggle_auto() 가 _restart_process() 로
        프로세스를 새로 띄우고, 새 프로세스가 6초 뒤 _auto_resume() 을 다시 태운다."""
        if self._hm() < LOGIN_HM: return                     # 08:25~08:30 은 대기(로그인은 08:30)
        d = self._t()
        if getattr(self, "_resumed_day", None) == d: return
        self._resumed_day = d
        if not self.cfg.get("auto_start"): return            # 사용자가 [자동매매 중지] 를 눌렀으면 그대로 둔다
        if self.cfg.get("enabled"): return                   # 이미 돌고 있으면 건드리지 않는다
        try: self.connected = int(self.kw.dynamicCall("GetConnectState()")) == 1   # 밤새 끊겼는지 실제로 확인
        except Exception: self.connected = False
        self.log("🔄 운영시간 진입 — 자동 로그인 시작(예약작업 없이 스스로)")
        self._auto_resume()

    def _auto_resume(self):
        """자동 재개 — 운영시간(평일 08:20~20:20)이면 08:30 로그인, 밖이면 아무것도 하지 않는다.

        ★예전엔 여기서도 _night_idle() 을 불렀다. 그런데 이 함수는 기동 몇 초 뒤에 도는 것이라
          '운영시간 밖에 방금 켰다' 는 상황과 구분이 안 됐다 — 켜자마자 꺼지는 원인 중 하나였다.
          하루를 마치는 판단은 tick 의 _night_idle 한 곳에서만 한다."""
        if not AUTO: return
        if not self._operating(): return
        if self.cfg.get("auto_start") and not self.cfg.get("enabled"):
            self.check_license()
            if not self._licensed:
                self.log("⚠️ 미승인 — 자동시작 보류(관리자 승인 필요)"); return   # ★알림창 없이 로그만(무인 모달블록 방지)
            self.log("🔄 자동 재개 — 08:30 자동루틴 시작(무인)"); self.toggle_auto()

    def _fetch_picks_bg(self):
        """깃허브 최근 추천종목을 백그라운드로 로드(메인스레드 블로킹 없이) → 대시보드 표시."""
        def _work():
            try:
                pj = self.fetch_picks()
                if pj and pj.get("stocks"): self._picks = pj; self._live_dirty = True
            except Exception: pass
        threading.Thread(target=_work, daemon=True).start()

    def _bg(self, fn, key):
        """★네트워크는 전부 여기로 — 메인스레드에서 기다리면 창이 그대로 얼어붙는다.

        2026-09-16 실측: _update_status 한 번에 2.5초(온라인 3초 + 허브 6초 타임아웃).
        refresh 가 5초마다 도니 25초마다 뚝 끊겼고, 채팅은 3초마다 같은 짓을 했다.
        같은 key 가 아직 돌고 있으면 새로 띄우지 않는다 — 느린 서버에서 스레드가 쌓이는 것 방지."""
        busy = self.__dict__.setdefault("_bg_busy", set())
        if key in busy: return
        busy.add(key)

        def _work():
            try: fn()
            except Exception: pass
            finally: busy.discard(key)
        threading.Thread(target=_work, daemon=True).start()

    def _probe_net(self):
        """온라인·관리자연결 확인(백그라운드 전용). 결과는 다음 갱신(5초) 때 화면에 반영된다."""
        self._st_online = self._check_online()
        self._hub_ok = self._hub_get("/api/ping") is not None

    def _chat_fetch(self):
        """채팅 새 글 받아오기(백그라운드 전용). 화면에 붙이는 건 메인스레드가 한다 — Qt 규칙."""
        self._chat_pending = self._hub_get("/api/chat?since=%d" % self._chat_rendered)

    def _t(self): return datetime.date.today().strftime("%Y-%m-%d")
    def _hm(self): return datetime.datetime.now().strftime("%H:%M")
    def wait(self, ms):
        loop = QEventLoop(); QTimer.singleShot(int(ms), loop.quit); loop.exec_()
    def tg(self, text):
        """★큐에 넣고 바로 돌아온다 — 전송 타임아웃이 8초다. 15:25 매수 중에 그걸 기다리면 안 된다.
        보내는 순서는 지킨다(일꾼 하나가 순서대로 처리)."""
        q = self.__dict__.setdefault("_tgq", [])
        q.append(text)
        if getattr(self, "_tg_worker", False): return
        self._tg_worker = True

        def _work():
            while True:
                if not q:
                    time.sleep(0.4); continue
                m = q.pop(0)
                try: tg_send(self.cfg.get("telegram_chat_id", ""), "🐷[종가배팅] " + m,
                             self.cfg.get("telegram_token", ""))   # ★비어 있으면 기본 봇
                except Exception: pass
        threading.Thread(target=_work, daemon=True).start()
    def log(self, m):
        line = f"[{datetime.datetime.now():%H:%M:%S}] {m}"
        try:
            with open(LOGF, "a", encoding="utf-8") as f: f.write(f"[{datetime.date.today()}] " + line + "\n")
        except Exception: pass
        try: self.logbox.setText(line + "\n" + self.logbox.text()[:600])
        except Exception: pass

    # ═══ GUI ═══
    def _build(self):
        self.setWindowTitle("종가배팅"); self.setStyleSheet(CSS); self.resize(600, 860)
        root = QWidget(); self.setCentralWidget(root); RV = QVBoxLayout(root); RV.setContentsMargins(0, 0, 0, 0); RV.setSpacing(0)
        # appbar + nav
        bar = QWidget(); bar.setObjectName("appbar"); bar.setFixedHeight(58); bh = QHBoxLayout(bar); bh.setContentsMargins(18, 0, 14, 0)
        br = QLabel("⬡ 종가배팅"); br.setObjectName("brand"); glow(br, CYAN, 22, 120); bh.addWidget(br)
        bh.addSpacing(12)
        self.stpills = {}
        for k in ("lic", "hub", "api", "online"):     # 승인·관리자연결·키움접속·온라인
            p = QLabel("—"); p.setObjectName("stpill"); bh.addWidget(p); self.stpills[k] = p
        bh.addStretch()
        self.navbtns = {}
        for k, t in [("dash", "📊 대시보드"), ("hist", "📒 거래내역"), ("chat", "💬 채팅"), ("set", "⚙️ 설정")]:
            b = QPushButton(t); b.setObjectName("navbtn"); b.clicked.connect(lambda _, kk=k: self.nav(kk)); bh.addWidget(b); self.navbtns[k] = b
        RV.addWidget(bar)
        self.stack = QStackedWidget(); RV.addWidget(self.stack, 1)
        self.stack.addWidget(self._page_dash())
        self.stack.addWidget(self._page_history())
        self.stack.addWidget(self._page_chat())
        self.stack.addWidget(self._page_set())
        self.nav("dash")
        self.refresh()
        QTimer.singleShot(400, self._warmup)      # ★창 뜬 뒤 각 탭을 미리 준비(첫 전환 렉 제거)

    def _warmup(self):
        """★탭 첫 전환 렉 제거 — 창이 뜬 뒤 각 탭의 스타일을 미리 해석해 둔다.

        Qt 는 위젯을 처음 그릴 때 스타일시트를 해석한다. 그 비용이 첫 탭 전환에 몰려 튄다.
        유휴 시간에 미리 해 두면 사용자가 누를 땐 이미 준비돼 있다."""
        try:
            for i in range(self.stack.count()):
                p = self.stack.widget(i)
                p.ensurePolished()
                for c in p.findChildren(QWidget): c.ensurePolished()
        except Exception:
            pass

    def nav(self, k):
        """★탭 전환은 통째로 감싼다 — 어느 탭에서 무엇이 터졌는지 남기고, 프로그램은 살린다.
        (2026-09-17: '설정 탭 누르면 꺼진다' 신고 — PyQt 는 슬롯 예외로 프로세스를 끝낸다)"""
        try:
            idx = {"dash": 0, "hist": 1, "chat": 2, "set": 3}[k]; self.stack.setCurrentIndex(idx)
            self._cur = k                               # ★지금 보는 탭 — refresh 가 이걸 보고 해당 탭만 갱신한다
            if k == "hist":
                try: self._refresh_history()
                except Exception as e: self.log(f"거래내역 갱신 오류 {e}")
            for kk, b in self.navbtns.items(): b.setProperty("on", "1" if kk == k else "0"); b.setStyle(b.style())
        except Exception as e:
            import traceback as _t
            try:
                self.log(f"⚠️ '{k}' 탭 전환 오류 — 계속 진행합니다: {e}")
                _runtime_log("탭 전환 오류 (%s)\n%s" % (k, _t.format_exc()))
            except Exception:
                pass

    # ── 대시보드 (드래그 카드) ──
    def _page_dash(self):
        pg = QWidget(); V = QVBoxLayout(pg); V.setContentsMargins(14, 12, 14, 10); V.setSpacing(10)
        top = QHBoxLayout(); top.setSpacing(10)
        self.btn_go = QPushButton("▶  자동매매 시작"); self.btn_go.setObjectName("gobtn"); self.btn_go.clicked.connect(self.toggle_auto); shadow(self.btn_go, 20, 5, 120)
        self.btn_mock = QPushButton("🟢 모의투자"); self.btn_mock.setObjectName("modebtn"); self.btn_mock.setFixedWidth(118); self.btn_mock.clicked.connect(lambda: self.set_mode(True))
        self.btn_real = QPushButton("🔴 실거래"); self.btn_real.setObjectName("modebtn"); self.btn_real.setFixedWidth(108); self.btn_real.clicked.connect(lambda: self.set_mode(False))
        top.addWidget(self.btn_go, 1); top.addWidget(self.btn_mock); top.addWidget(self.btn_real); V.addLayout(top)
        sa = QScrollArea(); sa.setWidgetResizable(True); inner = QWidget(); sa.setWidget(inner)
        G = QGridLayout(inner); G.setSpacing(11); G.setContentsMargins(2, 2, 2, 2)
        self.c_chart = Card("📈 수익률 추이", 320, 180); self.spark = Sparkline(); self.chart_sub = QLabel(); self.chart_sub.setObjectName("muted")
        self.c_chart.body.addWidget(self.spark, 1); self.c_chart.body.addWidget(self.chart_sub)
        self.c_win = Card("🏆 승률", 150, 180); self.gauge = Gauge(); self.c_win.body.addWidget(self.gauge, 1, Qt.AlignCenter)
        self.c_ret = Card("💹 누적 수익률(라이브)", 200, 110); self.ret_big = QLabel("—"); self.ret_big.setObjectName("big"); glow(self.ret_big, CYAN, 24, 110); self.ret_sub = QLabel(); self.ret_sub.setObjectName("muted")
        self.c_ret.body.addWidget(self.ret_big); self.c_ret.body.addWidget(self.ret_sub); self.c_ret.body.addStretch()
        self.c_hold = Card("🔴 보유중", 200, 150); self.hold_box = QLabel("없음"); self.hold_box.setWordWrap(True); self.hold_box.setAlignment(Qt.AlignTop); self.c_hold.body.addWidget(self.hold_box, 1)
        self.c_today = Card("✅ 오늘 거래", 200, 130); self.today_box = QLabel("없음"); self.today_box.setWordWrap(True); self.today_box.setAlignment(Qt.AlignTop); self.c_today.body.addWidget(self.today_box, 1)
        self.c_all = Card("📜 전체 거래내역", 320, 160); self.all_box = QLabel("없음"); self.all_box.setWordWrap(True); self.all_box.setAlignment(Qt.AlignTop); self.c_all.body.addWidget(self.all_box, 1)
        self.c_routine = Card("📋 루틴 상태 (오늘 진행 체크리스트)", 260, 170); self.routine_box = QLabel("—"); self.routine_box.setWordWrap(True); self.routine_box.setAlignment(Qt.AlignTop); self.routine_box.setTextFormat(Qt.RichText); self.c_routine.body.addWidget(self.routine_box, 1)
        self.c_picks = Card("🎯 오늘 추천 종목 (깃허브 · 매수 전에도 표시)", 320, 200); self.picks_box = QLabel("불러오는 중…"); self.picks_box.setWordWrap(True); self.picks_box.setAlignment(Qt.AlignTop); self.picks_box.setTextFormat(Qt.RichText); self.c_picks.body.addWidget(self.picks_box, 1)
        # ★💰 계좌 현재자산 (2026-09-18 · 관리자와 동일)
        #   전략자산(원금+누적손익 계산값)과 실제 잔고는 **다른 숫자다.** 둘 다 보여준다.
        self.c_acct = Card("💰 계좌 현재자산", 330, 190)
        _ab = QHBoxLayout(); _ab.setSpacing(14)
        self.acct_donut = Donut(132, 17)                       # 현금 vs 주식평가 비중
        _ab.addWidget(self.acct_donut, 0, Qt.AlignVCenter)
        _av = QVBoxLayout(); _av.setSpacing(3)
        self.acct_head = QLabel("—"); self.acct_head.setStyleSheet("font-size:12px;font-weight:800;color:%s" % INK)
        self.acct_big = QLabel("—"); self.acct_big.setStyleSheet("font-size:26px;font-weight:900;color:%s" % INK)
        self.acct_pl = QLabel(""); self.acct_pl.setStyleSheet("font-size:14px;font-weight:800;color:%s" % MUT)
        self.acct_box = QLabel("—"); self.acct_box.setWordWrap(True); self.acct_box.setTextFormat(Qt.RichText)
        self.acct_box.setObjectName("muted")
        for w in (self.acct_head, self.acct_big, self.acct_pl, self.acct_box): _av.addWidget(w)
        _av.addStretch(); _ab.addLayout(_av, 1)
        self.c_acct.body.addLayout(_ab, 1)
        G.addWidget(self.c_picks, 0, 0, 1, 3)          # ★추천종목 = 맨 위 전체너비(제일 잘 보이게)
        G.addWidget(self.c_chart, 1, 0, 1, 2); G.addWidget(self.c_win, 1, 2, 1, 1)
        G.addWidget(self.c_ret, 2, 0, 1, 1); G.addWidget(self.c_acct, 2, 1, 1, 1); G.addWidget(self.c_hold, 2, 2, 1, 1)
        G.addWidget(self.c_routine, 3, 0, 1, 1); G.addWidget(self.c_today, 3, 1, 1, 1); G.addWidget(self.c_all, 3, 2, 1, 1)
        for c in range(3): G.setColumnStretch(c, 1)
        G.setRowStretch(0, 0)                          # 추천종목은 내용만큼(고정), 나머지는 신축
        for r in range(1, 4): G.setRowStretch(r, 1)
        V.addWidget(sa, 1)
        return pg

    def set_mode(self, mock):
        # ★실거래 전환은 확인을 받는다 — 버튼 한 번에 바뀌면 안 되는 스위치다.
        if not mock and self.cfg.get("is_mock", True):
            srv = ""
            try: srv = self.kw.server_gubun()
            except Exception: pass
            m = QMessageBox(self); m.setIcon(QMessageBox.Warning)
            m.setWindowTitle("실거래 전환"); m.setText("🔴 실거래 모드로 바꿀까요?")
            m.setInformativeText(
                "현재 키움 접속: " + {"1": "모의투자 서버", "0": "실서버"}.get(srv, "확인 불가") + "\n\n"
                + ("⚠️ 지금 모의투자 서버에 접속돼 있습니다.\n"
                   "   설정만 바꿔도 주문은 모의로 나갑니다 — 키움을 실서버로 다시 로그인해야 합니다.\n\n"
                   if srv == "1" else "")
                + "· 이 설정은 기록에 '실전'으로 남기는 라벨입니다.\n"
                  "· 실제 체결은 키움 로그인 서버가 정합니다.\n"
                  "· 바꾼 뒤 로그인하면 서버와 설정이 맞는지 자동으로 대조합니다.")
            m.setStandardButtons(QMessageBox.Yes | QMessageBox.Cancel)
            m.setDefaultButton(QMessageBox.Cancel)
            m.button(QMessageBox.Yes).setText("실거래로 전환")
            m.button(QMessageBox.Cancel).setText("취소")
            if m.exec_() != QMessageBox.Yes:
                self.log("실거래 전환 취소"); self.refresh(); return
            self.tg("🔴 실거래 모드로 전환됨 — 다음 로그인에서 서버와 대조합니다")
        self.cfg["is_mock"] = mock; savej(CONFIG, self.cfg)
        try: (self.rb_mock if mock else self.rb_real).setChecked(True)
        except Exception: pass
        self.log(("모드 → " + ("🟢 모의투자" if mock else "🔴 실거래")))
        self.refresh()

    def _set_pick_tp(self, v):
        """익절 버튼 → tp_pct 즉시 반영(실시간 손익절·직접입력칸 동기)."""
        self.cfg["tp_pct"] = float(v); savej(CONFIG, self.cfg)
        if hasattr(self, "in_tp"): self.in_tp.setText(f"{float(v):g}")
        st.set_thresholds(self.cfg["tp_pct"], self.cfg.get("sl_pct", -3.0))
        for vv, bt in getattr(self, "set_tpbtns", {}).items(): bt.setProperty("on", "1" if vv == v else "0"); bt.setStyle(bt.style())
        self.log(f"🎯 익절 → +{float(v):g}% (실시간 반영)")

    def _set_pick_sl(self, v):
        """손절 버튼 → sl_pct 즉시 반영(독립·음수 저장·자동 1:1 규칙 없음)."""
        self.cfg["sl_pct"] = -abs(float(v)); savej(CONFIG, self.cfg)
        if hasattr(self, "in_sl"): self.in_sl.setText(f"{self.cfg['sl_pct']:g}")
        st.set_thresholds(self.cfg.get("tp_pct", 3.0), self.cfg["sl_pct"])
        for vv, bt in getattr(self, "set_slbtns", {}).items(): bt.setProperty("on", "1" if vv == v else "0"); bt.setStyle(bt.style())
        self.log(f"🛑 손절 → -{abs(float(v)):g}% (실시간 반영)")

    def _scroll(self):
        sa = QScrollArea(); sa.setWidgetResizable(True); inner = QWidget(); sa.setWidget(inner)
        return sa, inner

    def _ledger_trades(self, mode):
        """★이 PC 가 실제로 매매한 기록만. 관리자 원장이 아니라 client_state.json 이다."""
        out = []
        for t in (self.state.get("trades") or []):
            # ★기본값을 주지 않는다 — 관리자 _ledger_trades 와 같아야 한다(2026-09-30 재점검에서 발견).
            #   예전엔 `t.get("mode", "모의")` 로 **mode 없는 옛 기록을 모의로 세었다.**
            #   관리자는 `if not m ... continue` 로 아예 뺀다(레거시 mode=None = 구시스템 프록시).
            #   ⚠️왜 지금 고치는가 — 같은 날 _strategy_equity 를 관리자에 맞춰 `t.get("mode")` 로 바꿨는데
            #     여기만 기본값이 남아, **같은 프로그램 안에서** 모의 전략자산(레거시 제외)과
            #     모의 거래내역·자산곡선(레거시 포함)이 서로 다른 말을 하게 됐다.
            #   ★실전에는 영향이 0 이다 — 레거시는 "모의" 로 읽혀도 acct 분기에 안 걸렸다.
            #     바뀌는 것은 **모의 화면에서 레거시 기록이 빠지는 것**뿐이고, 관리자와 같은 모습이다.
            #     (2026-09-15 이후 client._record 는 mode 를 늘 적는다. mode 없는 건은
            #      _migrate 나 거래기록_복구.py 가 옛 설치에서 끌어온 것뿐이다)
            m = t.get("mode")
            # ★채택분(외부 보유 편입)은 실제 체결이 아니다 → 제외. 관리자 _ledger_trades 와 같다(2026-09-30).
            #   클라이언트 _record 는 아직 src 를 쓰지 않아 지금은 걸리는 건이 없다.
            #   앞으로 관리자처럼 채택분을 원장에 남기게 되면 여기서 조용히 섞여 들어간다 — 미리 막는다.
            if not m or t.get("src") == "adopt": continue
            if (mode == "acct" and m == "실전") or (mode == "mock" and m == "모의"):
                out.append(t)
        return out

    def _equity_stats(self, rec, base=None):
        """★관리자 _equity_stats 와 같은 식(2026-09-11 확정) — 두 프로그램 수치가 어긋나면 안 된다.

        원금에서 시작해 거래마다 **실현손익 − 수수료**를 쌓아 자산곡선을 만든다.
        MDD 는 자산 고점 대비 낙폭(%). ★거래 수익률 단순합과 혼동 말 것 —
        종목당 200만·자산 500만이면 단순합이 2.5배 부풀어 보인다."""
        # ★기본값 500 — 관리자 _equity_stats 와 같은 숫자다(2026-09-30 통일).
        #   여기는 1000 이었다. 같은 파일의 _base_for 도 500 을 쓰므로 안에서도 어긋나 있었다.
        #   호출부 둘 다 base= 를 넘기고 설정에 principal 이 늘 있어 실사용에선 안 물리는 잠복 불일치다.
        base = int(base if base is not None else int(self.cfg.get("principal", 500)) * 10000)
        fee = float(self.cfg.get("fee_pct", 0.23)) / 100.0
        eq = float(base); peak = float(base); mdd = 0.0
        curve = [0.0]; rets = []
        for t in rec:
            pl = (t.get("pl") or 0) - round((t.get("buy") or 0) * (t.get("qty") or 0) * fee)
            eq += pl
            if eq > peak: peak = eq
            if peak > 0:
                dd = eq / peak - 1.0
                if dd < mdd: mdd = dd
            curve.append(round((eq / base - 1) * 100, 2) if base else 0.0)
            # ★표시용 평균도 **실수령** 기준 — 관리자 2026-09-18 분 이식(2026-09-30).
            #   원장의 ret 은 수수료 미포함(gross)이다. 익절·손절 트리거가 순수 등락률로 돌고
            #   수수료는 자산곡선이 따로 빼기 때문이다(그 자체는 설계다).
            #   문제는 화면이 gross 를 그대로 띄워 증권사 앱 숫자와 안 맞아 보인 것이다.
            rets.append(round(float(t.get("ret") or 0) - fee * 100, 2))
        return {"base": base, "eq": eq, "pl": eq - base,
                "ret": round((eq / base - 1) * 100, 2) if base else 0.0,
                "mdd": round(mdd * 100, 2), "curve": curve,
                "avg": round(sum(rets) / len(rets), 2) if rets else 0.0,
                "sum": round(sum(rets), 2)}      # ★거래 수익률 단순합(참고용) — 계좌 수익률과 혼동 말 것

    def _page_history(self):
        """📒 거래내역 — 이 PC 가 실제로 매매한 것만 날짜별 카드로.

        ★보기 전환은 **매매 모드를 바꾸지 않는다.** 여기서 [🔴 실전] 을 눌러도
          실제 매매는 대시보드/설정의 모드가 정한 대로 간다."""
        pg = QWidget(); V = QVBoxLayout(pg); V.setContentsMargins(14, 12, 14, 10); V.setSpacing(10)

        head = QHBoxLayout(); head.setSpacing(9)
        t = QLabel("📒 거래내역"); t.setObjectName("brand"); head.addWidget(t)
        self.h_btn_mock = QPushButton("🟢 모의"); self.h_btn_mock.setObjectName("modebtn"); self.h_btn_mock.setFixedWidth(104)
        self.h_btn_real = QPushButton("🔴 실전"); self.h_btn_real.setObjectName("modebtn"); self.h_btn_real.setFixedWidth(104)
        self.h_btn_mock.clicked.connect(lambda: self._hist_view("mock"))
        self.h_btn_real.clicked.connect(lambda: self._hist_view("acct"))
        head.addWidget(self.h_btn_mock); head.addWidget(self.h_btn_real)
        head.addStretch()
        _n = QLabel("보기 전환일 뿐 — 매매 모드는 안 바뀝니다"); _n.setObjectName("muted"); head.addWidget(_n)
        V.addLayout(head)

        c_sum = Card("", 300, 96)
        sb = QHBoxLayout(); sb.setSpacing(18)
        self.h_big = QLabel("—"); self.h_big.setObjectName("big")
        sv = QVBoxLayout(); sv.setSpacing(2)
        self.h_sub1 = QLabel("—"); self.h_sub2 = QLabel("—")
        self.h_sub1.setStyleSheet("font-size:13px;font-weight:800;color:%s" % INK)
        self.h_sub2.setObjectName("muted"); self.h_sub2.setWordWrap(True)
        sv.addWidget(self.h_sub1); sv.addWidget(self.h_sub2)
        sb.addWidget(self.h_big); sb.addSpacing(6); sb.addLayout(sv); sb.addStretch()
        self.h_spark = Sparkline(); self.h_spark.setMinimumWidth(200)
        sb.addWidget(self.h_spark, 1)
        c_sum.body.addLayout(sb)
        V.addWidget(c_sum)

        sa, inner = self._scroll(); V.addWidget(sa, 1)
        gl = QVBoxLayout(inner); gl.setContentsMargins(2, 2, 2, 2); gl.setSpacing(8)
        self.h_grid = QGridLayout(); self.h_grid.setSpacing(10); self.h_grid.setAlignment(Qt.AlignTop)
        gl.addLayout(self.h_grid); gl.addStretch()
        self.h_empty = QLabel(""); self.h_empty.setObjectName("muted"); self.h_empty.setWordWrap(True)
        gl.addWidget(self.h_empty)
        self._hist_mode = "mock" if self.cfg.get("is_mock", True) else "acct"
        return pg

    def _hist_view(self, mode):
        self._hist_mode = mode
        self._refresh_history()

    def _hist_balance(self, mode):
        """거래내역 탭의 '자산' 숫자. (금액, 라벨) — 금액이 None 이면 알 수 없다는 뜻.

        실전 : **이 PC 키움 계좌에 실제로 있는 돈**. 실서버에 붙어 있을 때만 읽힌다.
               모의로 접속한 채 실전 탭을 보면 알 수 없다 — 없는 숫자를 지어내지 않는다.
        모의 : 모의 시드는 수천만이라 잔고가 의미 없다 → 전략자산(원금+실현손익)."""
        live_mode = not bool(self.cfg.get("is_mock", True))
        a = self.acct or {}
        if mode == "acct":
            if getattr(self, "connected", False) and live_mode:
                v = int(a.get("assets") or a.get("cash") or 0)
                if v > 0:
                    if a.get("stale"):                 # ★갱신이 막혔다 — 숫자는 주되 낡았다고 말한다(2026-09-17)
                        return v, f"실제 잔고 ⚠ {a.get('asof','')} 기준 옛 값"
                    if a.get("asof"):
                        # 15:18~15:35 은 청산·매수가 TR 을 몰아써서 잔고 조회를 쉰다 — 그것도 적는다
                        _sk = BALANCE_SKIP[0] <= self._hm() < BALANCE_SKIP[1]
                        return v, (f"실제 잔고 ({a['asof']} 기준 · 매수구간이라 잠시 멈춤)" if _sk
                                   else f"실제 잔고 ({a['asof']} 기준)")
                    return v, "실제 잔고"
                return None, "실제 잔고 조회 실패(계좌비밀번호 AUTO 확인)"
            return None, "실계좌 미접속"
        try: return int(self._strategy_equity()), "전략자산"
        except Exception: return None, "전략자산"

    def _day_card(self, d, ts):
        """날짜 하나 = 카드 하나. 종목별 수익률·청산시간 + 그날 흐름 미니차트."""
        dret = sum(x.get("ret", 0) for x in ts) / len(ts) if ts else 0
        dpl = sum(int(x.get("pl") or 0) for x in ts)
        c = UP if dpl >= 0 else DN
        f = QFrame(); f.setObjectName("card"); shadow(f)
        v = QVBoxLayout(f); v.setContentsMargins(13, 10, 13, 10); v.setSpacing(6)
        h = QHBoxLayout()
        dl = QLabel(f"<b style='font-size:14px'>{(d or '?')[5:]}</b>")
        dl.setTextFormat(Qt.RichText); h.addWidget(dl)
        h.addStretch()
        pl = QLabel(f"<b style='color:{c};font-size:14px'>{dpl:+,}원</b>")
        pl.setTextFormat(Qt.RichText); h.addWidget(pl)
        v.addLayout(h)
        sub = QLabel(f"{len(ts)}종목 · 평균 {dret:+.2f}%"); sub.setObjectName("muted"); v.addWidget(sub)
        rows = []
        for x in ts:
            rc = UP if x.get("ret", 0) >= 0 else DN
            tm = x.get("sell_time", "")
            why = x.get("reason", "")
            rows.append(f"• {x.get('name','')}  {int(x.get('buy') or 0):,}→{int(x.get('sell') or 0):,}"
                        f"  <b style='color:{rc}'>{x.get('ret',0):+.2f}%</b>"
                        + (f"  <span style='color:{MUT}'>{tm}</span>" if tm else "")
                        + (f"  <span style='color:{MUT}'>{why}</span>" if why else ""))
        body = QLabel("<br>".join(rows)); body.setTextFormat(Qt.RichText); body.setWordWrap(True)
        v.addWidget(body)
        sp = Sparkline(); sp.setMinimumHeight(38)
        cum = 0.0; curve = [0.0]
        for x in ts:
            cum += float(x.get("ret") or 0); curve.append(round(cum, 2))
        sp.setData(curve); v.addWidget(sp)
        return f

    def _refresh_history(self):
        """★이 PC 자기 거래·자기 계좌만 보여준다(관리자 자료가 아니다)."""
        if not hasattr(self, "h_grid"): return
        mode = getattr(self, "_hist_mode", "mock")
        on = ("#modebtn{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 %s,stop:1 %s);"
              "color:#fff;border:1px solid %s;border-radius:11px;padding:9px 12px;font-weight:800;}")
        off = ("#modebtn{background:#171525;color:#8b93a7;border:1px solid #2c2748;"
               "border-radius:11px;padding:9px 12px;font-weight:800;}")
        self.h_btn_mock.setStyleSheet((on % ("#22c55e", "#15803d", "#22c55e")) if mode == "mock" else off)
        self.h_btn_real.setStyleSheet((on % ("#ef4444", "#b91c1c", "#ef4444")) if mode == "acct" else off)

        trades = self._ledger_trades(mode)
        trades = sorted(trades, key=lambda t: (t.get("date", ""), t.get("sell_time", "")))
        es = self._equity_stats(trades, base=self._base_for(mode))   # ★실전은 실전 시작자산 기준
        fee = float(self.cfg.get("fee_pct", 0.23))
        wins = sum(1 for t in trades if (t.get("ret", 0) - fee) > 0)
        wr = round(wins / len(trades) * 100) if trades else 0
        pl = int(es["pl"]); c = UP if pl >= 0 else DN
        self.h_big.setText(f"{pl:+,}원")
        self.h_big.setStyleSheet(f"color:{c};font-size:27px;font-weight:900")

        bal, src = self._hist_balance(mode)
        if bal is not None:
            self.h_sub1.setText(f"{es['ret']:+.1f}%  ·  {src} <b>{bal:,}원</b>")
        else:
            self.h_sub1.setText(f"{es['ret']:+.1f}%  ·  {src}")
        self.h_sub1.setStyleSheet(f"font-size:13px;font-weight:800;color:{c}")
        self.h_sub1.setTextFormat(Qt.RichText)
        _tail = "  ·  실계좌에 접속하면 실제 잔고가 표시됩니다" if (mode == "acct" and bal is None) else ""
        self.h_sub2.setText(f"{'🟢 모의' if mode == 'mock' else '🔴 실전'} · 원금 {es['base']:,}원 · "
                            f"{len(trades)}거래 · 승 {wins}/패 {len(trades)-wins}({wr}%) · MDD {es['mdd']:.1f}%{_tail}")
        self.h_spark.setData(es["curve"])

        while self.h_grid.count():                       # 카드 비우기
            it = self.h_grid.takeAt(0)
            w = it.widget()
            if w is not None: w.setParent(None)
        byd = {}
        for t in trades: byd.setdefault(t.get("date", ""), []).append(t)
        n = 0
        for d in sorted(byd, reverse=True):
            self.h_grid.addWidget(self._day_card(d, byd[d]), n // 2, n % 2)
            n += 1
        self.h_grid.setColumnStretch(0, 1); self.h_grid.setColumnStretch(1, 1)
        self.h_empty.setText("" if n else
                             ("실전 거래내역이 아직 없습니다 (실거래로 바꾸면 여기에 쌓입니다)" if mode == "acct"
                              else "모의 거래내역이 아직 없습니다"))


    def _statcard(self, label, val, color):
        c = QFrame(); c.setObjectName("statcard"); c.setFixedHeight(96); shadow(c)
        v = QVBoxLayout(c); v.setContentsMargins(14, 12, 14, 12); v.setSpacing(2)
        l = QLabel(label); l.setObjectName("muted"); vv = QLabel(val); vv.setObjectName("big"); vv.setStyleSheet(f"color:{color};font-size:24px")
        v.addWidget(l); v.addWidget(vv)
        return {"card": c, "val": vv}

    # ── 설정 탭 ──
    def _tg_test(self):
        """📨 지금 입력된 토큰·chat_id 로 실제 한 통 보내 본다. (2026-09-17)

        넣어 놓고 맞는지 모르는 게 제일 답답하다 — 그 자리에서 판정해 준다.
        텔레그램이 돌려주는 영어 사유는 tg_try 가 한국어로 풀어 준다."""
        cid = self.in_tg.text().strip()
        tok = self.in_tgtok.text().strip()
        if not cid:
            self.log("⛔ chat_id 를 먼저 넣으세요 — 텔레그램에서 @userinfobot 으로 확인할 수 있습니다")
            return
        import datetime as _dt
        ok, msg = tg_try(cid, "🐷[종가배팅] 테스트 메시지\n\n"
                              "이 메시지가 보이면 알림 설정이 정상입니다.\n"
                              f"{_dt.datetime.now():%Y-%m-%d %H:%M:%S}",
                         tok)
        self.log(("📨 " if ok else "⛔ ") + msg + ("  (기본 봇)" if not tok else "  (내 봇)"))

    def _login_mode_mod(self):
        """로그인모드.py 를 불러온다(한글 모듈명이라 importlib 로)."""
        try:
            import importlib
            return importlib.import_module("로그인모드")
        except Exception as e:
            self.log(f"로그인모드 모듈 불러오기 실패 {e}")
            return None

    def _login_window_on(self):
        """🪟 다음 로그인에서 키움 창이 뜨게 한다 — 거기서 모의/실전을 고른다. (2026-09-17)

        자동로그인이 켜져 있으면 창이 안 떠서 '모의투자 접속' 체크를 바꿀 수 없다.
        ★Autologin.dat 사본을 되돌리는 방식은 안 된다(키움이 로그인마다 다시 쓴다) — 관리자에서 확인했다."""
        if self.cfg.get("enabled"):
            self.log("⛔ 자동매매가 도는 중입니다 — [자동매매 정지] 후에 하세요")
            self._refresh_login_mode(); return
        if getattr(self, "connected", False):
            self.log("⛔ 키움에 접속 중입니다 — [로그아웃] 후에 하세요")
            self._refresh_login_mode(); return
        m = self._login_mode_mod()
        if not m: return
        ok, msg = m.open_window()
        self.log(("🪟 " if ok else "⛔ ") + msg)
        if ok:
            self.log("   └ 이제 [🔑 키움 로그인] 을 누르면 창이 뜹니다.")
            self.log("      실전으로 가려면 '모의투자 접속' 체크를 풀고, '자동로그인 설정' 은 꼭 체크하세요.")
        self._refresh_login_mode()

    def _login_window_off(self):
        """창 띄우기를 취소하고 마지막 자동로그인으로 되돌린다."""
        if getattr(self, "connected", False):
            self.log("⛔ 키움에 접속 중입니다 — [로그아웃] 후에 하세요")
            self._refresh_login_mode(); return
        m = self._login_mode_mod()
        if not m: return
        ok, msg = m.restore_last()
        self.log(("↩️ " if ok else "⛔ ") + msg)
        self._refresh_login_mode()

    def _refresh_login_mode(self):
        """자동로그인이 켜져 있는지(=창이 뜰지) 보여준다."""
        if not hasattr(self, "lgm_btn_open"): return
        m = self._login_mode_mod()
        on = True
        if m:
            try: on = m.autologin_on()
            except Exception: pass
        busy = bool(self.cfg.get("enabled")) or bool(getattr(self, "connected", False))
        self.lgm_btn_open.setEnabled(on and not busy)
        self.lgm_btn_back.setEnabled((not on) and not getattr(self, "connected", False))
        if busy:
            self.lgm_lbl.setText("자동매매를 정지하고 로그아웃한 뒤에 바꿀 수 있습니다")
            self.lgm_lbl.setStyleSheet("color:#6f8a9a")
        elif on:
            self.lgm_lbl.setText("지금: 🔒 자동로그인 켜짐 — 창 없이 바로 접속합니다(무인 운영 가능)")
            self.lgm_lbl.setStyleSheet("color:#22c55e")
        else:
            self.lgm_lbl.setText("지금: 🪟 다음 로그인에서 창이 뜹니다 — "
                                 "⚠️ 로그인할 때 '자동로그인 설정' 을 다시 체크해야 무인 운영이 됩니다")
            self.lgm_lbl.setStyleSheet("color:#f5b53d")

    def _set_aftp(self, on):
        """🌙 애프터마켓 익절 켜기/끄기 — 각자 선택한다(관리자가 강제로 밀지 않는다).

        켜면 16:00~17:00 사이에 보유 종목마다 '매수가 x (1+익절%)' 매도 지정가를 걸어 둔다.
        그 주문은 20:00 까지 살아 있다가 소멸한다. 익절은 미리 걸고, 손절은 지켜보다가 닿으면 낸다."""
        self.cfg["aftp_live"] = bool(on)
        savej(CONFIG, self.cfg)
        if on:
            self.log("🌙 애프터마켓 익절 켬 — 16시 이후 매수가 +%g%% 매도 지정가를 걸어 둡니다(손절은 안 겁니다)"
                     % float(self.cfg.get("tp_pct", 6)))
        else:
            self.log("🌙 애프터마켓 익절 끔 — 정규장(09:00~15:19)에서만 손익절합니다")
        try: self._refresh_aftp()
        except Exception: pass

    def _refresh_aftp(self):
        """스위치 상태·설명을 지금 설정에 맞춘다. 모의투자면 못 켜게 막는다."""
        if not hasattr(self, "aftp_btn"): return
        mock = bool(self.cfg.get("is_mock", True))
        on = bool(self.cfg.get("aftp_live")) and not mock
        tp = float(self.cfg.get("tp_pct", 6))
        _base = "border-radius:11px;padding:10px 14px;font-weight:800;font-size:13px;text-align:left;"
        if mock:                                    # 모의는 애프터마켓 자체가 없다 — 눌리지 않게 하고 이유를 버튼에 쓴다
            self.aftp_btn.setText("🔒 모의투자에서는 쓸 수 없습니다 (실거래 전용)")
            self.aftp_btn.setStyleSheet("background:#141221;color:#4b5563;border:1px dashed #2c2748;" + _base)
            self.aftp_btn.setEnabled(False)
        elif on:
            self.aftp_btn.setText("✅ 켜짐 — 16시 이후 익절 +%g%% · 손절 %g%% 자동   (눌러서 끄기)"
                                  % (tp, -abs(float(self.cfg.get("sl_pct", -3.5)))))
            self.aftp_btn.setStyleSheet("background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #22c55e,stop:1 #15803d);"
                                        "color:#ffffff;border:1px solid #22c55e;" + _base)
            self.aftp_btn.setEnabled(True)
        else:
            self.aftp_btn.setText("⬜ 꺼짐 — 정규장에서만 매매합니다   (눌러서 켜기)")
            self.aftp_btn.setStyleSheet("background:#171525;color:#8b93a7;border:1px solid #2c2748;" + _base)
            self.aftp_btn.setEnabled(True)

    def _page_set(self):
        pg = QWidget(); sa = QScrollArea(); sa.setWidgetResizable(True); inner = QWidget(); sa.setWidget(inner)
        V = QVBoxLayout(inner); V.setContentsMargins(16, 16, 16, 16); V.setSpacing(14)
        outer = QVBoxLayout(pg); outer.setContentsMargins(0, 0, 0, 0); outer.addWidget(sa)
        # 로그인
        g1 = QFrame(); g1.setObjectName("card"); shadow(g1); l1 = QGridLayout(g1); l1.setContentsMargins(16, 14, 16, 14)
        t1 = QLabel("① 로그인 · 계좌 (최초 1회)"); t1.setObjectName("ctitle"); l1.addWidget(t1, 0, 0, 1, 3)
        self.btn_login = QPushButton("🔑 키움 로그인"); self.btn_login.clicked.connect(self.do_login)
        self.cmb_acc = QComboBox(); self.btn_pw = QPushButton("🔒 계좌비밀번호 등록"); self.btn_pw.clicked.connect(self.do_register_pw); self.btn_pw.setEnabled(False)
        self.btn_logout = QPushButton("🚪 로그아웃"); self.btn_logout.clicked.connect(self.do_logout)
        self.btn_logout.setStyleSheet("background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #444055,stop:1 #2b2838);")
        l1.addWidget(self.btn_login, 1, 0); l1.addWidget(QLabel("계좌"), 1, 1); l1.addWidget(self.cmb_acc, 1, 2)
        l1.addWidget(self.btn_pw, 2, 0, 1, 3); l1.addWidget(self.btn_logout, 3, 0, 1, 3); V.addWidget(g1)
        # 매매설정
        g2 = QFrame(); g2.setObjectName("card"); shadow(g2); l2 = QGridLayout(g2); l2.setContentsMargins(16, 14, 16, 14)
        t2 = QLabel("② 매매 설정 (저장 1회 → 다음부터 자동)"); t2.setObjectName("ctitle"); l2.addWidget(t2, 0, 0, 1, 4)
        self.in_tp = QLineEdit(str(self.cfg["tp_pct"])); self.in_sl = QLineEdit(str(self.cfg["sl_pct"]))
        self.in_inv = QLineEdit(str(int(self.cfg["invest_per_stock"]) // 10000)); self.in_tg = QLineEdit(self.cfg.get("telegram_chat_id", ""))
        self.in_prin = QLineEdit(str(int(self.cfg.get("principal", 1000))))   # ★투자원금(만원) — 복리 전략자산 기준(관리자 동일)
        # ★관리자와 동일한 설정칸(2026-09-15) — 값은 예전부터 동작했지만 화면에 없어서 보이지도 고치지도 못했다
        self.in_buf = QLineEdit(str(int(self.cfg.get("cash_buffer", 200000) or 0) // 10000))
        self.in_gap = QLineEdit(str(self.cfg.get("gapcut_pct", 0.0)))
        self.in_fee = QLineEdit(str(self.cfg.get("fee_pct", 0.23)))
        self.in_testqty = QLineEdit(str(int(self.cfg.get("test_qty", 0) or 0)))
        self.in_testqty.setPlaceholderText("0 = 평소대로 (실계좌 첫 테스트는 1 을 권합니다)")
        self.rb_real = QRadioButton("실거래"); self.rb_mock = QRadioButton("모의투자")
        (self.rb_mock if self.cfg["is_mock"] else self.rb_real).setChecked(True); bg = QButtonGroup(self); bg.addButton(self.rb_real); bg.addButton(self.rb_mock)
        # ── 🎯익절 / 🛑손절 버튼(독립·10%까지) — 실시간 손익절에 즉시 반영(손절 자동 1:1 규칙 해제·관리자 동일) ──
        self.set_tpbtns = {}; self.set_slbtns = {}
        _curtp = float(self.cfg.get("tp_pct", 3.0)); _cursl = abs(float(self.cfg.get("sl_pct", -3.0)))
        def _btnrow(vals, handler, store, cur):
            row = QHBoxLayout(); row.setSpacing(5)
            for v in vals:
                b = QPushButton(f"{v:g}"); b.setObjectName("seg"); b.setCheckable(True)
                b.setProperty("on", "1" if abs(v - cur) < 1e-9 else "0")
                b.clicked.connect(lambda _, vv=v: handler(vv)); row.addWidget(b); store[v] = b
            row.addStretch(); return row
        l2.addWidget(QLabel("🎯 익절 +%"), 1, 0)
        l2.addLayout(_btnrow([1, 2, 3, 4, 4.5, 5, 6, 7, 8, 10], self._set_pick_tp, self.set_tpbtns, _curtp), 1, 1, 1, 3)
        l2.addWidget(QLabel("🛑 손절 -%"), 2, 0)
        l2.addLayout(_btnrow([1, 2, 3, 4, 4.2, 5, 6, 7, 8, 10], self._set_pick_sl, self.set_slbtns, _cursl), 2, 1, 1, 3)
        l2.addWidget(QLabel("익절%(직접)"), 3, 0); l2.addWidget(self.in_tp, 3, 1); l2.addWidget(QLabel("손절%(직접·음수)"), 3, 2); l2.addWidget(self.in_sl, 3, 3)
        # ★이 값은 '최소'가 아니라 **상한**이다(하한은 가용÷최소보장종목수 로 자동) — 관리자와 동일
        _linv = QLabel("종목당 상한(만원)")
        _linv.setToolTip("한 종목에 넣는 금액의 상한입니다.\n"
                         "하한은 자산이 정합니다 — min(이 값, 가용 ÷ 최소보장종목수).\n"
                         "그래서 자산이 작아도 1종목에 갇히지 않고, 420만 이상에서는 예전과 똑같이 동작합니다.")
        l2.addWidget(_linv, 4, 0); l2.addWidget(self.in_inv, 4, 1)
        l2.addWidget(QLabel("원금(만원)"), 4, 2); l2.addWidget(self.in_prin, 4, 3)
        l2.addWidget(QLabel("현금버퍼(만원)"), 5, 0); l2.addWidget(self.in_buf, 5, 1)
        l2.addWidget(QLabel("갭컷 %(0=끔·음수)"), 5, 2); l2.addWidget(self.in_gap, 5, 3)
        _sd = int(self.cfg.get("size_div", 3) or 3)
        _sz = QLabel("종목당 = max(종목당 최소, (전략자산 − 현금버퍼) ÷ %d) · 최대 %d종목   |   "
                     "갭컷 = 09:00 시가가 매수가보다 그만큼 낮으면 손절선과 무관하게 즉시 시장가" % (_sd, _sd))
        _sz.setObjectName("muted"); _sz.setWordWrap(True); l2.addWidget(_sz, 6, 0, 1, 4)
        l2.addWidget(QLabel("수수료 왕복 %(일반계좌 0.23 = 위탁 0.015×2 + 거래세 0.20)"), 7, 0); l2.addWidget(self.in_fee, 7, 1)
        _tq = QLabel("🧪 테스트수량(주)")
        _tq.setToolTip("실계좌로 처음 돌릴 때 1 을 넣으면 종목당 1주만 삽니다(금액 사이징 무시).\n"
                       "체결 경로만 확인하는 용도이니 확인 끝나면 반드시 0 으로 되돌리세요.")
        l2.addWidget(self.rb_real, 7, 2); l2.addWidget(self.rb_mock, 7, 3)
        # ★테스트수량은 **자기 행**에 둔다(2026-09-18).
        #   전에는 7,2 / 7,3 에 놓았는데 바로 위 라디오버튼과 같은 칸이라 덮여 안 보였다.
        #   QGridLayout 은 같은 칸에 둘을 넣어도 오류 없이 겹쳐 놓는다 — 조용한 실패다.
        l2.addWidget(_tq, 8, 0); l2.addWidget(self.in_testqty, 8, 1)
        _tqh = QLabel("실계좌 첫날은 <b>1</b> 을 넣어 종목당 1주만 사 보세요. 확인되면 <b>0</b> 으로 되돌립니다.")
        _tqh.setObjectName("muted"); _tqh.setWordWrap(True); _tqh.setTextFormat(Qt.RichText)
        l2.addWidget(_tqh, 8, 2, 1, 2)
        l2.addWidget(QLabel("텔레그램 chat_id"), 9, 0); l2.addWidget(self.in_tg, 9, 1, 1, 3)
        # ★봇 토큰 — 비우면 기본 봇. 자기 봇을 쓰면 배포본 토큰이 새도 내 알림은 안전하다.
        self.in_tgtok = QLineEdit(self.cfg.get("telegram_token", ""))
        self.in_tgtok.setPlaceholderText("비워 두면 기본 봇으로 갑니다 (자기 봇이 있으면 붙여넣기)")
        _lt2 = QLabel("텔레그램 봇 토큰")
        _lt2.setToolTip("@BotFather → /mybots → 내 봇 → API Token\n"
                        "비워 두면 프로그램에 들어 있는 기본 봇이 보냅니다.")
        l2.addWidget(_lt2, 10, 0); l2.addWidget(self.in_tgtok, 10, 1, 1, 2)
        self.btn_tgtest = QPushButton("📨 테스트 전송"); self.btn_tgtest.clicked.connect(self._tg_test)
        l2.addWidget(self.btn_tgtest, 10, 3)
        _tgh = QLabel("알림에는 둘이 필요합니다 — **봇 토큰**(누가 보내는가) + **chat_id**(누구에게 가는가).\n"
                      "chat_id 는 텔레그램에서 그 봇에 [시작]을 누른 뒤 @userinfobot 으로 확인하세요.")
        _tgh.setObjectName("muted"); _tgh.setWordWrap(True)
        l2.addWidget(_tgh, 11, 0, 1, 4)
        # ★저장은 맨 아래 줄(11)로 — 9행은 텔레그램 봇 토큰이 쓴다(겹치면 버튼에 가려 안 보인다)
        self.btn_save = QPushButton("💾 저장"); self.btn_save.clicked.connect(self.save_settings); l2.addWidget(self.btn_save, 12, 0, 1, 4)
        V.addWidget(g2)
        # ── 🔑 로그인 서버 바꾸기 (모의 ↔ 실전) ──
        gk = QFrame(); gk.setObjectName("card"); shadow(gk); lk = QVBoxLayout(gk)
        lk.setContentsMargins(16, 12, 16, 12); lk.setSpacing(8)
        tk = QLabel("🔑 로그인 서버 바꾸기 (모의 ↔ 실전)"); tk.setObjectName("ctitle"); lk.addWidget(tk)
        _kr = QHBoxLayout(); _kr.setSpacing(8)
        self.lgm_btn_open = QPushButton("🪟 로그인 창 띄우기"); self.lgm_btn_open.setMinimumWidth(170)
        self.lgm_btn_back = QPushButton("되돌리기"); self.lgm_btn_back.setFixedWidth(110)
        self.lgm_btn_open.clicked.connect(self._login_window_on)
        self.lgm_btn_back.clicked.connect(self._login_window_off)
        _kr.addWidget(self.lgm_btn_open); _kr.addWidget(self.lgm_btn_back); _kr.addStretch()
        lk.addLayout(_kr)
        self.lgm_lbl = QLabel(""); self.lgm_lbl.setWordWrap(True); lk.addWidget(self.lgm_lbl)
        V.addWidget(gk)
        # ── 🌙 애프터마켓 익절 (16:00~20:00) ──
        ga = QFrame(); ga.setObjectName("card"); shadow(ga); la = QVBoxLayout(ga); la.setContentsMargins(16, 12, 16, 12); la.setSpacing(8)
        ta = QLabel("🌙 애프터마켓 손익절 (16:00~20:00)"); ta.setObjectName("ctitle"); la.addWidget(ta)
        self.aftp_btn = QPushButton("")            # ★버튼 하나 — 지금 상태와 다음 동작을 글자로 말한다
        self.aftp_btn.setMinimumHeight(40)
        self.aftp_btn.clicked.connect(lambda: self._set_aftp(not self.cfg.get("aftp_live")))
        la.addWidget(self.aftp_btn)
        V.addWidget(ga)
        # ── 💰 실자산 기준 (입금/출금 뒤 눌러 맞춘다) ──  2026-09-30 · 관리자 2026-09-18 분 이식
        #   ★_base_for 에서 원금 클램프(min)를 뺀 것과 **한 쌍**이다 — 기준이 낡으면 그만큼 작게 산다.
        gs = QFrame(); gs.setObjectName("card"); shadow(gs)
        ls_ = QVBoxLayout(gs); ls_.setContentsMargins(16, 12, 16, 12); ls_.setSpacing(8)
        ts_ = QLabel("💰 실자산 기준 (입금·출금 뒤에 누르세요)"); ts_.setObjectName("ctitle"); ls_.addWidget(ts_)
        # ★버튼 글자가 지금 상태와 다음 동작을 말한다(aftp_btn 과 같은 규칙).
        #   ★첫 글자를 비워 두지 않는다 — `_refresh_lsq()` 는 refresh() 에서 try/except 로 감싸 불리므로
        #     거기서 한 번이라도 예외가 나면 **글자 없는 버튼**이 남는다. 그 버튼은 눌리고,
        #     누르면 기준(=종목당 금액의 분모)이 바뀐다. 그래서 기본을 '비활성 + 상태 미확인' 으로 둔다.
        #     정상 경로에서는 창이 뜨는 즉시 _refresh_lsq 가 아래 5가지 상태 중 하나로 덮는다.
        self.lsq_btn = QPushButton("⏳ 상태 확인 중 — 잠시 뒤 지금 기준이 표시됩니다")
        self.lsq_btn.setEnabled(False)
        self.lsq_btn.setMinimumHeight(40)
        self.lsq_btn.clicked.connect(self._reset_live_start)
        ls_.addWidget(self.lsq_btn)
        self.lsq_lbl = QLabel(""); self.lsq_lbl.setObjectName("muted"); self.lsq_lbl.setWordWrap(True)
        ls_.addWidget(self.lsq_lbl)
        _lsh = QLabel("누적수익률의 분모이자 종목당 금액의 기준입니다. "
                      "입금·출금은 수익이 아니므로 이 기준에 반영해야 이후 수익률이 부풀지 않습니다.")
        _lsh.setObjectName("muted"); _lsh.setWordWrap(True); ls_.addWidget(_lsh)
        V.addWidget(gs)
        # ── 사용승인(라이선스) ──
        gl = QFrame(); gl.setObjectName("card"); shadow(gl); ll = QGridLayout(gl); ll.setContentsMargins(16, 12, 16, 12); ll.setSpacing(9)
        tl = QLabel("🪪 사용승인 (닉네임 + 관리자 승인 필요 · 한 달마다 재요청)"); tl.setObjectName("ctitle"); ll.addWidget(tl, 0, 0, 1, 4)
        self.in_nick = QLineEdit(self.cfg.get("nickname", "")); self.in_nick.setPlaceholderText("이름/닉네임")
        self.in_hub = QLineEdit(self.cfg.get("hub_url", ""))
        ll.addWidget(QLabel("닉네임"), 1, 0); ll.addWidget(self.in_nick, 1, 1); ll.addWidget(QLabel("관리자 서버주소"), 1, 2); ll.addWidget(self.in_hub, 1, 3)
        self.lic_lbl = QLabel("—"); self.lic_lbl.setWordWrap(True); ll.addWidget(self.lic_lbl, 2, 0, 1, 2)
        self.btn_req = QPushButton("📨 승인 요청"); self.btn_req.clicked.connect(self.request_license); ll.addWidget(self.btn_req, 2, 2)
        self.btn_save2 = QPushButton("💾 닉/서버 저장"); self.btn_save2.clicked.connect(self.save_settings); ll.addWidget(self.btn_save2, 2, 3)
        V.addWidget(gl)
        g3 = QFrame(); g3.setObjectName("card"); shadow(g3); l3 = QVBoxLayout(g3); l3.setContentsMargins(16, 12, 16, 12)
        t3 = QLabel("ℹ️ 안내"); t3.setObjectName("ctitle"); l3.addWidget(t3)
        info = QLabel("전략은 전체+하이브 고정. 관리자와 100% 동일 매매로직 — 관리자가 공유한 종목을 유통≤70%·상한가제외 필터 후 "
                  "매력도 상위 종목을 지정가로 종가매수, 미체결분 처리, 실잔고 보정, 다음날 09:00~15:19 실시간 손익절 후 15:19 종가청산.\n"
                  "시각은 모드에 따라 다릅니다 — 실거래 19:55/19:58/20:01(애프터마켓 종가) · 모의 15:25/15:28/15:31(정규장).\n"
                  "실거래는 본인 책임(모의로 먼저 테스트). ※사용하려면 관리자 승인 필요.")
        info.setObjectName("muted"); info.setWordWrap(True); l3.addWidget(info); V.addWidget(g3)
        self.logbox = QLabel(""); self.logbox.setObjectName("muted"); self.logbox.setWordWrap(True); V.addWidget(self.logbox)
        V.addStretch()
        return pg

    # ═══ 로직(로그인·매수·관리 — v1과 동일) ═══
    # ═══ 허브(라이선스 승인 + 채팅) ═══
    def _hub(self): return (self.cfg.get("hub_url") or "").rstrip("/")

    def _hub_get(self, path):
        try: return json.loads(urllib.request.urlopen(self._hub() + path, timeout=6).read().decode())
        except Exception: return None

    def _hub_post(self, path, obj):
        try:
            r = urllib.request.urlopen(urllib.request.Request(self._hub() + path, data=json.dumps(obj).encode("utf-8"), headers={"Content-Type": "application/json"}), timeout=6)
            return json.loads(r.read().decode())
        except Exception: return None

    def check_license(self):
        nick = (self.cfg.get("nickname") or "").strip()
        if not nick: self._licensed = False; self._lic_status = "닉네임 미설정"; return
        r = self._hub_get("/api/license?nick=" + urllib.parse.quote(nick))
        if r is None: self._licensed = False; self._lic_status = "서버 연결안됨"; return
        self._licensed = bool(r.get("valid")); self._lic_status = r.get("status"); self._lic_expiry = r.get("expiry")

    def request_license(self):
        nick = (self.cfg.get("nickname") or "").strip()
        if not nick: self.log("⛔ 닉네임 먼저 설정하세요(설정 탭)"); return
        r = self._hub_post("/api/request", {"nick": nick})
        if r: self.log(f"📨 승인요청 전송: {nick} — 관리자 승인 대기")
        else: self.log("승인요청 실패 — 설정 탭 서버주소 확인")
        self.check_license(); self.refresh()

    def _page_chat(self):
        pg = QWidget(); V = QVBoxLayout(pg); V.setContentsMargins(14, 12, 14, 12); V.setSpacing(10)
        head = QLabel("💬 채팅 · 관리자와 대화 (자동매매 중에도 유지 · 스크롤로 과거대화)"); head.setObjectName("brand"); V.addWidget(head)
        self.chat_sa = QScrollArea(); self.chat_sa.setWidgetResizable(True); inner = QWidget(); self.chat_sa.setWidget(inner)
        self.chat_sa.setStyleSheet("QScrollArea{border:1px solid #2c2748;border-radius:14px;background:#0e0c18;}")
        self.chat_box = QVBoxLayout(inner); self.chat_box.setSpacing(7); self.chat_box.setContentsMargins(10, 8, 12, 8); self.chat_box.setAlignment(Qt.AlignTop)
        V.addWidget(self.chat_sa, 1)
        row = QHBoxLayout(); row.setSpacing(8)
        self.chat_in = QLineEdit(); self.chat_in.setPlaceholderText("메시지 입력 후 Enter"); self.chat_in.returnPressed.connect(self._chat_send)
        b = QPushButton("전송"); b.clicked.connect(self._chat_send)
        row.addWidget(self.chat_in, 1); row.addWidget(b); V.addLayout(row)
        return pg

    def _chat_send(self):
        m = self.chat_in.text().strip(); nick = (self.cfg.get("nickname") or "").strip() or "익명"
        if not m: return
        if self._hub_post("/api/chat", {"nick": nick, "msg": m}) is not None:
            self.chat_in.clear(); self._refresh_chat()
        else: self.log("채팅 전송 실패 — 서버주소 확인")

    def _refresh_chat(self):
        if not hasattr(self, "chat_box"): return
        self._bg(self._chat_fetch, "chat")            # ★3초마다 메인스레드를 막던 자리(2026-09-16)
        r = getattr(self, "_chat_pending", None)
        if not r: return
        self._chat_pending = None
        mynick = (self.cfg.get("nickname") or "").strip()
        for m in r.get("msgs", []):
            who = m.get("who", "?"); ts = (m.get("ts", "") or "")[11:16]
            mine = who == mynick; sysm = who == "SYSTEM"; adm = who == "admin"
            c = "#9b6cff" if mine else ("#8b93a7" if sysm else ("#22c55e" if adm else "#c9c4d6"))
            al = Qt.AlignRight if mine else (Qt.AlignHCenter if sysm else Qt.AlignLeft)
            disp = "나" if mine else ("관리자" if adm else who)
            lab = QLabel(f"<span style='color:{c};font-size:10px;font-weight:700'>{disp} · {ts}</span><br>"
                         f"<span style='color:#e9e7f2;font-size:13px'>{m.get('msg','')}</span>")
            lab.setTextFormat(Qt.RichText); lab.setWordWrap(True); lab.setAlignment(al)
            bg = "rgba(155,108,255,.12)" if mine else ("transparent" if sysm else "rgba(255,255,255,.04)")
            lab.setStyleSheet(f"QLabel{{background:{bg};border-radius:9px;padding:5px 9px;}}")
            self.chat_box.addWidget(lab)
        self._chat_rendered = r.get("total", self._chat_rendered)
        if r.get("msgs"):
            QTimer.singleShot(40, lambda: self.chat_sa.verticalScrollBar().setValue(self.chat_sa.verticalScrollBar().maximum()))

    def _refresh_hub(self):
        try: self._refresh_chat()
        except Exception: pass
        self._lic_ticks += 1
        if self._lic_ticks % 10 == 1:   # ~30초마다 라이선스 재확인
            self._bg(self.check_license, "license")   # ★타임아웃 6초 — 메인스레드에서 기다리지 않는다

    def _check_online(self):
        try: urllib.request.urlopen("https://hn98201.github.io/apple_paly/picks_latest.json", timeout=3); return True
        except Exception: return False

    def _update_status(self):
        """상단 상태 점: 승인 · 관리자연결 · 키움접속 · 온라인 (항상 표시)."""
        if not hasattr(self, "stpills"): return
        self._st_ticks += 1
        if self._st_ticks % 5 == 1:
            self._bg(self._probe_net, "netprobe")     # ★여기서 기다리면 25초마다 창이 멈춘다(2026-09-16)
        GRN, RED, GRY = "#22c55e", "#F0455C", "#4b5563"
        def dot(k, col, label):
            self.stpills[k].setText(f"<span style='color:{col};font-size:14px'>●</span> "
                                    f"<span style='color:{col};font-size:10.5px;font-weight:700'>{label}</span>")
        dot("lic", GRN if self._licensed else RED, "승인됨" if self._licensed else "미승인")
        dot("hub", GRN if self._hub_ok else RED, "관리자연결" if self._hub_ok else "관리자끊김")
        dot("api", GRN if self.connected else GRY, "키움접속" if self.connected else "키움대기")
        dot("online", GRN if self._st_online else GRY, "온라인" if self._st_online else "오프라인")

    def _alert(self, title, msg, icon=None):
        m = QMessageBox(self); m.setWindowTitle(title); m.setText(msg); m.setIcon(icon or QMessageBox.Warning)
        m.setStyleSheet("QMessageBox{background:#15131f;} QLabel{color:#e9e7f2;font-size:13px;min-width:340px;} "
                        "QPushButton{background:#7c3aed;color:#fff;border-radius:8px;padding:6px 18px;font-weight:800;}")
        m.exec_()

    def do_login(self):
        if self._logging_in: return                          # ★재진입 차단 — 블로킹 로그인 중 틱의 재호출로 중첩 이벤트루프가 생기는 것 방지
        self._logging_in = True
        try:
            self.log("키움 로그인 시도…"); self.kw.dynamicCall("CommConnect()")
            loop = QEventLoop(); self.kw._login_loop = loop; QTimer.singleShot(120000, loop.quit); loop.exec_()
            self.connected = bool(getattr(self.kw, "connected", False))
            if not self.connected: self.log("❌ 로그인 실패"); return
            accs = self.kw.accounts(); self.cmb_acc.clear(); self.cmb_acc.addItems(accs)
            self.btn_pw.setEnabled(True)
            self.log(f"✅ 로그인 · {self.kw.user_name()} · {'모의' if self.kw.is_mock() else '실서버'} · {accs}")
            if not self._verify_live_env(accs): return      # ★서버·계좌 대조(어긋나면 안전정지)
            if self.cfg.get("account") in accs: self.cmb_acc.setCurrentText(self.cfg["account"])
            try: savej(RESTART_LOG, [])                       # ★접속 성공 → 재시작 백오프 초기화
            except Exception: pass
            self.query_account(); self.refresh()
        finally:
            self._logging_in = False

    def _halt(self, why, detail=""):
        """★안전정지 — 자동매매와 auto_start 를 **둘 다** 끈다.
        enabled 만 끄면 다음 재기동에서 auto_start 를 보고 되살아난다."""
        self.cfg["enabled"] = False; self.cfg["auto_start"] = False; savej(CONFIG, self.cfg)
        self.log(f"🛑 자동매매 안전정지 — {why}")
        for _l in (detail or "").split("\n"):
            if _l.strip(): self.log("     " + _l)
        self.tg(f"🛑 자동매매 안전정지\n{why}" + (f"\n\n{detail}" if detail else "")
                + "\n\n확인 후 [자동매매 시작]을 다시 눌러야 재개됩니다.")
        if not AUTO:                              # ★무인(auto)에서는 모달 금지 — 창 하나가 이벤트루프를 영구히 막는다
            try: self._alert("자동매매 안전정지", f"{why}\n\n{detail}")
            except Exception: pass
        try: self.refresh()
        except Exception: pass

    def _verify_live_env(self, accs):
        """★실계좌 안전점검 — 로그인 직후 '지금 어느 서버·어느 계좌인가'를 설정과 대조한다.

        주문에는 모의/실전 분기가 **없다.** 진짜 체결은 키움 로그인 서버만이 정한다.
        '실서버 접속 + 설정은 모의' 면 진짜 돈이 나가면서 기록은 모의로 쌓인다.
        반환 False = 안전정지했으니 더 진행하지 말 것."""
        srv = ""
        try: srv = self.kw.server_gubun()
        except Exception: pass
        cfg_mock = bool(self.cfg.get("is_mock", True))
        # ★서버 판정(2026-09-15) — server_gubun 이 빈 값을 주는 일이 실제로 있었다.
        #   그때는 **계좌번호로 판정한다**: 모의투자 서버는 모의계좌만, 실서버는 실계좌만 보여준다.
        #   아는 모의계좌가 목록에 있으면 모의서버다.
        srv_mock, how = None, ""
        if srv in ("1", "0"):
            srv_mock, how = (srv == "1"), "서버구분"
        else:
            _mk = str(self.cfg.get("mock_account", "") or "").strip()
            if _mk and accs:
                srv_mock, how = (_mk in accs), "계좌번호"
                self.log(f"⚠️ 서버구분 조회 실패 — 계좌번호로 판정: {'모의투자' if srv_mock else '실서버'}")
            else:
                self.log("⚠️ 서버구분 조회 실패 · 기준 모의계좌도 없어 대조 불가(진행은 계속)")
        # ★판정 결과를 남긴다 — 애프터마켓 발주(_place_afterhours_tp)가 재사용한다. (2026-09-17)
        #   server_gubun() 이 빈 값을 주는 일이 실제로 있다(2026-09-17 하루에 3번).
        #   그때마다 애프터마켓이 '판정불가'로 보류돼 익절 지정가가 아예 안 걸렸다.
        #   여기서 이미 계좌번호로 서버를 가리고 안전정지까지 통과시켰으니 그 값을 믿어도 된다.
        self._srv_live = (srv_mock is False) if srv_mock is not None else None
        if srv_mock is not None:
            if srv_mock and not cfg_mock or (not srv_mock) and cfg_mock:
                self._halt("키움 접속 서버와 프로그램 설정이 다릅니다",
                           f"키움 접속: {'모의투자 서버' if srv_mock else '실서버'}\n"
                           f"프로그램 설정: {'🟢 모의투자' if cfg_mock else '🔴 실거래'}\n\n"
                           f"→ 설정을 {'🟢모의투자' if srv_mock else '🔴실거래'} 로 맞추거나 키움을 다시 로그인하세요.\n"
                           f"   (설정은 라벨일 뿐이고 실제 주문은 접속 서버로 나갑니다)")
                return False
        # ★모의로 붙었으면 그 계좌를 기억해 둔다 — 다음에 서버구분이 안 읽힐 때 판정 기준이 된다
        if srv_mock and accs:
            _cur = self.cfg.get("account")
            _mk = _cur if (_cur in accs) else accs[0]
            if self.cfg.get("mock_account") != _mk:
                self.cfg["mock_account"] = _mk; savej(CONFIG, self.cfg)
                self.log(f"   기준 모의계좌 기억: {_mk}")
        if accs and self.cfg.get("account") not in accs:
            self._halt("설정된 계좌가 이 로그인 계좌목록에 없습니다",
                       f"설정 계좌: {self.cfg.get('account') or '(없음)'}\n"
                       f"접속 계좌: {', '.join(accs)}\n\n"
                       f"→ 설정 탭에서 쓸 계좌를 고르고 저장한 뒤 다시 시작하세요.\n"
                       f"   (예전엔 첫 계좌를 말없이 골랐습니다 — 실계좌가 여러 개면 위험해서 막았습니다)")
            return False
        return True

    def _already_running(self):
        """★나 말고 다른 client.py 가 떠 있으면 그 PID 를 돌려준다(없으면 "").

        `_kiwoom_conflict` 는 [자동매매 시작] 누를 때만 검사한다. 그런데 **프로그램이 뜨는 순간**
        이미 enabled=False 로 설정을 덮어쓰기 때문에, 그 전에 막아야 돌던 매매가 안 꺼진다.

        ★2026-09-16: 예전엔 PowerShell 로 프로세스 목록을 뒤졌다 — 그것만 5.3초여서 기동이 느렸다.
        이제 포트를 잡아 보는 것으로 판단한다. 못 잡았을 때만 옛 방식으로 확실하게 확인한다."""
        import socket
        try:                                     # ★빠른 길 — 포트를 잡으면 내가 유일한 인스턴스다(1ms)
            _s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            _s.bind(("127.0.0.1", LOCK_PORT)); _s.listen(1)
            self._lock_sock = _s                 # 프로세스가 사는 동안 물고 있어야 락이 유지된다
            return ""
        except OSError:
            pass                                 # 포트가 이미 잡혔다 → 아래에서 확실하게 확인
        try:                                     # 느린 길(5초대) — 포트를 못 잡았을 때만 온다
            import subprocess
            me = os.getpid()
            ps = ("Get-CimInstance Win32_Process -Filter \"Name='python.exe' or Name='pythonw.exe'\" "
                  "| Where-Object { $_.CommandLine -match 'client\\.py' } "
                  "| ForEach-Object { $_.ProcessId }")
            out = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                                 capture_output=True, text=True, timeout=15,
                                 creationflags=0x08000000).stdout or ""
            for t in out.split():
                if t.strip().isdigit() and int(t) != me:
                    return t.strip()
        except Exception:
            pass
        return ""

    def _kiwoom_conflict(self):
        """★사고예방 — 이 PC에서 키움 OCX 를 쓰는 다른 파이썬 프로세스를 찾는다.

        키움 OpenAPI 는 **PC당 1세션**이다. 클라이언트를 실수로 두 번 띄우면
        둘이 같은 계좌에 각각 주문을 내 이중매수·이중매도가 된다.
        자기 자신은 제외하고, 두 번째 client.py 부터 충돌로 본다."""
        try:
            ps = ("Get-CimInstance Win32_Process -Filter \"Name='python.exe' or Name='pythonw.exe'\" "
                  "| Select-Object -ExpandProperty CommandLine")
            out = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                                 capture_output=True, text=True, timeout=15,
                                 creationflags=0x08000000).stdout or ""      # CREATE_NO_WINDOW(무창)
        except Exception:
            return None                                                      # 조회 실패는 막지 않는다(오탐으로 매매를 멈추면 더 손해)
        mine = 0
        for line in out.splitlines():
            if "client.py" in line:
                mine += 1
                if mine >= 2: return "client.py (클라이언트가 이미 실행 중)"   # ★자기 자신 1개는 정상
                continue
            for key in ("auto_routine", "paper_auto", "jongga_auto", "live_trader",
                        "trade_hub", "bt_minute", "admin.py"):
                if key in line: return key
        return None

    def do_logout(self):
        self.cfg["enabled"] = False; savej(CONFIG, self.cfg)     # 자동매매 정지
        try: self.kw.clear_real()                                  # 실시간 해제
        except Exception: pass
        try: self.kw.dynamicCall("CommTerminate()")               # 키움 세션 종료
        except Exception: pass
        self._real_on = False; self._real_key = ""
        self.connected = False; self.acct = {}; self.btn_pw.setEnabled(False)
        self.log("🚪 로그아웃됨 · 자동매매 정지 — 재로그인하려면 [🔑 키움 로그인]")
        self.refresh()

    def do_register_pw(self):
        self.kw.show_account_window(); self.cfg["pw_registered"] = True; savej(CONFIG, self.cfg)
        self.log("🔒 비번창 호출 — 비번+AUTO체크+등록 (최초1회)")

    def save_settings(self):
        try:
            self.cfg["tp_pct"] = float(self.in_tp.text())
            self.cfg["sl_pct"] = -abs(float(self.in_sl.text()))   # ★손절 독립(버튼/직접입력값 그대로·음수저장) — 자동 1:1 규칙 해제
            self.in_sl.setText(f"{self.cfg['sl_pct']:g}")
            self.cfg["invest_per_stock"] = int(float(self.in_inv.text()) * 10000); self.cfg["telegram_chat_id"] = self.in_tg.text().strip()
            self.cfg["telegram_token"] = self.in_tgtok.text().strip()   # ★비우면 기본 봇
            self.cfg["principal"] = int(float(self.in_prin.text()))   # ★투자원금(만원) 저장
            self.cfg["fee_pct"] = float(self.in_fee.text())
            self.cfg["test_qty"] = max(0, int(float(self.in_testqty.text() or 0)))   # 🧪 0=평소 / 1↑=종목당 그 수량만
            self.cfg["cash_buffer"] = max(0, int(float(self.in_buf.text()) * 10000))   # ★현금버퍼(만원 입력 → 원 저장)
            _gp = float(self.in_gap.text() or 0)                                       # ★갭컷(0=끔, 음수만 유효)
            self.cfg["gapcut_pct"] = -abs(_gp) if _gp else 0.0
            self.in_gap.setText(f"{self.cfg['gapcut_pct']:g}")
            # ★실거래 전환은 반드시 확인창을 거친다 — 예전엔 이 라디오가 확인창을 그냥 우회했다
            _want = self.rb_mock.isChecked()
            if _want != bool(self.cfg.get("is_mock", True)):
                self.set_mode(_want)                                   # 취소하면 cfg 가 안 바뀐다
                (self.rb_mock if self.cfg.get("is_mock", True) else self.rb_real).setChecked(True)
            self.cfg["nickname"] = self.in_nick.text().strip(); self.cfg["hub_url"] = self.in_hub.text().strip()   # ★닉네임·서버주소
            if self.cmb_acc.currentText(): self.cfg["account"] = self.cmb_acc.currentText()
            savej(CONFIG, self.cfg); st.set_thresholds(self.cfg["tp_pct"], self.cfg["sl_pct"]); st.set_fee(self.cfg.get("fee_pct", 0.23)); self.check_license()
            for vv, bt in getattr(self, "set_tpbtns", {}).items(): bt.setProperty("on", "1" if abs(vv - self.cfg["tp_pct"]) < 1e-9 else "0"); bt.setStyle(bt.style())
            for vv, bt in getattr(self, "set_slbtns", {}).items(): bt.setProperty("on", "1" if abs(vv - abs(self.cfg["sl_pct"])) < 1e-9 else "0"); bt.setStyle(bt.style())
            self.log(f"💾 저장 · 익절 +{self.cfg['tp_pct']:g}%/손절 {self.cfg['sl_pct']:g}% · 원금 {self.cfg.get('principal',1000)}만 "
                     f"· 종목당상한 {self.cfg['invest_per_stock']//10000}만 · 현금버퍼 {self.cfg.get('cash_buffer',0)//10000}만 "
                     f"· {'모의' if self.cfg['is_mock'] else '실거래'}")
            # ★설정이 실제로 얼마로 적용됐는지 바로 보여준다 — 원금연동이라 입력값과 다를 수 있다
            _eq = self._strategy_equity(); _iv, _af = self._size(_eq)
            self.log(f"   └ 전략자산 {_eq//10000:,}만 → 종목당 {_iv//10000}만 × 최대 {_af}종목"
                     + (f" · 갭컷 {self.cfg['gapcut_pct']:g}%" if self.cfg.get("gapcut_pct") else " · 갭컷 끔"))
            self.tg("설정 저장 완료"); self.refresh()
        except Exception as e: self.log(f"저장 오류 {e}")

    def _refresh_acct_card(self):
        """💰 계좌 현재자산 — 계좌에 실제로 있는 돈, 그리고 그걸로 오늘 얼마를 사게 되는지.
        (2026-09-18 · 관리자 _refresh_acct_card 와 같은 규칙)

        전략자산(원금+누적손익)과 실제 잔고는 **다른 숫자다.** 둘 다 보여준다.
        매수는 `min(전략자산, 주문가능금액)` 으로 나가므로 그 기준값도 같이 찍는다."""
        if not hasattr(self, "acct_big"): return
        a = self.acct or {}
        acc = self.cfg.get("account", "") or "—"
        acc_d = "-".join([acc[:4], acc[4:8], acc[8:]]) if len(acc) >= 10 else acc
        mock = self.cfg.get("is_mock", True)
        mode = "🟢 모의" if mock else "🔴 실거래"
        _tq = int(self.cfg.get("test_qty", 0) or 0)
        if _tq > 0: mode += f"   <span style='color:{GOLD}'>🧪 테스트 {_tq}주</span>"
        self.acct_head.setText(f"{acc_d}   ·   {mode}")
        self.acct_head.setTextFormat(Qt.RichText)

        if not getattr(self, "connected", False) and not a:
            self.acct_big.setText("—"); self.acct_pl.setText("")
            self.acct_donut.setData([], "", "미접속")
            self.acct_box.setText("키움 미접속 — 로그인하면 표시됩니다")
            return

        assets = int(a.get("assets") or 0); cash = int(a.get("cash") or 0)
        orderable = int(a.get("orderable") or 0); pl = int(a.get("total_pl") or 0)
        ev = int(a.get("total_eval") or 0); tb = int(a.get("total_buy") or 0)
        pct = (pl / tb * 100) if tb else 0.0
        eq = self._strategy_equity()
        base = min(eq, orderable) if orderable else eq
        iv, af = self._size(base)

        # ★조회는 됐는데 잔고가 0 인 것을 '조회 실패' 라고 쓰면 거짓말이다(2026-09-18 실제 신고).
        #   asof 가 찍혔고 stale 이 아니면 조회는 성공한 것이다 — 0원은 0원이라고 쓴다.
        if assets or cash:
            self.acct_big.setText(f"{assets:,}원" if assets else f"{cash:,}원")
        else:
            self.acct_big.setText("0원" if (a.get("asof") and not a.get("stale")) else "조회 실패")
        self.acct_big.setStyleSheet("font-size:26px;font-weight:900;color:%s"
                                    % (INK if (assets or cash) else GOLD))
        if tb:
            c = UP if pl >= 0 else DN
            self.acct_pl.setText(f"평가손익 {pl:+,}원 ({pct:+.2f}%)")
            self.acct_pl.setStyleSheet(f"font-size:14px;font-weight:800;color:{c}")
        else:
            self.acct_pl.setText("보유 없음 — 전액 현금")
            self.acct_pl.setStyleSheet(f"font-size:13px;font-weight:700;color:{MUT}")

        # ── 도넛: 총자산이 어디에 들어 있나(주식 vs 현금) ──
        # ★합계를 '예수금+평가금액' 으로 쓰면 큰 숫자(추정예탁자산)와 안 맞는다.
        #   추정예탁자산은 D+2 예수금 기준이라 당일 예수금과 어긋나기 때문이다.
        #   총자산에서 주식평가를 빼 현금조각을 만들면 합계가 큰 숫자와 반드시 같다.
        tot = assets or (cash + ev)
        cash_part = max(0, tot - ev)
        if tot:
            self.acct_donut.setData([(cash_part, CYAN, "현금"), (ev, GOLD, "주식")],
                                    f"{tot//10000:,}만", "현금+주식")
        else:
            self.acct_donut.setData([], "—", "조회 실패")

        L = []
        if not orderable and not assets:
            # ★'조회가 막힌 것' 과 '계좌가 빈 것' 을 가른다(2026-09-18).
            #   둘 다 "비밀번호 확인" 이라고 말해서, 멀쩡한 비밀번호를 몇 번이나 다시 등록하게 만들었다.
            #   조회가 한 번이라도 성공하면 asof(조회시각) 가 찍힌다 — 그걸로 가린다.
            if a.get("asof") and not a.get("stale"):
                L.append(f"<span style='color:{GOLD}'>계좌에 잔고가 없습니다 "
                         f"({a['asof']} 조회 성공 · 입금 전이면 정상입니다)</span>")
            else:
                L.append(f"<span style='color:{GOLD}'>계좌 조회가 되지 않습니다 — "
                         f"계좌비밀번호 등록(AUTO 체크)을 확인하세요</span>")
        L.append(f"예수금 <b>{cash:,}</b> · 주문가능 <b>{orderable:,}</b>")
        if not mock:
            _ls = int(self.cfg.get("live_start_equity", 0) or 0)
            L.append(f"실전 시작자산 <b>{_ls:,}</b> (누적수익률 기준)" if _ls else
                     f"<span style='color:{GOLD}'>실전 시작자산 미기록 — 잔고가 읽히면 자동 기록됩니다</span>")
            # ★입금·출금을 하면 기준이 저절로 따라오지 않는다 (2026-09-30 · 관리자 2026-09-22 분 이식).
            #   live_start_equity 는 최초 1회 기록이라 입금을 모른다 → 실계좌에 돈을 더 넣어도
            #   매수는 옛 기준으로 나간다. _base_for 에서 원금 클램프를 뺀 뒤로는 이 기준이
            #   **곧 매수 규모**라, 낡은 채 두면 그만큼 작게 산다.
            #   기준 + 실현손익 + 평가손익 ≈ 지금 실자산 이어야 한다. 크게 어긋나면 입출금이다.
            #   ★수수료·D+2 평가 차이로 몇만 원은 늘 어긋나므로 **넉넉한 문턱**(30만 또는 10%)을 둔다.
            #     관리자 계좌탭과 **같은 문턱**이어야 두 화면이 다른 말을 하지 않는다.
            if _ls > 0 and (assets or cash) and not a.get("stale"):
                _real = assets or cash
                _gap = _real - (_ls + self._live_pnl() + pl)
                if abs(_gap) >= max(300000, int(_ls * 0.10)):
                    L.append(f"<span style='color:{GOLD}'>⚠ 실자산이 기준보다 {_gap:+,}원 어긋납니다"
                             " — 입금·출금했다면 [⚙️ 설정] 탭의 💰 실자산 기준 버튼을 눌러 맞추세요</span>")
        L.append(f"전략자산 {eq:,} · 매수기준 <b>{base:,}</b>")
        if _tq > 0:    # ★테스트모드면 금액 사이징을 무시한다 — 금액을 적으면 거짓말이 된다
            L.append(f"→ 오늘 <b>🧪 종목당 {_tq}주만</b> 매수 (금액 사이징 무시)")
        else:
            L.append(f"→ 오늘 <b>종목당 {iv//10000}만 × 최대 {af}종목</b>")
        if orderable and eq > orderable:
            L.append(f"<span style='color:{GOLD}'>⚠ 주문가능금액이 상한입니다</span>")
        # ★"90초마다 갱신" 은 실제로 그럴 때만 쓴다 — 아니면 왜 멈췄는지 적는다
        if a.get("stale"):
            L.append(f"<span style='color:{GOLD}'>⚠ 잔고 갱신 실패 — 아래는 {a.get('asof','')} 기준 옛 값입니다"
                     f" (계좌비밀번호 AUTO 등록을 확인하세요)</span>")
        elif a.get("asof"):
            if not getattr(self, "connected", False):
                _how = "키움 미접속 — 갱신 멈춤"
            elif BALANCE_SKIP[0] <= self._hm() < BALANCE_SKIP[1]:
                _how = f"매수 구간이라 잠시 멈춤({BALANCE_SKIP[1]} 재개)"
            else:
                _how = f"{BALANCE_SEC}초마다 갱신"
            L.append(f"<span style='color:{MUT}'>{a['asof']} 기준 · {_how}</span>")
        self.acct_box.setText("<br>".join(L))

    def _waiting_market(self):
        """★'장 시간 대기' 상태인가 — 예약은 됐지만 아직 장 시간이 아니라 매매는 쉬는 중.

        무인 생명주기(AUTO)에서만 뜻이 있다. 이 상태에서 [자동매매] 버튼은 '예약 취소' 로 동작한다."""
        return bool(AUTO and self.cfg.get("auto_start") and not self.cfg.get("enabled")
                    and not self._operating())

    def toggle_auto(self):
        # ★장 시간 밖(평일 08:20~20:05 밖)에서 누른 경우 — 켜 봐야 20초 뒤 _night_idle 이 끈다(2026-09-17).
        #   그래서 켜는 시늉을 하지 않고 **예약**으로 처리한다. 다음 평일 08:30 에 _daily_resume 이 진짜로 시작한다.
        if AUTO and not self._operating():
            if self._waiting_market():                   # 이미 예약돼 있으면 → 예약 취소
                self.cfg["auto_start"] = False; self.cfg["enabled"] = False; savej(CONFIG, self.cfg)
                self.log("⏹ 자동매매 예약 취소 — 다음 평일 08:30 에도 시작하지 않습니다")
            else:
                self.cfg["auto_start"] = True; self.cfg["enabled"] = False; savej(CONFIG, self.cfg)
                self._resumed_day = None
                self.log("🕗 지금은 장 시간이 아닙니다 — 자동매매를 예약했습니다. "
                         "다음 평일 08:30 에 스스로 시작합니다(프로그램은 켜 두세요).")
                self.tg("🕗 자동매매 예약 — 다음 평일 08:30 자동 시작")
            self.refresh(); return
        if not self.cfg.get("enabled"):                 # ★시작하려는 경우 — 관리자 사용승인 필수
            conf = self._kiwoom_conflict()               # ★사고예방: 다른 키움 매매 프로세스 충돌 검사
            if conf:
                if not AUTO:                      # ★무인에서는 모달 금지(이벤트루프 정지) — 로그·텔레그램으로만 알린다
                    self._alert("키움 프로세스 충돌",
                                f"이 PC에서 키움을 쓰는 다른 프로그램이 실행 중입니다.\n\n{conf}\n\n"
                                "키움 OpenAPI 는 PC당 1세션이라 동시에 돌면\n이중매매·접속불가가 납니다. 먼저 종료하세요.")
                self.log(f"⛔ 시작 취소 — 다른 키움 프로세스({conf}) 실행 중")
                self.tg(f"⛔ 자동매매 시작 취소 — {conf} 실행 중(충돌 방지)"); self.refresh(); return
            self.check_license()
            if not self._licensed:
                nick = (self.cfg.get("nickname") or "").strip()
                if not AUTO:                      # ★무인에서는 모달 금지 — 창 하나가 이벤트루프를 영구히 막는다
                    if not nick:
                        self._alert("사용 권한 없음", "닉네임이 설정되지 않았습니다.\n\n[⚙️ 설정] 탭에서 닉네임을 저장한 뒤\n[📨 승인 요청]을 눌러 관리자 승인을 받아주세요.")
                    elif self._lic_status == "서버 연결안됨":
                        self._alert("관리자 서버 연결 안됨", f"관리자 서버에 연결할 수 없습니다.\n\n[⚙️ 설정] 탭의 '관리자 서버주소'를 확인하세요.\n(관리자 프로그램이 켜져 있어야 합니다)")
                    else:
                        self._alert("관리자 미승인 · 사용 권한 없음", f"닉네임 '{nick}' 은(는) 아직 승인되지 않았습니다. (상태: {self._lic_status})\n\n[⚙️ 설정] 탭에서 [📨 승인 요청]을 누르고\n관리자가 승인하면 자동매매를 시작할 수 있습니다.")
                self.log(f"⛔ 사용승인 필요({self._lic_status}) — 승인 요청 후 시작"); self.refresh(); return
            if not self.cfg.get("account"):       # ★계좌 미설정으로 시작하면 주문 코드가 KeyError 로 죽는다(관리자 동일 가드)
                self.log("⛔ 계좌 미설정 — 설정 탭에서 로그인/계좌 저장 후 시작")
                self.tg("⛔ 자동매매 시작 취소 — 계좌가 설정되지 않았습니다"); self.refresh(); return
        self.cfg["enabled"] = not self.cfg.get("enabled"); self.cfg["auto_start"] = self.cfg["enabled"]; savej(CONFIG, self.cfg)   # ★auto_start=지속(워치독/부팅 후 자동재개용)
        if self.cfg["enabled"]:
            self.log(f"▶ 자동매매 시작(승인됨·만료 {self._lic_expiry}) — 로그인→조회→자동루틴")
            st.set_thresholds(self.cfg.get("tp_pct", 3.0), self.cfg.get("sl_pct", -3.0))
            if not self.connected: self.do_login()      # ★로그인부터
            if self.connected:
                self.query_account()                     # ★조회까지
                _eq = self._strategy_equity()
                _iv, _af = self._size(_eq)
                _gp = float(self.cfg.get("gapcut_pct", 0) or 0)
                self.tg("✅ 자동매매 시작 — 무인 운용(정지 전까지 매일 자동)\n"
                        f"계좌 {'🟢모의' if self.cfg.get('is_mock') else '🔴실거래'} · "
                        f"익절 +{self.cfg.get('tp_pct',6):g}% / 손절 {self.cfg.get('sl_pct',-3.5):g}%"
                        + (f" · 갭컷 {_gp:g}%" if _gp else " · 갭컷 끔") + "\n"
                        f"전략자산 {_eq//10000:,}만 → 종목당 {_iv//10000}만 × 최대 {_af}종목\n"
                        f"유통 ≤{self.cfg.get('float_max',70)}% · 상한가 제외 "
                        f"{'O' if self.cfg.get('exclude_upper',True) else 'X'}")
            elif AUTO and self.cfg.get("auto_start") and self._operating():
                self._restart_process("시작 로그인 실패 — 즉시 재시작")            # ★운영시간(08:25~17:00): 재시도 말고 바로 재시작
            elif self.cfg.get("auto_start"):
                self.log("⚠️ 로그인 실패 — 운영시간 밖, 재시작 보류")              # 야간/주말은 재시작 안 함(폭주 방지)
            else:
                self.log("⚠️ 로그인 실패 — 설정 탭에서 계좌 확인 후 다시 시작")
                self.cfg["enabled"] = False; savej(CONFIG, self.cfg)
        else:
            self.log("⏹ 자동매매 정지"); self.tg("⏹ 자동매매 정지")
        self.refresh()

    def _restart_process(self, why=""):
        """★접속 끊김/로그인 실패 시 재시도 말고 '즉시 프로세스 재시작'(키움 안내 '종료후 재접속'과 동일).
        새 인스턴스 먼저 기동 → 현재 즉시 종료(OCX 완전 초기화 → 새 인스턴스가 깨끗이 재접속).
        지속장애(서버다운) 시엔 새 인스턴스가 restart_history 보고 로그인을 지연(백오프)해 폭주·레이트차단 방지."""
        try:
            hist = [t for t in loadj(RESTART_LOG, []) if time.time() - t < 600]   # 최근 10분 재시작 이력
            spam = len(hist) >= 1                             # 첫 재시작만 텔레그램, 이후 지속장애는 로그만(스팸 방지)
            hist.append(time.time()); savej(RESTART_LOG, hist)
        except Exception:
            spam = False
        try:
            self.log(f"🔁 즉시 재시작 — {why}")
            if not spam: self.tg(f"🔁 클라이언트 재시작(OCX 초기화) — {why}")
        except Exception: pass
        try:                                                 # 새 인스턴스 먼저 기동(★auto 인자로 무인모드 유지) · 디태치(부모 종료해도 생존)
            # ★권한지갑 경유로 재기동한다(2026-09-17). run_client.vbs 를 직접 부르면
            #   재시작된 인스턴스가 관리자 권한을 잃을 수 있고, 그러면 키움 로그인에서
            #   UAC 창이 떠서 거기서 멈춘다 = 무인 운용이 깨진다.
            #   권한지갑(JonggaClientRun)은 작업 스케줄러가 UAC 없이 최고 권한으로 올려 준다.
            #   run_elevated.vbs 는 권한지갑이 없으면 스스로 run_client.vbs auto 로 떨어지므로
            #   이 한 줄이 두 경우를 다 덮는다.
            elev = os.path.join(DIR, "run_elevated.vbs")
            if os.path.exists(elev):
                subprocess.Popen(["wscript.exe", elev], cwd=DIR,
                                 creationflags=0x00000008 | 0x00000200, close_fds=True)
                os._exit(0)
            vbs = os.path.join(DIR, "run_client.vbs")         # ★런처가 없는 옛 설치본 대비
            bat = os.path.join(DIR, "run_client.bat")
            if os.path.exists(vbs):
                subprocess.Popen(["wscript.exe", vbs, "auto"], cwd=DIR,
                                 creationflags=0x00000008 | 0x00000200, close_fds=True)
            elif os.path.exists(bat):
                subprocess.Popen(["cmd", "/c", bat, "auto"], cwd=DIR,
                                 creationflags=0x00000008 | 0x00000200, close_fds=True)   # DETACHED_PROCESS|CREATE_NEW_PROCESS_GROUP
        except Exception: pass
        os._exit(0)                                          # 현재 프로세스 즉시 종료(OS가 OCX 자동 해제 — CommTerminate는 행 위험이라 생략)

    def _drop_legacy_tasks(self):
        """★옛 설치본이 남긴 예약작업을 지운다(있을 때만). 백그라운드 전용. (2026-09-17)

        2026-09-16 부터 클라이언트는 예약작업을 쓰지 않는다. 그런데 그 전에 깔았던 PC 에는
        `종가배팅_클라이언트감시`(2분마다)가 남아, 이미 삭제된 run_watchdog.vbs 를 계속 찾는다
        → 2분마다 'Windows Script Host … 찾을 수 없습니다' 오류창이 뜬다(실제 사용자 신고).
        재설치를 안 해도 프로그램만 한 번 띄우면 저절로 없어지게 한다."""
        try:
            import subprocess
            for t in ("종가배팅_클라이언트감시", "종가배팅_클라이언트시작"):
                q = subprocess.run(["schtasks", "/Query", "/TN", t],
                                   capture_output=True, timeout=20, creationflags=0x08000000)
                if q.returncode != 0: continue            # 없으면 넘어간다
                d = subprocess.run(["schtasks", "/Delete", "/TN", t, "/F"],
                                   capture_output=True, timeout=20, creationflags=0x08000000)
                if d.returncode == 0:
                    self.log(f"🧹 옛 예약작업 제거: {t} (이제 예약작업을 쓰지 않습니다)")
                else:
                    self.log(f"⚠️ 옛 예약작업 {t} 를 못 지웠습니다 — [2_프로그램설치.bat] 을 "
                             "마우스 오른쪽 > [관리자 권한으로 실행] 해 주세요")
        except Exception:
            pass

    def _kiwoom_dialog_watcher(self):
        """★무인 필수 — 키움 OCX 모달 팝업('통신 연결이 끊겼습니다 … 프로그램 종료후 재접속' 등)은 메인 스레드를
        모달로 막아 자동재접속을 방해한다. 별도 스레드에서 팝업을 감지해 [확인] 자동 클릭(언블록) → 이후 tick의
        GetConnectState→_restart_process가 재접속. (모달이 메인 Qt 스레드를 막아도 이 스레드는 별개라 동작)."""
        import ctypes
        from ctypes import wintypes
        try: u = ctypes.windll.user32
        except Exception: return
        WM_CLOSE, WM_COMMAND = 0x0010, 0x0111
        # 눌러도 되는 창 — 접속 끊김 알림 + OpenAPI 사용 동의/안내
        KEYS = ("통신 연결", "연결이 끊", "재접속", "종료후",
                "사용 동의", "이용 동의", "동의", "사용자 정보", "OpenAPI", "OPEN API", "허용")
        # ★절대 누르면 안 되는 창 — 돈이 나가는 확인창. 하나라도 걸리면 건너뛴다.
        DANGER = ("매수", "매도", "주문", "체결", "정정", "취소", "청산", "잔고이체", "출금")
        MYPID = os.getpid()
        ENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        def wtext(h):
            try:
                n = u.GetWindowTextLengthW(h); b = ctypes.create_unicode_buffer(n + 2)
                u.GetWindowTextW(h, b, n + 2); return b.value or ""
            except Exception: return ""
        while True:
            try:
                tops = []
                def _top(h, l):
                    if not u.IsWindowVisible(h): return True
                    t = wtext(h)
                    if "khopenapi" in t.lower():
                        tops.append(h); return True
                    # ★제목이 없어도 **우리 프로세스가 띄운 대화상자**면 본다
                    #   (키움 OCX 모달은 우리 프로세스 안에서 뜬다)
                    try:
                        cn = ctypes.create_unicode_buffer(64); u.GetClassNameW(h, cn, 64)
                        if cn.value == "#32770":
                            pid = wintypes.DWORD()
                            u.GetWindowThreadProcessId(h, ctypes.byref(pid))
                            if pid.value == MYPID: tops.append(h)
                    except Exception: pass
                    return True
                u.EnumWindows(ENUMPROC(_top), 0)
                for h in tops:
                    body = []; btns = []
                    def _child(c, l):
                        t = wtext(c); body.append(t)
                        try:
                            cn = ctypes.create_unicode_buffer(32); u.GetClassNameW(c, cn, 32)
                            if cn.value == "Button" and t: btns.append(t)
                        except Exception: pass
                        return True
                    u.EnumChildWindows(h, ENUMPROC(_child), 0)
                    txt = " ".join(body) + " " + wtext(h)
                    if any(d in txt for d in DANGER):        # ★주문 관련이면 손대지 않는다
                        continue
                    if not any(k in txt for k in KEYS):
                        continue
                    btn = None
                    for cap in ("확인", "예", "동의", "계속"):   # 긍정 버튼을 순서대로 찾는다
                        btn = u.FindWindowExW(h, 0, "Button", cap)
                        if btn: break
                    if btn:                                  # ★WM_COMMAND(BN_CLICKED, 확인버튼 ctrlID) — 실검증된 모달 확인 클릭
                        cid = u.GetDlgCtrlID(btn) & 0xFFFF
                        u.PostMessageW(h, WM_COMMAND, cid, btn)
                    else:
                        u.PostMessageW(h, WM_CLOSE, 0, 0)
                    self._popup_n += 1                       # 메인 tick이 보고
                    try:                                     # 무엇을 눌렀는지 남긴다(추적용)
                        _t = (wtext(h) or "(제목없음)")[:40]
                        _b = ", ".join(btns[:4])
                        self.log(f"🧹 팝업 자동확인 — {_t} [{_b}]")
                    except Exception: pass
            except Exception:
                pass
            time.sleep(1.5)

    def _pid_alive(self, pid):
        """PID 생존 확인(Windows)."""
        try:
            import ctypes
            h = ctypes.windll.kernel32.OpenProcess(0x1000, False, int(pid))   # PROCESS_QUERY_LIMITED_INFORMATION
            if h:
                ctypes.windll.kernel32.CloseHandle(h); return True
        except Exception:
            pass
        return False

    def _autostart(self):
        st.set_thresholds(self.cfg.get("tp_pct", 3.0), self.cfg.get("sl_pct", -3.0))
        if self.cfg.get("account") and not self.connected: self.do_login()

    def _base_for(self, mode):
        """★그 모드의 '시작 자산'. 관리자 admin._base_for() 와 **한 글자도 다르지 않아야 한다**. (2026-09-17)

        모의 : 설정 원금(principal). 모의계좌 시드는 수천만이라 기준으로 쓸 수 없다.
        실전 : live_start_equity — 실전 첫 거래 전에 계좌에 실제로 있던 돈.
               아직 안 잡혔으면 원금으로 물러난다(예전과 같은 동작).

        누적수익률·MDD·자산곡선·사이징이 전부 이 값을 분모로 쓴다."""
        _prin = int(self.cfg.get("principal", 500)) * 10000
        if mode == "acct":
            v = int(self.cfg.get("live_start_equity", 0) or 0)
            # ★실전은 **조회한 실계좌 값을 그대로 쓴다** (2026-09-30 · 관리자 2026-09-22 결정 이식).
            #   여기엔 `min(실계좌, 설정원금)` 이 있었다(2026-09-17 감사에서 위험한도를 지키려고 넣은 것).
            #   관리자는 2026-09-22 에 그걸 뺐다 — **실계좌를 조회해 3,054,400원을 기록해 놓고도
            #   설정값 300만을 쓰고 있었고**, 화면의 '전략자산'이 계좌와 무관한 임의값이 됐다.
            #   입금을 해도 기준이 안 따라온다.
            #   ★그런데 클라이언트에만 min 이 남아 있어서 **관리자와 사이징이 갈렸다**(2026-09-30 발견).
            #     사용자 지시 "관리자와 맞춰서" → 계좌 전액 기준으로 통일한다.
            #   위험한도는 여기가 아니라 아래 셋이 잡는다 —
            #     · `invest_per_stock`(종목당 상한 — ★아래 경고 참고)  · `cash_buffer`(안 건드릴 현금)
            #     · buy_picks 의 `min(전략자산, 매수여력)`(실제 돈을 절대 안 넘는다)
            #   ⚠️**`invest_per_stock` 은 전략자산이 커지면 상한 노릇을 못 한다** (2026-09-30 실측).
            #     `_size` 가 `max(min(cap, 가용/min_positions), 가용/size_div)` 라서,
            #     `가용/size_div` 가 cap 을 넘어서면 그쪽이 이긴다 —
            #     실측(cap 200만·buffer 20만·div 3): 전략자산 630만을 넘으면 종목당이 200만을 넘고,
            #     3,000만이면 종목당 993만이 된다. 복리로 키우려고 그렇게 만든 것이라 버그는 아니지만,
            #     **"cap 이 막아 준다" 고 믿으면 안 된다.** 클램프를 뺀 지금 실제로 남는 방어는
            #     `cash_buffer` 와 `min(전략자산, 매수여력)`(실제 돈), 그리고 사람이 관리하는
            #     `live_start_equity` 기준값이다.
            #   ★live_start_equity 는 스스로 커지지 않는다. 최초 1회(_capture_live_start) 또는
            #     사람이 설정 탭의 [💰 실자산 기준] 버튼을 눌렀을 때(_reset_live_start)만
            #     바뀐다. 그래서 이 값을 그대로 써도 기준이 제멋대로 부풀 일은 없다.
            #     ★min 을 뺀 만큼 **낡은 기준에 갇혀 작게 사는** 반대 방향 위험이 생겼다 —
            #       그래서 이 변경과 **같이** 그 재설정 버튼과 어긋남 경고를 넣었다. 둘은 한 쌍이다.
            #   ⛔되돌리지 말 것: 되돌리면 관리자와 종목당 금액이 최대 9배까지 갈린다.
            if v > 0: return v
        return _prin

    def _live_pnl(self):
        """실전 거래의 실현손익 누계(수수료 차감) — _strategy_equity 와 같은 식.
        ★원장 출처만 다르다(이 PC 의 client_state.json) — **계산식은 관리자와 같아야 한다.**"""
        fee = float(self.cfg.get("fee_pct", 0.23)) / 100.0
        s = 0
        for t in (self.state.get("trades") or []):
            if t.get("mode") != "실전": continue
            s += (t.get("pl") or 0) - round((t.get("buy") or 0) * (t.get("qty") or 0) * fee)
        return int(s)

    def _reset_live_start(self):
        """★실자산 기준 재설정 — 입금/출금 뒤 눌러 지금 계좌를 새 시작자산으로 삼는다.
        (2026-09-30 · 관리자 2026-09-18 분 이식)

        live_start_equity 는 '실전 첫 거래 전 잔고' 로 **한 번만** 기록돼 입금을 모른다.
        관리자에서 190만을 넣었는데 기준이 115만에 묶여 실계좌 305만 중 125만이 놀았다(실제 사례).

        ★이 버튼은 _base_for 의 원금 클램프(min) 제거와 **한 쌍**이다(2026-09-30).
          클램프를 빼면 기준이 곧 live_start_equity 라, 그 값이 낡으면 이번엔
          **낡은 기준에 갇혀 작게 사는** 반대 방향 문제가 된다. 사람이 맞출 통로가 있어야 한다.

        방침: 라이브가 기준이고, 수익률은 **거래로 번 것만** 친다.
        입금은 수익이 아니므로 분모에 더한다 — 그래야 이후 수익률이 부풀지 않는다.
        실현손익 누계를 빼서 기록하므로 `기준 + 실현손익 = 지금 실자산` 이 된다."""
        a = self.acct or {}
        real = int(a.get("assets") or a.get("cash") or 0)
        if real <= 0 or a.get("stale"):
            self.log("⚠️ 실자산 기준 재설정 — 계좌 조회가 안 돼 보류합니다(조회된 뒤 다시 눌러주세요)")
            return
        if self.cfg.get("is_mock", True):
            self.log("⚠️ 실자산 기준 재설정은 실거래 모드에서만 씁니다")
            return
        pnl = self._live_pnl()
        new = max(1, real - pnl)
        old = int(self.cfg.get("live_start_equity", 0) or 0)
        if not AUTO:            # ★무인에서는 모달 금지 — 창 하나가 tick() 을 영원히 막는다.
            m = QMessageBox(self); m.setIcon(QMessageBox.Question)
            m.setWindowTitle("실자산 기준 재설정")
            m.setText("실전 시작자산을 지금 계좌에 맞춥니다.\n\n"
                      f"  지금 실자산   {real:,}원\n"
                      f"  실현손익 누계 {pnl:+,}원\n"
                      f"  새 기준       {new:,}원   (기존 {old:,}원)\n\n"
                      "누적수익률의 분모와 종목당 금액이 바뀝니다. 진행할까요?")
            m.setStyleSheet("QMessageBox{background:#15131f;} QLabel{color:#e9e7f2;font-size:13px;min-width:340px;} "
                            "QPushButton{background:#7c3aed;color:#fff;border-radius:8px;padding:6px 18px;font-weight:800;}")
            m.setStandardButtons(QMessageBox.Yes | QMessageBox.Cancel)
            m.setDefaultButton(QMessageBox.Cancel)
            m.button(QMessageBox.Yes).setText("재설정"); m.button(QMessageBox.Cancel).setText("취소")
            if m.exec_() != QMessageBox.Yes:
                return
        self.cfg["live_start_equity"] = new; savej(CONFIG, self.cfg)
        self.log(f"💰 실자산 기준 재설정 — {old:,} → {new:,}원 (실자산 {real:,} · 실현손익 {pnl:+,})")
        _iv, _af = self._size(self._strategy_equity())
        self.log(f"   └ 전략자산 {self._strategy_equity():,} → 종목당 {_iv//10000}만 × 최대 {_af}종목")
        self.tg(f"💰 실자산 기준 재설정\n{old:,} → {new:,}원\n"
                f"(실자산 {real:,} · 실현손익 {pnl:+,})\n"
                "이후 수익률은 이 금액 대비로 계산됩니다.")
        try: self.refresh()
        except Exception: pass

    def _refresh_lsq(self):
        """💰 실자산 기준 카드 — 지금 기준·실현손익·실계좌를 나란히 적고, 어긋나면 버튼이 가리킨다.

        ★버튼 글자에 **지금 상태와 다음 동작**을 쓴다 — 이 프로젝트는 "색만으로는 구분이 안 된다"는
          지적을 받아 aftp_btn 을 그렇게 고쳤다. 같은 규칙을 따른다.
        ★어긋남 문턱은 관리자 계좌탭과 **같다**(30만 또는 기준의 10% 중 큰 쪽).
          두 프로그램이 같은 상황에서 다른 말을 하면 안 된다."""
        if not hasattr(self, "lsq_btn"): return
        _base = "border-radius:11px;padding:10px 14px;font-weight:800;font-size:13px;text-align:left;"
        _ls = int(self.cfg.get("live_start_equity", 0) or 0)
        _a = self.acct or {}
        _rl = int(_a.get("assets") or _a.get("cash") or 0)
        _pn = self._live_pnl()
        # ★평가손익(미실현)을 **반드시 같이 뺀다** — 계좌탭 _refresh_acct_card 와 같은 식이어야 한다
        #   (2026-09-30 재점검에서 고침). 처음엔 `_rl - (_ls + _pn)` 이었는데 그러면
        #   **보유 중 평가손익이 그대로 '어긋남' 으로 잡힌다** — 입출금이 한 푼도 없는데 버튼이
        #   "눌러서 맞추세요" 라고 재촉하고, 그걸 누르면 **미실현 이익이 기준(분모)에 박힌다.**
        #   그 뒤 그 포지션을 팔면 같은 이익이 실현손익으로 또 더해져 이중계상이 된다.
        #   기준 + 실현손익 + 평가손익 ≈ 실자산 이어야 하고, 어긋나면 그때가 입출금이다.
        _un = int(_a.get("total_pl") or 0)
        _thr = max(300000, int(_ls * 0.10))
        if self.cfg.get("is_mock", True):
            self.lsq_btn.setText("🔒 모의투자에서는 원금 설정을 씁니다 (실거래 전용)")
            self.lsq_btn.setStyleSheet("background:#141221;color:#4b5563;border:1px dashed #2c2748;" + _base)
            self.lsq_btn.setEnabled(False)
            self.lsq_lbl.setText("모의투자 기준은 위 ② 매매 설정의 <b>원금(만원)</b> 입니다.")
            self.lsq_lbl.setTextFormat(Qt.RichText)
            return
        if _rl <= 0 or _a.get("stale"):
            self.lsq_btn.setText("⏳ 계좌 조회를 기다립니다 — 잔고가 읽히면 누를 수 있습니다")
            self.lsq_btn.setStyleSheet("background:#141221;color:#4b5563;border:1px dashed #2c2748;" + _base)
            self.lsq_btn.setEnabled(False)
        else:
            self.lsq_btn.setEnabled(True)
            _gap = _rl - (_ls + _pn + _un)
            if _ls > 0 and abs(_gap) < _thr:
                self.lsq_btn.setText(f"✅ 기준 {_ls:,}원 — 실계좌와 맞습니다   (입금·출금했다면 눌러서 갱신)")
                self.lsq_btn.setStyleSheet("background:#171525;color:#8b93a7;border:1px solid #2c2748;" + _base)
            elif _ls > 0:
                self.lsq_btn.setText(f"⚠ 실계좌와 {_gap:+,}원 어긋남 — 눌러서 기준을 {max(1, _rl - _pn):,}원으로 맞추기")
                self.lsq_btn.setStyleSheet("background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #b7791f,stop:1 #8a5a12);"
                                           "color:#ffffff;border:1px solid #f5b53d;" + _base)
            else:
                self.lsq_btn.setText(f"▶ 기준 미기록 — 눌러서 지금 계좌 {max(1, _rl - _pn):,}원으로 기록하기")
                self.lsq_btn.setStyleSheet("background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #b7791f,stop:1 #8a5a12);"
                                           "color:#ffffff;border:1px solid #f5b53d;" + _base)
        _txt = f"현재 기준 <b>{_ls:,}</b>원 + 실현손익 {_pn:+,} = 전략자산 <b>{_ls + _pn:,}</b>원"
        if _rl > 0:
            _gap = _rl - (_ls + _pn + _un)          # ★평가손익까지 뺀 값 = 순수 입출금 차이
            _txt += f"<br>실계좌 <b>{_rl:,}</b>원"
            if _un: _txt += f" (평가손익 {_un:+,} 포함)"
            if _ls <= 0 or abs(_gap) >= _thr:
                _txt += (f" — <span style='color:{GOLD}'>{_gap:+,}원 차이. "
                         "입금·출금이 있었다면 위 버튼으로 맞추세요</span>")
            if _un:
                # ★버튼이 저장하는 값은 `실자산 − 실현손익` 이라 **평가손익이 섞인다**(관리자도 같다).
                #   보유가 없는 때 누르는 게 가장 정확하다 — 그 사실을 화면에 적는다.
                # ★색은 GOLD 다 — 처음엔 MUT(회색)로 썼는데 **실제로 렌더해 보니 카드에서 가장 흐린 줄**이
                #   됐다(2026-09-30 검증). 이 줄은 안내가 아니라 **돈이 틀어지는 경고**다 —
                #   평가손익이 기준에 박히면 그 종목을 판 날 실현손익으로 또 더해져 이중계상이 된다.
                #   이 프로젝트는 "색만으로는 구분이 안 된다"는 지적을 받아 aftp_btn 을 고친 적이 있다.
                #   같은 이유로 **경고는 경고 색**으로 둔다.
                _txt += ("<br><span style='color:%s'>※ 보유 종목이 있으면 평가손익이 기준에 섞입니다 "
                         "— 되도록 보유가 없을 때 누르세요.</span>" % GOLD)
        self.lsq_lbl.setText(_txt)
        self.lsq_lbl.setTextFormat(Qt.RichText)

    def _capture_live_start(self, a):
        """★실전 시작자산을 한 번만 기록한다. (2026-09-17)

        실전 모드 · 아직 미기록 · 실전 거래 0건 — 셋을 다 만족할 때만.
        거래가 하나라도 있으면 지금 잔고엔 손익이 섞여 '시작 자산'이 아니다."""
        if self.cfg.get("is_mock", True): return
        # ★설정 라벨만 믿으면 안 된다 — '설정은 실거래인데 키움은 아직 모의' 인 순간이 실제로 있다.
        #   (2026-09-17 09:32 관리자에서 실제로 났다) 그때 기록하면 모의 시드가 영구히 박힌다.
        #   _verify_live_env 가 로그인 때 계산해 둔 판정을 쓰고, 판정불가(None)면 기록하지 않는다.
        if getattr(self, "_srv_live", None) is not True: return
        if int(self.cfg.get("live_start_equity", 0) or 0) > 0: return
        if self._ledger_trades("acct"): return
        v = int(a.get("assets") or a.get("cash") or 0)
        if v <= 0: return
        self.cfg["live_start_equity"] = v; savej(CONFIG, self.cfg)
        self.log(f"🏦 실전 시작자산 {v:,}원 기록 — 이제 누적수익률·원금이 이 값 기준입니다")
        try: self.tg(f"🏦 실전 시작자산 {v:,}원 기록")
        except Exception: pass

    def _kw_last_msg(self):
        """키움이 마지막으로 보낸 메시지 — 실패 이유를 **추측하지 않고 그대로** 보여주려고 쓴다.
        (2026-09-18: "비번 미등록일 가능성이 큽니다" 라는 추측이 사람을 며칠 헤매게 했다.
         실제로는 키움이 "[100000] 조회가 완료되었습니다" 를 보냈고, 그냥 입금 전 빈 계좌였다.)"""
        try:
            d = getattr(self.kw, "last_msg", None) or {}
            for _tr in ("opw00018", "opw00001"):
                if d.get(_tr): return "[%s] %s" % (_tr, d[_tr])
            return d.get("_last", "") or ""
        except Exception:
            return ""

    def _popup_notice(self, title, lines, tone="warn"):
        """★비모달 알림창 — 무인(AUTO) 실행에서도 안전하다. (2026-09-18)

        모달(exec_)로 띄우면 창 하나가 tick() 을 **영원히** 막아 매매가 통째로 멈춘다.
        이 프로젝트에서 반복해 당한 함정이라 CLAUDE.md 에도 적혀 있다.
        show() 는 이벤트루프를 막지 않으므로 무인에서도 그대로 띄울 수 있다.

        ★참조를 붙들어 두지 않으면 Qt 가 즉시 회수해 창이 떴다가 사라진다.
          _popup_keep 에 담고, 닫힐 때 빼서 새지 않게 한다."""
        try:
            from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLabel, QPushButton
            dlg = QDialog(self); dlg.setWindowTitle(title); dlg.setModal(False)
            dlg.setStyleSheet("QDialog{background:#15131f;} QLabel{color:#e9e7f2;font-size:13px;} "
                              "QPushButton{background:#7c3aed;color:#fff;border-radius:8px;"
                              "padding:6px 20px;font-weight:800;}")
            v = QVBoxLayout(dlg); v.setContentsMargins(22, 18, 22, 16); v.setSpacing(12)
            head = QLabel(title)
            head.setStyleSheet("font-size:16px;font-weight:900;color:%s"
                               % ("#F0455C" if tone == "bad" else "#FFC24B"))
            v.addWidget(head)
            body = QLabel("<br>".join(lines)); body.setTextFormat(Qt.RichText)
            body.setWordWrap(True); body.setMinimumWidth(380); v.addWidget(body)
            btn = QPushButton("확인"); btn.clicked.connect(dlg.close)
            v.addWidget(btn, 0, Qt.AlignRight)
            keep = getattr(self, "_popup_keep", None)
            if keep is None: keep = self._popup_keep = []
            keep.append(dlg)
            dlg.finished.connect(lambda *_a, _d=dlg: (keep.remove(_d) if _d in keep else None))
            dlg.show(); dlg.raise_(); dlg.activateWindow()
            return dlg
        except Exception as e:
            try: self.log("알림창을 띄우지 못했습니다 — %s" % e)
            except Exception: pass
            return None

    @staticmethod
    def _left_text(left):
        """남은 일수를 사람 말로. 음수는 이미 지난 것이다."""
        if left < 0: return "이미 만료 (%d일 지남)" % (-left)
        if left == 0: return "오늘 만료"
        return "%d일 남음" % left

    def _check_license_expiry(self):
        """★내 사용승인 만료 7일 전 알림 — 만료 날짜를 팝업으로 알린다. (2026-09-18 사용자 요청)

        만료일은 허브가 준다(check_license → _lic_expiry, 약 30초마다 갱신).
        아직 확인 전이면 날짜 도장을 찍지 않는다 — 다음 틱에 다시 본다."""
        try:
            if getattr(self, "_licexp_day", "") == self._t(): return
            exp = str(getattr(self, "_lic_expiry", "") or "").strip()
            if not exp: return                      # ★서버 확인 전 — 오늘 것으로 도장 찍지 않는다
            try: left = (datetime.date.fromisoformat(exp) - datetime.date.today()).days
            except Exception:
                self._licexp_day = self._t(); return
            self._licexp_day = self._t()
            if left > LIC_WARN_DAYS: return
            col = "#F0455C" if left <= 0 else "#FFC24B"
            lines = ["사용승인 만료일이 <b>%s</b> 입니다." % exp,
                     "<span style='color:%s;font-weight:900'>%s</span>" % (col, self._left_text(left)),
                     "",
                     "<span style='color:#9a95b4'>만료되면 자동매매가 멈춥니다. "
                     "관리자에게 연장을 요청하세요.<br>"
                     "[⚙️ 설정] 탭 → [📨 승인 요청] 을 누르면 관리자에게 전달됩니다.</span>"]
            self.log("⏳ 사용승인 만료 임박 — 만료 %s · %s" % (exp, self._left_text(left)))
            self._popup_notice("⏳ 사용승인 만료 임박", lines, tone="bad" if left <= 0 else "warn")
            self.tg("⏳ 사용승인 만료 임박\n만료일 %s (%s)\n\n만료되면 자동매매가 멈춥니다. "
                    "관리자에게 연장을 요청하세요." % (exp, self._left_text(left)))
        except Exception:
            pass

    def _check_autostart_task(self):
        """★아침 자동실행 예약작업이 없으면 알린다. (2026-09-18 실제 사고)

        설치 때 권한 창에서 [아니오] 를 누르면 JonggaClientRun 이 등록되지 않는데,
        설치는 성공한 것처럼 끝난다. 그러면 다음 날 08:20 에 **아무 일도 일어나지 않는다.**
        실제로 2026-09-18 아침에 그렇게 됐다 — 사람이 직접 켜야 했다.
        프로그램이 스스로 알아채는 편이 확실하다. 하루 한 번만 알린다."""
        try:
            if getattr(self, "_task_warn_day", "") == self._t(): return
            self._task_warn_day = self._t()
            if self._autostart_task_ok(): return
            self.log("⚠️ 아침 자동실행 예약작업(JonggaClientRun)이 없습니다 — 내일 08:20 에 스스로 켜지지 않습니다")
            self.log("   [2_프로그램설치.bat] 을 다시 실행하고 권한 창에서 반드시 [예] 를 누르세요")
            self._popup_notice("⚠️ 아침 자동실행이 없습니다", [
                "이 PC 에는 <b>아침 08:20 자동실행 예약작업이 없습니다.</b>",
                "내일 아침 프로그램이 <b>스스로 켜지지 않습니다.</b>",
                "",
                "<span style='color:#9a95b4'>설치할 때 권한 창에서 [아니오] 를 누르면 이렇게 됩니다.<br>"
                "고치는 법 — 설치 폴더의 <b>[2_프로그램설치.bat]</b> 을 다시 실행하고,<br>"
                "권한 창이 뜨면 반드시 <b>[예]</b> 를 누르세요.</span>",
                "",
                "<span style='color:#9a95b4'>그때까지는 아침에 바탕화면 아이콘을 직접 눌러 주세요.</span>"],
                tone="bad")
            self.tg("⚠️ 아침 자동실행 예약작업(JonggaClientRun)이 없습니다.\n"
                    "내일 08:20 에 프로그램이 스스로 켜지지 않습니다.\n"
                    "[2_프로그램설치.bat] 을 다시 실행하고 권한 창에서 [예] 를 누르세요.")
        except Exception:
            pass

    def _tick_unit(self, px):
        """KRX 호가단위(2023~) — _tick_round 와 같은 표."""
        px = int(px)
        for lim, t in [(2000, 1), (5000, 5), (20000, 10), (50000, 50), (200000, 100), (500000, 500)]:
            if px < lim: return t
        return 1000

    def _tick_below(self, px, n=AF_SELL_TICKS):
        """n 호가 아래 가격. ★애프터마켓에는 시장가가 없어 이것이 '즉시 체결' 수단이다."""
        px = int(px)
        for _ in range(max(1, int(n))):
            px = max(1, px - self._tick_unit(px))
        return max(1, self._tick_round(px))

    def _af_live_ok(self):
        """지금 애프터마켓 실주문을 내도 되는 상태인가 (_place_afterhours_tp 와 같은 판정)."""
        if not self.cfg.get("aftp_live") or self.cfg.get("is_mock"): return False
        try: srv = (self.kw.server_gubun() or "")
        except Exception: srv = ""
        srv_live = (srv == "0") if srv in ("0", "1") else getattr(self, "_srv_live", None)
        return srv_live is True          # ★판정불가(None)면 안 한다 — 모의에 실주문을 내지 않으려고

    def _af_now_px(self, code):
        """애프터마켓 현재가 — **실시간 우선**, 끊기면 조회로 받친다. (2026-09-18)

        ★state 의 aft_px 는 쓰지 않는다. 재기동하면 어제 값이 그대로 실려 와서
          멀쩡한 종목을 손절가 이하로 오판한다.
          _af_live 는 **메모리에만** 있으므로 재기동하면 비어 있다 — 그 사고가 구조적으로 없다.
        조회 받침은 종목당 AF_WATCH_SEC 간격으로만 — 키움 조회제한(분당 65)을 지킨다."""
        import time as _tm
        lv = (getattr(self, "_af_live", None) or {}).get(code)
        if lv and (_tm.time() - lv[1]) <= AF_FRESH_SEC:
            return int(lv[0])                       # 실시간으로 받은 값 — 조회 안 함
        seen = getattr(self, "_afp_ts", None)
        if seen is None: seen = self._afp_ts = {}
        if _tm.time() - seen.get(code, 0) < AF_WATCH_SEC:
            return 0                                # 방금 조회했다 — 다음 기회에
        seen[code] = _tm.time()
        try: return abs(int((self.kw.basic(code) or {}).get("현재가") or 0))
        except Exception: return 0

    def _watch_afterhours(self):
        """★애프터마켓(16:00~20:00) 손절·익절 감시. (2026-09-18 사용자 요청)

        왜 '손절가에 미리 지정가를 걸어 두기' 가 아닌가
          매도 지정가는 '이 값 **이상**이면 판다' 는 뜻이다. 손절가는 현재가보다 아래라
          걸어 두는 순간 현재가에 즉시 체결된다 — 손절 예약이 아니라 그냥 지금 손절이다.
          진짜 예약은 역지정가(스탑)인데 키움 OpenAPI 애프터마켓 지원이 미확인이다
          (개발가이드 2026-09-12 에서 거래구분 62 가 삭제됐다).
          그래서 프로그램이 보고 있다가 닿으면 판다. 20:20 까지 떠 있으니 가능하다.

        애프터마켓에는 시장가가 없다 → '몇 호가 아래 지정가' 가 시장가 대용이다.
          · 손절가 이하            → 걸어 둔 익절 주문을 그 값으로 **정정**(즉시 체결)
          · 익절가 이상인데 미체결  → 같은 방법으로 정정(호가를 건너뛰어 안 팔린 경우)
        ★취소+재주문이 아니라 정정(otype 6)을 쓴다. 취소가 접수되기 전에 일부가 체결되면
          재주문이 **이중매도**가 된다. 정정은 키움이 원주문 잔량 기준으로 처리해 그 사고가 없다.
        ★익절·손절 기준은 매수가 대비 **순수 등락률**이다 — 수수료를 섞지 않는다(정규장과 같음)."""
        try:
            if self._hm() >= AF_WATCH_END: return          # 20:00 에 주문이 소멸한다 — 그 전에 멈춘다
            if not self._af_live_ok(): return
            # ★실시간 틱마다 불려도 되게 최소간격만 둔다(폭주 방지).
            #   가격 자체는 _af_now_px 가 실시간 우선으로 주므로 반응이 2초 이내다.
            now = time.time()
            if now - getattr(self, "_afw_ts", 0) < AF_MIN_GAP: return
            self._afw_ts = now
            today = self._t(); acc = self.cfg["account"]
            tp_cfg = float(self.cfg.get("tp_pct", 6)); sl_cfg = -abs(float(self.cfg.get("sl_pct", -3.5)))
            hits = []
            for o in self.state.get("positions", []):
                if o.get("open_buy") or o.get("aftx_day") == today: continue   # 오늘 이미 처리한 건 건드리지 않는다
                rem = o.get("filled", 0) - o.get("sold", 0)
                base = o.get("avg") or o.get("price") or 0
                if rem <= 0 or base <= 0: continue
                px = self._af_now_px(o["code"])
                if px <= 0: continue
                o["aft_px"] = px; o["aft_ret"] = round((px / base - 1) * 100, 2)
                otp = st.UPPER_TP if o.get("unbuyable") else tp_cfg
                ret = (px / base - 1) * 100
                if ret <= sl_cfg: hits.append((o, rem, px, "손절", ret))
                elif ret >= otp: hits.append((o, rem, px, "익절", ret))
            if not hits:
                return
            pend = self.kw.pending(acc)          # ★조건이 걸렸을 때만 조회한다(평소엔 TR 을 안 쓴다)
            # ★★`None`(모름) 을 `[]`(없음) 으로 뭉개면 안 된다 (2026-09-29 수정).
            #   아래 for 문은 `smap` 에 없는 종목을 '걸어 둔 매도주문이 없다' 로 보고 **새 매도를 낸다.**
            #   16:00 에 걸어 둔 익절 지정가가 살아 있는데 **조회만 실패한** 경우가 정확히 그것이다
            #   → 같은 물량에 매도주문이 둘이 된다. 대개 키움 매도가능수량 검증에 걸려 거부되지만,
            #   `SendOrder` 는 **전송만 성공하면 0** 을 주므로 `rc == 0` 이 와서 `aftx_day` 가 찍힌다
            #   → **그날 그 종목의 애프터 손절이 통째로 빠진다.** 게다가 로그·텔레그램은
            #   '손절 완료' 로 거짓 보고한다(안 팔렸는데 팔렸다고 믿게 된다).
            #   원소에 문자열이 섞인 **오정렬 응답**도 '없음' 이 아니라 '모른다' 다(2026-09-22 실제 발생).
            #   → `_ensure_closeout` 과 **같은 방침**으로 맞춘다: 못 믿을 응답이면 주문을 내지 않고
            #     이 회차를 건너뛴다. 다음 감시(AF_MIN_GAP=2초)에 다시 본다 —
            #     손절이 최대 2초 늦는 대신 이중매도가 없다. 늦는 쪽이 낫다.
            #   ★`aftp_day == today`(내가 익절을 걸어 둔) 로 가르면 **안 된다** —
            #     `_place_afterhours_tp` 는 익절가가 상한가를 넘어 **주문을 못 낸** 경우에도
            #     `aftp_day` 를 찍는다. 그 종목은 살아있는 주문이 없어 신규발주가 유일한 탈출구인데
            #     그걸로 가르면 정작 그 종목을 건너뛰게 된다.
            if not isinstance(pend, list) or any(not isinstance(p, dict) for p in pend):
                if time.time() - getattr(self, "_afw_pendlog", 0) > 60:
                    self._afw_pendlog = time.time()
                    self.log("  🌙 애프터 감시 — 미체결 조회 실패/오정렬(모름): "
                             "이번 회차 발주 보류, 다음 감시에 재시도")
                return
            smap = {p.get("code"): p for p in pend
                    if "매도" in (p.get("gubun") or "") and int(p.get("unfilled") or 0) > 0}
            for o, rem, px, why, ret in hits:
                sell_px = self._tick_below(px)               # 즉시 체결용(시장가 대용)
                p = smap.get(o["code"])
                if p:                                         # 걸어 둔 익절 주문을 낮은 값으로 정정
                    uq = int(p.get("unfilled") or 0) or rem
                    rc = self.kw.modify_sell(acc, o["code"], uq, sell_px, p.get("order_no", ""))
                    how = "정정"
                else:                                         # 주문이 없다(가격제한·발주실패) → 새로 건다
                    uq = rem
                    rc = self.kw.send_order(acc, o["code"], uq, sell_px, 2, "00")
                    how = "신규"
                if rc == 0:
                    o["aftx_day"] = today; o["aftp_px"] = sell_px; o["aftp_qty"] = uq
                    self.log(f"  🌙 애프터 {why} {o['name']} {uq}주 @{sell_px:,}"
                             f"({how}·현재 {px:,}·{ret:+.2f}%)")
                    self.tg(f"🌙 애프터마켓 {why} — {o['name']} {uq}주 @{sell_px:,}\n"
                            f"현재가 {px:,} ({ret:+.2f}%)\n"
                            f"애프터에는 시장가가 없어 {AF_SELL_TICKS}호가 아래 지정가로 냈습니다(즉시체결).")
                else:
                    self.log(f"  ⚠️ 애프터 {why} 발주 실패 {o['name']}(rc={rc}) — 다음 감시에 재시도")
                self.wait(300)
            savej(STATE, self.state)
        except Exception as e:
            self.log(f"애프터마켓 감시 오류 {e}")

    def _refresh_balance(self, force=False):
        """★계좌 잔고만 다시 읽는다 — 화면 실시간 표시용. (2026-09-17)

        query_account() 와 다른 점: **조회만 한다.** _adopt_holdings 를 부르지 않는다.
        그건 하루 몇 번만 돌아야 하고, 자주 돌리면 같은 종목을 다시 채택해 원장이 부풀어진다
        (2026-09-11 관리자에서 실제로 터진 사고).

        실패해도 self.acct 를 비우지 않는다 — 화면이 '조회 실패'로 깜빡이면 더 헷갈린다.
        대신 stale=True 로 '언제 기준인지'를 화면이 말하게 한다."""
        if not getattr(self, "connected", False) or not self.cfg.get("account"): return
        now = time.time()
        if not force:
            if now - getattr(self, "_bal_ts", 0) < BALANCE_SEC: return
            if BALANCE_SKIP[0] <= self._hm() < BALANCE_SKIP[1]: return
        self._bal_ts = now
        try:
            acc = self.cfg["account"]
            # ★holdings/deposit 은 **실패하면 None, 성공하면 dict** 를 준다.
            #   예전엔 그 반환을 `or {}` / `hold = {}` 로 뭉개 **구분을 지워 버렸다.**
            #   그래서 '입금 전 빈 계좌'(조회 성공·잔고 0)가 '조회 실패' 로 표시됐고,
            #   화면이 "계좌비밀번호를 확인하세요" 라고 말해 멀쩡한 비밀번호를
            #   몇 번이나 다시 등록하게 만들었다(2026-09-18 실제 신고). 구분을 되살린다.
            _h = self.kw.holdings(acc)
            # ★매수 여력의 천장 = **추정예탁자산**(2026-09-28). 반드시 opw00018 순수값만 넘긴다 —
            #   아래 `assets` 는 조회 실패 때 예수금으로 대체되므로 그걸 넘기면
            #   '인출 기준으로 매수를 깎던' 버그가 되살아난다. 없으면 천장 없음(깎지 않는다).
            _d = self.kw.deposit(acc, ceiling=(_h.get("assets") if isinstance(_h, dict) else None))
            ok = isinstance(_h, dict) and isinstance(_d, dict)
            hold = _h if isinstance(_h, dict) else {}
            dep = _d if isinstance(_d, dict) else {}
            if not ok:                                        # ★진짜 조회 실패 — 옛 값 유지하고 낡음만 표시
                if getattr(self, "_bal0_day", "") != self._t():
                    self._bal0_day = self._t()
                    self.log("⚠️ 계좌 조회가 되지 않습니다 — 계좌 %s" % (acc or "(없음)"))
                    _m = self._kw_last_msg()
                    if _m: self.log("   키움 응답: %s" % _m)
                    self.log("   → 설정 탭 [🔒 계좌비밀번호 등록] → 비밀번호 → AUTO 체크 → [등록] 을 확인하세요")
                if isinstance(getattr(self, "acct", None), dict) and self.acct: self.acct["stale"] = True
                return
            # ★★종목목록이 성하지 않으면 이번 회차를 건너뛴다 — `query_account` 와 **같은 방침**이다
            #   (클라이언트는 걸러내면 안 된다. `_adopt_holdings` 의 '정리' 가 그 종목을
            #    팔린 것으로 오정리해 보유가 사라진다. 2026-09-28 이식).
            _stk2 = hold.get("stocks")
            if not isinstance(_stk2, list) or any(not isinstance(s, dict) for s in _stk2):
                self.log("⚠️ 잔고 응답이 성하지 않습니다 — 이번 회차 잔고 갱신을 건너뜁니다")
                if isinstance(getattr(self, "acct", None), dict) and self.acct: self.acct["stale"] = True
                return
            # ★★이 dict 가 `self.acct` 를 **통째로 덮는다**(아래 `self.acct = got`).
            #   그래서 `query_account` 가 담아 둔 키가 여기 없으면 조용히 지워진다.
            #   2026-09-28 관리자에서 실제로 당했다 — `orderable_src`·`withdrawable` 이 빠져 있어
            #   화면의 매수여력 근거가 빈칸·출금가능 0 으로 떨어졌고 진단을 망쳤다.
            #   ★`query_account` 의 acct 키를 늘릴 때는 **여기도 같이** 늘려야 한다.
            got = {"assets": hold.get("assets") or dep.get("cash") or 0,
                   "assets_real": int(hold.get("assets") or 0),
                   "total_ret": hold.get("total_ret", 0.0), "cash": dep.get("cash", 0),
                   "stocks": _stk2, "orderable": dep.get("orderable", 0),
                   "orderable_src": dep.get("orderable_src", ""),
                   "orderable_uncapped": int(dep.get("orderable_uncapped") or 0),
                   "withdrawable": dep.get("withdrawable", 0),
                   "total_buy": hold.get("total_buy", 0), "total_eval": hold.get("total_eval", 0),
                   "total_pl": hold.get("total_pl", 0), "asof": self._hm(), "stale": False}
            self.acct = got                                   # ★조회 성공 — 잔고 0 도 '사실' 이니 그대로 반영한다
            if not (got["assets"] or got["cash"]):
                if getattr(self, "_bal0_day", "") != self._t():
                    self._bal0_day = self._t()
                    self.log("ℹ️ 조회 정상 · 계좌 %s 의 잔고가 0 입니다 (입금 전이면 정상입니다)" % acc)
                    _m = self._kw_last_msg()
                    if _m: self.log("   키움 응답: %s" % _m)
                return                                        # ★시작자산에 0 을 박으면 안 된다
            self._capture_live_start(got)                     # ★실전 시작자산(아직 없으면) 한 번 기록
        except Exception:
            if isinstance(getattr(self, "acct", None), dict) and self.acct: self.acct["stale"] = True

    def query_account(self):
        try:
            acc = self.cfg["account"]
            hold = self.kw.holdings(acc)
            # ★조회 실패(None)와 '보유 없음'({stocks:[]})은 전혀 다르다. (2026-09-17 감사)
            #   예전엔 `or {}` 로 뭉뚱그려 실패를 '보유 없음'으로 읽었고,
            #   그러면 _adopt_holdings 의 '정리' 가 보유 전부를 sold 처리해 손절이 끊겼다.
            if not isinstance(hold, dict):
                self.log("⚠️ 잔고 조회 실패 — 이번 회차 계좌 동기화를 건너뜁니다(보유 오정리 방지)")
                return
            # ★천장은 **순수 opw00018 추정예탁자산**만 (2026-09-28). 위에서 hold 가 dict 임이 확인됐다.
            dep = self.kw.deposit(acc, ceiling=hold.get("assets")) or {}
            if not isinstance(dep, dict): dep = {}
            # ★★종목목록이 성한지 **들어오는 자리에서** 본다 (2026-09-23 관리자 실사고 이식).
            #   키움 TR 은 응답이 오정렬돼 원소에 **문자열이 섞여** 오는 일이 있다.
            #   그대로 흘리면 뒤에서 `s.get(...)` 이 터져 이 함수가 예외로 끝나고
            #   **채택·계좌동기화가 통째로 멈춘다**(관리자에서 이틀에 걸쳐 두 번 났다.
            #   `'str' object has no attribute 'get'` · 조용히 멈춰서 알아채기 어려웠다).
            #   ★관리자는 걸러내고 진행했지만 **클라이언트는 그러면 안 된다** —
            #     아래 `_adopt_holdings` 에 '실계좌에 없으면 sold 처리' 하는 정리 단계가 있어서,
            #     원소 하나를 버리면 그 종목을 **팔린 것으로 오정리**한다. 보유가 사라진다.
            #   → 하나라도 성하지 않으면 이번 회차를 **건너뛴다**(조회 실패와 같은 취급).
            _stk = hold.get("stocks")
            if not isinstance(_stk, list) or any(not isinstance(s, dict) for s in _stk):
                self.log("⚠️ 잔고 응답이 성하지 않습니다 — 이번 회차 계좌 동기화를 건너뜁니다(보유 오정리 방지)")
                return
            assets = hold.get("assets") or dep.get("cash") or 0
            # ★관리자와 같은 항목을 채운다(2026-09-18).
            #   예전엔 assets/cash/stocks/total_ret 네 개뿐이었다. 계좌 카드는
            #   orderable·total_eval·total_buy·total_pl·asof 를 읽는데 전부 0 이 되고,
            #   `not orderable and not assets` 에 걸려 "계좌비밀번호 AUTO 등록을 확인하세요" 가 떴다.
            #   **비밀번호는 멀쩡한데** 그렇게 보였다(실제 신고).
            self.acct = {"assets": assets, "total_ret": hold.get("total_ret", 0.0),
                         # ★`assets` 는 조회 실패 때 예수금으로 **대체되는** 값이다(위 or 체인).
                         #   매수 여력의 천장으로 쓸 값은 **순수 opw00018 추정예탁자산**이라 따로 담는다.
                         #   없으면 0 이고, 0 이면 천장을 안 씌운다(2026-09-28).
                         "assets_real": int(hold.get("assets") or 0),
                         "cash": dep.get("cash", 0), "stocks": hold.get("stocks", []),
                         "orderable": dep.get("orderable", 0),
                         "orderable_src": dep.get("orderable_src", ""),
                         "orderable_uncapped": int(dep.get("orderable_uncapped") or 0),
                         "withdrawable": dep.get("withdrawable", 0),
                         "total_buy": hold.get("total_buy", 0), "total_eval": hold.get("total_eval", 0),
                         "total_pl": hold.get("total_pl", 0), "asof": self._hm(), "stale": False}
            self._adopt_holdings()   # ★실계좌 조회 기준 동기화 — 보유중=실계좌(채택/정리)
            self._audit_ledger_vs_account()   # ★원장이 '팔았다'는데 실계좌에 남아있는지 대조(가짜 수익률 차단)
        except Exception as e:
            self.log(f"계좌조회 오류 {e}")

    def _audit_ledger_vs_account(self):
        """★원장이 '팔았다'고 적은 종목이 **실계좌에 그대로 남아 있는지** 대조한다
        (2026-09-28 · 관리자 2026-09-22 분 이식).

        왜 — `_force_sell` 은 발주 직후 `sold=filled` 로 마킹하고 원장에 쓴다(기록 누락 방지).
        `_verify_sells()` 가 검증하지만 **`sell_pending` 이 붙은 포지션만** 본다.
        포지션이 state 에서 빠지면 **아무도 안 본다** → 팔리지도 않은 거래가 원장에 남아
        누적수익률·MDD·전략자산(=사이징 기준)을 전부 오염시킨다.

        판정은 보수적으로
          · 잔고 조회가 성공했을 때만 본다(실패를 '없음'으로 보면 정상 기록을 지운다).
          · 오늘 매도기록의 수량이 **실잔고에 고스란히 남아 있을 때만** 되돌린다(부분체결은 경고만).
          · **오늘 새로 산 종목은 제외한다** — 청산 뒤 같은 종목을 사면 잔고에 있는 게 정상이다."""
        a = getattr(self, "acct", None)
        if not isinstance(a, dict) or a.get("stale"): return
        stocks = a.get("stocks")
        if not isinstance(stocks, list): return                   # 조회 실패 → 손대지 않는다
        held = {}
        for x in stocks:
            if not isinstance(x, dict): return                    # 응답이 성하지 않다 → 판단 보류
            c = x.get("code")
            if c: held[c] = held.get(c, 0) + int(x.get("qty") or 0)
        today = self._t()
        _open = {o.get("code") for o in self.state.get("positions", [])
                 if (o.get("filled", 0) - o.get("sold", 0)) > 0}
        bad = []
        for rec in self.state.get("trades", []):
            if rec.get("date") != today: continue
            code = rec.get("code"); q = int(rec.get("qty") or 0)
            if not code or q <= 0 or code in _open: continue
            h = int(held.get(code, 0) or 0)
            if h <= 0: continue                                   # 정상 — 다 팔렸다
            if h >= q: bad.append((rec, h, q))                    # 전량 그대로 남아있다 = 안 팔렸다
            else:
                _k = f"{code}:{today}:부분"
                if _k not in getattr(self, "_audit_warned", set()):
                    if not hasattr(self, "_audit_warned"): self._audit_warned = set()
                    self._audit_warned.add(_k)
                    self.log(f"  ⚠️ 원장↔잔고 부분 불일치 {rec.get('name')} — 기록 {q}주 매도인데 잔고 {h}주 남음(확인 필요)")
                    self.tg(f"⚠️ 거래기록 확인 필요 — {rec.get('name')}\n"
                            f"원장은 {q}주 매도인데 실계좌에 {h}주가 남아 있습니다(부분체결 추정).\n"
                            f"자동으로 고치지 않았습니다 — 키움에서 직접 확인하세요.")
        if not bad: return
        for rec, h, q in bad:
            code = rec.get("code"); nm = rec.get("name")
            self.state["trades"] = [r for r in self.state.get("trades", [])
                                    if not (r.get("date") == today and r.get("code") == code
                                            and r.get("sell_time") == rec.get("sell_time"))]
            _p = next((o for o in self.state.get("positions", []) if o.get("code") == code), None)
            if _p is None:
                _p = {"code": code, "name": nm, "qty": h, "price": rec.get("buy") or 0,
                      "avg": rec.get("buy") or 0, "filled": h, "sold": 0, "unbuyable": False}
                self.state.setdefault("positions", []).append(_p)
            else:
                _p["filled"] = h; _p["sold"] = 0
            _p.pop("sell_pending", None); _p.pop("tp_placed", None); _p.pop("tp_ord", None)
            # ★살아있는 매도주문이 없음을 **확인했으면 잠그지 않는다** — 잠그면 그 종목은
            #   오늘 밤 애프터 손익절 보호를 못 받는다. 모르면(조회 실패) 잠근다 = 보수적.
            try: _pd = self.kw.pending(self.cfg["account"])
            except Exception: _pd = None
            _live = ({p.get("code") for p in _pd if isinstance(p, dict)
                      and "매도" in (p.get("gubun") or "")} if isinstance(_pd, list) else None)
            if _live is None or code in _live:
                _p["sell_stuck"] = True
            self.log(f"  🛑 가짜 매도기록 삭제 {nm} — 원장은 {q}주 매도인데 실계좌에 {h}주 그대로 있습니다"
                     f" → 기록 취소 · 보유 복원")
            self.tg(f"🛑 거래기록을 바로잡았습니다 — {nm}\n"
                    f"원장에 '{q}주 매도'로 적혀 있었지만 실계좌에는 {h}주가 그대로 있습니다.\n"
                    f"(발주는 됐지만 체결되지 않았습니다)\n\n"
                    f"· 그 매도기록을 지웠습니다 — 누적수익률이 사실대로 돌아옵니다\n"
                    f"· 보유로 되살렸습니다 · 다음 거래일 아침에 정상 관리로 돌아갑니다")
        savej(STATE, self.state)
        try: self.refresh()
        except Exception: pass

    def _aftp_reconcile(self):
        """★전날 애프터마켓(16~20시) 익절이 체결됐는지 아침에 확인해 원장에 남긴다. (2026-09-17)

        예전엔 17:00 에 매매를 멈춰 그 뒤 체결을 제때 못 봤다(2026-09-17 부터 20:05).
        그래도 이 복구는 남겨 둔다 — PC 절전·종료로 저녁에 꺼져 있었을 수 있다.
        그냥 두면 돈은 들어왔는데 원장에 없어 전략자산(=사이징 기준)이 계속 어긋나고,
        관리자 쪽은 판 종목이 유령으로 남아 다음날 유령 청산주문을 낸다.

        계좌에서 사라졌으면 = 팔린 것이다. 체결가는 밤새 켜져 있었으면 키움 체결통보에 실값이 있고,
        없으면 지정가(aftp_px)로 적는다 — 매도 지정가는 그 가격 이상에서 체결되므로 보수적이다.
        부분체결은 기록하지 않는다(_record 가 수량을 포지션 전량으로 쓰기 때문)."""
        if not getattr(self, "connected", False): return
        today = self._t()
        if getattr(self, "_aftp_rec_date", "") == today: return
        acct = getattr(self, "acct", None)
        if not isinstance(acct, dict) or "stocks" not in acct: return    # 계좌조회 전 — 다음 틱에 다시
        # ★★잔고 스냅샷이 믿을 만하지 않으면 **판단을 보류**한다 (2026-10-01 · 관리자 09-30 실사고 이식).
        #   관리자에서 로그인 직후 opw00018 이 **통째로 빈 응답**(추정예탁자산 0 · 평가 0 · 종목목록 [])을 줬다.
        #   아래 `left = 0 < rem` 이 그걸 "계좌에서 사라졌다 = 전날 애프터에서 팔렸다" 로 읽었다.
        #     08:30:41  🌙 애프터마켓 익절 체결 확인 한켐 110주 @12,370 (+7.29%) — 원장 기록   <- 거짓
        #     09:23:40  ⚡실시간손절 한켐 -3.56%                                                <- 실제
        #   거짓 '+7.29% 익절' 텔레그램이 나갔고, 원장은 `_audit_ledger_vs_account` 가 되돌렸다(운이 좋았다).
        #   ★클라이언트 `query_account` 는 '성하지 않은 목록' 만 건너뛴다. 빈 목록 + 추정예탁자산 0 은
        #     그대로 통과해 여기까지 온다(opw00018 파서가 관리자와 같다).
        #   ★진짜 '보유 없음' 과 반드시 가른다 — 이 함수가 존재하는 이유가 바로 그 경우다.
        #     진짜 보유 없음(애프터에서 다 팔림) : 목록 [] · 평가 0 · **추정예탁자산 > 0** (매도대금이 D+2 로 잡힌다)
        #     빈 응답(사고)                     : 목록 [] · 평가 0 · **추정예탁자산 0**
        #     예수금만 있는 계좌도 추정예탁자산은 0 이 아니다(관리자 실측 09-30 보유 0 · 2,706,677).
        #   ★`stale`(잔고 갱신 실패로 옛 목록을 들고 있음)도 보류한다. `stocks_stale` 은 관리자 판정식과
        #     맞추려고 **읽기만** 한다 — 클라이언트는 목록을 이어받지 않고 회차를 건너뛰므로 빌더에 없다.
        #   ★`_aftp_rec_date` 를 찍기 **전에** 돌아간다 → 다음 계좌조회(09:01·15:18·15:31)에서 다시 본다.
        #   ★계좌가 정말 0원이면(입금 전·전액 출금) 그날은 끝까지 보류다. 그래도 된다 —
        #     전날 애프터에서 실제로 팔렸다면 그 매도대금이 추정예탁자산에 잡혀 0 일 수 없다
        #     (출금은 D+2 라 하룻밤 사이에 빠져나갈 수도 없다). 0원인데 보유를 주장하는 장부는 장부가 틀린 것이고,
        #     그걸 '익절' 로 적는 게 더 나쁘다. 로그는 대상 포지션이 있을 때만 **하루 한 번** 남긴다.
        #   ★판정은 모듈 `_acct_snapshot_doubt` 한 곳에서 한다(관리자와 같은 식 · 2026-10-01 검증 때 옮김).
        #     처음 이식본은 '목록 [] 인데 주식평가·총매입 > 0'(불완전 조회)을 빠뜨려서, 그 응답이 오면
        #     여전히 거짓 '애프터 익절' 을 적었다(하니스 ④ — 관리자는 보류, 클라이언트는 기록).
        _why = _acct_snapshot_doubt(acct)
        if _why:
            _wait = [str(o.get("name") or o.get("code")) for o in self.state.get("positions", [])
                     if o.get("aftp_px") and not o.get("aftp_recorded") and o.get("aftp_day") != today
                     and (o.get("filled", 0) - o.get("sold", 0)) > 0]
            if _wait and getattr(self, "_aftp_hold_day", "") != today:
                self._aftp_hold_day = today
                self.log(f"⏸ 전일 애프터 대조 보류 — 잔고 스냅샷을 믿을 수 없습니다({_why})"
                         f" · 대상 {', '.join(_wait)} · 다음 계좌조회에서 다시 봅니다")
            return
        if getattr(self, "_aftp_hold_day", "") == today:
            self.log("✅ 잔고 스냅샷 정상 — 보류했던 전일 애프터 대조를 이제 진행합니다")
        self._aftp_rec_date = today
        real = {s.get("code"): int(s.get("qty") or 0) for s in (acct.get("stocks") or [])
                if isinstance(s, dict)}
        # ★★'계좌에서 사라졌다' 를 **전일 애프터 체결로 단정하면 안 된다** (2026-09-23 관리자 실사고).
        #   오늘 장에서 팔려도 계좌에서 사라진다. 당일매매일지에 오늘 매도가 있으면 **오늘 건**이다.
        #   관리자에서 삼미금속이 오늘 아침 12,550(-6.20%)에 팔렸는데
        #   `애프터마켓 익절 @14,350(+7.25%)` 로 기록됐다. 가격은 뒤늦게 고쳐졌지만
        #   **이유가 '익절' 로 남아** 리서치가 손실을 익절로 셌다.
        #   오늘 매도는 `_sync_account_ledger` 가 당일매매일지 실체결가로 제대로 기록한다.
        _sold_today = set()
        try:
            for r in (self.kw.today_journal(self.cfg.get("account", "")) or []):
                if isinstance(r, dict) and r.get("sell_amt") and r.get("code"):
                    _sold_today.add(r["code"])
        except Exception as e:
            self.log(f"애프터 대조용 당일매매일지 조회 실패 — 전일 애프터 기록 보류 {e}")
            self._aftp_rec_date = ""      # ★모르면 기록하지 않고 다음 틱에 다시 본다
            return
        changed = False
        for o in self.state.get("positions", []):
            if o.get("code") in _sold_today:                             # ★오늘 팔린 것 — 여기 소관이 아니다
                self.log(f"  🌙 {o.get('name')} 은 **오늘** 매도됐습니다 — 전일 애프터 체결로 기록하지 않습니다")
                continue
            if not o.get("aftp_px") or o.get("aftp_recorded"): continue
            if o.get("aftp_day") == today: continue                      # 오늘 건 아직 진행 중
            rem = o.get("filled", 0) - o.get("sold", 0)
            if rem <= 0: continue
            left = real.get(o.get("code"), 0)
            if left >= rem: continue                                     # 그대로 있다 = 안 팔렸다
            base = o.get("avg") or o.get("price") or 0
            fp = 0
            for f in reversed(getattr(self.kw, "fills", []) or []):      # 밤새 켜져 있었으면 실체결가가 있다
                if f.get("code") == o.get("code") and "매도" in (f.get("otype", "") or "") \
                        and (f.get("fill_price") or 0) > 0:
                    fp = f["fill_price"]; break
            fp = fp or o["aftp_px"]
            ret = round((fp / base - 1) * 100, 2) if base else 0.0
            if left > 0:                                                 # ★부분체결 — 기록하지 않는다(원장이 부풀어진다)
                o["sold"] = o.get("sold", 0) + (rem - left); changed = True
                self.log(f"⚠️ 애프터마켓 부분체결 {o.get('name')} {rem - left}/{rem}주 — 잔량만 맞췄습니다(원장 직접 확인)")
                try: self.tg(f"⚠️ 애프터마켓 부분체결 {o.get('name')} {rem - left}/{rem}주 — 원장 확인 필요")
                except Exception: pass
                continue
            o["sold"] = o.get("filled", 0); o["exit_ret"] = ret; o["aftp_recorded"] = True
            self._rec(o, ret, "애프터마켓 익절(전일 체결)")
            changed = True
            self.log(f"🌙 애프터마켓 익절 체결 확인 {o.get('name')} {rem}주 @{fp:,} ({ret:+.2f}%) — 원장 기록")
            try: self.tg(f"🌙 애프터마켓 익절 체결 {o.get('name')} {ret:+.2f}% (전일 16~20시)")
            except Exception: pass
        if changed: savej(STATE, self.state)

    def _routine_hm(self):
        """★지금 모드의 매수 루틴 시각 — (매수, 정정, 보정, 마감). (2026-09-17)

        실계좌 : 애프터마켓 종가(20:00) 기준. 19:55 / 19:58 / 20:01 / 20:05
        모의   : 애프터마켓이 열리지 않으므로 정규장 그대로. 15:25 / 15:28 / 15:31 / 15:35

        ★강제청산(15:19)과 손익절 감시(09:00~15:19)는 모드와 무관하게 그대로다."""
        if EVENING_ROUTINE and not self.cfg.get("is_mock", True):
            return AF_BUY_HM, AF_CONVERT_HM, AF_RECON_HM, AF_DONE_HM
        return BUY_HM, CONVERT_HM, RECON_HM, DONE_HM

    def _is_af_routine(self):
        """저녁(애프터마켓) 매수 루틴을 쓰는가 — 원복(2026-09-17) 이후로는 항상 False."""
        return bool(EVENING_ROUTINE) and not self.cfg.get("is_mock", True)

    def _adopt_holdings(self):
        """★실계좌 조회 기준 보유 동기화 — 실보유는 채택(손익절 관리 편입), 실계좌에 없는 '허위 보유'는 정리.
        보유중 표시·관리 모두 실계좌와 일치(어제 버그 같은 불일치 방지). 매수/체결 진행중(15:20~15:35)엔 미체결 지정가 오정리 방지로 '정리' 보류."""
        self._aftp_reconcile()   # ★전날 애프터마켓 체결을 먼저 원장에 반영(정리·채택보다 앞)
        if not getattr(self, "connected", False): return
        real = {s.get("code"): s for s in (self.acct or {}).get("stocks", []) if s.get("qty", 0) > 0}
        pos = self.state.setdefault("positions", [])
        changed = False
        settling = ("15:20" <= self._hm() < "15:35")   # 매수·시장가전환·체결보정 진행중 → 정리 보류(오정리 방지)
        # 1) 정리: state는 '보유중'인데 실계좌엔 없음 → 보유 0 처리(실계좌에 없는 종목 표시/관리/기록 금지)
        # ★★잔고 스냅샷을 못 믿으면 **정리하지 않는다** (2026-10-01 · 관리자 09-30 빈 응답 사고의 클라이언트 쪽 구멍).
        #   정리는 원장 기록 없이 `sold=filled` 로 **조용히** 지운다. 빈 응답(목록 [] · 추정예탁자산 0)이 오면
        #   실제로 들고 있는 종목이 전부 지워지고, 채택은 `code in have` 라 되살리지 않고, 원장에 기록이 없으니
        #   `_audit_ledger_vs_account` 도 복원하지 못한다 → **그날 손절도 15:19 청산도 안 나간다.**
        #   ★`_aftp_reconcile` 에 보류만 넣고 이걸 안 막으면 오히려 나빠진다(검증 하니스로 확인):
        #     예전엔 거짓 '애프터 익절' 기록이 남아 09:01 `_audit` 이 그걸 보고 보유를 되살렸는데,
        #     보류로 기록이 안 생기니 되살릴 근거까지 사라졌다. 진짜 애프터 매도도 정리가 먼저 지워 버려
        #     다음 정상 응답에서 기록되지 않았다(하니스 ⑧).
        #   ★판정은 `_aftp_reconcile` 과 **같은 함수**(`_acct_snapshot_doubt`)다 — 진짜 '보유 없음'
        #     (추정예탁자산 > 0)은 예전처럼 정리한다. 15:18 조회가 빈 응답이어도 15:19 청산이 살아남는다.
        _doubt = _acct_snapshot_doubt(self.acct)
        if not settling and _doubt:
            _keep = [f"{o.get('name') or o.get('code')} {o.get('filled', 0) - o.get('sold', 0)}주" for o in pos
                     if (o.get("filled", 0) - o.get("sold", 0) > 0) and o.get("code") not in real]
            if _keep and getattr(self, "_jr_hold_day", "") != self._t():
                self._jr_hold_day = self._t()
                self.log(f"⏸ 보유 정리 보류 — {_doubt} · {', '.join(_keep)} 를 팔린 것으로 지우지 않습니다"
                         f"(다음 계좌조회에서 다시 봅니다)")
        if not settling and not _doubt:
            for o in pos:
                if (o.get("filled", 0) - o.get("sold", 0) > 0) and o.get("code") not in real:
                    o["sold"] = o.get("filled", 0); changed = True
        # 1.5) 수량 갱신: 이미 들고 있는 종목의 **수량이 늘어난 것**도 따라간다 (2026-09-22 관리자분 이식)
        #   왜 — 아래 '채택' 은 `code in have` 면 통째로 건너뛴다. 그래서 영웅문에서 추가매수하면
        #   장부가 옛 수량에 멈춘다. 관리자에서 70주 → 338주가 됐는데 장부는 70주였고,
        #   그대로면 15:19 청산이 **70주만 팔고 268주가 계좌에 남는다.**
        #   ★늘어난 경우만 반영한다. **줄어든 건 건드리지 않는다** — 매도 진행 중(체결 지연)일 수 있고
        #     그건 위 '정리' 와 `_verify_sells` 가 판단할 몫이다. 여기서 줄이면 장치들이 같은 값을 다툰다.
        _grew = []
        for o in pos:
            s = real.get(o.get("code"))
            if not s: continue
            _rem = o.get("filled", 0) - o.get("sold", 0)
            _real = int(s.get("qty") or 0)
            if _real > _rem > 0:
                o["filled"] = o.get("sold", 0) + _real      # 잔량이 실계좌와 같아지게
                o["qty"] = _real
                _b = int(s.get("buy") or 0)
                if _b > 0: o["avg"] = _b; o["price"] = o.get("price") or _b
                _grew.append(f"{o.get('name')} +{_real - _rem}주(→{_real}주 · 평단 {o.get('avg'):,})")
                changed = True
        if _grew:
            self.log("📥 보유수량 갱신(계좌 기준) — " + ", ".join(_grew))
            try:
                self.tg("📥 보유수량을 계좌에 맞췄습니다\n" + "\n".join(_grew)
                        + "\n손익절·종가청산이 이 수량으로 나갑니다.")
            except Exception: pass
        # 2) 채택: 실계좌 보유인데 state에 '보유중' 없음 → 편입(실수량·매입가 반영·손익절 관리)
        # ★중복채택 방지(2026-09-14 · 관리자 2026-09-11 수정분 이식)
        #   예전엔 '잔량>0'인 포지션만 have 에 넣었다. 그래서 매도 직후(sold=filled, 잔량 0)
        #   계좌 반영이 늦으면 같은 종목을 '모르는 보유'로 오인해 다시 편입 → 또 매도 → 원장 중복기록.
        #   관리자에서 실제로 실현손익이 4배로 부풀었던 버그다.
        #   → 잔량과 무관하게 **오늘 한 번이라도 다룬 종목은 다시 채택하지 않는다.**
        have = {o["code"] for o in pos}
        _today = self._t()
        have |= {t.get("code") for t in (self.state.get("trades") or []) if t.get("date") == _today}
        for code, s in real.items():
            if code in have: continue
            buy = s.get("buy") or s.get("cur") or 0
            # ★정규장 밖(애프터마켓·장전)에는 cur_px/cur_ret 를 넣지 않는다. (2026-09-17 감사)
            #   밤 시세가 STATE 에 남으면 다음날 09:00 첫 틱이 그걸 '오늘 값'으로 읽어
            #   하이브 계좌청산이 거짓으로 터진다(버그기록.md 에 있는 그 사고).
            #   OP_END 를 20:05 로 늘리면서 저녁에 _adopt_holdings 가 돌 수 있게 돼 새로 열린 구멍이다.
            _reg = (MANAGE_OPEN <= self._hm() < REG_END)
            _o = {"code": code, "name": s.get("name", code), "qty": s["qty"], "price": buy, "avg": buy,
                  "filled": s["qty"], "sold": 0, "unbuyable": False, "adopted": True}
            if _reg:
                _o["cur_ret"] = s.get("ret", 0.0); _o["cur_px"] = s.get("cur")
            else:
                _o["aft_ret"] = s.get("ret", 0.0); _o["aft_px"] = s.get("cur")
            pos.append(_o)
            changed = True
        if changed:
            if not self.state.get("buy_date"): self.state["buy_date"] = self._t()
            savej(STATE, self.state); self._ensure_real(force=True)
            self.log("📥 실계좌 동기화 — 보유중=실계좌(채택/정리)")

    def fetch_picks(self):
        try:
            url = PICKS_URL + ("&" if "?" in PICKS_URL else "?") + "nc=" + datetime.datetime.now().strftime("%H%M%S")  # ★캐시무효화(최신 픽)
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0", "Cache-Control": "no-cache"})
            return json.loads(urllib.request.urlopen(req, timeout=10).read().decode())
        except Exception as e: self.log(f"픽 로드 실패 {e}"); return None

    def _strategy_equity(self):
        """★전략 자산(복리) = 원금 + 누적 실현손익(수수료 반영) — 관리자와 동일. af=자산÷종목당."""
        _mk = bool(self.cfg.get("is_mock", True))
        base = self._base_for("mock" if _mk else "acct")             # ★실전은 '실전 시작자산' 기준(2026-09-17)
        fee = float(self.cfg.get("fee_pct", 0.23)) / 100.0
        pnl = 0
        want = "모의" if _mk else "실전"                              # ★지금 모드의 거래만 센다(2026-09-15)
        for t in self.state.get("trades", []):
            # ★기본값을 주지 않는다 — 관리자 `t.get("mode")` 와 같아야 한다(2026-09-30).
            #   예전엔 `t.get("mode", "모의")` 로 **mode 없는 옛 기록을 모의로 세었다.**
            #   실전(want="실전")에서는 어차피 안 맞아 실제 돈에는 영향이 0 이었지만,
            #   모의 전략자산이 관리자와 갈려 `프로그램_대조점검` 이 잡아야 할 불일치로 남았다.
            #   (레거시 mode=None = 옛 시스템 기록 → 지금 모드의 성적이 아니다 → 센다는 게 틀렸다)
            if t.get("mode") != want: continue                       # 모의 성적을 실전 자산으로 이월하지 않는다
            pnl += (t.get("pl") or 0) - round((t.get("buy") or 0) * (t.get("qty") or 0) * fee)   # 왕복 수수료 차감
        # ★'최소 1종목치' 바닥 — 실전에서는 실제 계좌보다 위로 올리지 않는다(2026-09-17).
        #   계좌에 100만뿐인데 전략자산이 200만으로 떠서 화면이 허구가 됐다는 지적.
        #   _size() 가 usable=max(0,·) 와 자산연동 하한으로 이미 0종목을 막으므로 바닥이 없어도 된다.
        #   조회가 안 돼 계좌 자산을 모르면(0) 예전 그대로 둔다 — 모르면서 낮추지 않는다.
        #   매수 자체는 buy_close 의 min(전략자산, 주문가능금액) 이 정하므로 주문은 안 바뀐다.
        # ★기본값 2,000,000 — 관리자와 같은 숫자다(2026-09-30 통일).
        #   여기는 2,500,000 · 관리자는 1,500,000 이었다. 설정에 invest_per_stock 이 늘 있어서
        #   실사용에선 안 물리지만, 설정이 비면 양쪽 전략자산 바닥이 100만 원 갈리는 잠복 불일치였다.
        floor = int(self.cfg.get("invest_per_stock", 2000000))
        if not self.cfg.get("is_mock", True):
            _real = int((getattr(self, "acct", None) or {}).get("assets")
                        or (getattr(self, "acct", None) or {}).get("cash") or 0)
            if _real > 0: floor = min(floor, _real)
        return max(floor, base + pnl)

    def buy_picks(self):
        """★관리자 buy_close와 100% 동일 — 15:25 지정가(@entry) 발주 → 15:28 미체결 시장가전환 → 15:31 실잔고 보정.
        유통≤70% 게이트 + 상한가 제외 후, 복리자산÷종목당=af, 매력도 상위 af만 매수, af 밖=⛔체결안됨(원금부족)."""
        if self.bought_today: return
        pj = self.fetch_picks()
        if not pj or not pj.get("stocks") or pj.get("date") != self._t():
            self.log("오늘 픽 아직 없음/불일치 — 다음 폴링에 재시도(마감 전까지)"); return
        self.bought_today = True; self.converted_today = False       # ★매수 개시(중복발주 방지·관리자 동일)
        picks = [s for s in pj["stocks"] if st.buy_filter(s, "전체")]
        picks.sort(key=lambda s: -(s.get("score") or -1))            # ★매력도 상위(상한가 포함)
        picks = self._float_filter(picks)                            # ★유통비율 ≤70% 게이트(관리자 동일)
        if self.cfg.get("exclude_upper", True):                      # ★상한가 제외(관리자 동일) — 비상한가로 슬롯 채움
            _nup = sum(1 for s in picks if s.get("unbuyable"))
            picks = [s for s in picks if not s.get("unbuyable")]
            if _nup: self.log(f"  🚫 상한가 {_nup}종목 제외(비상한가로 슬롯 채움)")
        acc = self.cfg["account"]
        _af = self._is_af_routine()                                  # ★실계좌 애프터마켓 루틴인가(시장가 없음)
        _cv_hm = self._routine_hm()[1]                               # 미체결 처리 시각(문구용)
        equity = self._strategy_equity()                             # ★복리 자산(원금+누적)
        # ★실제 주문가능금액을 상한으로(관리자 동일) — 전략자산이 실제 예수금보다 크면
        #   종목당 금액만 커지고 정작 발주는 '예수금 스킵'으로 조용히 빠진다.
        # ★천장(추정예탁자산)은 직전 정식 조회값을 쓴다 — 이 시각엔 주기조회가 쉬고(BALANCE_SKIP),
        #   여기서 holdings 를 또 부르면 TR 만 늘고 청산 직후라 빈 응답이 올 수도 있다.
        #   ★`assets`(대체값 섞인 것)가 아니라 `assets_real` 이다 — 없으면 천장 없음.
        _ceil = int((self.acct or {}).get("assets_real") or 0)
        _dep = self.kw.deposit(acc, ceiling=_ceil) or {}
        _ord = _dep.get("orderable")
        if _dep.get("orderable_uncapped"):
            self.log(f"  🏦 매수여력 {int(_dep['orderable_uncapped']):,} → 추정예탁자산 상한 {_ceil:,} 적용")
        _cap = int(_ord) if isinstance(_ord, (int, float)) and _ord > 0 else None
        if _cap is None:
            self.log("  ⚠️ 주문가능금액 조회 실패 — 전략자산 기준으로 진행")
        elif _cap < equity:
            self.log(f"  🏦 주문가능 {_cap//10000:,}만 < 전략자산 {equity//10000:,}만 → 주문가능 기준")
            self.tg(f"🏦 예수금 상한 — 전략자산 {equity//10000:,}만 → 주문가능 {_cap//10000:,}만 기준")
            equity = _cap
        # ★종목수 보완안(2026-10-01 · 사용자 결정 "종목수는 대안으로 간다") — _size 에 **지금 발주할 후보 수**를 넘긴다.
        #   유통 게이트·상한가 제외가 끝난 picks 중 unbuyable 이 아닌 것. exclude_upper=False 면 상한가가 남아 있지만
        #   그건 open_pending(내일 시가)이라 오늘 돈을 안 쓴다 → 세지 않는다. 관리자 buy_close 와 같은 자리·같은 식이다.
        _nc = sum(1 for s in picks if not s.get("unbuyable"))
        invest, af = self._size(equity, n_cand=_nc)                   # ★원금연동 사이징 + 종목수 보완안(관리자 동일)
        _iv0, _af0 = self._size(equity)                              # 보완안 없이 — 작동했는지 가리는 비교용(계산만·TR 0)
        if (invest, af) != (_iv0, _af0):
            self.log(f"  💡 남는 돈 {(max(0, int(equity) - int(self.cfg.get('cash_buffer', 0) or 0)) - _iv0 * _af0) // 10000:,}만"
                     f" → {af}종목 {invest // 10000:,}만씩 균등분배(후보 {_nc}개)")
        _tqc = int(self.cfg.get("test_qty", 0) or 0)                  # 🧪 실계좌 소액 테스트(0=꺼짐)
        if _tqc > 0:
            self.log(f"  🧪 테스트모드 — 종목당 {_tqc}주만 삽니다(금액 사이징 무시)")
            self.tg(f"🧪 테스트모드 매수 — 종목당 {_tqc}주만 발주합니다\n"
                    f"체결 경로 확인용입니다. 끝나면 설정에서 꼭 끄세요(테스트수량 0).")
        _buf = int(self.cfg.get("cash_buffer", 0) or 0)
        sel = picks[:af]; skip = picks[af:]                          # ★상위 af만 매수·나머지 체결안됨
        budget = _cap if _cap else equity
        self.log(f"📥 종가매수(지정가) 기준자산 {equity//10000}만 − 버퍼 {_buf//10000}만 → 종목당 {invest//10000}만 × 상위 {af}종목 · 후보 {len(picks)}·체결안됨 {len(skip)}")
        pos = []; pend = []
        for s in sel:
            if s.get("unbuyable"):                                    # ★(exclude_upper=False일 때만) 상한가 → 내일 09:00 시가매수 예약
                pend.append({"code": s["code"], "name": s["name"], "won": invest, "score": s.get("score")})
                self.log(f"  🔴 상한가 {s['name']} → 내일 시가매수 예약"); continue
            code = s["code"]; px = int(s.get("entry") or 0)          # ★지정가 = entry(스캔 종가)
            if px <= 0: continue
            qty = invest // px
            if _tqc > 0: qty = _tqc                                   # 🧪 테스트모드 — 수량 강제(관리자와 동일)
            if qty < 1 or qty * px > budget: self.log(f"  💸 {s['name']} 스킵(예수금)"); continue
            if _af:                       # ★애프터마켓 매수는 '지금 현재가' 로 건다(픽의 entry 는 몇 분 전 값)
                try:
                    _now = abs(int((self.kw.basic(code) or {}).get("현재가") or 0))
                    if _now > 0: px = _now; qty = (_tqc if _tqc > 0 else (invest // px)) or 1
                except Exception: pass
            self.kw.send_order(acc, code, qty, px, 1, "00"); budget -= qty * px   # ★00=보통(지정가)
            pos.append({"code": code, "name": s["name"], "qty": qty, "price": px, "avg": px, "filled": qty, "sold": 0, "unbuyable": False, "buy_time": self._hm()})
            self.log(f"  📥 종가매수 지정가 {s['name']} {qty}주 @{px:,}"
                     f"({_cv_hm} 미체결시 {'한 호가 위 정정' if _af else '시장가전환'})"); self.wait(400)
        self.state = {"date": self._t(), "buy_date": self._t(), "positions": pos, "open_pending": pend, "trades": self.state.get("trades", [])}
        savej(STATE, self.state)
        self._ensure_real(force=True)   # ★매수 즉시 실시간 시세 등록
        self.tg(f"종가매수 지정가 {len(pos)}종목({_cv_hm} 미체결 {'한 호가 위 정정' if _af else '시장가전환'})" + (f" · 🔴상한가 예약 {len(pend)}" if pend else "") + (f" · ⛔체결안됨 {len(skip)}" if skip else "") + ((": " + ", ".join(o['name'] for o in pos)) if pos else "")); self.refresh()

    def _report(self, hm):
        """★관리자처럼 때맞춰 알린다(2026-09-14 신설).
        08:30 장전 대기 · 09:00 장 시작 · 매시 정각 상태보고 · 15:35 마감 요약.
        각각 하루 1회만 보낸다(스팸 방지)."""
        today = self._t()
        held = [o for o in self.state.get("positions", []) if o.get("filled", 0) - o.get("sold", 0) > 0]
        # 08:30 장전
        if LOGIN_HM <= hm < MANAGE_OPEN and getattr(self, "_premkt_date", "") != today:
            self._premkt_date = today
            self.tg(f"🟢 [{hm}] 장 시작 전 접속 정상 · 보유 {len(held)}종목 손익절 준비완료")
        # 09:00 장 시작
        if MANAGE_OPEN <= hm and getattr(self, "_open_date", "") != today:
            self._open_date = today
            self.tg(f"☀️ 장 시작 · 보유 {len(held)}종목 실시간 관리 시작(무인)")
        # 매시 정각 상태보고(09~15시)
        if hm.endswith(":00") and "09:00" <= hm <= "15:00" and getattr(self, "_rep_hm", "") != hm:
            self._rep_hm = hm
            if held:
                rs = [o.get("cur_ret", 0.0) for o in held]
                body = " · ".join(f"{o['name']} {o.get('cur_ret',0):+.2f}%" for o in held[:4])
                self.tg(f"🟢 [{hm}] 클라이언트 무인 상태보고\n보유 {len(held)}종목 평균 {sum(rs)/len(rs):+.2f}%\n{body}")
            else:
                self.tg(f"🟢 [{hm}] 클라이언트 무인 상태보고 · 보유 없음 ({self._routine_hm()[0]} 종가매수 대기)")
        # 15:35 마감 요약
        if hm >= DONE_HM and getattr(self, "_eod_date", "") != today:
            self._eod_date = today
            tr = [t for t in (self.state.get("trades") or []) if t.get("date") == today]
            if tr:
                pl = sum(t.get("pl") or 0 for t in tr)
                rets = [t.get("ret") or 0 for t in tr]
                wins = sum(1 for r in rets if r > 0)
                body = "\n".join(f"· {t['name']} {t.get('ret',0):+.2f}%" for t in tr[:6])
                self.tg(f"📄 [{hm}] 오늘 마감 · {len(tr)}건 청산 · 승{wins}/패{len(tr)-wins}\n"
                        f"실현손익 {pl:+,}원 · 평균 {sum(rets)/len(rets):+.2f}%\n{body}")
            else:
                self.tg(f"📄 [{hm}] 오늘 마감 · 청산 거래 없음 · 보유 {len(held)}종목")

    def _size(self, equity, n_cand=None):
        """★종목당 금액·매수종목수 — 관리자 admin._size() 와 **같은 식**(2026-09-14 이식).

            가용   = 전략자산 − cash_buffer
            하한   = min(invest_per_stock, 가용 ÷ min_positions)   ← 자산에 연동
            종목당 = max(하한, 가용 ÷ size_div)
            종목수 = 가용 ÷ 종목당

        예전엔 invest_per_stock 이 고정 하한이라, 자산이 작으면 1종목에 갇혔다.
        (백테 134일: 원금 300만·하한 200만이면 거래일의 95%가 1종목, +60.6%/MDD -24%.
         하한을 가용의 절반으로 눌러 2종목을 보장하면 +143.5%/MDD -15.6%.)
        자산이 (invest_per_stock × min_positions + 버퍼) 이상이면 예전 식과 완전히 같다.
        ★부동소수점: usable // a 는 a=usable/3 일 때 2.999…→2 가 된다. +1e-9 로 보정.

        ★종목수 보완안 — n_cand (2026-10-01 · 사용자 결정 "종목수는 대안으로 간다")
          종목당을 먼저 정하고(상한 200만) 개수를 **버림**하니, 기준자산 420만~620만 구간에서 돈이 놀았다
          (가용 480만 → 200만×2=400만 · 80만 유휴 / 기준자산 605만=가용 585만 → 185만=32% 유휴).
          → 그날 **지금 발주할 후보가 충분하면** 올림 개수(nu)로 가용을 균등분배한다.
             조건: nu > 버림개수 · 후보 ≥ nu · 남는 돈 ≥ MIN_POS_WON · 균등분배 종목당 ≥ MIN_POS_WON.
          ★'대안' 을 그대로(무조건 올림) 넣으면 후보 2개인 날 종목당만 깎이고 **오히려 덜 산다**(실측) —
            그래서 후보 수를 받아 **후보가 있을 때만** 쪼갠다. 이게 사용자에게 설명한 '보완안' 이다.
          ★n_cand=None(기본)이면 **예전과 1원도 안 다르다** — 화면 표시(설정저장·계좌카드·자동시작)는
            후보 수를 모르므로 None 으로 부른다. 실매수 경로(buy_picks)만 후보 수를 넘긴다.
          ★ceil 쪽은 -1e-9 — 위 +1e-9 와 같은 이유(usable/a 가 정수인데 2.0000001 로 나와 한 칸 더 올리지 않게).
          ★관리자 admin._size 와 **바이트 단위로 같은 로직**이어야 한다(`프로그램_대조점검` 이 n_cand 축까지 본다).
            실계좌_전환점검.sizing · sizing_report.guard 에는 이 분기가 **없다**(후보 수를 모른다) — 어긋난 게 아니다."""
        cap = max(1, int(self.cfg.get("invest_per_stock", 2000000)))     # 이제 '상한'
        buf = max(0, int(self.cfg.get("cash_buffer", 0) or 0))
        div = max(1, int(self.cfg.get("size_div", 3) or 3))
        mp = max(1, int(self.cfg.get("min_positions", 2) or 2))
        usable = max(0, int(equity) - buf)
        if usable < MIN_POS_WON:
            return max(1, min(cap, max(1, int(equity)))), 1
        a = max(min(cap, usable / mp), usable / div)
        if a < MIN_POS_WON:
            a = min(MIN_POS_WON, usable)
        n = max(1, int(usable / a + 1e-9))
        if n_cand is not None:                          # ★보완안 — 실매수 경로에서만(후보 수를 알 때)
            nu = min(div, max(1, math.ceil(usable / a - 1e-9)))
            if nu > n and n_cand >= nu and (usable - a * n) >= MIN_POS_WON and usable / nu >= MIN_POS_WON:
                return int(usable / nu), nu
        return int(a), n

    def _gapcut(self):
        """★시가 갭컷 — 관리자 admin._gapcut() 과 같은 규칙(2026-09-14 이식).
        09:00 시가가 매수가보다 gapcut_pct% 넘게 낮으면 손절선과 무관하게 즉시 시장가 매도.
        · 판정은 09:00~09:10 첫 시세로 **포지션당 하루 1회**. 09:10을 넘기면 하지 않는다
          (그 시각 가격은 시가가 아니라 장중가라 규칙이 달라진다).
        · gapcut_pct = 0 이면 기능 끔."""
        thr = float(self.cfg.get("gapcut_pct", 0) or 0)
        if thr >= 0: return
        hm = self._hm()
        if not (MANAGE_OPEN <= hm <= "09:10"): return
        today = self._t(); hit = 0
        for o in self.state.get("positions", []):
            if o.get("filled", 0) - o.get("sold", 0) <= 0 or o.get("sell_stuck"): continue
            if o.get("gapcut_date") == today: continue
            base = o.get("avg") or o.get("price") or 0
            px = o.get("cur_px") or (getattr(self.kw, "real_prices", {}) or {}).get(o["code"])
            if not base or not px: continue
            o["gapcut_date"] = today; o["open_px"] = px
            r = (px / base - 1) * 100
            if r < thr:
                self._force_sell(o, f"갭컷(시가 {r:+.2f}%)")
                self.log(f"  ⚡ 갭컷 {o['name']} 시가 {px:,}({r:+.2f}%) < 기준 {thr:g}% → 즉시 시장가")
                self.tg(f"⚡ 갭컷 {o['name']} 시가 {r:+.2f}% 즉시매도"); hit += 1
            else:
                self.log(f"  ⏱ 시가 확인 {o['name']} {r:+.2f}% (기준 {thr:g}%) → 보유 유지")
        if hit: savej(STATE, self.state); self._ensure_real(force=True)

    def _float_filter(self, picks):
        """★유통비율 ≤ float_max(기본70%) 매수 게이트(관리자 동일·매수시점 opt10001 조회). 조회실패/없음=통과(보수). float_max=0이면 끔."""
        fmax = self.cfg.get("float_max", 70)
        if not fmax: return picks
        kept = []
        for s in picks:
            fr = None
            try:
                info = self.kw.basic(s["code"]) or {}
                v = info.get("유통비율")
                if v in (None, "", 0, "0"):
                    us = _int(info.get("유통주식")); ss = _int(info.get("상장주식"))
                    v = round(us / ss * 100, 2) if ss else None
                fr = float(str(v).replace("%", "").replace(",", "").strip()) if v not in (None, "") else None
            except Exception:
                fr = None
            # ★조회 실패 = 통과(fail-open)는 의도한 설계다 — 그런데 **로그가 0줄**이었다 (2026-10-01).
            #   실측: 스캔 종목의 19.4% 가 무데이터로 조용히 통과했고, 09-28 한국비엔씨는 실제 유통 79.9% 인데
            #   관리자 15:26 게이트를 소리 없이 넘었다(상한가로 빠져 결과만 같았다). 단기과열 필터가 엿새 동안
            #   죽어 있었던 것과 같은 종류다 — fail-open 은 죽어도 조용하다. 동작은 그대로(통과), **말만 한다.**
            #   문구는 관리자와 한 글자도 다르지 않게 둔다(프로그램_대조점검 이 문자열로 볼 수 있게).
            #   ★`s['name']` 이 아니라 `.get` — 로그 한 줄이 KeyError 로 그날 매수 전체를 멈추면 안 된다.
            if fr is None:
                self.log(f"  ⚠️ 유통비율 조회 실패 — 통과(fail-open): {s.get('name') or s.get('code')}")
            if fr is not None and fr > fmax:
                self.log(f"  🚫 유통 {fr:.0f}% > {fmax}% 제외: {s['name']}"); continue
            kept.append(s)
        if len(kept) < len(picks): self.log(f"  🔎 유통≤{fmax}% 필터: {len(picks)}→{len(kept)}종목")
        return kept

    def _convert_unfilled_market(self):
        """★15:28 미체결 지정가매수 → 시장가 전환(관리자 동일·이중체결 방지: 15:30 컷오프 → 취소 rc=0 확인 → 취소 재확인된 뒤에만 시장가)."""
        if self._hm() >= "15:30":
            self.converted_today = True; self.log("⚠️ 15:30 경과 — 시장가 전환 중단(이중체결 방지)"); return
        acc = self.cfg["account"]
        pend = self.kw.pending(acc)                  # None=조회실패(빈목록과 구분)
        if pend is None:
            self.log("⚠️ 미체결 조회 실패 — 다음 틱 재시도(전환 보류)"); return
        self.converted_today = True
        pmap = {p.get("code"): p for p in pend if "매수" in (p.get("gubun", "") or "") and _int(p.get("unfilled", 0)) > 0}
        nconv = 0
        for o in self.state.get("positions", []):
            if self._hm() >= "15:30": break
            if o.get("mkt") or (o.get("filled", 0) - o.get("sold", 0) <= 0): continue
            p = pmap.get(o["code"])
            if not p: continue                       # 미체결 아님(이미 체결/주문없음) → 손대지 않음
            uq = _int(p.get("unfilled", 0)) or o["qty"]
            rc = self.kw.cancel_buy(acc, o["code"], uq, p.get("order_no", ""))   # 1) 취소 발주 + 반환값 확인
            if rc != 0:
                self.log(f"  ⚠️ {o['name']} 취소발주 실패(rc={rc}) — 시장가 보류(중복방지)"); continue
            self.wait(700)
            if self._hm() >= "15:30":
                self.log(f"  ⚠️ {o['name']} 15:30 경과 — 시장가 보류(중복방지)"); continue
            pend2 = self.kw.pending(acc)             # 2) 취소 확인(조회실패=None이면 보류)
            if pend2 is None:
                self.log(f"  ⚠️ {o['name']} 취소확인 조회실패 — 시장가 보류(중복방지)"); continue
            still = next((q for q in pend2 if q.get("code") == o["code"] and "매수" in (q.get("gubun", "") or "") and _int(q.get("unfilled", 0)) > 0), None)
            if still:                                # 3) 아직 미체결 = 취소 안 됨 → 시장가 보류
                self.log(f"  ⚠️ {o['name']} 취소 미확인 — 시장가 보류(중복방지)"); continue
            self.kw.send_order(acc, o["code"], uq, 0, 1, "03"); o["mkt"] = True; nconv += 1   # 취소확인 후에만 시장가
            self.log(f"  🔄 15:28 미체결→시장가전환 {o['name']} {uq}주(취소확인 후 발주)"); self.wait(500)
        savej(STATE, self.state)
        if nconv: self.tg(f"🔄 15:28 미체결 {nconv}종목 시장가 전환(중복방지·종가 확실체결)")
        self.log(f"15:28 시장가 전환 {nconv}종목")

    def _reconcile_positions(self):
        """★15:31 체결 후 실제 계좌잔고로 positions 보정(관리자 동일) — 안 산 건 제거, 산 건 실수량·매입가 반영(손익절 정확)."""
        self.query_account()
        holds = {s["code"]: s for s in (self.acct or {}).get("stocks", []) if s.get("qty", 0) > 0}
        for o in self.state.get("positions", []):
            h = holds.get(o["code"])
            if h:
                o["filled"] = h["qty"]; o["avg"] = h.get("buy") or o.get("avg")
            elif not o.get("sold"):
                o["filled"] = 0                          # 미체결/취소 → 보유 아님
        self.state["positions"] = [o for o in self.state["positions"] if o.get("filled", 0) - o.get("sold", 0) > 0]
        savej(STATE, self.state); self._ensure_real(force=True)
        held = len([o for o in self.state["positions"] if o.get("filled", 0) - o.get("sold", 0) > 0])
        self.log(f"✅ {self._routine_hm()[2]} 체결 보정 — 실보유 {held}종목")

    def _buy_open_pending(self):
        """★상한가 예약분 → 개장(09:00) 시가 시장가매수 → 실체결가로 즉시 ±3%. 자본제약(원금-보유묶임)·관리자와 동일."""
        pend = self.state.get("open_pending") or []
        if not pend: return
        acc = self.cfg["account"]
        equity = self._strategy_equity()
        held = sum(max(0, (p.get("filled", 0) - p.get("sold", 0))) * (p.get("avg") or 0) for p in self.state.get("positions", []))
        budget = equity - held
        try:
            od = (self.kw.deposit(acc, ceiling=int((self.acct or {}).get("assets_real") or 0))
                  or {}).get("orderable")
            if od: budget = min(budget, int(od))
        except Exception: pass
        pend = sorted(pend, key=lambda o: -(o.get("score") if o.get("score") is not None else -1))
        done = []; skipped = []
        for o in pend:
            code = o["code"]; px = self.cur(code) or 0
            if px <= 0: continue
            won = o.get("won") or self.cfg["invest_per_stock"]
            qty = won // px
            _tqo = int(self.cfg.get("test_qty", 0) or 0)              # 🧪 테스트모드 — 여기도 막아야 한다(관리자 동일)
            if _tqo > 0:
                qty = _tqo
                self.log(f"  🧪 테스트모드 — {o['name']} {qty}주만")
            if qty < 1 or (qty * px > budget and not o.get("force")):   # ★force=강제매수 · 나머지 원금부족 체결안됨
                self.log(f"  ⛔ 상한가 {o['name']} 체결안됨(원금부족·여유 {budget:,.0f}원)")
                skipped.append(o["name"]); done.append(code); continue
            self.kw.send_order(acc, code, qty, 0, 1, "03"); budget -= qty * px
            avg = 0; rqty = 0                                        # ★체결통보로 실체결단가(최대 3초)
            for _ in range(6):
                self.wait(500)
                real = (getattr(self.kw, "positions", {}) or {}).get(code, {})
                if real.get("avg"): avg = real["avg"]; rqty = real.get("qty") or qty; break
            if not avg: avg = px; rqty = qty
            self.state.setdefault("positions", []).append({"code": code, "name": o["name"], "qty": rqty, "price": avg, "avg": avg, "filled": rqty, "sold": 0, "unbuyable": True})
            self.state.setdefault("upper_today", [])
            if code not in self.state["upper_today"]: self.state["upper_today"].append(code)
            self.log(f"  🔵 상한가 시가매수 {o['name']} {rqty}주 @{avg:,} (±{st.UPPER_TP:g}%)"); self.tg(f"🔵 상한가 시가매수 {o['name']} @{avg:,}(±{st.UPPER_TP:g}%)")
            done.append(code)
        self.state["open_pending"] = [o for o in pend if o["code"] not in done]
        if done: savej(STATE, self.state); self._ensure_real(force=True)
        if skipped: self.tg(f"⛔ 상한가 {len(skipped)}종목 원금부족 체결안됨: {', '.join(skipped)}")

    # ═══ 실시간(SetRealReg) — HTS처럼 매 틱 현재가·수익률 반영 + 즉시 ±손익절 ═══
    def _ensure_real(self, force=False):
        """보유종목을 실시간 시세(SetRealReg FID10 현재가)로 등록. 보유가 바뀌면 재등록."""
        if not self.connected: return
        codes = [o["code"] for o in self.state.get("positions", []) if o.get("filled", 0) - o.get("sold", 0) > 0]
        key = ";".join(sorted(codes))
        if not codes:
            if self._real_on:
                try: self.kw.clear_real()
                except Exception: pass
                self._real_on = False; self._real_key = ""
            return
        if force or not self._real_on or self._real_key != key:
            try:
                self.kw.set_real(codes, self._on_realtick); self._real_on = True; self._real_key = key
                self.log(f"📡 실시간 시세 {len(codes)}종목 등록 (매 틱 손익절)")
            except Exception as e:
                self.log(f"실시간등록오류 {e}")

    def _on_realtick(self, code, px):
        """SetRealReg 실시간 틱: 즉시 현재가·수익률 반영 + 장중 ±손익절 즉시 판정."""
        if not self.connected or px <= 0: return
        o = next((o for o in self.state.get("positions", []) if o.get("code") == code and o.get("filled", 0) - o.get("sold", 0) > 0), None)
        if not o: return
        base = o.get("avg") or o.get("price") or px; ret = (px / base - 1) * 100
        if not (MANAGE_OPEN <= self._hm() < REG_END):            # ★정규장(09:00~15:30) 밖 = 시간외종가·애프터마켓(2026-09-16)
            o["aft_px"] = px; o["aft_ret"] = round(ret, 2)       #   따로 담는다. cur_* 를 덮으면 그 값이 STATE 에 남아
            # ★애프터마켓 손익절은 여기서 **실시간으로** 판정한다(2026-09-18).
            #   _af_live 는 메모리 전용이다 — STATE 에 넣으면 재기동 때 어제 값을
            #   오늘 값으로 오인해 멀쩡한 종목을 손절한다.
            _lv = getattr(self, "_af_live", None)
            if _lv is None: _lv = self._af_live = {}
            _lv[code] = (px, time.time())
            if AFTP_START <= self._hm() < AF_WATCH_END:
                try: self._watch_afterhours()
                except Exception: pass
            self._live_dirty = True; return                      #   다음날 09:00 첫 틱에 오늘 값으로 오인된다
        o["cur_ret"] = round(ret, 2); o["cur_px"] = px
        o["cur_ts"] = time.time()          # ★시세가 언제 것인지 — manage() 의 손절 백업이 낡음을 판단한다
        self._live_dirty = True            # HTS처럼 실시간 변동
        if o.get("sell_stuck"): return                           # ★미체결 매도주문이 살아있음 — 시세만 갱신하고 주문은 금지(이중매도 방지)
        if not self.cfg.get("enabled"): return
        if not (MANAGE_OPEN <= self._hm() < MANAGE_CLOSE): return    # 장중(09:00~15:20)에만 실매도
        tp, acc = self.cfg["tp_pct"], self.cfg["account"]   # ★손익절은 수수료를 넣지 않는다(매수가 기준 순수 등락률)
        otp = st.UPPER_TP if o.get("unbuyable") else tp
        osl = self.cfg.get("sl_pct", -3.0)                           # ★손절 독립(설정값·음수) — 자동 1:1 규칙 해제(관리자 동일)
        rem = o["filled"] - o.get("sold", 0)
        if rem > 0 and ret <= osl:                                   # ★손절 — 정정(즉시 시장체결·이중매도0), 지정가 없으면 시장가
            try:
                self._force_sell(o, "실시간 손절")
                self.log(f"  ⚡실시간손절 {o['name']} {ret:+.2f}%"); self.tg(f"⚡손절 {o['name']} {ret:+.2f}%")
                savej(STATE, self.state); self._ensure_real(force=True)
            except Exception as e:
                self.log(f"실시간손절오류 {e}")
        elif rem > 0 and ret >= otp and not o.get("tp_placed"):      # ★익절 폴백(지정가 미배치 시만)
            try:
                self.kw.send_order(acc, code, rem, 0, 2, "03"); o["sold"] = o["filled"]; o["exit_ret"] = round(ret, 2); self._rec(o, ret, "실시간 익절")
                self.log(f"  ⚡실시간익절(폴백) {o['name']} {ret:+.2f}%"); self.tg(f"⚡익절 {o['name']} {ret:+.2f}%")
                savej(STATE, self.state); self._ensure_real(force=True)
            except Exception as e:
                self.log(f"실시간익절오류 {e}")

    def _live_flush(self):
        if self._live_dirty:
            self._live_dirty = False
            try: self.refresh()
            except Exception: pass

    def _tick_round(self, px):
        """호가단위 반올림(KRX 2023~) — 지정가 주문 거부 방지."""
        px = int(px)
        for lim, t in [(2000, 1), (5000, 5), (20000, 10), (50000, 50), (200000, 100), (500000, 500)]:
            if px < lim: return max(t, (px // t) * t)
        return (px // 1000) * 1000

    def _force_sell(self, o, reason=""):
        """★보유분 즉시 전량매도 — 익절 지정가 있으면 정정(하한가로)해 즉시 시장체결(이중매도0·취소race0), 없으면 시장가. 기록은 _reconcile_sells가 실체결가 보정."""
        acc = self.cfg["account"]; code = o["code"]; rem = o["filled"] - o.get("sold", 0)
        if rem <= 0 or o.get("sell_stuck"): return               # ★최후 방어선 — 미체결 매도주문이 살아있으면 또 내지 않는다
        base = o.get("avg") or o.get("price") or 0; px = o.get("cur_px") or base
        if o.get("tp_placed") and not o.get("tp_ord"):              # 주문번호 미확보 → fills서 재조회
            f = next((x for x in reversed(getattr(self.kw, "fills", []) or []) if x.get("code") == code and "매도" in (x.get("otype", "") or "") and x.get("order_no")), None)
            if f: o["tp_ord"] = f["order_no"]
        if o.get("tp_ord"):
            low = self._tick_round(max(1, round(base * 0.71)))       # 하한가 근처 정정 → 즉시 시장체결
            self.kw.modify_sell(acc, code, rem, low, o["tp_ord"]); o["tp_ord"] = None; o["tp_placed"] = False
        else:
            self.kw.send_order(acc, code, rem, 0, 2, "03")
        o["sold"] = o["filled"]; o["exit_ret"] = round((px / base - 1) * 100, 2) if base else 0.0
        o["sell_pending"] = {"hm": self._hm(), "ts": time.time(), "qty": rem, "warned": False}  # ★체결확인 대기
        self._rec(o, o["exit_ret"], reason)

    def manage(self):
        self._ensure_real()   # 보유종목 실시간 등록 보장(재등록)
        pos = [o for o in self.state.get("positions", [])
               if o.get("filled", 0) - o.get("sold", 0) > 0 and not o.get("sell_stuck")]   # ★미체결 주문 살아있음 → 신규주문 금지
        if not pos: return
        tp, acc = self.cfg["tp_pct"], self.cfg["account"]   # ★손익절은 수수료를 넣지 않는다(매수가 기준 순수 등락률)
        kwpos = getattr(self.kw, "positions", {}) or {}; kwfills = getattr(self.kw, "fills", []) or []
        for o in pos:
            code = o["code"]; base = o.get("avg") or o["price"]; rem = o["filled"] - o.get("sold", 0)
            px = self.cur(code)
            if px: o["cur_ret"] = round((px / base - 1) * 100, 2)
            otp = st.UPPER_TP if o.get("unbuyable") else tp; osl = self.cfg.get("sl_pct", -3.0)   # ★손절 독립(설정값)
            if rem > 0 and not o.get("tp_placed"):                    # ★익절 지정가 예약(포지션당 1회)
                tp_px = self._tick_round(round(base * (1 + otp / 100)))
                if self.kw.send_order(acc, code, rem, tp_px, 2, "00") == 0:
                    o["tp_placed"] = True; o["tp_px"] = tp_px
                    for _ in range(4):                                # 주문번호 즉시확보(정정용)
                        self.wait(300)
                        f2 = next((x for x in reversed(getattr(self.kw, "fills", []) or []) if x.get("code") == code and "매도" in (x.get("otype", "") or "") and x.get("order_no")), None)
                        if f2: o["tp_ord"] = f2["order_no"]; break
                    self.log(f"  🎯 익절 지정가 예약 {o['name']} {rem}주 @{tp_px:,}(+{otp:g}%)")
            if o.get("tp_placed") and not o.get("tp_ord"):
                f = next((x for x in reversed(kwfills) if x.get("code") == code and "매도" in (x.get("otype", "") or "") and x.get("order_no")), None)
                if f: o["tp_ord"] = f["order_no"]
            if rem > 0 and o.get("tp_placed"):                       # ★익절 지정가 체결감지(잔고 감소)
                heldn = kwpos.get(code, {}).get("qty")
                if heldn is not None and heldn < rem:
                    fs = next((x for x in reversed(kwfills) if x.get("code") == code and "매도" in (x.get("otype", "") or "") and (x.get("fill_price") or 0) > 0), None)
                    fp = fs["fill_price"] if fs else o.get("tp_px", px or base)
                    o["sold"] = o.get("sold", 0) + (rem - heldn); o["exit_ret"] = round((fp / base - 1) * 100, 2) if base else 0
                    self._rec(o, o["exit_ret"])
                    self.log(f"  ✅ 익절 지정가 체결 {o['name']} @{fp:,} ({o['exit_ret']:+.2f}%)")
            # ★★손절은 **독립 검사**다 (2026-09-28 버그수정).
            #   예전엔 위 '익절 체결감지' 의 `elif` 였다. `tp_placed` 는 매수 후 첫 사이클에 True 가 되므로
            #   그 뒤로는 위 `if` 가 항상 잡혀 **이 손절이 영구히 실행되지 않았다**(죽은 코드).
            #   그래서 손절이 `_on_realtick` 하나에만 걸려 있었고, 틱이 끊기면 손절이 아예 안 됐다.
            if rem > 0 and (o.get("filled", 0) - o.get("sold", 0)) > 0 and not o.get("sell_stuck"):
                # ★시세가 낡았을 때만 직접 조회한다 — 틱이 정상이면 추가 TR 이 0 이다.
                #   `cur_ts` 가 **없는 것**(기동 직후·신규 채택분)과 **낡은 것**(진짜 끊김)은 다르다.
                #   없음을 0 으로 치면 age 가 17억초로 찍히고 경보 쿼터를 기동 때 태워
                #   오후의 진짜 끊김을 못 알린다(관리자에서 당한 실수).
                _cts = float(o.get("cur_ts") or 0)
                _age = (time.time() - _cts) if _cts > 0 else -1.0
                if _age < 0 or _age > SL_BACKUP_STALE:
                    _seen = getattr(self, "_slb_ts", None)
                    if _seen is None: _seen = self._slb_ts = {}
                    if time.time() - _seen.get(code, 0) >= SL_BACKUP_GAP:
                        _first = code not in _seen
                        _seen[code] = time.time()
                        try: _bp = abs(int((self.kw.basic(code) or {}).get("현재가") or 0))
                        except Exception: _bp = 0
                        if _bp > 0:
                            px = _bp; o["cur_px"] = _bp; o["cur_ts"] = time.time()
                            o["cur_ret"] = round((px / base - 1) * 100, 2)
                            if _age < 0:
                                if _first:
                                    self.log(f"  🛟 {o['name']} 실시간 시세 대기 — 직접 조회로 손절선을 지킵니다(기동 직후)")
                            elif getattr(self, "_slb_day", "") != self._t():
                                self._slb_day = self._t()
                                self.log("🛟 손절 백업 작동 — 실시간 시세가 %.0f초 낡아 직접 조회합니다" % _age)
                                self.tg("🛟 손절 백업 작동\n실시간 시세가 끊겨 20초마다 직접 조회로 손절을 지킵니다.")
                            try: self._ensure_real(force=True)
                            except Exception: pass
                if px and base and (px / base - 1) * 100 <= osl:      # ★손절(지정가 정정→즉시 시장체결)
                    _r = round((px / base - 1) * 100, 2)
                    self._force_sell(o, "손절")
                    self.log(f"  🛑 손절 {o['name']} {o.get('exit_ret', _r):+.2f}%")
                    self.tg(f"손절 {o['name']} {o.get('exit_ret', _r):+.2f}%")
        pos2 = [o for o in self.state.get("positions", [])
                if o.get("filled", 0) - o.get("sold", 0) > 0 and not o.get("sell_stuck")]
        rr = [o.get("cur_ret", 0.0) for o in pos2]; acct = round(sum(rr) / len(rr), 2) if rr else 0.0
        if pos2 and acct >= tp:                                       # 계좌평균 도달 → 전량청산(정정 기반)
            for o in pos2: self._force_sell(o, "하이브 계좌청산")
            self.log(f"  🏦 계좌 {acct:+.1f}% 전량청산"); self.tg(f"계좌 {acct:+.1f}% 전량청산")
        savej(STATE, self.state); self.refresh()

    def close_all(self):
        did = False
        _tg = []                                          # ★청산 대상 — _ensure_closeout 이 쓴다
        for o in self.state.get("positions", []):
            if o.get("filled", 0) - o.get("sold", 0) > 0 and not o.get("sell_stuck"):
                _tg.append({"code": o["code"], "name": o["name"],
                            "qty": o["filled"] - o.get("sold", 0),
                            "avg": int(o.get("avg") or o.get("price") or 0)})   # 하한가 계산용
                self._force_sell(o, "15:19 종가청산"); did = True                      # ★익절 지정가 있으면 정정→즉시 시장체결
                self.log(f"  🔚 종가청산(어제분) {o['name']} {o.get('exit_ret', 0):+.1f}%")
        if did:
            # ★왜 코드를 적어 두나 — 15:25 에 **새 종목을 산다.** 잔고만 보고 '남아 있으면 팔아라' 하면
            #   방금 산 종목을 청산해 버린다. 그래서 청산 대상을 이 순간에 못박아 둔다.
            self.state["closeout"] = {"date": self._t(), "targets": _tg, "tries": {}}
            savej(STATE, self.state); self.refresh()

    def _ensure_closeout(self):
        """★15:19 강제청산이 **실제로 끝났는지** 확인하고, 안 끝났으면 밀어붙인다
        (2026-09-28 · 관리자 2026-09-22 분 이식. 관리자에서 7/7 검증한 코드다).

        왜 필요한가
          `close_all()` 은 **발주만 하고 끝이다** — 체결 확인도, 재시도도 없다.
          `_verify_sells()` 는 3분 뒤 경고하고 10분 뒤 `sell_stuck` 을 걸어 **포기한다**(이중매도 방지).
          그 사이 종가 동시호가(15:20~15:30)가 지나가면 **그날 청산은 실패하고 다음날로 넘어간다.**

        무엇을 하나 — 15:19 에 적어 둔 대상이 **실잔고에 남아 있으면**
          · 미체결 매도주문이 있으면 → **하한가로 정정**한다(새 주문이 아니라 가격 변경이라 이중매도가 없다)
          · 미체결 매도주문이 없으면 → 청산이 아예 안 나간 것이다 → **시장가로 발주**한다
            (조회로 '살아있는 주문이 없다'를 **확인했으므로** 이중매도가 아니다)
        ★동시호가에서 하한가 지정가·시장가는 **종가에 체결된다** — 그래서 이 창에서 끝낼 수 있다.
        ★조회 실패(None)와 '없음'([])을 반드시 가른다. 실패를 '없음'으로 보면 이중매도가 난다."""
        st_ = self.state.get("closeout") or {}
        if st_.get("date") != self._t(): return
        tg = [t for t in (st_.get("targets") or []) if not st_.get("tries", {}).get(t["code"], {}).get("done")]
        if not tg: return
        if not getattr(self, "connected", False): return
        try: hd = self.kw.holdings(self.cfg["account"])
        except Exception as e:
            self.log(f"청산 확인 잔고조회 오류 {e}"); return
        if not isinstance(hd, dict): return                           # ★조회 실패 — 다음 틱에 다시 본다
        _stk = hd.get("stocks")
        if not isinstance(_stk, list) or any(not isinstance(s, dict) for s in _stk): return
        held = {s.get("code"): int(s.get("qty") or 0) for s in _stk}
        acc = self.cfg["account"]; tries = st_.setdefault("tries", {}); changed = False
        _pend = None                                                  # 미체결 목록 — 필요할 때 한 번만 조회
        for t in tg:
            code = t["code"]; h = int(held.get(code, 0) or 0)
            rec = tries.setdefault(code, {"n": 0, "ts": 0})
            if h <= 0:
                rec["done"] = True; changed = True; continue          # 다 팔렸다
            if rec["n"] >= 3: continue                                # ★무한루프 금지 — 3회까지만
            if time.time() - float(rec.get("ts") or 0) < 40: continue  # 같은 종목 재시도 간격
            if _pend is None:
                try: _pend = self.kw.pending(acc)
                except Exception as e:
                    self.log(f"청산 확인 미체결조회 오류 {e}"); return
                if _pend is None or not isinstance(_pend, list):
                    self.log("⚠️ 청산 확인 — 미체결조회 실패, 다음 틱 재시도"); return   # ★실패면 아무것도 안 한다
                # ★★원소에 dict 아닌 것이 섞여 있으면 **조회 실패로 본다** (2026-09-29 신설).
                #   키움 opt10075 는 응답이 오정렬돼 문자열이 섞여 오는 일이 실제로 있었다
                #   (2026-09-22 16:37 `'str' object has no attribute 'get'`).
                #   · 그냥 두면 아래 `p.get(...)` 에서 터져 이 함수가 중단된다 — `rec["n"]` 만 올려 놓고
                #     `savej` 를 못 해 청산 재시도 3회를 조용히 태운다.
                #   · **걸러내고 진행해도 안 된다** — 못 읽은 원소가 그 종목의 **살아있는 매도주문**일 수 있고,
                #     그러면 `_my` 가 비어 "주문 없음 확인" 으로 **시장가를 또 발주**한다(이중매도).
                #   → 못 믿을 응답은 '없음' 이 아니라 '모른다' 다. 다음 틱에 다시 본다.
                if any(not isinstance(p, dict) for p in _pend):
                    self.log("⚠️ 청산 확인 — 미체결 응답 오정렬(문자열 섞임), 다음 틱 재시도"); return
            rec["n"] += 1; rec["ts"] = time.time(); changed = True
            _my = [p for p in _pend if isinstance(p, dict) and p.get("code") == code
                   and "매도" in (p.get("gubun") or "") and int(p.get("unfilled") or 0) > 0
                   and p.get("order_no")]
            if _my and int(t.get("avg") or 0) > 0:
                _low = self._tick_round(max(1, round(int(t["avg"]) * 0.71)))   # 하한가 근처 = "얼마든 팔아라"
                p = _my[0]
                self.kw.modify_sell(acc, code, int(p["unfilled"]), _low, p["order_no"])
                self.log(f"  🔚❗청산 미체결 {t['name']} {h}주 — 하한가 {_low:,} 정정(시도 {rec['n']}/3)")
                self.tg(f"🔚❗15:19 청산이 아직 안 됐습니다 — {t['name']} {h}주\n"
                        f"살아있는 매도주문을 하한가로 정정했습니다(동시호가 종가 체결).")
            elif not _my:
                self.kw.send_order(acc, code, h, 0, 2, "03")          # 살아있는 주문 없음이 확인됨 → 시장가
                self.log(f"  🔚❗청산 주문 없음 {t['name']} {h}주 — 시장가 재발주(시도 {rec['n']}/3)")
                self.tg(f"🔚❗15:19 청산 주문이 없어졌습니다 — {t['name']} {h}주\n"
                        f"살아있는 주문이 없음을 확인하고 시장가로 다시 냈습니다.")
            else:
                # ★조용히 넘어가면 안 된다 — 잔고는 남았는데 손을 못 쓴 것이다
                self.log(f"  🔚❗청산 미완료 {t['name']} {h}주 — 매수가를 몰라 자동정정 불가 · 직접 확인 필요")
                self.tg(f"🔚❗15:19 청산이 안 끝났습니다 — {t['name']} {h}주\n"
                        f"프로그램이 자동으로 처리하지 못했습니다. **영웅문에서 직접 매도**하세요.")
        if changed: savej(STATE, self.state)

    def _rec(self, o, ret, reason=""):
        buy = o.get("avg") or o.get("price") or 0
        rec = {"date": self._t(), "code": o.get("code"), "name": o["name"], "buy": buy,
               "sell": round(buy * (1 + ret / 100)), "ret": round(ret, 2), "qty": o.get("filled", 0),
               "pl": round(buy * o.get("filled", 0) * ret / 100), "real_fill": False,
               "sell_time": self._hm(), "reason": reason,
               "mode": "모의" if self.cfg.get("is_mock", True) else "실전",   # ★전략자산을 모드별로 가르려면 필요

               # ★슬리피지 측정용(관리자 동일) — 백테가 가정한 가격을 남긴다
               "buy_plan": o.get("price") or None,
               "sell_plan": round(buy * (1 + ret / 100)),
               "open_px": o.get("open_px") or None, "adopted": bool(o.get("adopted"))}
        # ★중복기록 차단(2026-09-14 · 관리자 동일) — 마지막 방어선.
        #   ★진짜 분할체결은 수량이나 단가가 다르다. 전부 같은 것만 거부한다.
        _k = (rec["date"], rec["code"], rec["qty"], rec["buy"], rec["sell"], rec["ret"])
        for _t in reversed(self.state.get("trades") or []):
            if _t.get("date") != rec["date"]: break
            if (_t.get("date"), _t.get("code"), _t.get("qty"), _t.get("buy"),
                    _t.get("sell"), _t.get("ret")) == _k:
                self.log(f"  ⛔ 중복기록 차단 {rec['name']} {rec['qty']}주 {rec['ret']:+.2f}%")
                self.tg(f"⛔ 중복기록 차단 {rec['name']} {rec['ret']:+.2f}% (기록 보호)")
                return
        self.state.setdefault("trades", []).append(rec)

    def _clear_sell_stuck(self):
        """★날이 바뀌면 매도잠금을 푼다(2026-09-14 버그수정).

        `sell_stuck` 은 '이미 낸 매도주문이 살아 있으니 또 내지 말라'는 잠금이다.
        그런데 한국 시장의 당일 주문은 **장 마감에 자동 취소**된다 — 다음 날엔 살아있는 주문이 없다.
        안 풀면 그 포지션은 손절·익절·종가청산·갭컷이 전부 막힌 채 계좌에 영원히 남는다."""
        stuck = [o for o in self.state.get("positions", []) if o.get("sell_stuck")]
        if not stuck: return
        for o in stuck:
            o.pop("sell_stuck", None); o.pop("sell_pending", None); o.pop("tp_placed", None); o.pop("tp_ord", None)
            self.log(f"  🔓 매도잠금 해제 {o['name']} — 전일 미체결 주문은 자동취소됨 · 오늘부터 정상 관리")
        self.tg("🔓 전일 매도 미체결분 잠금 해제 — " + ", ".join(o["name"] for o in stuck)
                + "\n오늘부터 손익절·종가청산이 다시 작동합니다.")
        savej(STATE, self.state)

    def _sync_account_ledger(self):
        """★계좌 자동동기화 — 접속이 끊긴 사이 앱/외부(영웅문·MTS)로 청산된 종목을
        당일매매일지(실체결가)로 잡아 기록한다.

        안 하면: 이미 판 종목이 포지션에 유령으로 남아 매일 종가청산을 시도하고,
        실현손익이 안 잡혀 전략자산(=사이징 기준)이 계속 어긋난다.

        ★안전: 당일매매일지가 '실제 매도'로 확인한 것만 기록한다.
          빈 응답은 조회실패일 수 있으므로 아무것도 하지 않는다."""
        if not self.connected: return
        try:
            journal = self.kw.today_journal(self.cfg.get("account", "")) or []
        except Exception as e:
            self.log(f"당일매매일지 조회 오류 {e}"); return
        if not journal: return                               # 빈 응답 = 조회실패/매도없음 → 아무것도 안 함(안전)
        jr = {t["code"]: t for t in journal if t.get("sell_amt")}
        today = self._t()
        recorded = {t.get("code") for t in (self.state.get("trades") or []) if t.get("date") == today}
        changed = False
        for o in self.state.get("positions", []):
            if o.get("open_buy") or o.get("filled", 0) - o.get("sold", 0) <= 0: continue
            if o["code"] in recorded: continue               # 우리가 이미 기록한 매도
            if o.get("sell_pending"): continue               # ★발주 직후 — _verify_sells 가 판정할 몫
            j = jr.get(o["code"])
            if not j: continue                               # 일지에 매도 없음 → 스킵(미확인·안전)
            buy = o.get("avg") or o.get("price") or 0; qty = o.get("filled", 0)
            amt = j.get("sell_amt", 0)
            if amt <= 0 or qty <= 0: continue
            sell = round(amt / qty); ret = round((amt / (buy * qty) - 1) * 100, 2) if (buy and qty) else 0.0
            o["sold"] = qty; o["exit_ret"] = ret; o.pop("sell_stuck", None)   # 중복기록 방지
            self._rec(o, ret, "계좌동기화(당일매매일지)")
            _lt = (self.state.get("trades") or [])[-1:]     # ★일지값이 실체결이다 — 정확한 금액으로 덮고 보정 대상에서 뺀다
            if _lt and _lt[0].get("code") == o["code"]:
                _lt[0]["sell"] = sell; _lt[0]["pl"] = amt - buy * qty; _lt[0]["real_fill"] = True
            self.log(f"🔄 계좌동기화 — {o['name']} 앱/외부 청산 기록(실체결 {sell:,} · {ret:+.2f}%)")
            self.tg(f"🔄 계좌동기화 · {o['name']} 청산 반영 {ret:+.2f}%\n"
                    f"(프로그램 밖에서 매도된 것을 당일매매일지로 확인했습니다)")
            changed = True
        if changed:
            self.state["positions"] = [o for o in self.state["positions"]
                                       if o.get("open_buy") or o.get("filled", 0) - o.get("sold", 0) > 0]
            self.state["date"] = today
            savej(STATE, self.state); self._ensure_real(force=True)

    def _verify_sells(self):
        """★매도 체결확인 — '발주했으니 팔렸다'고 가정한 기록을 실제 잔고로 검증한다.

        _force_sell 은 send_order 직후 sold=filled 로 마킹하고 기록한다.
        모의계좌는 시장가가 늘 즉시 체결돼 문제없지만 **실계좌는 다르다** —
        급등주는 VI(변동성완화장치)가 흔하고, 걸리면 2분 단일가라 시장가가 안 나간다.
        그 사이 기록에는 '없었던 거래'가 남고, 포지션은 잔량 0으로 보여 손익절이 끊긴다.

          3분  — 잔량이 남아 있으면 텔레그램 경고(주문은 살아 있으니 기다린다)
          10분 — 그래도 남으면 **기록을 사실에 맞추고** 포지션 잔량을 되살린다.
                 되살린 포지션엔 `sell_stuck` 을 붙여 **새 주문을 내지 않는다**
                 (살아있는 매도주문 + 새 주문 = 이중매도).

        ★조회 실패(None)와 '보유 없음'(빈 목록)을 반드시 구분한다."""
        if not self.connected: return
        if not (MANAGE_OPEN <= self._hm() <= "15:45"): return
        due = [o for o in self.state.get("positions", [])
               if o.get("sell_pending") and time.time() - (o["sell_pending"].get("ts") or 0) >= 180]
        if not due: return
        try: hd = self.kw.holdings(self.cfg["account"])
        except Exception as e:
            self.log(f"매도 체결확인 조회 오류 {e}"); return
        if not isinstance(hd, dict):
            self.log("⚠️ 매도 체결확인 — 잔고조회 실패, 다음 틱 재시도"); return
        held = {x.get("code"): int(x.get("qty") or 0) for x in (hd.get("stocks") or [])}
        changed = False
        for o in due:
            sp = o["sell_pending"]; h = int(held.get(o["code"], 0) or 0)
            if h <= 0:
                o.pop("sell_pending", None); changed = True; continue
            if time.time() - (sp.get("ts") or 0) < 600:
                if not sp.get("warned"):
                    sp["warned"] = True; changed = True
                    self.log(f"  ⏳ 매도 미체결 {o['name']} — 잔량 {h}주(VI·거래정지 가능 · 주문은 살아있음)")
                    self.tg(f"⏳ 매도 미체결 {o['name']} — {sp.get('qty')}주 중 {h}주 남음\n"
                            f"VI(변동성완화) 등으로 지연 중일 수 있습니다.\n10분 뒤에도 남으면 기록을 되돌립니다.")
                continue
            sold_real = max(0, int(sp.get("qty") or 0) - h)
            self._unrecord_sell(o, sold_real)
            o["sold"] = max(0, o.get("filled", 0) - h)
            o["sell_stuck"] = True; o.pop("sell_pending", None); o.pop("tp_placed", None); changed = True
            self.log(f"  🛑 매도 미체결 확정 {o['name']} — 잔량 {h}주 · 실제매도 {sold_real}주 → 기록 보정 · 신규주문 중지")
            self.tg(f"🛑 매도가 체결되지 않았습니다 — {o['name']}\n"
                    f"잔량 {h}주 (실제 매도 {sold_real}주)\n\n"
                    f"· 기록을 사실에 맞게 고쳤습니다\n"
                    f"· 이미 낸 매도주문이 살아 있을 수 있어 **새 주문은 내지 않습니다**\n"
                    f"· 키움에서 주문 상태를 직접 확인하세요")
        if changed:
            savej(STATE, self.state); self._ensure_real(force=True)

    def _unrecord_sell(self, o, sold_real):
        """★_verify_sells 전용 — 오늘 그 종목의 마지막 기록을 실제 체결수량에 맞춘다(0이면 삭제)."""
        today = self._t(); lst = self.state.setdefault("trades", [])
        for i in range(len(lst) - 1, -1, -1):
            r = lst[i]
            if r.get("date") != today or r.get("code") != o.get("code"): continue
            if sold_real <= 0: del lst[i]
            else:
                r["qty"] = sold_real
                r["pl"] = round((r.get("sell", 0) - r.get("buy", 0)) * sold_real)
            return

    def _reconcile_sells(self):
        """★매도 실체결가 보정 — 라이브 기록가(트리거 시점)를 키움 실제 체결가(chejan FID910)로 갱신(관리자 동일). fills 없으면 no-op."""
        fills = getattr(self.kw, "fills", []) or []
        today = self._t(); changed = False
        _jr = None; _jr_tried = False                                # 당일매매일지 — 한 회차에 한 번만
        for rec in self.state.get("trades", []):
            if rec.get("real_fill") or rec.get("date") != today: continue
            f = next((x for x in reversed(fills)
                      if x.get("code") == rec.get("code") and "매도" in (x.get("otype", "") or "") and (x.get("fill_price") or 0) > 0), None)
            fp = int(f["fill_price"]) if f else 0
            if not fp and not _jr_tried:
                # ★폴백 — 체결통보에 단가(FID910)가 안 오는 경우가 있다. **정정을 거치면** 그렇다.
                #   관리자에서 티이엠씨가 이래서 원장에 트리거 시점가가 `real_fill=False` 로 남았다
                #   (실제 체결가가 아니다). 그러면 수익률이 추정값 위에 세워진다.
                #   → 당일매매일지(opt10170)의 **매도금액 ÷ 수량 = 실제 평균 체결단가**로 받친다.
                #   ★이 함수는 20초 틱마다 돈다 → 2분 게이트로 묶지 않으면 TR 이 폭주한다.
                #   ★매도금액은 '당일 그 종목 전체'다(하루 1회 청산이라 해당 없음. 부분체결은 평균가로 정확해진다).
                _jr_tried = True
                if time.time() - float(getattr(self, "_jr_ts", 0) or 0) >= 120:
                    self._jr_ts = time.time()
                    try:
                        _jr = {r["code"]: r for r in (self.kw.today_journal(self.cfg["account"]) or [])
                               if isinstance(r, dict) and r.get("code")}
                    except Exception as e:
                        _jr = {}; self.log(f"당일매매일지 조회 실패 — 실체결가 보정 보류 {e}")
            if not fp and _jr:
                _j = _jr.get(rec.get("code")); _q = rec.get("qty") or 0
                if _j and _j.get("sell_amt") and _q > 0:
                    fp = int(round(_j["sell_amt"] / _q))
            if not fp: continue                                      # 아직 확인 불가 → 다음 회차에 다시 본다
            buy = rec.get("buy") or 0; old = rec.get("sell")
            if buy and fp != old:
                rec["sell"] = fp; rec["ret"] = round((fp / buy - 1) * 100, 2); rec["pl"] = round((fp - buy) * (rec.get("qty") or 0))
                self.log(f"  📝 매도 실체결가 보정 {rec.get('name')} 기록 {old:,}→실제 {fp:,} ({rec['ret']:+.2f}%)")
            rec["real_fill"] = True; changed = True
        if changed: savej(STATE, self.state)

    def cur(self, code):
        try:
            rp = getattr(self.kw, "real_prices", None)
            if rp and rp.get(code): return rp[code]
            info = self.kw.basic(code); return (_int(info.get("현재가")) or None) if info else None
        except Exception: return None

    def _routine_checklist(self):
        """오늘 루틴 진행 체크리스트 HTML — 현재 단계 🔵강조(관리자와 동일 UI)."""
        run = self.cfg.get("enabled"); conn = self.connected; hm = self._hm()
        def item(state, label):
            ic = {"done": "✅", "cur": "🔵", "pend": "⚪", "fail": "⚠️"}[state]
            col = {"done": "#eafcff", "cur": "#22c55e", "pend": "#8b93a7", "fail": "#ef4444"}[state]
            return f"<span style='color:{col}'>{ic} {label}</span>"
        held = [o for o in self.state.get("positions", []) if o.get("filled", 0) - o.get("sold", 0) > 0]
        try: uname = f" · {self.kw.user_name()}" if conn else ""
        except Exception: uname = ""
        L = [
            item("done" if self._licensed else "fail", "관리자 승인" + ("" if self._licensed else f" ({self._lic_status})")),
            item("done" if self._hub_ok else "pend", "관리자 연결(픽 수신)"),
            item("done" if run else "pend", "자동매매 가동" + ("" if run else " (정지)")),
            item("done" if conn else "pend", "키움 로그인" + uname),
            item("done" if self._real_on else "pend", f"실시간 감시 {len(held) if self._real_on else 0}종목 · 보유 {len(held)}"),
            "<span style='color:#163540'>──────────</span>",
        ]
        def stage(label, a, b, done=False):
            if done or hm >= b: return item("done", label)
            if a <= hm < b: return item("cur", label + "  ◀ 진행중")
            return item("pend", label)
        # ★시각·퍼센트를 박지 않는다 — 설정을 바꾸면 화면이 거짓말이 된다(2026-09-18).
        #   예전엔 '±3%' 라고 적어 뒀는데 실제 설정은 익절 6% · 손절 -3.5% 였다.
        _tp = float(self.cfg.get("tp_pct", 6)); _sl = -abs(float(self.cfg.get("sl_pct", -3.5)))
        _by, _cv, _rc, _dn = self._routine_hm()
        L.append(stage(f"{LOGIN_HM} 장전 접속 대기", LOGIN_HM, MANAGE_OPEN))
        L.append(stage(f"{MANAGE_OPEN}~{MANAGE_CLOSE} 보유 손익절(익절 +{_tp:g}% · 손절 {_sl:g}%)",
                       MANAGE_OPEN, MANAGE_CLOSE))
        L.append(stage(f"{MANAGE_CLOSE} 전일 보유 종가청산", MANAGE_CLOSE, CLOSE_END))
        L.append(stage(f"{_by} 관리자 픽 → 지정가 종가매수", _by, _cv, done=self.bought_today))
        L.append(stage(f"{_cv} 미체결→시장가전환", _cv, _rc,
                       done=getattr(self, "converted_today", False)))
        L.append(stage(f"{_rc} 실잔고 체결보정", _rc, _dn,
                       done=(getattr(self, "_recon_date", "") == self._t())))
        if not self.cfg.get("is_mock") and self.cfg.get("aftp_live"):
            L.append(stage(f"{AFTP_START}~{AFTP_END} 애프터마켓 손익절", AFTP_START, AFTP_END))
        L.append(item("done" if hm >= OP_END else "pend",
                      f"{OP_END} 프로그램 종료(다음 평일 {OP_START} 재시작)"))
        return "<br>".join(L)

    def _pick_score(self, s):
        sc = s.get("score")
        if sc is None and ba and s.get("feat"):
            try: sc = ba.score(s["feat"])
            except Exception: sc = None
        return sc

    def _picks_html(self):
        """깃허브 최근 추천종목 HTML — 매력도순, 체결강도·상한가·선정 표시(매수 전에도 표시).
        ★오늘 날짜 픽만 표시 — 오래된 픽(어제 이전)은 '오늘 추천 종목 없음' 처리(매수 날짜가드와 일치)."""
        pj = self._picks or {}
        if pj.get("date") != self._t():                       # ★오늘 픽 아니면 stale 종목 표시 안 함
            return f"<span class=muted>📭 오늘 추천 종목 없음 — 관리자 15:20 스캔·깃허브 배포 후 표시<br>(마지막 배포일: {pj.get('date') or '—'})</span>"
        for s in pj.get("stocks", []): s["_sc"] = self._pick_score(s)
        stocks = sorted(pj.get("stocks", []), key=lambda s: -(s.get("_sc") or -1))
        if not stocks:
            return "<span class=muted>추천 종목 대기 중 — 관리자 15:20 스캔 후 깃허브에서 자동 표시</span>"
        L = [f"<span class=muted>{pj.get('date','')} · {len(stocks)}종목 · 매력도순 · 생성 {pj.get('generated','')}</span>"]
        for i, s in enumerate(stocks):
            sc = s.get("_sc"); ub = s.get("unbuyable"); f = s.get("feat") or {}; ch = f.get("chegang")
            sel = " <span style='color:#f5b53d'>★선정</span>" if s.get("kind") == "선정" else ""
            ubt = " · <span style='color:#f5b53d'>🔴상한가(내일 시가매수)</span>" if ub else ""
            grd = "🔥" if (sc or 0) >= 85 else ("👍" if (sc or 0) >= 65 else "")
            cht = (f" · 체결강도 <b style='color:{UP if (ch or 0) >= 100 else DN}'>{ch:.0f}</b>" if ch is not None else "")
            thb = (f" · <span style='color:#f5b53d;font-weight:700'>⭐테마+{s.get('theme_bonus')}</span>"
                   + (f"<span class=muted>({f.get('theme')} {s.get('theme_chg'):+.1f}%·{s.get('theme_rank')}위)</span>" if s.get('theme_chg') is not None and f.get('theme') else "")
                   if s.get('theme_bonus') else "")
            L.append(f"{i+1}. <b>{s.get('name','')}</b> {int(s.get('entry') or 0):,}원 · 매력도 <b style='color:{CYAN}'>{sc if sc is not None else '—'}</b>{grd}{cht}{thb}{sel}{ubt}")
        return "<br>".join(L)

    # ═══ 화면 갱신 ═══
    def refresh(self):
        try: self._update_status()
        except Exception: pass
        run = self.cfg.get("enabled")
        if hasattr(self, "lic_lbl"):
            if self._licensed: self.lic_lbl.setText(f"<b style='color:#22c55e'>✅ 승인됨</b> · 만료 {self._lic_expiry}")
            else: self.lic_lbl.setText(f"<b style='color:#F0455C'>⛔ 미승인</b> · {self._lic_status} — 닉네임/서버 저장 후 [승인 요청]")
        _wait = False
        try: _wait = self._waiting_market()
        except Exception: pass
        if run:     self.btn_go.setText("⏹  자동매매 정지")
        elif _wait: self.btn_go.setText("⏳  장 시간 대기 — 평일 08:30 자동시작 (눌러서 예약취소)")
        else:       self.btn_go.setText("▶  자동매매 시작")
        self.btn_go.setStyleSheet("#gobtn{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 %s,stop:1 %s);}" %
                                  (("#22c55e", "#15803d") if run else
                                   (("#b7791f", "#8a5a12") if _wait else ("#7c3aed", "#6321c9"))))
        mock = self.cfg.get("is_mock", True)
        onm = "#modebtn{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #22c55e,stop:1 #15803d);color:#fff;border:1px solid #22c55e;border-radius:11px;padding:9px 12px;font-weight:800;}"
        onr = "#modebtn{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #ef4444,stop:1 #b91c1c);color:#fff;border:1px solid #ef4444;border-radius:11px;padding:9px 12px;font-weight:800;}"
        off = "#modebtn{background:#171525;color:#8b93a7;border:1px solid #2c2748;border-radius:11px;padding:9px 12px;font-weight:800;}"
        self.btn_mock.setStyleSheet(onm if mock else off)
        try: self._refresh_login_mode()    # ★로그인 서버 카드 상태
        except Exception: pass
        try: self._refresh_acct_card()     # ★💰 계좌 현재자산(관리자 동일)
        except Exception: pass
        try: self._refresh_aftp()          # ★애프터마켓 스위치 상태(모의면 못 켜게)
        except Exception: pass
        try: self._refresh_lsq()           # ★💰 실자산 기준 — 어긋나면 버튼 글자가 알려준다
        except Exception: pass
        self.btn_real.setStyleSheet(onr if not mock else off)
        trades = self.state.get("trades", [])
        fee = float(self.cfg.get("fee_pct", 0.23))                   # ★왕복 수수료 반영(관리자 동일 net)
        cum = 0.0; curve = [0.0]
        for t in trades: cum += t.get("ret", 0) - fee; curve.append(round(cum, 2))
        wins = sum(1 for t in trades if (t.get("ret", 0) - fee) > 0); wr = round(wins / len(trades) * 100) if trades else 0
        self.spark.setData(curve); self.chart_sub.setText(f"{len(trades)}거래 · 누적 {cum:+.1f}%")
        self.gauge.setPct(wr)
        self.ret_big.setText(f"{cum:+.1f}%"); self.ret_big.setStyleSheet(f"color:{UP if cum>=0 else DN};font-size:30px;font-weight:900")
        self.ret_sub.setText(f"{len(trades)}거래 · 승 {wins} / 패 {len(trades)-wins}")
        held = [o for o in self.state.get("positions", []) if o.get("filled", 0) - o.get("sold", 0) > 0]
        rpc = getattr(self.kw, "real_prices", {}) or {}
        def hrow(o):
            r = o.get("cur_ret", 0.0); c = UP if r >= 0 else DN
            px = o.get("cur_px") or rpc.get(o["code"]) or (o.get("avg") or o.get("price") or 0)
            live = " <span style='color:#22c55e'>●</span>" if self._real_on and rpc.get(o["code"]) else ""
            return f"• {o['name']}  {o.get('filled',0)}주  <b>{px:,}</b>  <b style='color:{c}'>{r:+.2f}%</b>{live}"
        rows = [hrow(o) for o in held]; hcodes = {o["code"] for o in held}
        for s in (self.acct or {}).get("stocks", []):        # 실제 계좌보유(state 밖)도 표시
            if s.get("code") not in hcodes and s.get("qty", 0) > 0:
                r = s.get("ret", 0.0); c = UP if r >= 0 else DN
                rows.append(f"• {s.get('name','')}  {s.get('qty',0)}주  <b>{int(s.get('cur') or 0):,}</b>  <b style='color:{c}'>{r:+.2f}%</b> <span style='color:#f5b53d'>(계좌)</span>")
        self.hold_box.setText("<br>".join(rows) or "없음")
        today = [t for t in trades if t.get("date") == self._t()]
        def trow(t): return f"• {t['name']}  {t.get('buy',0):,}→{t.get('sell',0):,}  <b style='color:{UP if t['ret']>=0 else DN}'>{t['ret']:+.2f}%</b>"
        self.today_box.setText("<br>".join(trow(t) for t in reversed(today)) or "없음")
        self.all_box.setText("<br>".join(f"{t.get('date','')[5:]} " + trow(t) for t in reversed(trades[-30:])) or "없음")
        try: self.routine_box.setText(self._routine_checklist())   # ★루틴 체크리스트
        except Exception: pass
        try: self.picks_box.setText(self._picks_html())            # ★추천종목(깃허브)
        except Exception: pass
        # 📒 거래내역 탭 — 보고 있을 때만 다시 그린다(카드를 매번 새로 만들면 무겁다)
        if getattr(self, "_cur", "dash") == "hist":
            try: self._refresh_history()
            except Exception as e: self.log(f"거래내역 갱신 오류 {e}")

    def _watch_disconnect(self):
        """미접속 1분↑ 시 텔레그램 경보(복구는 _restart_process 즉시재시작이 담당)."""
        now = datetime.datetime.now()
        if self._disc_since is None: self._disc_since = now
        elif (now - self._disc_since).total_seconds() >= 60 and not self._disc_alerted:
            self._disc_alerted = True
            self.log("⚠️ 키움 미접속 1분↑ — 텔레그램 경보 + 복구 시도"); self.tg("⚠️ 키움 미접속 1분 경과 — 자동 복구 시도 중")

    def _place_afterhours_tp(self):
        """★애프터마켓 익절 지정가(16:00~20:00) — 관리자 admin._place_afterhours_tp 와 같은 규칙.

        2026-09-14 제도변경: 시간외단일가(16~18시·10분 단일가)가 폐지되고 KRX 애프터마켓
        (16:00~20:00 접속매매 · 가격제한 전일종가 ±30% · 지정가만, 시장가 불가)이 생겼다.

        규칙
          · 여기서는 익절 지정가만 미리 건다. 손절은 _watch_afterhours 가 지켜보다가 낸다
            (손절가에 매도 지정가를 미리 걸면 현재가에 **즉시 체결**된다 — 예약이 안 된다).
          · 익절가는 매수가 기준 설정 익절% (수수료 무관 — 정규장과 같은 목표).
          · 미체결이면 그대로 둔다. 주문은 20:00 소멸, 다음날 정규장에서 평소대로 손익절.
          · 모의계좌는 애프터마켓 불가 → 실서버로 확인될 때만 발주.
        중복발주는 날짜(aftp_day)로 막는다(메모리 플래그는 재기동마다 풀려 이중발주가 난다)."""
        today = self._t()
        pos = [o for o in self.state.get("positions", [])
               if not o.get("open_buy") and (o.get("filled", 0) - o.get("sold", 0)) > 0
               # ★하루 1회가 원칙이지만 **수량이 바뀌었으면 다시 건다** (2026-09-22 관리자분 이식).
               #   외부 추가매수로 70주 → 338주가 됐는데 익절 예약이 70주에 머물면 268주가 무방비다.
               and (o.get("aftp_day") != today
                    or int(o.get("aftp_qty") or 0) != (o.get("filled", 0) - o.get("sold", 0)))
               and not o.get("sell_stuck")]          # ★잠긴 종목엔 안 건다
        if not pos: return
        # ★★이미 **살아있는 매도주문**이 있는 종목은 건너뛴다 (2026-09-22 관리자분 이식).
        #   사용자가 영웅문·MTS 에서 직접 매도를 걸어 둘 수 있다. 여기서 또 걸면 같은 물량에
        #   매도주문이 **둘**이 되고, 둘 다 체결되면 **없는 주식을 판다.**
        #   ★조회 실패면 건너뛰지 않는다 — '모르니까 전부 막는다' 로 하면 조회가 한 번 실패한 날
        #     익절 예약이 통째로 빠진다. 그때는 아래 발주가 키움의 잔고검증에 걸린다.
        try: _pd = self.kw.pending(self.cfg["account"])
        except Exception: _pd = None
        if isinstance(_pd, list):
            _live = {p.get("code") for p in _pd if isinstance(p, dict)
                     and "매도" in (p.get("gubun") or "") and int(p.get("unfilled") or 0) > 0}
            if _live:
                _lg = getattr(self, "_aftp_skip_lg", None)
                if _lg is None: _lg = self._aftp_skip_lg = set()
                for o in pos:
                    if o.get("code") in _live and (today, o["code"]) not in _lg:
                        _lg.add((today, o["code"]))      # 20초 틱마다 도배되지 않게 하루 1회
                        self.log(f"  🌙 {o['name']} 애프터 익절 건너뜀 — 이미 살아있는 매도주문이 있습니다(이중매도 방지)")
                pos = [o for o in pos if o.get("code") not in _live]
        if not pos: return
        srv = ""
        try: srv = (self.kw.server_gubun() or "")     # '1'=모의 / '0'=실서버 / ''=판정불가
        except Exception: srv = ""
        # ★공백이면 로그인 때 계좌번호로 가린 판정을 쓴다(_verify_live_env 가 남겨 둔 값). 2026-09-17
        #   관리자에서 server_gubun 이 공백을 주는 일을 실제로 확인했다(하루 3번).
        srv_live = (srv == "0") if srv in ("0", "1") else getattr(self, "_srv_live", None)
        if srv == "" and srv_live is True and getattr(self, "_aftp_srvlog", "") != today:
            self._aftp_srvlog = today
            self.log("🌙 서버구분이 공백 — 로그인 때 계좌번호로 판정한 '실서버'를 씁니다")
        live = bool(self.cfg.get("aftp_live")) and not self.cfg.get("is_mock") and srv_live is True
        if not live:
            why = ("설정 aftp_live 꺼짐" if not self.cfg.get("aftp_live")
                   else "모의모드" if self.cfg.get("is_mock")
                   else ("서버 판정불가(server_gubun 공백 + 로그인 판정도 없음) — 발주 보류"
                         if srv_live is None else "모의서버 접속중"))
            if getattr(self, "_aftp_log_date", "") != today:      # 하루 한 줄만
                self._aftp_log_date = today
                self.log(f"🌙 애프터마켓 익절: 발주 안 함({why}) — 보유 {len(pos)}종목 관찰만")
            return                                                # ★봉인하지 않는다 — 나중에 켜면 그날 바로 걸린다
        acc = self.cfg["account"]; tp = self.cfg["tp_pct"]
        hoga = str(self.cfg.get("aftp_hoga", "00"))               # "00"=지정가. 옛 "62"는 폐지됐다
        done = 0; changed = False
        for o in pos:
            code = o["code"]; rem = o["filled"] - o.get("sold", 0)
            base = o.get("avg") or o.get("price") or 0
            if base <= 0: continue
            otp = st.UPPER_TP if o.get("unbuyable") else tp
            tp_px = self._tick_round(round(base * (1 + otp / 100)))
            # ★가격제한 검사 — **당일 상한가**와 비교한다. (2026-09-29 관리자 2026-09-22 분 이식)
            #   예전엔 `당일 종가 x 1.3` 과 비교했다. 그게 틀렸다 —
            #   가격제한은 **전일 종가** ±30% 다. 오늘 이미 오른 만큼은 여유에서 빠져 있다.
            #   관리자가 실제로 당했다(2026-09-21 티이엠씨): 종가 12,670(+23.49%) · 상한가 13,338 인데
            #   익절가 13,750 을 걸려다 "[571551] 주문단가가 상한가를 초과합니다" 로 거부됐다.
            #   검사식은 12,670x1.3 = 16,471 이라 통과시켜 버렸다 → 발주가 거부되고
            #   `aftp_day` 가 안 찍혀 20초마다 재시도만 반복한다(그날 익절 예약이 통째로 빠진다).
            #   opt10001 이 **상한가를 직접 준다** — 그걸 쓴다. 조회 실패 시에만 옛 방식으로 되돌린다.
            _up = 0
            try: _up = abs(int((self.kw.basic(code) or {}).get("상한가") or 0))
            except Exception: _up = 0
            ref = o.get("cur_px") or base                         # 당일 종가 근사 = 정규장 마지막 시세
            lim = _up if _up > 0 else int(ref * 1.3)              # 조회 실패면 옛 근사(보수적이지 않음 — 로그에 남긴다)
            if tp_px > lim:
                # ★`aftp_qty` 도 같이 찍어야 한다 — 안 찍으면 '수량이 바뀌었다' 로 보여
                #   20초마다 이 경로를 무한 반복한다(재예약 조건을 넣으면서 생긴 함정).
                o["aftp_day"] = today; o["aftp_qty"] = rem; changed = True
                self.log(f"  🌙 {o['name']} 익절가 {tp_px:,} > 상한가 {lim:,}"
                         f"{'' if _up > 0 else '(추정)'} — 안 걸음(내일 정규장에서 처리)")
                continue
            if self.kw.send_order(acc, code, rem, tp_px, 2, hoga) == 0:
                o["aftp_day"] = today; o["aftp_px"] = tp_px; o["aftp_qty"] = rem
                done += 1; changed = True
                self.log(f"  🌙 애프터마켓 익절 예약 {o['name']} {rem}주 @{tp_px:,}(+{otp:g}%·20시까지)")
            else:
                self.log(f"  ⚠️ 애프터마켓 익절 예약 실패 {o['name']} — 다음 틱에 재시도")
        if changed: savej(STATE, self.state)
        if done:
            self.tg(f"🌙 애프터마켓 익절 예약 {done}종목(16~20시)\n"
                    f"손절은 주문을 미리 걸지 않고 프로그램이 지켜보다가 닿으면 냅니다"
                    f"(매도 지정가를 손절가에 미리 걸면 즉시 체결돼 버립니다).")

    def tick(self):
        if getattr(self, "_tick_busy", False): return        # ★재진입 방지
        # ★계좌 잔고 갱신은 **모든 게이트보다 앞**에 둔다. (2026-09-18)
        #   매매 여부(enabled)와도, 운영시간과도 무관하다 — 접속만 돼 있으면 숫자는 살아 있어야 한다.
        #   ★어제는 enabled 게이트 앞으로만 옮겼는데 그 **위의 운영시간 게이트**를 못 봤다.
        #     그래서 밤에 켜 두면 잔고를 한 번도 안 읽어 카드가 계속 '조회 실패' 로 떴다(실제 신고).
        try:
            if getattr(self, "connected", False): self._refresh_balance()
        except Exception: pass
        try:
            self._check_license_expiry()          # ★승인 만료 임박 알림(하루 한 번·비모달) — 매매 게이트 앞
        except Exception: pass
        try:
            self._check_autostart_task()          # ★아침 자동실행 예약작업 확인(하루 한 번)
        except Exception: pass
        if AUTO:
            if not self._operating():                        # ★평일 08:20~20:20 밖(야간·주말)
                self._night_idle(); return
            self._was_op = True                              # ★이번 실행에서 운영시간을 지나왔다(= 하루를 돈 것)
            self._daily_resume()                             # ★운영시간 진입 → 그날 한 번 스스로 로그인
        if not self.cfg.get("enabled"): return
        self._tick_busy = True
        try:
            if self._popup_n > self._popup_reported:               # ★키움 통신끊김 팝업 자동확인 발생 → 보고(끊김 신호)
                self._popup_reported = self._popup_n
                self.log(f"🧹 키움 통신끊김 팝업 자동확인({self._popup_n}회) — 재접속 진행")
                self.tg("🧹 키움 '통신연결 끊김' 팝업 자동처리 → 재접속 시도 중")
            if self.connected:                                     # ★실제 OCX 연결상태 능동 확인(silent disconnect 감지)
                try:
                    if int(self.kw.dynamicCall("GetConnectState()")) != 1: self.connected = False
                except Exception: self.connected = False
            if not self.connected:
                if self._logging_in: return                       # 로그인 진행 중이면 대기(중복 재시작 방지)
                if AUTO: self._restart_process("접속 끊김 — 즉시 재시작")     # ★무인(auto)만: 끊기면 바로 프로세스 재시작
                else: self._watch_disconnect()                    # 수동실행은 경보만(사용자가 직접 재접속)
                return
            self._disc_since = None; self._disc_alerted = False    # 연결 정상 복구
            self._ensure_real()   # ★보유종목 실시간 시세 항상 유지(HTS처럼 실시간 반영)
            self._reconcile_sells()   # ★매도 실체결가로 거래기록 보정(라이브=실제)
            try: self._verify_sells()  # ★매도가 진짜 체결됐는지 잔고로 검증(VI·거래정지 대비)
            except Exception as e: self.log(f"매도 체결확인 오류 {e}")
            if MANAGE_OPEN <= self._hm() <= "15:45" and time.time() - getattr(self, "_sync_ts", 0) >= 300:
                self._sync_ts = time.time()                 # ★5분 간격(TR 제한 보호)
                try: self._sync_account_ledger()            # ★외부(영웅문·MTS) 청산 자동 반영
                except Exception as e: self.log(f"계좌동기화 오류 {e}")
            if self.state.get("buy_date") != self._t(): self.bought_today = False
            if self._upper_date != self._t():
                self._upper_date = self._t(); self.state["upper_today"] = []   # ★상한가 표시 일일리셋
                self._clear_sell_stuck()   # ★미체결 매도잠금 해제(당일 주문은 장 마감에 자동취소되므로 새 날엔 살아있는 주문이 없다)
            hm = self._hm()
            self._report(hm)                                              # ★장전·장시작·매시·마감 텔레그램(관리자 동일)
            # ★루틴 시각은 모드마다 다르다 — 실계좌는 애프터마켓 종가(20:00) 기준(2026-09-17)
            _by, _cv, _rc, _dn = self._routine_hm()
            if MANAGE_OPEN <= hm < MANAGE_CLOSE:                          # 09:00~15:19 보유 손익절(관리자 동일)
                if self.state.get("open_pending"): self._buy_open_pending()   # ★09:00+ 상한가 예약분 시가매수
                try: self._gapcut()                                       # ★09:00 시가 갭컷(관리자 동일)
                except Exception as e: self.log(f"갭컷 오류 {e}")
                self.manage()
            elif MANAGE_CLOSE <= hm < CLOSE_END:                          # 15:19 강제청산(모드 무관)
                self.close_all()
            elif _by <= hm < _cv and not self.bought_today:               # 지정가 매수
                self.buy_picks()
            elif _cv <= hm < _rc and self.bought_today and not self.converted_today:   # 미체결 처리
                self._convert_unfilled_market()
            elif _rc <= hm < _dn and self._recon_date != self._t():       # 실잔고 체결보정(1일1회)
                self._recon_date = self._t(); self._reconcile_positions()
            # ★청산 보장(2026-09-28) — **elif 사슬 밖**에 둔다. 매수(15:25~)가 그 자리를 차지하면
            #   안에 넣었을 때 아예 안 돈다. 종가 동시호가가 끝나기(15:30) 전에 청산을 마무리해야 한다 —
            #   놓치면 그날 청산이 실패하고 다음날로 넘어간다.
            if CLOSE_END <= hm < "15:29": self._ensure_closeout()
            # ★애프터마켓 익절 지정가 예약(16:00~20:00) — 실계좌 + 설정에서 켠 경우만 실주문.
            #   익절은 미리 지정가로 걸고, 손절은 _watch_afterhours 가 지켜보다가 닿으면 낸다.
            if AFTP_START <= hm < AFTP_END and self.state.get("positions"):
                self._place_afterhours_tp()
                self._watch_afterhours()        # ★손절·익절 감시(2026-09-18) — 닿으면 호가 아래 지정가로 즉시체결
            if hm in ("09:01", "15:18"): self.query_account()   # ★잔고 갱신은 tick 머리로 옮겼다(enabled 와 무관하게)
        except Exception as e: self.log(f"루프 오류 {e}")
        finally:
            self._tick_busy = False                          # ★재진입 가드 해제(예외 시에도 반드시)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    try: QFontDatabase()
    except Exception: pass
    w = Client()
    if getattr(w, "_dup_exit", False):      # ★이미 실행 중 — 빈 창을 띄우지 않고 바로 나간다
        sys.exit(0)
    w.show()
    # ★여기부터는 '시작 실패' 가 아니다 — 화면에서 난 예외로 프로그램을 끄지 않는다(2026-09-17)
    _GUI[0] = w
    _UI_READY[0] = True
    sys.exit(app.exec_())
