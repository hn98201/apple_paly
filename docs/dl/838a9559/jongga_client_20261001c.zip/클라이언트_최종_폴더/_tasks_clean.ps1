﻿# 옛 설치가 남긴 예약작업을 지운다. (2026-09-17)
#
# 증상: 2분마다 'Windows Script Host — run_watchdog.vbs 을(를) 찾을 수 없습니다' 오류창
# 원인: 2026-09-16 부터 클라이언트는 예약작업을 쓰지 않는다. 그런데 그 전에 깔았던 PC 에는
#       `종가배팅_클라이언트감시`(2분마다)가 남아, 이미 지워진 파일을 계속 찾는다.
$ErrorActionPreference = "Continue"
Write-Host ""
Write-Host "  옛 예약작업 정리" -ForegroundColor Cyan
Write-Host "  ------------------------------------------------"
# ★존재 확인은 `schtasks /Query` 로 한다 — `Get-ScheduledTask -TaskName` 은 **건당 6초**다
#   (2026-09-29 실측: 2건 12,768ms vs schtasks 2건 1,556ms). 이건 "뭔가 안 될 때" 쓰는 도구라
#   빨리 대답하는 게 특히 중요하다. _uninstall.ps1 이 같은 이유로 이미 이 패턴을 쓴다.
function TaskExists($n) { schtasks /Query /TN $n 2>$null | Out-Null; return ($LASTEXITCODE -eq 0) }
$n = 0
$failed = @()      # ★이름 아는 작업의 실패도 센다 — 안 세면 빨간 [실패] 아래에 초록 '지울 게 없었습니다' 가 찍혔다(검토 반영)
foreach ($t in @('종가배팅_클라이언트감시','종가배팅_클라이언트시작')) {
    if (TaskExists $t) {
        schtasks /Delete /TN $t /F | Out-Null
        if (TaskExists $t) {
            $failed += $t
            Write-Host "  [실패] $t — 관리자 권한이 필요합니다" -ForegroundColor Red
            Write-Host "         이 파일을 마우스 오른쪽 > [관리자 권한으로 실행] 해 주세요" -ForegroundColor Yellow
        } else {
            Write-Host "  [제거] $t" -ForegroundColor Green; $n++
        }
    } else {
        Write-Host "  [없음] $t"
    }
}
# ★이름을 모르는 작업도 실행 경로로 찾는다 (2026-10-01 · 실사고).
#   다른 PC 에서 사람이 따로 만든 `JonggaClientGuardian`(2분 감시)이 이름이 바뀐 옛 폴더를 계속 찾으며
#   같은 오류창("스크립트 파일을 찾을 수 없습니다")을 2분마다 띄웠다. 위 두 이름만 보면 못 잡는다.
#   찾는 규칙은 _tasks_scan.ps1 머리말에 있다. JonggaClientRun(지금 쓰는 작업)은 건드리지 않는다.
$scanFile = Join-Path $PSScriptRoot "_tasks_scan.ps1"
if (Test-Path -LiteralPath $scanFile) {
    . $scanFile
    Write-Host ""
    Write-Host "  옛 경로를 가리키는 예약작업 찾는 중..." -ForegroundColor Cyan
    $isAdminC = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
                  [Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $isAdminC) {
        Write-Host "  (일반 권한이라 시스템·다른 계정의 작업은 안 보입니다 — 다 보려면 마우스 오른쪽 > 관리자 권한으로 실행)" -ForegroundColor DarkGray
    }
    $stale = Find-JgStaleTasks (Get-JgTaskList) @() ((Resolve-Path -LiteralPath $PSScriptRoot).Path) @('JonggaClientRun')
    if ($stale.Count -eq 0) { Write-Host "  [없음] 옛 경로를 가리키는 작업" }
    foreach ($s in $stale) {
        if (Remove-JgTask $s.Name (Join-Path $PSScriptRoot "_예약작업백업")) {
            Write-Host "  [제거] $($s.Name)  (백업: $JG_LAST_BACKUP)" -ForegroundColor Green; $n++
        }
        else {
            $failed += $s.Name
            Write-Host "  [실패] $($s.Name) — 관리자 권한이 필요합니다" -ForegroundColor Red
        }
        Write-Host "         └ $($s.Why)" -ForegroundColor DarkGray
    }
    if ($failed.Count -gt 0) {
        Write-Host "         이 파일을 마우스 오른쪽 > [관리자 권한으로 실행] 해 주세요" -ForegroundColor Yellow
    }
} else {
    Write-Host "  [경고] _tasks_scan.ps1 이 없어 옛 경로 작업 검사를 건너뜁니다" -ForegroundColor Yellow
}
Write-Host ""
if ($failed.Count -gt 0) {
    Write-Host "  지우지 못한 작업이 남았습니다 — 위 안내대로 관리자 권한으로 다시 실행하세요." -ForegroundColor Red
} elseif ($n -gt 0) {
    Write-Host "  끝났습니다. 이제 그 오류창이 뜨지 않습니다." -ForegroundColor Green
} else {
    Write-Host "  지울 예약작업이 없었습니다." -ForegroundColor Green
}
Write-Host ""
Write-Host "  참고: 지금 클라이언트가 쓰는 예약작업은 JonggaClientRun 하나뿐입니다."
Write-Host "        (평일 08:20 자동실행 · 최고권한 · 2분마다 도는 감시는 없습니다)"
Write-Host "        위에서 지운 것은 옛 버전·옛 경로 것입니다 - JonggaClientRun 은 지우지 마세요."
Write-Host "        감시 작업을 따로 만들 필요는 없습니다. 만들었다면 재설치 뒤 새 폴더를 가리키게 다시 만드세요."
Write-Host "        08:20 자동실행 -> 08:30 자동로그인 -> 15:25 종가매수 -> 20:20 종료."
