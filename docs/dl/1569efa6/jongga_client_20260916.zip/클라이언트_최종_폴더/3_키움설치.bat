@echo off
title Step 3 - Install Kiwoom OpenAPI
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0_kiwoom.ps1"
echo.
pause
