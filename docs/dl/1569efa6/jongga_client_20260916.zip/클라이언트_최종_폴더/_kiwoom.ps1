﻿$ErrorActionPreference = "Continue"
Write-Host "============================================"
Write-Host "  [3단계] 키움 OpenAPI+ 설치" -ForegroundColor Cyan
Write-Host "============================================`n"
Write-Host "키움 OpenAPI+ 는 키움증권 계좌가 있어야 사용할 수 있습니다."
Write-Host "설치본을 내려받아 실행합니다...`n"

$tmp = Join-Path $env:TEMP "OpenAPISetup.exe"
$ok = $false
foreach ($u in @("https://download.kiwoom.com/web/openapi/OpenAPISetup.exe",
                 "http://download.kiwoom.com/web/openapi/OpenAPISetup.exe")) {
    try {
        Invoke-WebRequest -Uri $u -OutFile $tmp -UseBasicParsing -TimeoutSec 60
        if ((Get-Item $tmp -ErrorAction SilentlyContinue).Length -gt 100000) { $ok = $true; break }
    } catch {}
}
if ($ok) {
    Write-Host "[OK] 다운로드 완료 → 설치를 실행합니다."
    Start-Process -FilePath $tmp -Wait
    Write-Host "[OK] 키움 OpenAPI+ 설치 완료"
} else {
    Write-Host "[안내] 자동 다운로드가 안 돼 키움 OpenAPI 페이지를 엽니다." -ForegroundColor Yellow
    Start-Process "https://www3.kiwoom.com/nkw.templateFrameSet.do?m=m1408000000"
    Write-Host "  페이지에서 'OpenAPI+' 모듈 설치본을 받아 설치하세요."
}

Write-Host "`n--------------------------------------------"
Write-Host "설치가 모두 끝났습니다. 마지막 순서:" -ForegroundColor Green
Write-Host "  1) 키움 로그인 1회 실행 → '자동로그인' 체크 + 계좌비밀번호 저장"
Write-Host "  2) 바탕화면 [▶ 종가배팅 클라이언트] 실행"
Write-Host "  3) 설정 탭에서 닉네임 입력 → [승인 요청] → 관리자 승인 대기"
Write-Host "  승인되면 매일 08:25 자동 시작 → 15:25 종가매수 → 다음날 손익절 (전부 자동)"
