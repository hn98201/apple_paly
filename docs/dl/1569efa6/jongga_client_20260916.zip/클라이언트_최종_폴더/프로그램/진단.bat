@echo off
title Jongga Client - Diagnosis
cd /d "%~dp0"
rem  Run with 32-bit python when available, but fall back to ANY python on
rem  purpose: if this PC only has 64-bit, the report has to be able to say so.
set "PY="
set "PYOK="
if exist "%~dp0python_path.txt" for /f "usebackq delims=" %%A in ("%~dp0python_path.txt") do set "PY=%%A"
if defined PY set "PY=%PY:pythonw.exe=python.exe%"
if defined PY if exist "%PY%" set "PYOK=1"
if defined PYOK goto :run
for %%V in (312 311 313 310) do (
  if not defined PYOK if exist "%LOCALAPPDATA%\Programs\Python\Python%%V-32\python.exe" (
    set "PY=%LOCALAPPDATA%\Programs\Python\Python%%V-32\python.exe"
    set "PYOK=1"
  )
)
if defined PYOK goto :run
py -3-32 jindan.py && exit /b
py jindan.py && exit /b
python jindan.py && exit /b
echo.
echo  [ERROR] No Python found on this PC.
echo          Run  [2_program-install.bat]  first.
echo.
pause
exit /b 1

:run
"%PY%" jindan.py
exit /b
