﻿$ErrorActionPreference = "Continue"
# run_client.bat 이 32비트 파이썬을 못 찾았을 때 — 조용히 죽지 않고 이유를 알린다.
# (예전에는 PATH 의 아무 파이썬으로 실행해 버려서, 64비트면 키움 OCX 가 안 올라오고
#  영문 AttributeError 트레이스백만 떴다. 2026-09-15)

$msg = @"
32비트 파이썬을 찾지 못했습니다.

키움 OpenAPI 는 32비트 파이썬에서만 동작합니다.
64비트로 실행하면 키움 접속 자체가 되지 않습니다.

고치는 법
  1) [2_프로그램설치.bat] 를 다시 실행하세요.
  2) 그래도 안 되면 python.org 에서
     'Windows installer (32-bit)' 3.12.x 를 직접 설치한 뒤
     [2_프로그램설치.bat] 를 다시 실행하세요.

자세한 점검은 이 폴더의 [진단.bat] 을 더블클릭하세요.
"@

try {
    $log = Join-Path $PSScriptRoot "실행오류.txt"
    [System.IO.File]::WriteAllText($log, $msg, [System.Text.Encoding]::UTF8)
} catch {}

try {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show($msg, "종가배팅 클라이언트 - 실행 불가", "OK", "Error") | Out-Null
} catch {
    Write-Host $msg
    Read-Host "엔터를 누르면 닫힙니다"
}
