@echo off
title Kiwoom Setup Check
cd /d "%~dp0"
set "PY="
if exist "%~dp0python_path.txt" for /f "usebackq delims=" %%A in ("%~dp0python_path.txt") do set "PY=%%A"
if defined PY set "PY=%PY:pythonw.exe=python.exe%"
if defined PY if exist "%PY%" ( "%PY%" kiwoom_check.py & exit /b )
if exist "%LOCALAPPDATA%\Programs\Python\Python312-32\python.exe" ( "%LOCALAPPDATA%\Programs\Python\Python312-32\python.exe" kiwoom_check.py & exit /b )
if exist "%LOCALAPPDATA%\Programs\Python\Python311-32\python.exe" ( "%LOCALAPPDATA%\Programs\Python\Python311-32\python.exe" kiwoom_check.py & exit /b )
py -3-32 kiwoom_check.py
if errorlevel 9009 python kiwoom_check.py
