﻿param([switch]$Elevated)
# 종가배팅 클라이언트 - 운영 스케줄 자동등록
# 평일 08:25 자동실행 + 2분마다 워치독(운영시간만 재실행)
# 프로그램 자체가 08:30 키움로그인 -> 17:00 종료 -> 야간/주말 종료를 자동 처리.
# ※ 관리자 승인(라이선스)이 되어 있어야 자동매매가 시작됩니다.
$ErrorActionPreference = "Continue"
$d    = $PSScriptRoot
$bat  = Join-Path $d 'run_client.bat'
$vbs  = Join-Path $d 'run_client.vbs'      # cmd창 없이 실행
$wvbs = Join-Path $d 'run_watchdog.vbs'    # 워치독도 무창(-WindowStyle Hidden 은 깜빡임을 못 막는다)
$wd   = Join-Path $d 'client_watchdog.ps1'
$T1   = '종가배팅_클라이언트시작'
$T2   = '종가배팅_클라이언트감시'

if (-not (Test-Path $bat)) { Write-Host "[오류] run_client.bat 없음: $bat" -ForegroundColor Red; return }
if (-not (Test-Path $wd))  { Write-Host "[오류] client_watchdog.ps1 없음: $wd" -ForegroundColor Red; return }

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
             [Security.Principal.WindowsBuiltInRole]::Administrator)

# ── 관리자가 아니면 딱 한 번 권한 상승을 요청한다 ────────────────────
#    최고 권한으로 등록해야 키움 버전업 UAC 창이 무인 상태에서 안 뜬다.
if (-not $isAdmin -and -not $Elevated) {
    Write-Host ""
    Write-Host "  키움이 버전 업데이트를 할 때 '사용자 계정 컨트롤(UAC)' 창을 띄웁니다." -ForegroundColor Yellow
    Write-Host "  사람이 없는 아침 8시 30분에 그 창이 뜨면 프로그램이 거기서 멈춥니다." -ForegroundColor Yellow
    Write-Host "  그걸 막으려면 예약작업을 '최고 권한'으로 등록해야 하고, 지금 한 번만 허용이 필요합니다."
    Write-Host "  -> 잠시 후 뜨는 파란 창에서 [예] 를 눌러 주세요." -ForegroundColor Cyan
    Write-Host ""
    try {
        Start-Process powershell -Verb RunAs -Wait -ArgumentList @(
            "-NoProfile","-ExecutionPolicy","Bypass","-File","`"$PSCommandPath`"","-Elevated")
        Write-Host "[OK] 최고 권한으로 등록했습니다"
        return
    } catch {
        Write-Host "[알림] 권한 상승을 건너뜁니다 - 일반 권한으로 등록합니다." -ForegroundColor Yellow
        Write-Host "       키움 버전업이 있는 날 아침에 UAC 창이 떠서 멈출 수 있습니다."
        Write-Host "       그때는 [2_프로그램설치.bat] 을 마우스 오른쪽 > [관리자 권한으로 실행] 하세요."
    }
}

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
             [Security.Principal.WindowsBuiltInRole]::Administrator)

# ── 1) 08:25 시작 (월~금) — auto 인자로 무인 생명주기 적용 ────────────
$run1 = 'wscript.exe "' + $vbs + '" auto'
if ($isAdmin) {
    schtasks /Create /TN $T1 /TR $run1 /SC WEEKLY /D MON,TUE,WED,THU,FRI /ST 08:25 /RL HIGHEST /F | Out-Null
} else {
    schtasks /Create /TN $T1 /TR $run1 /SC WEEKLY /D MON,TUE,WED,THU,FRI /ST 08:25 /F | Out-Null
}

# ── 2) 2분마다 워치독 (운영시간 판정은 client_watchdog.ps1 내부) ──────
if (Test-Path $wvbs) { $run2 = 'wscript.exe "' + $wvbs + '"' }
else { $run2 = 'powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $wd + '"' }
if ($isAdmin) {
    schtasks /Create /TN $T2 /TR $run2 /SC MINUTE /MO 2 /RL HIGHEST /F | Out-Null
} else {
    schtasks /Create /TN $T2 /TR $run2 /SC MINUTE /MO 2 /F | Out-Null
}

# ── 3) 전원·놓친작업 보정 ──────────────────────────────────────────
#    ★08:25 시작에는 **WakeToRun** 을 준다(2026-09-16).
#      클라이언트는 PC 를 재우는 작업이 없지만, Windows 가 알아서 절전에 들어간다.
#      그때 깨우지 못하면 그날 08:30 로그인도 15:25 매수도 통째로 날아간다.
#      감시(2분마다)는 깨우면 안 된다 — 밤새 2분마다 깨어난다.
foreach ($t in @($T1, $T2)) {
    try {
        $st = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
                -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero)
        if ($t -eq $T1) { $st.WakeToRun = $true }
        Set-ScheduledTask -TaskName $t -Settings $st | Out-Null
    } catch { Write-Host "[경고] $t 전원설정 보정 실패 (동작에는 지장 없음)" -ForegroundColor Yellow }
}

# ── 3-1) 전원 옵션 — 깨우기가 실제로 먹히게 (관리자 권한일 때만) ──
if ($isAdmin) {
    try {
        # 절전 모드 해제 타이머 허용 — 이게 꺼져 있으면 WakeToRun 이 무시된다
        powercfg /setacvalueindex SCHEME_CURRENT SUB_SLEEP BD3B718A-0680-4D9D-8AB2-E1D2B4AC806D 1 2>$null
        powercfg /setdcvalueindex SCHEME_CURRENT SUB_SLEEP BD3B718A-0680-4D9D-8AB2-E1D2B4AC806D 1 2>$null
        # 전원 연결 상태에서는 컴퓨터를 재우지 않는다(모니터는 꺼져도 됨) — 매매 PC 에는 이게 가장 확실
        powercfg /setacvalueindex SCHEME_CURRENT SUB_SLEEP STANDBYIDLE 0 2>$null
        powercfg /setacvalueindex SCHEME_CURRENT SUB_SLEEP HIBERNATEIDLE 0 2>$null
        powercfg /setactive SCHEME_CURRENT 2>$null
        Write-Host "[OK] 전원 옵션 보정 — 절전 해제 타이머 허용 · 전원 연결 시 절전 안 함"
    } catch { Write-Host "[경고] 전원 옵션 보정 실패 (수동으로 '컴퓨터를 절전 모드로' 를 '해당 없음' 으로)" -ForegroundColor Yellow }
} else {
    Write-Host "[알림] 일반 권한이라 전원 옵션은 못 바꿨습니다." -ForegroundColor Yellow
    Write-Host "       PC 가 혼자 절전에 들면 아침에 안 깨어납니다."
    Write-Host "       [2_프로그램설치.bat] 을 관리자 권한으로 다시 실행하면 자동으로 잡힙니다."
}

$lvl = (Get-ScheduledTask -TaskName $T1 -ErrorAction SilentlyContinue).Principal.RunLevel
Write-Host ""
Write-Host "[완료] 클라이언트 스케줄 등록됨" -ForegroundColor Green
Write-Host "  - $T1 : 평일(월~금) 08:25 자동실행"
Write-Host "  - $T2 : 2분마다 감시(운영시간만 재실행)"
if ("$lvl" -eq "Highest") {
    Write-Host "  - 권한: 최고 권한 (키움 버전업 UAC 창이 안 뜹니다)" -ForegroundColor Green
} else {
    Write-Host "  - 권한: 일반 (키움 버전업이 있는 날 아침에 UAC 창이 떠서 멈출 수 있습니다)" -ForegroundColor Yellow
    Write-Host "          고치려면 [2_프로그램설치.bat] 을 관리자 권한으로 다시 실행하세요."
}
Write-Host ""
Write-Host "동작: 08:25 실행 -> 08:30 키움로그인 -> 매매대기 -> 17:00 종료 -> 야간/주말 종료 (전부 자동)"
Write-Host "※ PC 는 켜 두세요. 절전에 들어가도 08:25 에 깨우도록 해 뒀습니다(전원 연결 시 절전 해제)."
Write-Host "※ 관리자 승인(라이선스) 필요 + PC 전원 ON + 윈도우 로그인(세션) 유지. 자동로그인 권장."
