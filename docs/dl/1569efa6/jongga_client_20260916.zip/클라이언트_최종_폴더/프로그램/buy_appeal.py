# -*- coding: utf-8 -*-
"""구매매력도 — 검증된 종가매수 승자신호로 0~100 점수·등급 산출.

근거(2026-08-01, KR 20건 백필검증):
  · LRL 기울기 양수(상승세)  : 수익 +5.24 vs 손실 -3.99  → 클수록 매력↑
  · MA200 이격도 낮음(비과열): 수익 +21.6% vs 손실 +51.5% → 낮을수록 매력↑
  · MA400 이격도 낮음        : 수익 +43.0% vs 손실 +76.0% → 낮을수록 매력↑
회전율·거래대금은 아직 판단보류(백필 불안정)라 점수 제외. 데이터 쌓이면 가중치 재보정.
"""

# 등급 색(대시보드 팔레트: 빨강=좋음/수익, 파랑=나쁨/손실 관례)
_UP = "#F0455C"; _GRN = "#34E5A0"; _AMB = "#F5A524"; _DN = "#4C8DF7"; _MUT = "#7C8598"


def _clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


def score(feat):
    """구매매력도 0~100(None=피처없음). LRL 45% · MA200 35% · MA400 20%(있는 것만 재정규화)."""
    if not feat:
        return None
    comps = []
    lrl = feat.get("lrl_slope")
    if lrl is not None:
        comps.append((_clamp((lrl + 8) / 16 * 100, 0, 100), 0.45))   # 추세(세력 상승강도)
    d200 = feat.get("disp200")
    if d200 is not None:
        comps.append((_clamp(100 - d200, 0, 100), 0.35))              # 200일 과열 회피
    d400 = feat.get("disp400")
    if d400 is not None:
        comps.append((_clamp(100 - d400 * 0.6, 0, 100), 0.20))        # 400일 과열 회피
    if not comps:
        return None
    tw = sum(w for _, w in comps)
    return round(sum(s * w for s, w in comps) / tw)


def grade(sc):
    """(등급, 라벨, 색) — 점수 구간별."""
    if sc is None:
        return ("?", "데이터대기", _MUT)
    if sc >= 80:
        return ("A", "🔥매우매력", _UP)
    if sc >= 60:
        return ("B", "👍양호", _GRN)
    if sc >= 40:
        return ("C", "⚖️보통", _AMB)
    return ("D", "⚠️주의", _DN)


def reasons(feat):
    """점수 근거 한줄 태그들(툴팁/상세용)."""
    if not feat:
        return []
    out = []
    lrl = feat.get("lrl_slope"); d200 = feat.get("disp200"); d400 = feat.get("disp400")
    if lrl is not None:
        out.append(("상승세" if lrl > 0 else "하락세") + f" LRL{lrl:+.1f}")
    if d200 is not None:
        out.append(("비과열" if d200 < 30 else "과열주의") + f" 200이격{d200:+.0f}%")
    if d400 is not None:
        out.append(f"400이격{d400:+.0f}%")
    return out


def badge_html(feat, esc=lambda x: x):
    """종목명 옆 인라인 뱃지. 피처 없으면 빈 문자열."""
    sc = score(feat)
    if sc is None:
        return ""
    g, label, col = grade(sc)
    tip = " · ".join(reasons(feat))
    return (f'<span class="ba" style="--bac:{col}" title="{esc(tip)}">'
            f'<b>{g}</b> {sc}<span class="bal">{esc(label)}</span></span>')


# 뱃지 CSS(export_html에서 <style>에 주입) — 인라인 알약형
BADGE_CSS = """
.ba{display:inline-flex;align-items:center;gap:4px;margin-left:6px;padding:1px 7px;border-radius:999px;
 font-size:11px;font-weight:800;line-height:1.6;color:var(--bac);
 background:color-mix(in srgb,var(--bac) 15%,transparent);border:1px solid color-mix(in srgb,var(--bac) 45%,transparent);
 vertical-align:middle;white-space:nowrap}
.ba b{font-size:11.5px}
.ba .bal{font-size:9.5px;font-weight:700;opacity:.9}
@media(max-width:430px){.ba .bal{display:none}}
"""
