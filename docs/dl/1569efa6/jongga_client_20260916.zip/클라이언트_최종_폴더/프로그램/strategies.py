# -*- coding: utf-8 -*-
"""
strategies.py — 종가배팅 매수3 × 매도2 = 6전략 비교 엔진 (기준가 2종: 매수가/시가)
────────────────────────────────────────────────────────────────
매수(종목 선택): 전체(선정+탈락) / 신규(어제 제외) / 선정(3조건)
매도(청산):      포트(등가중 합산 ±5%) / 개별(종목별 ±5%)
기준가(ref):     매수가(전날 15:27 종가) 기준  또는  시가(다음날 09:00 개장가) 기준
                 → 두 기준 모두 계산해 비교(갭업 종목은 기준에 따라 수익↔손실).

각 종목: entry(매수가)·open(시가)·path([[HHMM,price]])·last·high·low.
±5% 익절/-5% 손절 첫 터치를 기준가 대비로 판정.
"""
TP, SL = 5.0, -5.0       # 익절/손절 % (대시보드에서 조정 가능 — 손익절 시나리오 탐색)
UPPER_TP, UPPER_SL = 3.0, -3.0   # ★상한가 시가매수 종목 전용 손익절 ±3%(사용자 확정 2026-07-28)
FEE = 0.15               # ★왕복 수수료% — 손절 자동보정(net 1:1)용. set_fee로 설정(사용자 확정 2026-08-19)


def set_fee(f):
    global FEE
    FEE = float(f)


def _tpsl(stock):
    """종목별 손익절 — 익절=목표(raw), 손절=자동 수수료보정 -(목표-2×FEE) → 순손익 1:1(사용자 확정 2026-08-19).
    익절 raw tp서 순이익 tp-FEE / 손절 raw -(tp-2FEE)서 순손실 -(tp-FEE) = 익절과 1:1.
    (예: tp 4.5·FEE 0.15 → 익절 +4.5raw(순+4.35) / 손절 -4.20raw(순-4.35))."""
    tp = UPPER_TP if stock.get("unbuyable") else TP
    return (tp, -(tp - 2 * FEE))
REFS = ["매수가", "시가"]


def set_thresholds(tp, sl):
    """익절/손절 임계값 설정(대시보드 분석용). 예: set_thresholds(3, -3)."""
    global TP, SL
    TP, SL = float(tp), float(sl)

BUY_STRATS = [("전체", "검색기 전체(선정+탈락)"),
              ("신규", "어제 제외 신규만"),
              ("선정", "3조건 선정만")]
SELL_STRATS = [("포트", "합산 ±5%"),
               ("개별", "개별 ±5%")]
COMBOS = [(b[0], s[0]) for b in BUY_STRATS for s in SELL_STRATS]


def _tick_unit(price):
    """한국 호가단위(2023 개편)."""
    p = abs(price or 0)
    if p < 2000: return 1
    if p < 5000: return 5
    if p < 20000: return 10
    if p < 50000: return 50
    if p < 200000: return 100
    if p < 500000: return 500
    return 1000


def upper_limit_price(prev_close):
    """전일종가 → 당일 상한가(+30%, 호가단위 내림). 예: 3130 → 4065."""
    if not prev_close:
        return None
    raw = abs(prev_close) * 1.30
    u = _tick_unit(raw)
    return int(raw // u) * u


def is_upper_limit_close(entry, prev_close):
    """당일 종가(entry)가 상한가 도달 = 장마감 동시호가 매수 사실상 불가(매수대기 몰림)."""
    up = upper_limit_price(prev_close)
    return bool(up and entry and entry >= up)


def _pick_filter(stock, buy):
    """상한가 제외를 뺀 순수 선정/신규/전체 필터(표시용 — '이 전략 대상 종목인가')."""
    if buy == "신규":
        # 테스팅 시작일(첫 배치)·is_new 미표기는 신규로 본다 — 시작일엔 모든 종목이 처음 등장.
        return bool(stock.get("is_new", True))
    if buy == "선정":
        return stock.get("kind", "선정") == "선정"
    return True


# ★종목 필터: 바이오/건강관리 성향 테마는 전 트랙(라이브·페이퍼·백테) 매수 제외(사용자 지시 2026-08-25).
BIO_EXCLUDE = ["바이오", "제약", "생명과학", "생명공학", "생물공학", "건강관리", "의약", "의료", "진단", "헬스", "치료제"]
_BIO_TC = None
def _bio_theme(stock):
    thm = (stock.get("feat") or {}).get("theme") or stock.get("theme")
    if thm: return thm
    global _BIO_TC
    if _BIO_TC is None:
        try:
            import os as _os, json as _json
            _p = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "theme_cache.json")
            _BIO_TC = _json.load(open(_p, encoding="utf-8")) if _os.path.exists(_p) else {}
        except Exception:
            _BIO_TC = {}
    return _BIO_TC.get(str(stock.get("code", "")), "")
def is_bio(stock):
    """★바이오/건강관리 성향 테마면 True → 매매 제외. feat.theme 우선, 없으면(백테 과거종목) theme_cache 조회."""
    return any(k in (_bio_theme(stock) or "") for k in BIO_EXCLUDE)


def buy_filter(stock, buy):
    # ★상한가 종목(unbuyable)도 매수 포함 — 제외 안 함. 단 '다음날 시가매수'라 기준가만 시가로(_ref_price).
    #   (2026-07-28 규칙변경: 이전엔 제외했으나, 상한가는 다음날 시가에 사서 시가±5%로 잡는 것으로 확정)
    # ★바이오 필터 해제(2026-08-25 사용자: 바이오 포함 관찰) — 재적용 시 복구: if is_bio(stock): return False
    return _pick_filter(stock, buy)


DAY_LIMIT = 0.31   # 한국 일일 가격제한 ±30% + 여유 — 매수가 기준 이 밖의 틱은 글리치로 제거


def _clean_path(s):
    """실측 path에서 가격제한(±31%, 매수가 기준) 밖 글리치 틱 제거.
    (예: SK 정상 70900인데 4130으로 튄 폴링 오류틱 제거)."""
    path = s.get("path")
    if not path:
        return None
    ent = s.get("entry")
    if ent:
        lo, hi = ent * (1 - DAY_LIMIT), ent * (1 + DAY_LIMIT)
        cleaned = [pt for pt in path if pt[1] and lo <= pt[1] <= hi]
    else:
        cleaned = [pt for pt in path if pt[1]]
    return cleaned or None


def _open_price(stock):
    path = _clean_path(stock)
    if path and path[0][1]:
        return path[0][1]
    return stock.get("open")


def _ref_price(stock, ref):
    """기준가: '시가'면 개장가, 아니면 매수가(entry=전날종가).
    ★상한가 마감 종목(unbuyable)은 장마감 매수불가 → '다음날 시가매수'로 처리:
      기준가를 항상 개장가(시가)로 잡아 시가 기준 ±5% 손익절(사용자 확정 2026-07-28)."""
    if stock.get("unbuyable"):
        return _open_price(stock)
    return _open_price(stock) if ref == "시가" else stock.get("entry")


def _synth_path(s):
    """경로 없는 백필 → OHLC로 최소 장중경로 재구성 [[HHMM,price]].
    종가 방향으로 고·저 순서 추정: 하락마감(종가<시가)=고점(1200)→저점(1400),
    상승/보합=저점(1200)→고점(1400). (그날 계좌가 장초반 고점 후 하락한
    실측(peak 09:03)과 부합 — 하락마감 종목은 고점이 앞서므로 익절이 먼저)."""
    o, h, l, c = s.get("open"), s.get("high"), s.get("low"), s.get("last")
    if not o:
        return None
    pts = [["0900", o]]
    if h is not None and l is not None:
        pts += ([["1200", h], ["1400", l]] if (c is not None and c < o)
                else [["1200", l], ["1400", h]])
    elif h is not None:
        pts += [["1200", h]]
    elif l is not None:
        pts += [["1200", l]]
    if c is not None:
        pts += [["1520", c]]
    return pts


def _ret_series(stock, ref):
    """기준가 대비 수익률 시계열 [(HHMM,%)]. 포트(합산) 판정용.
    실경로 없으면 _synth_path로 OHLC 근사경로 사용(개별과 동일 경로)."""
    base = _ref_price(stock, ref)
    if not base:
        return []
    path = _clean_path(stock) or _synth_path(stock)
    if not path:
        return []
    return [(t, (p / base - 1.0) * 100.0) for t, p in path if p]


def _realize(s, ref):
    """실전 체결 기준 실현결과 → {ret, exit_px, result} (없으면 None).
    ★핵심(실전화): '지정가 +5% 매도 / 손절가 -5%'는 그 가격에 거래가 있어야 체결된다.
      · 밤사이 갭으로 목표 위(아래)에서 개장 → 그 가격엔 체결 불가, 실제 체결은 개장가.
        예) 매수가 3185, 시가 3635(+14%) → +5%(3344)에 못 팔고 개장가 3635에 체결 = +14% 실현.
      · 장중(연속거래)에 ±5% 통과 → 지정가/손절가에 정확히 체결(+5%/-5%).
      · 시가 중립인데 고·저 둘 다 통과(순서불명) → 보수적으로 손절 가정.
    경로(실측 또는 _synth_path)의 첫 봉=개장가 갭판정, 이후는 장중 통과판정."""
    base = _ref_price(s, ref)
    if not base:
        return None
    tp, sl = _tpsl(s)                         # ★상한가=±3%, 나머지=±5%
    tp_px, sl_px = base * (1 + tp / 100.0), base * (1 + sl / 100.0)

    def out(px, label, t):
        return {"ret": (px / base - 1.0) * 100.0, "exit_px": px, "result": label, "exit_time": t}

    path = _clean_path(s) or _synth_path(s)
    if not path:
        return None
    t0, p0 = path[0]                          # 개장가(≈09:00 첫 기록)·시각
    if p0:
        r0 = (p0 / base - 1.0) * 100.0
        if r0 >= tp:
            return out(p0, "🎯 갭 익절(개장가)", t0)   # 갭업 개장 → 개장가 체결
        if r0 <= sl:
            return out(p0, "🛑 갭 손절(개장가)", t0)   # 갭다운 개장 → 개장가 체결
    for t, p in path[1:]:                      # 장중: 임계 통과 시 그 시각에 체결
        if not p:
            continue
        rr = (p / base - 1.0) * 100.0
        if rr >= tp:
            return out(tp_px, f"🎯 +{tp:g}% 익절", t)
        if rr <= sl:
            return out(sl_px, f"🛑 {sl:g}% 손절", t)
    return out(path[-1][1], "종가청산", path[-1][0])


def _perstock_ret(s, ref):
    r = _realize(s, ref)
    return r["ret"] if r else None


def eval_perstock(stocks, ref):
    rets = [r for r in (_perstock_ret(s, ref) for s in stocks) if r is not None]
    return sum(rets) / len(rets) if rets else 0.0


def eval_portfolio(stocks, ref):
    """포트(계좌 합산) 실현수익% — 청산 상세/스냅샷은 portfolio_detail 참조."""
    return portfolio_detail(stocks, ref)["ret"]


def eval_day(batch, ref):
    out = {}
    for bk, _ in BUY_STRATS:
        sel = [s for s in batch.get("stocks", []) if buy_filter(s, bk)]
        has_data = any(_ret_series(s, ref) for s in sel)
        for sk, _ in SELL_STRATS:
            if not sel or not has_data:
                out[(bk, sk)] = {"ret": None, "n": len(sel), "win": None, "traded": False}
                continue
            r = eval_portfolio(sel, ref) if sk == "포트" else eval_perstock(sel, ref)
            out[(bk, sk)] = {"ret": round(r, 2), "n": len(sel), "win": r > 0, "traded": True}
    return out


def _cum(xs):
    c, out = 0.0, []
    for x in xs:
        c += x; out.append(round(c, 2))
    return out


def aggregate(db, ref):
    days = sorted([b for b in db["batches"]
                   if b.get("status") == "closed" and any(_ret_series(s, ref) for s in b.get("stocks", []))],
                  key=lambda b: (b.get("test_date", ""), b.get("rec_date", "")))
    acc = {c: {"rets": [], "wins": []} for c in COMBOS}
    labels = [b.get("test_date", "")[5:] for b in days]
    for b in days:
        ev = eval_day(b, ref)
        for c in COMBOS:
            v = ev[c]
            if v["traded"] and v["win"] is not None:
                acc[c]["rets"].append(v["ret"]); acc[c]["wins"].append(1 if v["win"] else 0)
            else:
                acc[c]["rets"].append(0.0); acc[c]["wins"].append(None)
    summary = {}
    for c in COMBOS:
        rets = [r for r, w in zip(acc[c]["rets"], acc[c]["wins"]) if w is not None]
        wins = [w for w in acc[c]["wins"] if w is not None]
        n = len(rets)
        summary[c] = {"n": n, "win_rate": (sum(wins) / n * 100.0) if n else 0.0,
                      "avg": (sum(rets) / n) if n else 0.0, "cum": sum(rets),
                      "rets": acc[c]["rets"], "cum_curve": _cum(acc[c]["rets"])}
    return summary, labels, days


def best_combo(summary):
    valid = [(c, s) for c, s in summary.items() if s["n"] > 0]
    return max(valid, key=lambda x: x[1]["cum"])[0] if valid else None


def capital_util(db, ref, buy, per_stock=1_000_000, cap=10):
    """자본 활용도 — 하루 평균 매수종목수·원금 대비 투입비율(%). (buy 전략별, sell 무관)"""
    ns = []
    for b in db.get("batches", []):
        if b.get("status") not in ("closed", "active"):
            continue
        sel = [s for s in b.get("stocks", []) if buy_filter(s, buy)][:cap]
        if sel:
            ns.append(len(sel))
    if not ns:
        return {"avg_n": 0.0, "util": 0.0, "days": 0}
    avg_n = sum(ns) / len(ns)
    return {"avg_n": round(avg_n, 1), "util": round(avg_n / cap * 100, 1), "days": len(ns)}


def capital_scenarios(db, ref, buy, capital=10_000_000, per_stock=1_000_000, cap=10):
    """자본 배분 분석 — 하루 종목수 분포 + 종목당 투자금 시나리오별 예상 총자산 수익률·집중 리스크.
    현행/관측최대(안전 완전활용)/평균(공격 완전활용) 3안으로 '놀고 있는 현금'을 정량화."""
    perday = []
    for b in db.get("batches", []):
        if b.get("status") not in ("closed", "active"):
            continue
        picks = [s for s in b.get("stocks", []) if buy_filter(s, buy)][:cap]
        if picks:
            perday.append(len(picks))
    if not perday:
        return None
    days = len(perday); avg_n = sum(perday) / days; max_n = max(perday)
    r = hybrid_aggregate(db, ref, buy, False)["avg"]        # 종목평균 일수익률(하이브)

    def scen(ps_amt):
        ps_amt = max(1.0, min(ps_amt, capital))             # 종목당은 원금 이하
        invested = min(avg_n * ps_amt, capital)             # 평균 실투입(원금 상한)
        return {"per_stock": ps_amt, "util": invested / capital * 100,
                "exp": r * invested / capital, "risk": 5.0 * ps_amt / capital}

    return {
        "days": days, "avg_n": round(avg_n, 2), "max_n": max_n, "r": r,
        "idle": capital - min(avg_n * per_stock, capital),
        "cur": scen(per_stock),                             # 현행(보수)
        "safe": scen(capital / max_n) if max_n else None,   # 관측최대 기준(초과없이 최대활용)
        "full": scen(capital / avg_n) if avg_n else None,   # 평균 기준(완전활용·공격)
    }


def strategy_profit(db, ref, buy, sell, per_stock=1_000_000, cap=10):
    """전략별 누적 실현손익(통화단위) — 종목당 per_stock, 하루 최대 cap종목 가정.
    buy=전체/신규/선정, sell=개별/포트/하이브. (마감·장중 배치 합산. 각 종목 실현수익%×per_stock)"""
    total = 0.0
    for b in db.get("batches", []):
        if b.get("status") not in ("closed", "active"):
            continue
        sel = [s for s in b.get("stocks", []) if buy_filter(s, buy)][:cap]
        if not sel:
            continue
        n = len(sel)
        if sell == "포트":
            r = portfolio_detail(sel, ref)["ret"]
        elif sell in ("하이브", "하이브리드"):
            r = hybrid_detail(sel, ref, False)["ret"]
        else:                                     # 개별
            r = eval_perstock(sel, ref)
        total += n * per_stock * r / 100.0
    return int(round(total))


def _stock_hilo(s):
    """장중 고가·저가 + 각 시각. 반환 (hi, hi_time, lo, lo_time)."""
    path = _clean_path(s)
    if path:
        pts = [(t, p) for t, p in path if p]
        if pts:
            ht, hp = max(pts, key=lambda x: x[1])
            lt, lp = min(pts, key=lambda x: x[1])
            return hp, ht, lp, lt
        return None, None, None, None
    return s.get("high"), None, s.get("low"), None


def perstock_detail(s, ref):
    """개별 매매 상세(기준가 ref): 매수가·시가·기준가·청산가·손익%·결과."""
    base = _ref_price(s, ref); r = _realize(s, ref)
    if base is None or r is None:
        return None
    hi, hi_t, lo, lo_t = _stock_hilo(s)
    path = _clean_path(s) or _synth_path(s)
    open_t = path[0][0] if path else None
    # ★상한가(시가매수)는 매수가 표시도 시가(base)로 — 매수가→청산 손익%가 일관되게 보이도록
    entry_disp = base if s.get("unbuyable") else s.get("entry")
    return {"ret": r["ret"], "entry": entry_disp, "open": _open_price(s), "base": base,
            "exit": r["exit_px"], "result": r["result"], "exit_time": r.get("exit_time"),
            "hi": hi, "hi_time": hi_t, "lo": lo, "lo_time": lo_t, "open_time": open_t}


def portfolio_detail(stocks, ref):
    """포트(계좌 합산) 청산 결과 + 청산시점 종목별 스냅샷.
    return {ret, result, exit_time, legs:[(name, ret%)]}.
    ★각 시각의 합산은 종목별 '최근가(forward-fill)'로 항상 전 종목 반영 —
      특정 시각에 일부 종목만 틱이 있어도 계좌 전체 수익을 올바르게 계산.
    개장 갭이면 실제 합산으로 청산, 장중 통과는 임계(±TP/SL)에 청산, 미도달은 종가.
    ★legs는 '계좌 합산이 목표에 정확히 닿는 순간'으로 각 종목을 직전관측~통과관측 사이
      선형보간해 표시 → legs 평균 = 계좌손익(=목표). (관측 간격/백필로 스냅샷이 목표를
      초과해 보이던 문제 해결.) 개장 갭·종가청산은 실제 관측값 그대로."""
    state = []
    for s in stocks:
        ser = dict(_ret_series(s, ref))
        if ser:
            state.append({"name": s.get("name", s.get("code", "")), "map": ser, "last": None})
    times = sorted({t for st in state for t in st["map"]})
    combined = 0.0; exit_t = None; legs = []
    prev_c, prev_legs = None, None
    for i, t in enumerate(times):
        for st in state:                         # 이 시각 값 있으면 갱신, 없으면 직전가 유지
            if t in st["map"]:
                st["last"] = st["map"][t]
        cur = [(st["name"], st["last"]) for st in state if st["last"] is not None]
        if not cur:
            continue
        combined = sum(v for _, v in cur) / len(cur)
        exit_t, legs = t, cur
        crossed = None
        if i == 0:                               # 개장 첫 시점: 갭이면 실제 합산·개장가 legs
            if combined >= TP or combined <= SL:
                break
        elif combined >= TP:
            crossed = TP
        elif combined <= SL:
            crossed = SL
        if crossed is not None:                  # 장중 통과 → 통과 순간으로 각 종목 보간
            if prev_c is not None and abs(combined - prev_c) > 1e-9:
                frac = min(1.0, max(0.0, (crossed - prev_c) / (combined - prev_c)))
                legs = [(nm, pv + frac * (cv - pv)) for (nm, cv), (_, pv) in zip(cur, prev_legs)]
            combined = crossed
            break
        prev_c, prev_legs = combined, cur
    if combined >= TP:
        result = f"🎯 계좌 +{TP:g}% 익절" if abs(combined - TP) < 1e-9 else "🎯 계좌 갭 익절(개장가)"
    elif combined <= SL:
        result = f"🛑 계좌 {SL:g}% 손절" if abs(combined - SL) < 1e-9 else "🛑 계좌 갭 손절(개장가)"
    else:
        result = "종가청산(목표 미도달)"
    legs = sorted(legs, key=lambda x: x[1], reverse=True)
    return {"ret": combined, "result": result, "exit_time": exit_t, "legs": legs}


def hybrid_detail(stocks, ref, account_sl=False):
    """하이브리드 청산 = 개별 ±TP/SL 첫터치로 종목별 실현 + 계좌 평균이 +TP% 되면 남은 전량청산.
    account_sl=True면 계좌 -SL%에서도 전량청산(비교분석용 변형). 반환 {ret, result, exit_time, legs}.
    ★실전 auto_routine과 동일 로직(익절 개별+계좌 / 손절 개별). 페이퍼 비교 전용."""
    info = []
    for s in stocks:
        base = _ref_price(s, ref); r = _realize(s, ref); ser = _ret_series(s, ref)
        if base is None or r is None or not ser:
            continue
        info.append({"name": s.get("name", s.get("code", "")), "exit_t": r.get("exit_time"),
                     "exit_ret": r["ret"], "label": r["result"], "map": dict(ser)})
    if not info:
        return {"ret": 0.0, "result": "거래없음", "exit_time": None, "legs": [], "detail": []}
    times = sorted({t for st in info for t in st["map"]})
    last = {i: None for i in range(len(info))}
    trigger_t, trigger_kind, snap = None, None, {}
    for t in times:
        vals = []
        for i, st in enumerate(info):
            if st["exit_t"] is not None and t >= st["exit_t"]:   # 개별청산 후엔 실현값 고정
                v = st["exit_ret"]
            else:
                if t in st["map"]:
                    last[i] = st["map"][t]
                v = last[i]
            if v is not None:
                vals.append(v)
        if not vals:
            continue
        acct = round(sum(vals) / len(vals), 2)               # 실전과 동일: 2자리 반올림(경계 float 방지)
        if acct >= TP or (account_sl and acct <= SL):        # 계좌 임계 → 전량청산
            trigger_t = t; trigger_kind = "익" if acct >= TP else "손"
            snap = {i: (st["exit_ret"] if (st["exit_t"] is not None and t >= st["exit_t"])
                        else (last[i] if last[i] is not None else st["exit_ret"]))
                    for i, st in enumerate(info)}
            break
    # ── 종목별 청산 상세: 계좌 트리거 전 개별청산됐으면 개별, 아니면 계좌강제청산 ──
    detail = []
    for i, st in enumerate(info):
        indiv_first = st["exit_t"] is not None and (trigger_t is None or st["exit_t"] <= trigger_t)
        if trigger_t is not None and not indiv_first:
            detail.append({"name": st["name"], "ret": round(snap.get(i, st["exit_ret"]), 2),
                           "time": trigger_t, "how": "🏦 계좌강제청산"})
        else:
            detail.append({"name": st["name"], "ret": round(st["exit_ret"], 2),
                           "time": st["exit_t"], "how": st["label"]})
    ret = round(sum(d["ret"] for d in detail) / len(detail), 4)
    if trigger_t is not None:
        result = f"🏦 계좌 +{TP:g}% 전량청산" if trigger_kind == "익" else f"🏦 계좌 {SL:g}% 전량청산"
    else:
        result = "개별청산(계좌 미도달)"
    legs = sorted([(d["name"], d["ret"]) for d in detail], key=lambda x: x[1], reverse=True)
    return {"ret": ret, "result": result, "exit_time": trigger_t, "legs": legs,
            "detail": sorted(detail, key=lambda x: x["ret"], reverse=True)}


def eval_hybrid(stocks, ref, account_sl=False):
    return hybrid_detail(stocks, ref, account_sl)["ret"]


def compare_row(sel, ref):
    """한 종목집합의 4전략 오늘수익 — 개별/포트/하이브리드/하이브리드S."""
    return {"개별": eval_perstock(sel, ref), "포트": eval_portfolio(sel, ref),
            "하이브": eval_hybrid(sel, ref, False), "하이브S": eval_hybrid(sel, ref, True)}


def hybrid_aggregate(db, ref, buy="전체", account_sl=False):
    """하이브리드(또는 하이브S) 일별 수익 + 누적곡선 + 통계 — aggregate와 동일 구조.
    return {n, win_rate, avg, cum, cum_curve}."""
    days = sorted([b for b in db["batches"]
                   if b.get("status") == "closed" and any(_ret_series(s, ref) for s in b.get("stocks", []))],
                  key=lambda b: (b.get("test_date", ""), b.get("rec_date", "")))
    rets, traded, wins = [], [], []
    for b in days:
        sel = [s for s in b.get("stocks", []) if buy_filter(s, buy)]
        if sel and any(_ret_series(s, ref) for s in sel):
            r = eval_hybrid(sel, ref, account_sl)
            rets.append(r); traded.append(r); wins.append(1 if r > 0 else 0)
        else:
            rets.append(0.0)
    n = len(traded)
    return {"n": n, "win_rate": (sum(wins) / n * 100.0) if n else 0.0,
            "avg": (sum(traded) / n) if n else 0.0, "cum": sum(rets), "cum_curve": _cum(rets)}


def compare_cum(db, ref, buy="전체"):
    """닫힌 날들 누적 — 개별/포트/하이브리드/하이브리드S 누적수익."""
    out = {"개별": 0.0, "포트": 0.0, "하이브": 0.0, "하이브S": 0.0}
    for b in db.get("batches", []):
        if b.get("status") != "closed":
            continue
        sel = [s for s in b.get("stocks", []) if buy_filter(s, buy)]
        if not sel or not any(_ret_series(s, ref) for s in sel):
            continue
        row = compare_row(sel, ref)
        for k in out:
            out[k] += row[k]
    return out


def day_report(batch, db):
    """하루 매매결과 — 매수가/시가 두 기준 모두 6전략 비교 텔레그램 리포트."""
    nsel = sum(1 for s in batch.get("stocks", []) if s.get("kind", "선정") == "선정")
    nnew = sum(1 for s in batch.get("stocks", []) if s.get("is_new", True))
    L = [f"🐷 종가배팅 전략비교 리포트 · {batch['test_date']}",
         f"검색기 {len(batch.get('stocks', []))}종목 (선정 {nsel}·신규 {nnew}) · 익절+{TP:g}%/손절{SL:g}%"]
    for ref in REFS:
        ev = eval_day(batch, ref)
        summary, _, _ = aggregate(db, ref)
        L.append(f"━━ [{ref} 기준] 오늘 ━━")
        for bk, _ in BUY_STRATS:
            parts = []
            for sk, _ in SELL_STRATS:
                v = ev[(bk, sk)]
                parts.append(f"{sk} {v['ret']:+.1f}%" if v["traded"] else f"{sk} -")
            L.append(f"· {bk}({ev[(bk,'포트')]['n']}): " + " / ".join(parts))
        bc = best_combo(summary)
        if bc:
            L.append(f"  누적 🏆 {bc[0]}+{bc[1]} {summary[bc]['cum']:+.1f}% (승률 {summary[bc]['win_rate']:.0f}%)")
    # ── 하이브리드 비교(전체매수) — 실전 하이브리드 vs 계좌손절 변형, 페이퍼 분석 ──
    L.append("━━ [🏦 하이브리드 비교 · 전체매수] ━━")
    for ref in REFS:
        sel = [s for s in batch.get("stocks", []) if buy_filter(s, "전체")]
        if not any(_ret_series(s, ref) for s in sel):
            continue
        row = compare_row(sel, ref); cum = compare_cum(db, ref, "전체")
        L.append(f"[{ref}] 오늘 개별 {row['개별']:+.1f} · 포트 {row['포트']:+.1f} · "
                 f"하이브 {row['하이브']:+.1f} · 하이브S {row['하이브S']:+.1f}")
        L.append(f"  누적 개별 {cum['개별']:+.1f} · 포트 {cum['포트']:+.1f} · "
                 f"하이브 {cum['하이브']:+.1f} · 하이브S {cum['하이브S']:+.1f}")
    L.append("(하이브=개별5%+계좌5%청산〔실전동일〕 · 하이브S=+계좌-5%손절도)")
    return "\n".join(L)
