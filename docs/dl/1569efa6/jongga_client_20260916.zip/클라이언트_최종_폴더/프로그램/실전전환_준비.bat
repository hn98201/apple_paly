@echo off
title Live Account Switch
cd /d "%~dp0"
set "PY="
if exist "%~dp0python_path.txt" for /f "usebackq delims=" %%A in ("%~dp0python_path.txt") do set "PY=%%A"
if defined PY set "PY=%PY:pythonw.exe=python.exe%"
if defined PY if exist "%PY%" ( "%PY%" live_switch.py --on & exit /b )
if exist "%LOCALAPPDATA%\Programs\Python\Python312-32\python.exe" ( "%LOCALAPPDATA%\Programs\Python\Python312-32\python.exe" live_switch.py --on & exit /b )
if exist "%LOCALAPPDATA%\Programs\Python\Python311-32\python.exe" ( "%LOCALAPPDATA%\Programs\Python\Python311-32\python.exe" live_switch.py --on & exit /b )
py -3-32 live_switch.py --on
if errorlevel 9009 python live_switch.py --on
