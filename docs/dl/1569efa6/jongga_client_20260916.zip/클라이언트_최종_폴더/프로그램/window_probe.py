# -*- coding: utf-8 -*-
"""지금 떠 있는 팝업창의 정체를 알아낸다. (2026-09-16)

왜 필요한가
  무인 운용에서 창이 하나 뜨면 거기서 멈춘다. 자동으로 눌러 없애려면
  **그 창을 정확히 특정**해야 한다. 아무 창이나 누르면 엉뚱한 걸 눌러 더 큰 사고가 난다.
  그래서 제목·클래스·프로세스·버튼 글자를 있는 그대로 뽑아 둔다.

쓰는 법
  1) 문제의 창이 **떠 있는 상태**에서
  2) 팝업창_확인.bat 을 더블클릭 (또는 python window_probe.py)
  3) 같은 폴더에 생기는 `팝업창_정보.txt` 를 관리자에게 보낸다

★이 도구는 창을 읽기만 한다. 누르거나 닫지 않는다.
"""
import ctypes, io, os, sys, datetime
from ctypes import wintypes

try: sys.stdout.reconfigure(errors="replace")
except Exception: pass

DIR = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(DIR, "팝업창_정보.txt")
u = ctypes.windll.user32
k = ctypes.windll.kernel32
ENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)


def wtext(h):
    try:
        n = u.GetWindowTextLengthW(h)
        b = ctypes.create_unicode_buffer(n + 2)
        u.GetWindowTextW(h, b, n + 2)
        return b.value or ""
    except Exception:
        return ""


def wclass(h):
    try:
        b = ctypes.create_unicode_buffer(256)
        u.GetClassNameW(h, b, 256)
        return b.value or ""
    except Exception:
        return ""


def wproc(h):
    """그 창을 띄운 프로세스 이름."""
    try:
        pid = wintypes.DWORD()
        u.GetWindowThreadProcessId(h, ctypes.byref(pid))
        h2 = k.OpenProcess(0x1000, False, pid.value)          # QUERY_LIMITED_INFORMATION
        if not h2: return "?(pid %d)" % pid.value
        sz = wintypes.DWORD(260)
        buf = ctypes.create_unicode_buffer(260)
        ok = k.QueryFullProcessImageNameW(h2, 0, buf, ctypes.byref(sz))
        k.CloseHandle(h2)
        return (os.path.basename(buf.value) if ok else "?") + " (pid %d)" % pid.value
    except Exception:
        return "?"


def children(h):
    out = []
    def _c(c, l):
        t = wtext(c); cl = wclass(c)
        if t or cl in ("Button", "Static", "Edit"):
            out.append((cl, t))
        return True
    try: u.EnumChildWindows(h, ENUMPROC(_c), 0)
    except Exception: pass
    return out


def main():
    L = []
    def p(m=""):
        L.append(m); print(m)

    p("=" * 66)
    p("  팝업창 정보 — %s" % datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    p("=" * 66)
    p("")
    p("지금 화면에 보이는 창을 전부 적습니다. 문제의 창을 찾아 관리자에게 보내세요.")
    p("(읽기만 합니다. 누르거나 닫지 않습니다)")
    p("")

    wins = []
    def _top(h, l):
        if not u.IsWindowVisible(h): return True
        t = wtext(h)
        if not t and wclass(h) not in ("#32770",): return True   # 제목 없고 대화상자도 아니면 skip
        wins.append(h)
        return True
    u.EnumWindows(ENUMPROC(_top), 0)

    n = 0
    for h in wins:
        t = wtext(h); cl = wclass(h); pr = wproc(h)
        kids = children(h)
        btns = [x[1] for x in kids if x[0] == "Button" and x[1]]
        texts = [x[1] for x in kids if x[0] == "Static" and x[1]]
        # 대화상자(#32770)거나 버튼이 있으면 '눌러야 하는 창'일 가능성이 높다
        likely = (cl == "#32770") or bool(btns)
        n += 1
        p("[%02d] %s" % (n, "★ 눌러야 하는 창으로 보임" if likely else ""))
        p("     제목    : %s" % (t or "(없음)"))
        p("     클래스  : %s" % cl)
        p("     프로세스: %s" % pr)
        p("     핸들    : %d" % h)
        if btns:  p("     버튼    : %s" % ", ".join(btns))
        if texts: p("     본문    : %s" % " | ".join(texts[:6]))
        p("")

    p("-" * 66)
    p("창 %d개" % n)
    p("")
    p("※ 문제의 창이 안 보이면, 그 창이 떠 있는 상태에서 다시 실행하세요.")
    p("※ 키움이 띄우는 창은 보통 프로세스가 python.exe / pythonw.exe / opstarter.exe 입니다.")

    try:
        io.open(OUT, "w", encoding="utf-8-sig", newline="\r\n").write("\n".join(L))
        print("\n저장: %s" % OUT)
    except Exception as e:
        print("\n저장 실패: %s" % e)
    return 0


if __name__ == "__main__":
    try:
        rc = main()
    except Exception as e:
        print("오류:", e); rc = 1
    try: input("\n엔터를 누르면 닫힙니다...")
    except Exception: pass
    sys.exit(rc)
