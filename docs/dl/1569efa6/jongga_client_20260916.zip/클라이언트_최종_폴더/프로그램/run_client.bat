@echo off
cd /d "%~dp0"
rem use python path saved at install time (works even if PATH differs per PC)
set "PYW="
if exist "%~dp0python_path.txt" for /f "usebackq delims=" %%A in ("%~dp0python_path.txt") do set "PYW=%%A"
if defined PYW if exist "%PYW%" ( start "" "%PYW%" client.py %* & exit /b )
if exist "%LOCALAPPDATA%\Programs\Python\Python312-32\pythonw.exe" ( start "" "%LOCALAPPDATA%\Programs\Python\Python312-32\pythonw.exe" client.py %* & exit /b )
if exist "%LOCALAPPDATA%\Programs\Python\Python311-32\pythonw.exe" ( start "" "%LOCALAPPDATA%\Programs\Python\Python311-32\pythonw.exe" client.py %* & exit /b )
if exist "%LOCALAPPDATA%\Programs\Python\Python310-32\pythonw.exe" ( start "" "%LOCALAPPDATA%\Programs\Python\Python310-32\pythonw.exe" client.py %* & exit /b )
if exist "%LOCALAPPDATA%\Programs\Python\Python313-32\pythonw.exe" ( start "" "%LOCALAPPDATA%\Programs\Python\Python313-32\pythonw.exe" client.py %* & exit /b )
pyw -3-32 client.py %* 2>nul && exit /b
rem -------------------------------------------------------------------------
rem  32-bit Python not found. Do NOT fall back to PATH python:
rem  it is usually 64-bit, the Kiwoom OCX silently fails to load there, and
rem  the user only saw an English AttributeError traceback. (2026-09-15)
rem -------------------------------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0no_python32.ps1"
exit /b 1
