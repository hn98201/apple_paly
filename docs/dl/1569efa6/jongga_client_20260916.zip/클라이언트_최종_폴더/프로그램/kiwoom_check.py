# -*- coding: utf-8 -*-
"""키움 무인운용 설정 점검 — '자동매매 시작' 눌렀을 때 창이 뜨는 이유를 찾는다. (2026-09-15)

무인으로 돌리려면 키움 쪽에 **두 가지**가 설정돼 있어야 한다.
둘 다 `C:\\OpenAPI\\system\\Autologin.dat` 한 파일에 저장된다.

  [Login]   AutoGb=1 · ID · PW      → 자동로그인. 없으면 **로그인 창**이 뜬다
  [AccInfo] AccNo1 · AccPW1 · Count → 계좌비밀번호. 없으면 **계좌비밀번호 창**이 뜬다
                                      (잔고·예수금 조회 때마다 뜬다)

사람이 없는 새벽/장중에 창이 뜨면 프로그램이 거기서 멈춘다 — 매수도 손절도 안 된다.
그래서 배포 후 **반드시 이 점검을 한 번** 돌려 본다.

  python 키움설정_점검.py        (또는 키움설정_점검.bat 더블클릭)
"""
import io, os, sys, configparser

try: sys.stdout.reconfigure(errors="replace")   # 한글 콘솔(cp949)에서 print 가 죽지 않게
except Exception: pass

PATH = r"C:\OpenAPI\system\Autologin.dat"
if len(sys.argv) > 1: PATH = sys.argv[1]   # 점검용 — 다른 파일을 지정할 수 있다
LINE = "=" * 58


def read_ini(p):
    """Autologin.dat 은 INI 형식이지만 값에 = 나 특수문자가 섞여 있어 직접 파싱한다."""
    try: raw = io.open(p, "rb").read().decode("cp949", "replace")
    except Exception as e: return None, str(e)
    sec, out = "", {}
    for ln in raw.splitlines():
        ln = ln.strip()
        if not ln: continue
        if ln.startswith("[") and ln.endswith("]"): sec = ln[1:-1]; out.setdefault(sec, {}); continue
        if "=" in ln:
            k, v = ln.split("=", 1)
            out.setdefault(sec, {})[k.strip()] = v.strip()
    return out, None


def task_runlevel(name):
    """예약작업의 권한 수준을 본다. ('Highest' / 'Limited' / None=작업없음)"""
    try:
        import subprocess
        ps = ("$t=Get-ScheduledTask -TaskName '%s' -ErrorAction SilentlyContinue;"
              "if($t){$t.Principal.RunLevel}else{'NONE'}" % name)
        r = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                           capture_output=True, timeout=25, creationflags=0x08000000)
        out = (r.stdout or b"").decode("cp949", "replace").strip()
        return None if out in ("", "NONE") else out
    except Exception:
        return None


def uac_prompts():
    """UAC 가 관리자에게 창을 띄우는 설정인지. True=창이 뜬다 / False=안 뜬다 / None=모름"""
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                           r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System")
        lua = winreg.QueryValueEx(k, "EnableLUA")[0]
        beh = winreg.QueryValueEx(k, "ConsentPromptBehaviorAdmin")[0]
        if not lua: return False              # UAC 자체가 꺼짐
        return beh != 0                       # 0 = 묻지 않고 바로 상승
    except Exception:
        return None

def find_certs():
    """공동인증서가 몇 군데에 있는지 찾는다. 중복이면 키움이 '골라달라'고 묻는다."""
    import glob
    roots = [os.path.join(os.environ.get("USERPROFILE", ""), "AppData", "LocalLow", "NPKI"),
             r"C:\Program Files\NPKI", r"C:\Program Files (x86)\NPKI", r"C:\NPKI"]
    for d in "DEFGHIJKLMNOPQRSTUVWXYZ":          # 이동식(USB) 포함 전 드라이브
        roots.append(d + ":\\NPKI")
    out = []
    for r in roots:
        if not os.path.isdir(r): continue
        for p in glob.glob(os.path.join(r, "*", "USER", "*", "signCert.der")):
            d = os.path.dirname(p)
            usb = not d.upper().startswith("C:")
            out.append((d, usb))
    return out

def main():
    print(LINE)
    print("  키움 무인운용 설정 점검")
    print(LINE)
    print()

    if not os.path.isfile(PATH):
        print("[X] 키움 설정파일이 없습니다")
        print("    %s" % PATH)
        print()
        print("  → 키움 OpenAPI 가 아직 설치되지 않았거나, 한 번도 로그인한 적이 없습니다.")
        print("    [3_키움설치.bat] 를 먼저 실행하고, 키움에 한 번 로그인하세요.")
        return 1

    ini, err = read_ini(PATH)
    if ini is None:
        print("[X] 설정파일을 읽지 못했습니다 :", err); return 1

    login = ini.get("Login", {})
    acc = ini.get("AccInfo", {})
    auto = login.get("AutoGb", "") == "1"
    has_id = bool(login.get("ID", "").strip())
    cert = bool(login.get("Cert", "").strip())
    try: cnt = int(acc.get("Count", "0") or 0)
    except Exception: cnt = 0
    accnos = [v for k, v in acc.items() if k.lower().startswith("accno") and v.strip()]
    accpws = [v for k, v in acc.items() if k.lower().startswith("accpw") and v.strip()]

    ok = True

    # ── ① 자동로그인 ──────────────────────────────────────────────
    print("① 자동로그인  (안 되어 있으면 '로그인 창'이 뜬다)")
    if auto and has_id:
        print("   [OK] 설정됨 — 아이디·비밀번호가 저장돼 있습니다")
    else:
        ok = False
        print("   [X] 설정 안 됨")
        print()
        print("   고치는 법")
        print("     1. 바탕화면 [▶ 종가배팅 클라이언트] 실행")
        print("     2. [자동매매 시작] → 키움 로그인 창이 뜨면")
        print("        ** 창 안의 '자동로그인 설정' 을 체크 ** 하고 로그인")
        print("     3. 한 번만 하면 다음부터는 창이 안 뜹니다")

    # ── ② 계좌비밀번호 ────────────────────────────────────────────
    print()
    print("② 계좌비밀번호  (안 되어 있으면 '계좌비밀번호 창'이 뜬다)")
    if cnt > 0 and accpws:
        print("   [OK] 등록됨 — 계좌 %d개" % max(cnt, len(accnos)))
    else:
        ok = False
        print("   [X] 등록 안 됨")
        print()
        print("   고치는 법")
        print("     1. 프로그램에서 키움 로그인을 먼저 한다")
        print("     2. [설정] 탭 → [🔒 계좌비밀번호 등록] 버튼")
        print("     3. 뜨는 키움 창에서")
        print("          · 계좌를 고르고 계좌비밀번호 입력")
        print("          ** 'AUTO' 에 체크 **   <- 이걸 빼먹으면 매번 다시 뜹니다")
        print("          · [등록] 누르고 창 닫기")

    # ── ③ 실계좌 쓸 때만 ──────────────────────────────────────────
    print()
    print("③ 공동인증서  (모의투자면 필요 없음)")
    if cert:
        print("   [OK] 인증서 비밀번호 저장됨 — 실계좌 자동로그인 가능")
    else:
        print("   [--] 저장 안 됨 — 지금은 **모의투자만** 무인으로 돌아갑니다")
        print("        실계좌로 바꿀 때는 공동인증서를 설치하고,")
        print("        로그인 창에서 인증서 비밀번호까지 저장해야 창 없이 붙습니다")

    # ── ④ 키움 버전업 UAC ─────────────────────────────────────────
    print()
    print("④ 키움 버전업 UAC  (무인 아침에 창이 뜨면 거기서 멈춘다)")
    lvl = task_runlevel("종가배팅_클라이언트시작")
    pr = uac_prompts()
    if lvl is None:
        print("   [--] 예약작업이 아직 없습니다 — [2_프로그램설치.bat] 을 실행하세요")
    elif lvl == "Highest":
        print("   [OK] 예약작업이 최고 권한 — 아침 08:25 자동시작에서는 UAC 창이 안 뜹니다")
        print("        (바탕화면 아이콘으로 직접 띄울 때는 일반 권한이라 뜰 수 있습니다.")
        print("         그때 한 번 [예] 를 눌러 버전 업데이트를 끝내면 다음 버전까지 안 뜹니다)")
    elif pr is False:
        print("   [OK] 이 PC 는 UAC 가 묻지 않도록 설정돼 있어 창이 안 뜹니다")
    else:
        ok = False
        print("   [X] 예약작업이 일반 권한이고 UAC 는 묻는 설정입니다")
        print()
        print("   무슨 일이 생기나")
        print("     키움이 새 버전을 내면 로그인할 때 'NKStarter' 업데이트 창(UAC)이 뜹니다.")
        print("     아침 08:25 무인 시작에서 뜨면 아무도 [예] 를 못 눌러 그날 매매가 통째로 날아갑니다.")
        print("     ※ 이 창은 프로그램이 대신 눌러줄 수 없습니다(윈도우 보안 화면에서 뜹니다).")
        print()
        print("   고치는 법")
        print("     [2_프로그램설치.bat] 을 마우스 오른쪽 > [관리자 권한으로 실행]")
        print("     (예약작업이 '최고 권한'으로 다시 등록돼 그 뒤로는 안 뜹니다)")

    # ── ⑤ 인증서 중복 (실계좌만 해당) ─────────────────────────────
    certs = find_certs()
    if certs:
        print()
        print("⑤ 공동인증서 위치  (2개 이상이면 키움이 매번 '골라달라'고 묻는다)")
        for d, usb in certs:
            print("   %s %s" % ("[USB]  " if usb else "[하드]", d))
        if len(certs) > 1:
            ok = False
            print()
            print("   [X] 인증서가 %d군데 있습니다 — 자동로그인이 안 됩니다" % len(certs))
            print()
            print("   무슨 일이 생기나")
            print("     키움이 어느 인증서를 쓸지 못 정해 로그인할 때마다 선택 창을 띄웁니다.")
            print("     자동로그인을 저장해 둬도 소용없습니다. 아침에 사람이 없으면 거기서 멈춥니다.")
            print()
            print("   고치는 법")
            if any(u for _, u in certs):
                print("     USB 를 뽑으세요. 하드디스크 것 하나만 남으면 자동으로 선택됩니다.")
            else:
                print("     쓰지 않는 인증서 폴더를 지우거나 다른 곳으로 옮기세요.")
        else:
            print("   [OK] 한 곳에만 있습니다 — 고를 게 없으니 자동 선택됩니다")

    print()
    print(LINE)
    if ok:
        print("  결과 : 정상 — 창 없이 무인으로 돌아갑니다")
    else:
        print("  결과 : 위의 [X] 항목을 고치세요")
        print("         안 고치면 사람이 없을 때 창에서 멈춰 매수·손절이 안 됩니다")
    print(LINE)
    print()
    print("설정파일 : %s" % PATH)
    print("(이 점검은 읽기만 합니다. 아무것도 바꾸지 않습니다)")
    return 0 if ok else 1


if __name__ == "__main__":
    try:
        rc = main()
    except Exception as e:
        print("점검 중 오류:", e); rc = 1
    try: input("\n엔터를 누르면 닫힙니다...")
    except Exception: pass
    sys.exit(rc)
