# -*- coding: utf-8 -*-
"""키움 OCX 를 '진짜로' 올릴 수 있는지 확인하고, 안 되면 무엇을 어떻게 고치는지 한글로 알려준다.
   (2026-09-15 추가 — 아래 사고의 재발 방지)

── 왜 필요한가 ──────────────────────────────────────────────
QAxWidget 은 OCX 로딩에 실패해도 **예외를 던지지 않고 빈 위젯이 된다.**
그래서 jongga_scanner.Kiwoom.__init__ 은 14줄 뒤에서야

    AttributeError: 'TradeKiwoom' object has no attribute 'OnEventConnect'

라는 영문 트레이스백으로 죽는다. 사용자는 원인을 알 수 없다.
(OnEventConnect 는 코드에 적힌 속성이 아니라, OCX 가 올라와야 생기는 이벤트 시그널이다)

또 하나 — 예전 점검은 레지스트리의 **ProgID 만** 봤다. 그런데 옛 OpenAPI 를
폴더째 지우거나 옮긴 PC 는 ProgID 만 남고 실제 ocx 파일이 없다. ProgID 조회는
통과하고 로딩은 실패하는, 정확히 이번 사고의 모양이 된다.
반드시 **실제 파일까지** 확인해야 한다.
"""
import os

PROGID = "KHOPENAPI.KHOpenAPICtrl.1"
OCX_DEFAULT = r"C:\OpenAPI\khopenapi.ocx"
REGSVR32 = r"C:\Windows\SysWOW64\regsvr32.exe"


class KiwoomOcxError(RuntimeError):
    """키움 OCX 를 못 올렸다. str(e) 안에 한글 안내문이 들어 있다."""


def py_bits():
    import struct
    return struct.calcsize("P") * 8


def _read_default(root, path, view=0):
    """레지스트리 기본값(@) 읽기. 없으면 빈 문자열."""
    import winreg
    try:
        k = winreg.OpenKey(root, path, 0, winreg.KEY_READ | view)
        try:
            return str(winreg.QueryValueEx(k, "")[0]).strip()
        finally:
            winreg.CloseKey(k)
    except Exception:
        return ""


def _views():
    import winreg
    return (0, getattr(winreg, "KEY_WOW64_32KEY", 0), getattr(winreg, "KEY_WOW64_64KEY", 0))


def find_clsid():
    """ProgID → CLSID. 등록 안 돼 있으면 빈 문자열."""
    import winreg
    for v in _views():
        c = _read_default(winreg.HKEY_CLASSES_ROOT, PROGID + r"\CLSID", v)
        if c:
            return c
    return ""


def find_server(clsid):
    """CLSID → InprocServer32 (실제 ocx 파일 경로). 32비트 뷰까지 훑는다."""
    import winreg
    if not clsid:
        return ""
    cands = [(winreg.HKEY_CLASSES_ROOT, r"CLSID\%s\InprocServer32" % clsid),
             (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Classes\CLSID\%s\InprocServer32" % clsid),
             (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Classes\Wow6432Node\CLSID\%s\InprocServer32" % clsid)]
    for hive, path in cands:
        for v in _views():
            p = _read_default(hive, path, v).strip('"')
            if p:
                return os.path.expandvars(p)
    return ""


def inspect():
    """이 PC 상태를 사실 그대로 모아 온다. (판단·문구는 problem() 이 한다)"""
    clsid = find_clsid()
    server = find_server(clsid)
    return {"bits": py_bits(),
            "clsid": clsid,
            "server": server,
            "server_exists": bool(server) and os.path.isfile(server),
            "default_ocx": os.path.isfile(OCX_DEFAULT),
            "openapi_dir": os.path.isdir(os.path.dirname(OCX_DEFAULT))}


def problem():
    """OCX 를 못 올릴 게 확실한 이유가 있으면 한글 안내문, 없으면 None."""
    info = inspect()

    if info["bits"] != 32:
        return ("64비트 파이썬으로 실행되었습니다.\n"
                "키움 OpenAPI(OCX)는 32비트에서만 동작합니다.\n\n"
                "고치는 법\n"
                "  1) https://www.python.org/downloads/windows/ 에서\n"
                "     'Windows installer (32-bit)' 3.12.x 를 설치\n"
                "  2) [2_프로그램설치.bat] 다시 실행")

    if not info["clsid"]:
        return ("키움 OpenAPI(OCX)가 이 PC 에 등록되어 있지 않습니다.\n\n"
                "고치는 법\n"
                "  [3_키움설치.bat] 를 실행해 'Open API+' 를 설치하세요.\n"
                "  (설치창을 끝까지 [다음] 눌러 마쳐야 합니다)")

    # ★이번 사고의 실제 모양 — 등록만 남고 파일이 없다(옛 설치를 폴더째 지운 PC)
    if info["server"] and not info["server_exists"]:
        return ("키움 OpenAPI 등록만 남아 있고 실제 파일이 없습니다.\n"
                "(옛 OpenAPI 를 지우거나 옮겼을 때 생기는 증상입니다)\n\n"
                "등록된 위치 : %s\n\n"
                "고치는 법\n"
                "  [3_키움설치.bat] 를 실행해 OpenAPI+ 를 다시 설치하세요." % info["server"])

    if not info["server"] and not info["default_ocx"]:
        return ("키움 OpenAPI 파일(khopenapi.ocx)을 찾을 수 없습니다.\n\n"
                "고치는 법\n"
                "  [3_키움설치.bat] 를 실행해 OpenAPI+ 를 다시 설치하세요.")

    return None


def guide(extra=""):
    """로딩이 실패했을 때 띄울 최종 안내문. 원인이 특정되면 그걸, 아니면 전체 점검표를."""
    tail = ("\n\n" + extra) if extra else ""
    p = problem()
    if p:
        return "키움 OpenAPI 를 사용할 수 없습니다.\n\n" + p + tail

    info = inspect()
    where = info["server"] or OCX_DEFAULT
    return ("키움 OpenAPI(OCX) 를 불러오지 못했습니다.\n"
            "설치·등록은 되어 있는데 실제 로딩에서 막혔습니다.\n\n"
            "등록 위치 : %s\n"
            "파이썬    : %d비트\n\n"
            "차례대로 해 보세요\n"
            "  1) 키움 OpenAPI 를 직접 한 번 실행해 로그인 (버전처리가 남아 있을 수 있습니다)\n"
            "  2) 관리자 권한 명령프롬프트에서 다시 등록\n"
            "       %s \"%s\"\n"
            "  3) [3_키움설치.bat] 로 OpenAPI+ 재설치\n"
            "  4) 그래도 안 되면 [진단.bat] 결과를 관리자에게 보내주세요"
            % (where, info["bits"], REGSVR32, where)) + tail


def ensure_loaded(widget):
    """QAxWidget 을 만든 직후 호출 — 로딩 실패면 한글 안내를 담아 예외를 던진다."""
    if not hasattr(widget, "OnEventConnect"):
        raise KiwoomOcxError(guide())
    return widget
