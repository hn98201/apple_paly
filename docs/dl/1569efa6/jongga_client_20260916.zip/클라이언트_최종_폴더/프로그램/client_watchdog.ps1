# Client watchdog - relaunch client.py if it died DURING operating hours.
# Operating window: Mon-Fri 08:25-17:00 (outside = program should be OFF: night/weekend).
# ASCII only + $PSScriptRoot for the Korean folder path (PS5.1 safe).
# Only relaunches when auto_start=true (user pressed Start & got approved). If Stop, it stays down.
$ErrorActionPreference = "SilentlyContinue"

# operating window check (Mon-Fri 08:25-17:00) - do NOT keep alive at night/weekend
$now = Get-Date
$dow = [int]$now.DayOfWeek        # 0=Sun,1=Mon,...,5=Fri,6=Sat
$hm  = $now.ToString("HH:mm")
$operating = ($dow -ge 1 -and $dow -le 5 -and $hm -ge "08:25" -and $hm -lt "17:00")
if (-not $operating) { return }

# respect the user's Stop: only keep alive when auto_start is on
$cfg = Join-Path $PSScriptRoot "client_config.json"
$autostart = $false
if (Test-Path $cfg) {
    try { $autostart = [bool]((Get-Content $cfg -Raw -Encoding UTF8 | ConvertFrom-Json).auto_start) } catch {}
}
if (-not $autostart) { return }

# match the AUTO (scheduled) instance only - a manual viewer (client.py w/o 'auto') must not block relaunch
$proc = Get-CimInstance Win32_Process -Filter "Name='python.exe' or Name='pythonw.exe'" |
        Where-Object { $_.CommandLine -match 'client\.py.*auto' }
if (-not $proc) {
    $vbs = Join-Path $PSScriptRoot "run_client.vbs"      # hidden launcher (no cmd window)
    $bat = Join-Path $PSScriptRoot "run_client.bat"
    if (Test-Path $vbs) {
        Start-Process -FilePath "wscript.exe" -ArgumentList "`"$vbs`"", "auto" -WorkingDirectory $PSScriptRoot -WindowStyle Hidden
    } elseif (Test-Path $bat) {
        Start-Process -FilePath $bat -ArgumentList 'auto' -WorkingDirectory $PSScriptRoot -WindowStyle Hidden
    }
}
