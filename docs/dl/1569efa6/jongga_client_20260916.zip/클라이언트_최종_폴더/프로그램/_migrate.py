# -*- coding: utf-8 -*-
"""이전 설치의 개인설정을 새 설정에 병합한다. (_install.ps1 이 호출)

가르는 기준
  개인값  = 그 사람 것    → 이전 값을 **가져온다** (계좌·닉네임·원금·텔레그램…)
  전략값  = 관리자 것     → 새 값을 **강제한다**  (익절·손절·종목당·사이징·게이트)

전략값을 안 덮으면 옛 client_config.json 이 그대로 남아 **익절3%/손절3%** 옛 전략으로 매매한다.
관리자와 다른 전략으로 도는 클라이언트는 밖에서 보이지 않으므로 반드시 여기서 맞춘다.
"""
import io, json, os, sys, datetime

# ★한글 콘솔(cp949)은 — 같은 문자를 못 찍고 print 가 그대로 죽는다 — 마이그레이션이 통째로 안 돌게 된다.
try: sys.stdout.reconfigure(errors="replace")
except Exception: pass

DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG = os.path.join(DIR, "client_config.json")
STATE = os.path.join(DIR, "client_state.json")
KEEP = os.path.join(DIR, "_이전설정")

PERSONAL = ("account", "nickname", "telegram_chat_id", "principal",
            "is_mock", "pw_registered", "hub_url", "card_pos")
STRATEGY = ("tp_pct", "sl_pct", "invest_per_stock", "fee_pct", "cash_buffer",
            "size_div", "min_positions", "gapcut_pct", "float_max", "exclude_upper")


def load(p):
    try: return json.load(io.open(p, encoding="utf-8"))
    except Exception: return None


def save(p, o):
    io.open(p, "w", encoding="utf-8", newline="").write(json.dumps(o, ensure_ascii=False, indent=1))


def main():
    if not os.path.isdir(KEEP):
        print("[--] 이전 설정 없음 - 새로 설치하는 PC 입니다"); return 0

    new = load(CONFIG)
    if new is None:
        print("[오류] client_config.json 을 읽을 수 없습니다"); return 1

    old = load(os.path.join(KEEP, "client_config.json"))
    if old:
        took = []
        for k in PERSONAL:
            v = old.get(k)
            if v in (None, "", {}): continue
            new[k] = v; took.append(k)
        save(CONFIG, new)
        print("[OK] 개인설정 인계 :", ", ".join(took) if took else "(가져올 값 없음)")
        print("[OK] 전략값은 새 값 유지 : 익절 +%g%% / 손절 %g%% / 종목당 %d만 / 갭컷 %g%%"
              % (new.get("tp_pct", 0), new.get("sl_pct", 0),
                 int(new.get("invest_per_stock", 0)) // 10000, new.get("gapcut_pct", 0)))
        ch = [k for k in STRATEGY if old.get(k) != new.get(k)]
        if ch:
            print("[!!] 이전 PC 와 달라진 전략값 :")
            for k in ch: print("       %-18s %s -> %s" % (k, old.get(k), new.get(k)))
    else:
        print("[--] 이전 client_config.json 없음")

    # ── 상태파일: 거래기록만 살리고 포지션은 비운다 ──
    #    ★포지션을 그대로 옮기면 이미 판 종목이 유령으로 남아 유령 청산주문을 낸다.
    #      비워 두면 로그인 직후 query_account() -> _adopt_holdings() 가
    #      실제 계좌에서 매입가까지 정확히 다시 채택한다(추측보다 정확).
    ost = load(os.path.join(KEEP, "client_state.json"))
    if ost:
        tr = ost.get("trades") or []
        keep = {"date": datetime.date.today().strftime("%Y-%m-%d"),
                "positions": [], "upper_today": [], "trades": tr}
        save(STATE, keep)
        drop = len(ost.get("positions") or [])
        print("[OK] 거래기록 %d건 인계 · 포지션 %d개는 비움(로그인 때 실계좌에서 다시 채택)" % (len(tr), drop))

    ol = os.path.join(KEEP, "client_log.txt")
    if os.path.isfile(ol) and not os.path.isfile(os.path.join(DIR, "client_log.txt")):
        io.open(os.path.join(DIR, "client_log.txt"), "w", encoding="utf-8").write(
            io.open(ol, encoding="utf-8", errors="replace").read())
        print("[OK] 이전 로그 이어붙임")
    return 0


if __name__ == "__main__":
    sys.exit(main())
