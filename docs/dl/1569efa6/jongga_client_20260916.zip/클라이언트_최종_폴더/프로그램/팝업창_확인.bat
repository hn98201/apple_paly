@echo off
title Popup Window Probe
cd /d "%~dp0"
set "PY="
if exist "%~dp0python_path.txt" for /f "usebackq delims=" %%A in ("%~dp0python_path.txt") do set "PY=%%A"
if defined PY set "PY=%PY:pythonw.exe=python.exe%"
if defined PY if exist "%PY%" ( "%PY%" window_probe.py & exit /b )
if exist "%LOCALAPPDATA%\Programs\Python\Python312-32\python.exe" ( "%LOCALAPPDATA%\Programs\Python\Python312-32\python.exe" window_probe.py & exit /b )
if exist "%LOCALAPPDATA%\Programs\Python\Python311-32\python.exe" ( "%LOCALAPPDATA%\Programs\Python\Python311-32\python.exe" window_probe.py & exit /b )
py -3-32 window_probe.py
if errorlevel 9009 python window_probe.py
