@echo off
chcp 949 >nul
title Jongga Client - Console Run (see the error)
cd /d "%~dp0"
rem  Same launcher as run_client.bat, but with python.exe (console visible)
rem  so the error message stays on screen instead of vanishing.
set "PY="
set "PYOK="
if exist "%~dp0python_path.txt" for /f "usebackq delims=" %%A in ("%~dp0python_path.txt") do set "PY=%%A"
if defined PY set "PY=%PY:pythonw.exe=python.exe%"
if defined PY if exist "%PY%" set "PYOK=1"
if defined PYOK goto :run
for %%V in (312 311 313 310) do (
  if not defined PYOK if exist "%LOCALAPPDATA%\Programs\Python\Python%%V-32\python.exe" (
    set "PY=%LOCALAPPDATA%\Programs\Python\Python%%V-32\python.exe"
    set "PYOK=1"
  )
)
if defined PYOK goto :run
echo.
echo  [ERROR] 32-bit Python not found.  Run [2_program-install.bat] first,
echo          then run this again.  (Diagnosis: ����.bat)
echo.
pause
exit /b 1

:run
echo Using: %PY%
echo.
"%PY%" client.py
echo.
echo ----------------------------------------------------------
echo  If anything above looks like an error, send this screen
echo  (or ���ܰ��.txt from ����.bat) to the administrator.
echo ----------------------------------------------------------
pause
