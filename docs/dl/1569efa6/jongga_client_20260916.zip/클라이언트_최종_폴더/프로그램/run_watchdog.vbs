' Hidden launcher for client_watchdog.ps1 - NO cmd/powershell window flash.
' wscript has no console; sh.Run(..., 0, False) launches powershell fully hidden.
Option Explicit
Dim sh, fso, d
Set sh  = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
d = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = d
' 0 = hidden window, False = do not wait
sh.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -File """ & d & "\client_watchdog.ps1""", 0, False
