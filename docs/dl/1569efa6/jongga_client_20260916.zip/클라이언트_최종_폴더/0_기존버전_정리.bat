@echo off
title Step 0 - Clean Previous Install
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0_uninstall.ps1"
echo.
pause
