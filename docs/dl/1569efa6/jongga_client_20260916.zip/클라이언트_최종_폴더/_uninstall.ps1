﻿# 종가배팅 클라이언트 - 기존 설치 정리 (재설치/업그레이드용)
#
# 새 PC 면 이 단계는 필요 없다. 이미 깔려 있던 PC 에서만 1단계 前에 한 번 돌린다.
# 지우지 않고 **이름만 바꾼다** — 잘못돼도 되돌릴 수 있게.
$ErrorActionPreference = "SilentlyContinue"
$root = $PSScriptRoot
$prg  = Join-Path $root "프로그램"
$keep = Join-Path $prg "_이전설정"          # 여기로 개인설정을 인계한다(설치 2단계가 읽는다)
$TASKS = @('종가배팅_클라이언트시작','종가배팅_클라이언트감시')

Write-Host "============================================"
Write-Host "  [0단계] 기존 설치 정리 (재설치/업그레이드)" -ForegroundColor Cyan
Write-Host "============================================`n"
Write-Host "새로 설치하는 PC 라면 이 단계는 건너뛰고 [1_PC변형_먼저실행.bat] 부터 하세요.`n"

# ── 1) 옛 설치 폴더 찾기 ───────────────────────────────────────────
#    예약작업의 실행경로가 가장 확실하다. 그게 없으면 바로가기·흔한 위치를 본다.
$found = New-Object System.Collections.Generic.List[string]
function AddDir($p) {
    if (-not $p) { return }
    $p = $p.Trim('"').Trim()
    if (-not (Test-Path -LiteralPath $p)) { return }
    $d = (Resolve-Path -LiteralPath $p).Path
    $cp = Join-Path $d "client.py"
    if (-not (Test-Path -LiteralPath $cp)) { return }
    # ★지금 설치하려는 이 키트 안쪽은 건드리지 않는다(자기 자신을 옛 설치로 오인 방지).
    #   예전엔 client.py 내용으로 '최신인지' 판별했는데, 새 버전끼리 갱신할 때
    #   옛 폴더를 '이미 최신'으로 보고 **설정 인계도 폴더 정리도 건너뛰는** 버그가 있었다.
    $kit = (Resolve-Path -LiteralPath $PSScriptRoot).Path
    if ($d -eq $kit -or $d.StartsWith($kit + [IO.Path]::DirectorySeparatorChar)) {
        Write-Host "  (건너뜀·이번에 설치할 폴더) $d" -ForegroundColor DarkGray
        return
    }
    if ($found -notcontains $d) { $found.Add($d) }
}

foreach ($t in $TASKS) {
    $a = (Get-ScheduledTask -TaskName $t).Actions
    foreach ($x in $a) {
        # 인자에서 .vbs / .bat / .ps1 경로를 뽑아 그 부모 폴더를 본다
        $m = [regex]::Matches("$($x.Execute) $($x.Arguments)", '"?([A-Za-z]:\\[^"]+?\.(vbs|bat|ps1|py))"?')
        foreach ($g in $m) { AddDir (Split-Path -Parent $g.Groups[1].Value) }
    }
}

$lnk = Join-Path ([Environment]::GetFolderPath('Desktop')) "▶ 종가배팅 클라이언트.lnk"
if (Test-Path -LiteralPath $lnk) {
    $sh = New-Object -ComObject WScript.Shell
    AddDir ($sh.CreateShortcut($lnk)).WorkingDirectory
}
# ★바탕화면은 OneDrive 로 리디렉션돼 있을 수 있다 — 둘 다 본다(한쪽만 보면 못 찾는다)
$desks = @([Environment]::GetFolderPath('Desktop'), "$env:USERPROFILE\Desktop",
           "$env:USERPROFILE\OneDrive\Desktop", "$env:USERPROFILE\OneDrive\바탕 화면") |
         Where-Object { $_ } | Select-Object -Unique
foreach ($dk in $desks) {
    foreach ($sub in @("종가배팅_클라이언트", "클라이언트_최종_폴더\프로그램",
                       "종가배팅클라이언트", "클라이언트")) { AddDir (Join-Path $dk $sub) }
}
foreach ($c in @("$env:USERPROFILE\Documents\종가배팅_클라이언트",
                 "C:\종가배팅_클라이언트", "C:\종가배팅클라이언트")) { AddDir $c }

# 지금 설치하려는 폴더 자신은 대상이 아니다(같은 자리에 덮어쓰는 경우)
$self = if (Test-Path -LiteralPath $prg) { (Resolve-Path -LiteralPath $prg).Path } else { "" }
$old = @($found | Where-Object { $_ -ne $self })

Write-Host "── 찾은 것 ──────────────────────────────"
if ($old.Count -gt 0) { foreach ($d in $old) { Write-Host "  옛 설치 폴더 : $d" -ForegroundColor Yellow } }
else                  { Write-Host "  옛 설치 폴더 : 없음(또는 같은 자리에 덮어쓰는 중)" }
foreach ($t in $TASKS) {
    if (Get-ScheduledTask -TaskName $t) { Write-Host "  예약작업     : $t" -ForegroundColor Yellow }
}
$run = Get-CimInstance Win32_Process -Filter "Name='python.exe' or Name='pythonw.exe'" |
       Where-Object { $_.CommandLine -match 'client\.py' }
if ($run) { Write-Host "  실행 중      : client.py ($($run.Count)개)" -ForegroundColor Yellow }
Write-Host ""

Write-Host "── 할 일 ────────────────────────────────"
Write-Host "  1. 실행 중인 클라이언트 종료   (파일이 잠겨 있으면 못 고친다)"
Write-Host "  2. 옛 예약작업 삭제            (안 지우면 옛 폴더의 옛 코드가 계속 뜬다)"
Write-Host "  3. 계좌·닉네임·거래기록 인계   (_이전설정 폴더로 복사 → 설치 2단계가 읽음)"
Write-Host "  4. 옛 폴더 이름만 변경         (_구버전_날짜 · 지우지 않음)"
Write-Host "  5. 옛 바탕화면 바로가기 삭제"
Write-Host ""
$ans = Read-Host "진행할까요? (Y/N)"
if ($ans -notmatch '^[Yy]') { Write-Host "취소했습니다." -ForegroundColor Yellow; return }
Write-Host ""

# ── 2) 실행 중인 클라이언트 종료 ───────────────────────────────────
#    ★먼저 멈춰야 한다 — 메모리의 state 가 파일을 덮어쓰고, 파일도 잠긴다.
$n = 0
foreach ($p in $run) { Stop-Process -Id $p.ProcessId -Force; $n++ }
if ($n -gt 0) { Start-Sleep -Seconds 2 }
Write-Host "[OK] 실행 중인 클라이언트 $n 개 종료"

# ── 3) 예약작업 삭제 ──────────────────────────────────────────────
foreach ($t in $TASKS) {
    if (Get-ScheduledTask -TaskName $t) {
        schtasks /Delete /TN $t /F | Out-Null
        Write-Host "[OK] 예약작업 삭제 : $t"
    }
}

# ── 4) 개인설정 인계 ──────────────────────────────────────────────
#    계좌·닉네임·원금·텔레그램·거래기록은 그 사람 것이다. 전략값은 새 것을 쓴다(설치 2단계가 가른다).
$src = if ($old.Count -gt 0) { $old[0] } else { $prg }
if (-not (Test-Path -LiteralPath $keep)) { New-Item -ItemType Directory -Path $keep -Force | Out-Null }
$got = 0
foreach ($f in @("client_config.json","client_state.json","client_log.txt")) {
    $s = Join-Path $src $f
    if (Test-Path -LiteralPath $s) { Copy-Item -LiteralPath $s -Destination (Join-Path $keep $f) -Force; $got++ }
}
if ($got -gt 0) { Write-Host "[OK] 이전 설정 $got 개 인계 → 프로그램\_이전설정\  (설치 2단계가 자동 병합)" }
else            { Write-Host "[--] 인계할 이전 설정 없음 (새로 입력하면 됩니다)" }

# ── 5) 옛 폴더 이름 변경 (삭제 아님) ──────────────────────────────
foreach ($d in $old) {
    $stamp = Get-Date -Format "yyyyMMdd_HHmm"
    $new = "$d`_구버전_$stamp"
    Rename-Item -LiteralPath $d -NewName (Split-Path -Leaf $new) -Force
    if (Test-Path -LiteralPath $new) { Write-Host "[OK] 옛 폴더 보관   : $new" }
    else {
        Write-Host "[경고] 폴더 이름을 못 바꿨습니다 (파일이 열려 있거나 사용 중)" -ForegroundColor Yellow
        Write-Host "       $d" -ForegroundColor Yellow
        Write-Host "       설정 인계와 예약작업 삭제는 이미 끝났습니다." -ForegroundColor Yellow
        Write-Host "       이 폴더를 직접 다른 이름으로 바꾸거나 지우세요 — 그냥 두면" -ForegroundColor Yellow
        Write-Host "       실수로 옛 client.py 를 띄워 이중매매가 날 수 있습니다." -ForegroundColor Yellow
    }
}

# ── 6) 옛 바로가기 삭제 (설치 2단계가 새로 만든다) ────────────────
if (Test-Path -LiteralPath $lnk) { Remove-Item -LiteralPath $lnk -Force; Write-Host "[OK] 옛 바탕화면 바로가기 삭제" }

# ── 7) 묵은 파이썬 캐시 ───────────────────────────────────────────
$pc = Join-Path $prg "__pycache__"
if (Test-Path -LiteralPath $pc) { Remove-Item -LiteralPath $pc -Recurse -Force; Write-Host "[OK] 파이썬 캐시 정리" }

Write-Host "`n정리 완료! 이제 [1_PC변형_먼저실행.bat] 부터 순서대로 실행하세요." -ForegroundColor Green
Write-Host "옛 폴더는 지우지 않고 '_구버전_날짜' 로 남겨 뒀습니다. 며칠 써 보고 문제 없으면 지우세요."
