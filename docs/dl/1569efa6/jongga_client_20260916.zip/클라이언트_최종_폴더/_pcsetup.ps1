﻿$ErrorActionPreference = "SilentlyContinue"
$root = $PSScriptRoot
Write-Host "============================================"
Write-Host "  [1단계] 이 PC용 변형(초기화)" -ForegroundColor Cyan
Write-Host "============================================`n"

# 1) 다운로드 차단 해제 — 메일/인터넷에서 받은 파일 실행 허용(Mark of the Web 제거)
Get-ChildItem -Path $root -Recurse -File | Unblock-File
Write-Host "[OK] 다운로드 차단 해제 완료 (메일로 받은 파일 실행 허용)"

# 2) 이전 PC 흔적/런타임 파일 정리 — 계좌/상태/로그는 새 PC에서 처음부터
#    ★_이전설정 폴더(0단계가 만든다)는 건드리지 않는다 — 2단계가 그걸 읽어 계좌·닉네임을 되살린다.
$prg = Join-Path $root "프로그램"
if (Test-Path -LiteralPath (Join-Path $prg "_이전설정")) {
    Write-Host "[i] 업그레이드 설치로 감지 - 이전 계좌/닉네임은 2단계에서 자동 복원됩니다" -ForegroundColor Cyan
}
foreach ($f in @("python_path.txt","client_state.json","client_log.txt","restart_history.json")) {
    $p = Join-Path $prg $f
    if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Force }
}
Write-Host "[OK] 런타임 파일 정리 완료 (계좌/설정은 처음 실행 때 본인이 입력)"

Write-Host "`n변형 완료! 이제 [2_프로그램설치.bat] 를 실행하세요." -ForegroundColor Green
