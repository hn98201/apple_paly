@echo off
chcp 949 >nul
title Step 4 - Diagnosis (run this when something goes wrong)
cd /d "%~dp0"
if exist "%~dp0���α׷�\����.bat" (
  call "%~dp0���α׷�\����.bat"
) else (
  echo.
  echo  [ERROR] program folder not found next to this file.
  echo          Run [2_program-install.bat] first.
  echo.
  pause
)
