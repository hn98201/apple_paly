@echo off
title Step 1 - PC Setup (transform)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0_pcsetup.ps1"
echo.
pause
