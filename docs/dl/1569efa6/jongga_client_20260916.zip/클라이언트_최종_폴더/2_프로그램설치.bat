@echo off
title Step 2 - Install Program
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0_install.ps1"
echo.
pause
