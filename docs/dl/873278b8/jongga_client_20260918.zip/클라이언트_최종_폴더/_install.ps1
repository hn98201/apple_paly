﻿$ErrorActionPreference = "Continue"
$root  = $PSScriptRoot
$env0  = Join-Path $root "환경팩"
$prg   = Join-Path $root "프로그램"
$pydir = Join-Path $env:LOCALAPPDATA "Programs\Python\Python312-32"
$py    = Join-Path $pydir "python.exe"
$pyw   = Join-Path $pydir "pythonw.exe"

Write-Host "============================================"
Write-Host "  [2단계] 프로그램 설치 (파이썬+PyQt5+바로가기)" -ForegroundColor Cyan
Write-Host "============================================`n"

# 1) 파이썬 32비트 (키움 OCX 필수) — 번들 설치본 우선, 없으면 온라인
if (Test-Path -LiteralPath $py) {
    Write-Host "[OK] 파이썬 32비트 이미 설치됨"
} else {
    Write-Host "[설치] 파이썬 32비트 설치 중... (1~2분, 창이 잠깐 멈춰도 정상)"
    $setup = Get-ChildItem -LiteralPath $env0 -Filter "python-*-32bit.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $setup) {
        Write-Host "  번들 설치본 없음 → 온라인 다운로드"
        $tmp = Join-Path $env:TEMP "python-32bit.exe"
        Invoke-WebRequest -Uri "https://www.python.org/ftp/python/3.12.10/python-3.12.10.exe" -OutFile $tmp -UseBasicParsing
        $setup = Get-Item $tmp
    }
    Start-Process -FilePath $setup.FullName -ArgumentList "/quiet","InstallAllUsers=0","PrependPath=1","Include_test=0","TargetDir=$pydir" -Wait
    if (Test-Path -LiteralPath $py) { Write-Host "[OK] 파이썬 설치 완료" } else { Write-Host "[경고] 파이썬 설치 확인 실패 — 다시 실행해 보세요." -ForegroundColor Yellow }
}

# 2) PyQt5 — 번들 휠(오프라인) 우선, 실패 시 온라인
Write-Host "[설치] PyQt5 설치 중..."
$wh = Join-Path $env0 "wheels"
if (Test-Path -LiteralPath $wh) { & $py -m pip install --no-index --find-links "$wh" PyQt5 2>&1 | Out-Null }
& $py -c "import PyQt5" 2>$null
if ($LASTEXITCODE -ne 0) { & $py -m pip install "PyQt5==5.15.11" 2>&1 | Out-Null; & $py -c "import PyQt5" 2>$null }
if ($LASTEXITCODE -eq 0) { Write-Host "[OK] PyQt5 설치 확인" } else { Write-Host "[경고] PyQt5 설치 실패 — 인터넷 연결 후 다시 실행하세요." -ForegroundColor Yellow }

# 3) 무창 실행용 파이썬 경로 저장 (BOM 없이)
#    ★확인하고 쓴다 — 예전에는 32비트 설치가 실패해도 경로를 그냥 적어 두었다.
#      그러면 run_client.bat 이 PATH 의 64비트 파이썬으로 떨어지고,
#      키움 OCX 가 안 올라와 영문 AttributeError 로 죽었다. (2026-09-15)
$bits = ""
if (Test-Path -LiteralPath $py) { $bits = (& $py -c "import struct;print(struct.calcsize('P')*8)" 2>$null | Select-Object -First 1) }
if ($bits -ne "32") {
    Write-Host ""
    Write-Host "[중단] 32비트 파이썬을 확인하지 못했습니다 (확인값: '$bits')" -ForegroundColor Red
    Write-Host "       키움 OpenAPI 는 32비트 파이썬에서만 동작합니다." -ForegroundColor Red
    Write-Host "       https://www.python.org/downloads/windows/ 에서" -ForegroundColor Yellow
    Write-Host "       'Windows installer (32-bit)' 3.12.x 를 설치한 뒤 이 파일을 다시 실행하세요." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "       (설치를 여기서 멈춥니다 - 잘못된 경로를 저장하면 나중에 원인을 알 수 없는" -ForegroundColor Yellow
    Write-Host "        오류로 죽습니다)" -ForegroundColor Yellow
    exit 1
}
[System.IO.File]::WriteAllText((Join-Path $prg "python_path.txt"), $pyw, (New-Object System.Text.ASCIIEncoding))
Write-Host "[OK] 파이썬 경로 저장 (32비트 확인됨)"

# 3-0) 설정파일 준비 — ★기존 설정을 절대 덮지 않는다(2026-09-17)
#      배포본에는 client_config.default.json(빈 설정)만 들어 있다.
#      client_config.json 이 이미 있으면 그 사람 설정이므로 손대지 않는다.
#      예전엔 zip 에 client_config.json 을 그대로 넣어서, 0단계를 건너뛰고
#      기존 폴더 위에 풀면 계좌·닉네임이 통째로 날아갔다(안전정지 → 그날 손익절·청산 정지).
$cfgNew = Join-Path $prg "client_config.json"
$cfgDef = Join-Path $prg "client_config.default.json"
if (Test-Path -LiteralPath $cfgDef) {
    if (Test-Path -LiteralPath $cfgNew) {
        Write-Host "[OK] 기존 설정 유지 — client_config.json 을 덮지 않았습니다"
    } else {
        Copy-Item -LiteralPath $cfgDef -Destination $cfgNew -Force
        Write-Host "[OK] 새 설정파일 생성 (client_config.json)"
    }
}

# 3-0-1) ★0단계를 건너뛴 채 재설치하는가 — 그러면 계좌·거래기록이 통째로 날아간다(2026-09-18)
#        _이전설정 이 없으면 _migrate.py 가 안 돌고, 그 결과
#        "설정 계좌 (없음)" 안전정지 반복 + 거래기록 소실이 된다.
#        지금까지는 아무 경고 없이 설치가 끝나서 사용자가 잘 된 줄 알았다.
if (-not (Test-Path -LiteralPath (Join-Path $prg "_이전설정"))) {
    $hint = @()
    foreach ($t in @('종가배팅_클라이언트시작','종가배팅_클라이언트감시','JonggaClientRun')) {
        if (Get-ScheduledTask -TaskName $t -ErrorAction SilentlyContinue) { $hint += "예약작업 $t" }
    }
    foreach ($dk in @([Environment]::GetFolderPath('Desktop'), "$env:USERPROFILE\Desktop",
                      "$env:USERPROFILE\OneDrive\Desktop", "$env:USERPROFILE\OneDrive\바탕 화면")) {
        if ($dk -and (Test-Path -LiteralPath (Join-Path $dk "▶ 종가배팅 클라이언트.lnk"))) { $hint += "옛 바탕화면 바로가기" }
    }
    if ($hint.Count -gt 0) {
        Write-Host ""
        Write-Host "============================================================" -ForegroundColor Red
        Write-Host "  [경고] 이 PC 에 이미 설치된 흔적이 있는데" -ForegroundColor Red
        Write-Host "         [0_기존버전_정리.bat] 을 거치지 않았습니다." -ForegroundColor Red
        Write-Host "============================================================" -ForegroundColor Red
        Write-Host "  찾은 흔적 : $($hint -join ', ')"
        Write-Host ""
        Write-Host "  이대로 진행하면 다음이 인계되지 않습니다 :" -ForegroundColor Yellow
        Write-Host "    · 계좌번호·닉네임  → '설정 계좌 (없음)' 안전정지가 반복됩니다"
        Write-Host "    · 지금까지의 매매기록"
        Write-Host ""
        Write-Host "  [권장] 이 창을 닫고 [0_기존버전_정리.bat] 을 먼저 실행하세요." -ForegroundColor Green
        Write-Host "         (권한 창이 뜨면 반드시 [예])"
        Write-Host ""
        $go = Read-Host "그래도 계속할까요? (계속=Y / 중단=N)"
        if ($go -notmatch '^[Yy]') {
            Write-Host "중단했습니다. [0_기존버전_정리.bat] 부터 실행해 주세요." -ForegroundColor Yellow
            Read-Host "`nEnter 를 눌러 닫기"
            exit 1
        }
        Write-Host ""
        Write-Host "  계속합니다. 매매기록은 나중에 되살릴 수 있습니다 :" -ForegroundColor Yellow
        Write-Host "    프로그램\거래기록_복구.py  를 더블클릭(또는 python 으로 실행)" -ForegroundColor Yellow
        Write-Host ""
    }
}

# 3-1) 이전 설치 설정 병합 — [0_기존버전_정리.bat] 이 남긴 _이전설정 이 있을 때만
#      개인값(계좌·닉네임·원금·텔레그램)은 가져오고, 전략값(익절·손절·종목당)은 새 것을 강제한다.
#      옛 config 를 통째로 두면 익절3%/손절3% 옛 전략으로 조용히 매매한다.
if (Test-Path -LiteralPath (Join-Path $prg "_이전설정")) {
    Write-Host "[인계] 이전 설치 설정 병합 중..."
    & $py (Join-Path $prg "_migrate.py")
}

# 4) 예약작업 제거 (2026-09-16 — 클라이언트는 이제 예약작업을 쓰지 않는다)
#    예전엔 두 개를 등록했다:
#      종가배팅_클라이언트시작 : 평일 08:25 + WakeToRun(자고 있는 PC 를 깨움)
#      종가배팅_클라이언트감시 : 하루 종일 2분마다 powershell 실행
#    남의 PC 에 부담이고 등록할 때 UAC 창까지 떠서 없앴다.
#    대신 프로그램이 켜져 있기만 하면 08:30 로그인 -> 15:25 매수 -> 16:00 애프터마켓 -> 20:05 대기를 스스로 한다.
Write-Host "[정리] 예전 자동 예약작업 제거..."
$removed = 0
foreach ($t in @('종가배팅_클라이언트시작','종가배팅_클라이언트감시')) {
    if (Get-ScheduledTask -TaskName $t -ErrorAction SilentlyContinue) {
        schtasks /Delete /TN $t /F | Out-Null
        Write-Host "  - 제거: $t"; $removed++
    }
}
if ($removed -eq 0) { Write-Host "[OK] 예약작업 없음 - 부팅/평소에 아무것도 돌지 않습니다" }
else { Write-Host "[OK] 예약작업 없음 - $removed 개 제거했습니다" -ForegroundColor Green }

# 4-1) 전원 옵션 — 전원이 연결돼 있으면 PC 가 혼자 절전에 들지 않게.
#      예약작업이 없어졌으니 절전에 들면 깨울 방법도 없다(모니터는 꺼져도 된다).
try {
    # AC(전원 연결) + DC(배터리) 둘 다 끈다.
    # ★예전엔 AC 만 껐다 — 노트북을 배터리로 쓰면 그대로 잠들었다(2026-09-17 감사).
    #   클라이언트는 PC 를 깨우지 않으므로 한 번 자면 그날 매매가 통째로 빠진다.
    powercfg /setacvalueindex SCHEME_CURRENT SUB_SLEEP STANDBYIDLE 0 2>$null
    powercfg /setacvalueindex SCHEME_CURRENT SUB_SLEEP HIBERNATEIDLE 0 2>$null
    powercfg /setdcvalueindex SCHEME_CURRENT SUB_SLEEP STANDBYIDLE 0 2>$null
    powercfg /setdcvalueindex SCHEME_CURRENT SUB_SLEEP HIBERNATEIDLE 0 2>$null
    powercfg /hibernate off 2>$null
    powercfg /setactive SCHEME_CURRENT 2>$null
    Write-Host "[OK] 전원 옵션 - 전원 연결 시 절전 안 함 (모니터는 꺼져도 됩니다)"
} catch {
    Write-Host "[알림] 전원 옵션을 못 바꿨습니다 - [설정 > 전원] 에서" -ForegroundColor Yellow
    Write-Host "       '다음 시간 후 장치를 절전 모드로 전환' 을 '안 함' 으로 바꿔 주세요." -ForegroundColor Yellow
}

# 4-2) 권한지갑 — 키움 UAC 창을 없앤다 (2026-09-17)
#    키움 로그인 실행파일 opstarter.exe 는 매니페스트가 관리자 권한을 요구한다.
#    일반 권한으로 띄우면 로그인할 때마다 파란 UAC 창이 뜨고, 그 창은 프로그램이 대신 못 누른다.
#    -> 트리거 없는 최고권한 작업을 하나 만들어 두고(스스로 도는 일 없음),
#       바탕화면 아이콘이 그 작업을 깨운다. 작업 스케줄러는 UAC 없이 권한을 올려 준다.
Write-Host ""
Write-Host "[등록] 평일 08:20 자동실행 + 키움 UAC 창 없애기..."
$holder = Join-Path $prg "권한지갑_등록.ps1"
if (Test-Path -LiteralPath $holder) {
    & powershell -NoProfile -ExecutionPolicy Bypass -File $holder
} else {
    Write-Host "[경고] 권한지갑_등록.ps1 이 없습니다 - 키움 로그인 때 UAC 창이 뜹니다" -ForegroundColor Yellow
}
$hasHolder = [bool](Get-ScheduledTask -TaskName JonggaClientRun -ErrorAction SilentlyContinue)

# ★등록이 안 됐으면 **크게** 세운다. (2026-09-18 실제 사고)
#   예전엔 조용히 지나가고 마지막 요약에 "08:20 자동실행" 이라고 그대로 적었다.
if (-not $hasHolder) {
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Red
    Write-Host "  [중요] 아침 08:20 자동실행이 등록되지 않았습니다" -ForegroundColor Red
    Write-Host "============================================================" -ForegroundColor Red
    Write-Host "  이대로 두면 내일 아침 프로그램이 스스로 켜지지 않습니다."
    Write-Host "  (2026-09-18 아침에 실제로 이 일이 있었습니다 - 사람이 직접 켜야 했습니다)"
    Write-Host ""
    Write-Host "  고치는 법 : [2_프로그램설치.bat] 을 다시 실행하고" -ForegroundColor Cyan
    Write-Host "              권한 창이 뜨면 반드시 [예] 를 누르세요." -ForegroundColor Cyan
    Write-Host ""
    Read-Host "확인했으면 Enter 를 누르세요"
}

# 5) 바탕화면 바로가기 생성
Write-Host "[바로가기] 바탕화면 실행 아이콘 생성..."
$lnk = Join-Path ([Environment]::GetFolderPath('Desktop')) "▶ 종가배팅 클라이언트.lnk"
$w = New-Object -ComObject WScript.Shell
$s = $w.CreateShortcut($lnk)
$s.TargetPath = "C:\Windows\System32\wscript.exe"
if ($hasHolder) {
    # ★권한지갑 경유 — UAC 창 없이 관리자 권한으로 뜬다
    $s.Arguments = '"' + (Join-Path $prg "run_elevated.vbs") + '"'
} else {
    # 권한지갑이 없다 -> 직접 실행. auto 인자가 있어야 08:30 자동로그인/매매까지 한다
    $s.Arguments = '"' + (Join-Path $prg "run_client.vbs") + '" auto'
}
$s.WorkingDirectory = $prg
$s.IconLocation = "$env:SystemRoot\System32\shell32.dll,137"
$s.Description = "종가배팅 클라이언트 실행"
$s.Save()
if (-not $hasHolder) {
    # ★권한지갑이 없으면 바로가기라도 '관리자 권한으로 실행' 으로 만든다
    #   (.lnk 헤더 0x15 바이트의 0x20 비트). 아이콘 누를 때 UAC 가 한 번 뜨고, 그 뒤로는 안 뜬다.
    try {
        $b = [IO.File]::ReadAllBytes($lnk); $b[0x15] = $b[0x15] -bor 0x20
        [IO.File]::WriteAllBytes($lnk, $b)
        Write-Host "[알림] 권한지갑이 없어 바로가기를 '관리자 권한으로 실행' 으로 만들었습니다." -ForegroundColor Yellow
        Write-Host "       아이콘을 누를 때 UAC 창이 한 번 뜹니다. 완전히 없애려면 [2_프로그램설치.bat] 을 다시 실행하세요."
    } catch { }
}
Write-Host "[OK] 바탕화면 바로가기 생성 (▶ 종가배팅 클라이언트)"
if ($hasHolder) {
    Write-Host "     이 아이콘을 누르면 UAC 창 없이 자동매매까지 시작됩니다" -ForegroundColor Cyan
} else {
    Write-Host "     이 아이콘을 누르면 자동매매까지 시작됩니다" -ForegroundColor Cyan
}

Write-Host ""
Write-Host "동작 방식" -ForegroundColor Cyan
if ($hasHolder) {
    Write-Host "  PC 만 켜 두면 됩니다. 아무것도 누르지 않아도 됩니다."
    Write-Host "    08:20  프로그램 자동실행"
} else {
    Write-Host "  [주의] 08:20 자동실행이 등록되지 않았습니다." -ForegroundColor Red
    Write-Host "         아침마다 바탕화면 [▶ 종가배팅 클라이언트] 를 직접 눌러야 합니다." -ForegroundColor Yellow
    Write-Host "         고치려면 [2_프로그램설치.bat] 을 다시 실행하고 권한 창에서 [예]." -ForegroundColor Cyan
}
Write-Host "    08:30  키움 자동로그인 (장 시작 전 대기)"
Write-Host "    09:00  자동매매 개시 - 손익절"
Write-Host "    15:19  전일 보유 종가청산   15:25 오늘 픽 종가매수"
Write-Host "    16:00  애프터마켓 익절 지정가 (실거래 + 설정에서 켠 경우)"
Write-Host "    20:20  매매 종료 - 프로그램도 종료 (다음 평일 08:20 에 다시 시작)"
Write-Host "  ※ PC 를 깨우지는 않습니다 - 아침에 PC 가 켜져 있어야 합니다."
Write-Host "  ※ 지금 바로 띄우려면 바탕화면 [▶ 종가배팅 클라이언트] 를 누르세요."
Write-Host ""
Write-Host "`n프로그램 설치 완료! 이제 [3_키움설치.bat] 를 실행하세요." -ForegroundColor Green
