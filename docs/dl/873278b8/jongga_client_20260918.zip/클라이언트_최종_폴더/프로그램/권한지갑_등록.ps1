﻿param([switch]$Elevated)
# 종가배팅 클라이언트 - '권한지갑' 예약작업 등록 (2026-09-17)
#
# 왜 필요한가
#   키움 로그인 실행파일 opstarter.exe 는 **매니페스트가 관리자 권한을 요구**한다
#   (requestedExecutionLevel level='requireAdministrator').
#   그래서 일반 권한으로 프로그램을 띄우면 로그인할 때마다 UAC 창이 뜬다.
#   UAC 는 보안 데스크톱에서 뜨므로 **어떤 프로그램도 대신 눌러줄 수 없다** = 무인 불가.
#
# 어떻게 푸는가
#   시간 트리거가 **없는** 예약작업을 최고 권한으로 하나 만들어 둔다(스스로 도는 일 없음).
#   바탕화면 아이콘은 그 작업을 실행시킨다. 작업 스케줄러는 UAC 없이 권한을 올려주므로
#   프로그램이 관리자 권한으로 뜨고, 키움 로그인도 UAC 없이 지나간다.
#
#   ※ 이 등록 자체는 관리자 권한이 필요해 설치 때 한 번만 허용을 받는다.
$ErrorActionPreference = "Continue"
$d   = $PSScriptRoot
$vbs = Join-Path $d 'run_client.vbs'
$T   = 'JonggaClientRun'

if (-not (Test-Path -LiteralPath $vbs)) {
    Write-Host "[오류] run_client.vbs 없음: $vbs" -ForegroundColor Red
    exit 1
}

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
             [Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin -and -not $Elevated) {
    Write-Host ""
    Write-Host "  키움 로그인 프로그램(NKStarter)은 윈도우에 '관리자 권한'을 요구합니다." -ForegroundColor Yellow
    Write-Host "  그래서 그냥 두면 로그인할 때마다 파란 UAC 창이 뜨고, 사람이 눌러야 진행됩니다."
    Write-Host "  지금 한 번만 허용해 두면 **앞으로 그 창이 아예 안 뜹니다.**" -ForegroundColor Cyan
    Write-Host "  -> 잠시 후 뜨는 창에서 [예] 를 눌러 주세요."
    Write-Host ""
    try {
        Start-Process powershell -Verb RunAs -Wait -ArgumentList @(
            "-NoProfile","-ExecutionPolicy","Bypass","-File","`"$PSCommandPath`"","-Elevated")
    } catch {
        Write-Host "[알림] 권한 상승을 건너뛰었습니다." -ForegroundColor Yellow
    }
    # ★상승된 창이 실제로 등록했는지 **반드시 재확인**한다. (2026-09-18)
    #   예전엔 여기서 그냥 exit 0 이었다. [아니오] 를 눌러도 성공처럼 끝나서
    #   설치가 "08:20 자동실행" 이라고 적어 두고, 다음 날 아침 아무 일도 안 일어났다.
    if (Get-ScheduledTask -TaskName $T -ErrorAction SilentlyContinue) {
        Write-Host "[OK] 평일 08:20 자동실행 등록 확인" -ForegroundColor Green
        exit 0
    }
    Write-Host ""
    Write-Host "[실패] 아침 자동실행을 등록하지 못했습니다." -ForegroundColor Red
    Write-Host "       권한 창에서 [아니오] 를 눌렀거나 창이 닫혔습니다."
    Write-Host "       이대로 두면 내일 아침 08:20 에 프로그램이 스스로 켜지지 않습니다." -ForegroundColor Yellow
    Write-Host "       [2_프로그램설치.bat] 을 다시 실행하고 권한 창에서 [예] 를 눌러 주세요." -ForegroundColor Cyan
    exit 1
}

try {
    $act = New-ScheduledTaskAction -Execute "wscript.exe" -Argument ('"' + $vbs + '" auto') -WorkingDirectory $d
    $pr  = New-ScheduledTaskPrincipal -UserId ([Security.Principal.WindowsIdentity]::GetCurrent().Name) `
             -RunLevel Highest -LogonType Interactive
    $st  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
             -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero) -StartWhenAvailable
    # ★평일 08:20 자동실행 (2026-09-17 사용자 지시)
    #   · PC 를 깨우지 않는다(WakeToRun 없음) - "PC 가 켜져 있으면" 이라는 지시 그대로다.
    #   · StartWhenAvailable - 08:20 에 PC 가 꺼져 있었다가 늦게 켜지면 그때 따라잡아 실행한다.
    #   · 바탕화면 아이콘은 이 작업을 그대로 수동 실행한다(schtasks /Run) - 작업 하나로 둘 다 한다.
    $trg = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Monday,Tuesday,Wednesday,Thursday,Friday -At "08:20"
    Register-ScheduledTask -TaskName $T -Action $act -Principal $pr -Settings $st -Trigger $trg -Force | Out-Null
    $chk = Get-ScheduledTask -TaskName $T -ErrorAction SilentlyContinue
    if ($chk -and "$($chk.Principal.RunLevel)" -eq "Highest") {
        Write-Host "[OK] 자동실행 등록 완료 - UAC 창도 뜨지 않습니다" -ForegroundColor Green
        Write-Host "     작업 이름: $T  (ASCII - schtasks/VBS 를 오갈 때 한글이 깨져서)"
        Write-Host "     평일 08:20 자동실행 -> 08:30 키움 자동로그인 -> 09:00 자동매매" -ForegroundColor Cyan
        Write-Host "     PC 를 깨우지는 않습니다. PC 가 켜져 있어야 합니다."
    } else {
        Write-Host "[경고] 등록은 됐지만 최고 권한이 아닙니다 - UAC 창이 뜰 수 있습니다" -ForegroundColor Yellow
    }
} catch {
    Write-Host "[오류] 권한지갑 등록 실패: $_" -ForegroundColor Red
    exit 1
}
