# -*- coding: utf-8 -*-
"""
🐷 종가배팅 스캐너 (키움 OpenAPI+)  ·  김프 시스템 스타일 다크 UI
────────────────────────────────────────────────────────────
세 조건을 모두 만족하는 '종가매수 후보'만 스캔 + 텔레그램 전송.
  ① 세력(빨간선): LRL(20) > LRL(40)  AND  종가 > LRL(20)
  ② 200/400일선: 종가 > MA200  AND  종가 > MA400
  ③ 거래량:       당일 거래량 > 유통주식수 (회전율 100%+)

★ 조회 횟수 제한 대응: 분당 요청 상한 + 제한 감지 시 자동 쿨다운 재개
  + 종목당 요청 최소화(일봉→조건①②→통과분만 유통주식 조회)
"""
import sys, csv, json, time, datetime, urllib.request, urllib.parse
import numpy as np
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QGridLayout, QPushButton, QTableWidget, QTableWidgetItem, QLabel, QComboBox,
    QProgressBar, QPlainTextEdit, QCheckBox, QSpinBox, QFileDialog, QGroupBox,
    QHeaderView, QMessageBox)
from PyQt5.QtCore import Qt, QEventLoop, QTimer
from PyQt5.QtGui import QColor
from PyQt5.QAxContainer import QAxWidget

TG_TOKEN = "8614298361:AAGX2y2nG0ysq6dhkuRWo9BUlVK7Xa9nAgo"
TG_CHAT  = "6977591299"


def _dec(s):
    """키움 OCX가 cp949 한글을 latin1로 넘겨 깨진 문자열 복원(이미 정상이면 원본 유지).
    예: 'SKÀÌÅÍ´Ð½º' → 'SK이터닉스'. 숫자/ASCII는 그대로 통과."""
    try:
        return s.encode("latin1").decode("cp949")
    except (UnicodeEncodeError, UnicodeDecodeError, AttributeError):
        return s

def send_telegram(text):
    try:
        data = urllib.parse.urlencode({"chat_id": TG_CHAT, "text": text}).encode("utf-8")
        req = urllib.request.Request(f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage", data=data)
        with urllib.request.urlopen(req, timeout=15) as r:
            return r.status == 200
    except Exception as e:
        print("[TG]", e); return False

def send_telegram_long(text, limit=3900):
    """텔레그램 4096자 제한 대응: 줄 단위로 나눠 여러 메시지로 전송."""
    lines = text.split("\n"); chunks = []; cur = ""
    for ln in lines:
        while len(ln) > limit:                 # 한 줄이 너무 길면 강제 분할
            chunks.append(ln[:limit]); ln = ln[limit:]
        if cur and len(cur) + len(ln) + 1 > limit:
            chunks.append(cur); cur = ln
        else:
            cur = ln if not cur else cur + "\n" + ln
    if cur: chunks.append(cur)
    n = len(chunks); ok = True
    for i, ch in enumerate(chunks, 1):
        head = f"({i}/{n})\n" if n > 1 else ""
        ok = send_telegram(head + ch) and ok
        if i < n: time.sleep(0.5)
    return ok

def tg_send_id(text):
    """전송 후 message_id 반환(라이브 편집용). 실패 시 None."""
    try:
        data = urllib.parse.urlencode({"chat_id": TG_CHAT, "text": text}).encode("utf-8")
        req = urllib.request.Request(f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage", data=data)
        with urllib.request.urlopen(req, timeout=15) as r:
            return json.loads(r.read().decode("utf-8")).get("result", {}).get("message_id")
    except Exception as e:
        print("[TG]", e); return None

def tg_edit(message_id, text):
    """기존 메시지를 새 내용으로 편집(한 메시지로 라이브 갱신)."""
    if not message_id:
        return send_telegram(text)
    try:
        data = urllib.parse.urlencode({"chat_id": TG_CHAT, "message_id": message_id,
                                       "text": text}).encode("utf-8")
        req = urllib.request.Request(f"https://api.telegram.org/bot{TG_TOKEN}/editMessageText", data=data)
        with urllib.request.urlopen(req, timeout=15) as r:
            return r.status == 200
    except Exception as e:
        print("[TG-edit]", e); return False

def fail_reasons(r):
    """탈락 종목의 사유(어떤 조건이 왜 안 됐는지)."""
    out = []
    if not r.get("c1"):
        out.append("①세력약(LRL20≤LRL40)" if r["lrl1"] <= r["lrl2"] else "①종가<LRL20")
    if not r.get("c2"):
        if r["close"] <= r["ma200"]: out.append("②종가<MA200")
        elif r["close"] <= r["ma400"]: out.append("②종가<MA400")
        else: out.append("②이평선미달")
    if not r.get("c3"):
        out.append(f"③거래량부족(회전율{r.get('turnover', 0):.2f})")
    return out

def cond_marks(r):
    """조건별 색상 표기 — 충족 🟢 / 미충족 🔴 (텔레그램은 글자색 미지원→색이모지)."""
    return " ".join((("🟢" if r.get(f"c{i}") else "🔴") + n)
                    for i, n in ((1, "①"), (2, "②"), (3, "③")))

DEF_LRL1, DEF_LRL2 = 20, 40
DEF_MA_A, DEF_MA_B = 200, 400
DEF_REQ_MS   = 350     # TR 최소 간격(ms)
DEF_PER_MIN  = 65      # 분당 최대 요청수 (키움 제한 회피)
COOLDOWN_S   = 62      # 제한 감지 시 쿨다운(초)
NEED_BARS    = 405

def _int(s):
    if s is None: return 0
    t = "".join(c for c in str(s) if c.isdigit() or c == "-")
    try: return abs(int(t)) if t not in ("", "-") else 0
    except ValueError: return 0

def _float(s):
    if s is None: return 0.0
    t = "".join(c for c in str(s) if c.isdigit() or c in ".-")
    try: return abs(float(t)) if t not in ("", ".", "-") else 0.0
    except ValueError: return 0.0

def lrl_endpoint(closes):
    n = len(closes); x = np.arange(n, dtype=float)
    sx, sy = x.sum(), closes.sum()
    denom = n * (x * x).sum() - sx * sx
    if denom == 0: return float(closes[-1])
    b = (n * (x * closes).sum() - sx * sy) / denom
    a = (sy - b * sx) / n
    return float(a + b * (n - 1))

def smart_float(info):
    price = _int(info.get("현재가")); mcap_eok = _int(info.get("시가총액"))
    ratio = _float(info.get("유통비율")); fs_raw = _int(info.get("유통주식"))
    total = int(mcap_eok * 1e8 / price) if (price > 0 and mcap_eok > 0) else 0
    if ratio > 0 and total > 0:
        return int(total * ratio / 100.0), f"유통비율 {ratio:.1f}% × 총주 {total:,}"
    if fs_raw > 0 and total > 0:
        if fs_raw * 1000 <= total * 1.05: return fs_raw * 1000, f"유통주식 {fs_raw:,}천주"
        if fs_raw <= total * 1.05: return fs_raw, f"유통주식 {fs_raw:,}주"
    if fs_raw > 0: return fs_raw * 1000, f"유통주식 {fs_raw:,}(천주가정)"
    if total > 0: return total, f"총주식수 {total:,}(유통비율없음)"
    return 0, "산출불가"

def _wait(ms):
    loop = QEventLoop(); QTimer.singleShot(int(ms), loop.quit); loop.exec_()

# ── 키움 래퍼 (조회제한 대응 내장) ────────────────────────
class Kiwoom(QAxWidget):
    def __init__(self):
        super().__init__("KHOPENAPI.KHOpenAPICtrl.1")
        # ★OCX 로딩 실패는 예외가 아니라 '빈 위젯'으로 돌아온다 — 여기서 잡아 한글로 알린다.
        #   (안 잡으면 아래 OnEventConnect 줄에서 영문 AttributeError 만 뜬다. 2026-09-15)
        try:
            from kiwoom_ocx import ensure_loaded
            ensure_loaded(self)
        except ImportError:
            if not hasattr(self, "OnEventConnect"):
                raise RuntimeError("키움 OpenAPI(OCX) 를 불러오지 못했습니다. "
                                   "[3_키움설치.bat] 실행 후 다시 시도하세요.")
        self._login_loop = self._tr_loop = self._cond_loop = None
        self.tr_data = None; self.connected = False; self.conditions = {}
        self._prevnext = "0"; self.limit_hit = False; self.abort = False
        self.min_interval = DEF_REQ_MS / 1000.0
        self.max_per_min = DEF_PER_MIN
        self._req_times = []; self._last_req = 0.0
        self.on_pause = None; self.on_log = None
        # ── 실시간 체결(SetRealReg) 인프라: 매 틱 푸시 → TR제한 없이 실시간 감시 ──
        self.real_prices = {}          # code -> 최신 실시간 현재가(양수)
        self.real_hi = {}; self.real_lo = {}   # code -> 실시간 장중 고/저(폴링 누락 없음)
        self._real_cb = None           # 틱 콜백 cb(code, price)
        self._real_screen = "9500"
        self.OnEventConnect.connect(self._on_login)
        self.OnReceiveTrData.connect(self._on_tr)
        self.OnReceiveMsg.connect(self._on_msg)
        self.OnReceiveConditionVer.connect(self._on_cond_ver)
        self.OnReceiveTrCondition.connect(self._on_tr_cond)
        try:
            self.OnReceiveRealData.connect(self._on_real)
        except Exception:
            pass

    def login(self):
        self.dynamicCall("CommConnect()")
        self._login_loop = QEventLoop(); self._login_loop.exec_()
    def _on_login(self, err):
        self.connected = (err == 0)
        if self._login_loop: self._login_loop.exit()
    def get(self, name): return self.dynamicCall("GetLoginInfo(QString)", name)
    def codes(self, market):
        return [c for c in self.dynamicCall("GetCodeListByMarket(QString)", market).split(';') if c]
    def name(self, code): return _dec(self.dynamicCall("GetMasterCodeName(QString)", code).strip())

    def load_conditions(self):
        # ★조건검색 로드 재시도(간헐적 실패/서버지연 대비) — 빈 목록이면 최대 4회 재시도, 8초 대기
        for _attempt in range(4):
            self.conditions = {}
            self.dynamicCall("GetConditionLoad()")
            self._cond_loop = QEventLoop(); QTimer.singleShot(8000, self._cond_loop.quit); self._cond_loop.exec_()
            if self.conditions:
                return self.conditions
            if self.on_log:
                self.on_log(f"  ⏳ 조건검색 로드 빈 목록 → 재시도 {_attempt+1}/4")
        return self.conditions
    def _on_cond_ver(self, ret, msg):
        raw = self.dynamicCall("GetConditionNameList()"); self.conditions = {}
        for it in [x for x in raw.split(';') if x]:
            idx, nm = it.split('^')
            self.conditions[_dec(nm)] = idx        # ★OCX cp949→latin1 깨짐 복원
        if self._cond_loop: self._cond_loop.exit()
    def send_condition(self, cond_name):
        idx = self.conditions.get(cond_name)
        if idx is None: return []
        self._cond_codes = []
        self.dynamicCall("SendCondition(QString, QString, int, int)", "9001", cond_name, int(idx), 0)
        self._cond_loop = QEventLoop(); QTimer.singleShot(6000, self._cond_loop.quit); self._cond_loop.exec_()
        return self._cond_codes
    def _on_tr_cond(self, scr, code_list, cond_name, idx, nnext):
        self._cond_codes = [c for c in code_list.split(';') if c]
        if self._cond_loop: self._cond_loop.exit()

    # ── 제한 감지 ──
    def _on_msg(self, scr, rq, tr, msg):
        """★키움이 보내는 메시지를 **전부** 남긴다. (2026-09-18)

        예전엔 '제한/초과/과부하/횟수' 가 든 것만 찍고 나머지를 버렸다.
        그래서 "조회가 계속 실패합니다 — 계좌비밀번호를 확인해주세요" 같은
        **실패 이유가 어디에도 안 남아** 원인을 추측할 수밖에 없었다(실제로 그렇게 헤맸다).
        같은 메시지가 반복되면 한 번만 남긴다 — 매 조회마다 찍히면 정작 중요한 게 묻힌다."""
        m = (msg or "").strip()
        if m:                       # ★마지막 메시지를 TR 별로 보관 — 화면이 실패 이유를 추측 대신 그대로 말하게
            d = getattr(self, "last_msg", None)
            if d is None: d = self.last_msg = {}
            d[tr or ""] = m; d["_last"] = m
        if any(k in m for k in ("제한", "초과", "과부하", "횟수")):
            self.limit_hit = True
            if self.on_log: self.on_log(f"⚠️ 키움 메시지: {m}")
            return
        if not m: return
        seen = getattr(self, "_msg_seen", None)
        if seen is None: seen = self._msg_seen = set()
        key = (tr or "") + "|" + m
        if key in seen: return
        seen.add(key)
        if self.on_log: self.on_log(f"📩 키움 메시지[{tr}]: {m}")

    # ── 레이트 리미터 ──
    def _throttle(self):
        now = time.time()
        if self._last_req:
            gap = now - self._last_req
            if gap < self.min_interval:
                _wait((self.min_interval - gap) * 1000); now = time.time()
        self._req_times = [t for t in self._req_times if now - t < 60]
        if len(self._req_times) >= self.max_per_min:
            wait_s = 60 - (now - self._req_times[0]) + 0.3
            self._pause(wait_s, "분당 한도")
            now = time.time(); self._req_times = [t for t in self._req_times if now - t < 60]
        self._req_times.append(now); self._last_req = now

    def _pause(self, secs, reason):
        end = time.time() + secs
        while time.time() < end and not self.abort:
            left = int(end - time.time()) + 1
            if self.on_pause: self.on_pause(left, reason)
            _wait(500)

    def _cooldown(self, reason):
        if self.on_log: self.on_log(f"⏸ 조회제한({reason}) — {COOLDOWN_S}초 대기 후 재개")
        self._pause(COOLDOWN_S, "조회제한 쿨다운")
        self._req_times = []; self.limit_hit = False

    # ── TR 요청 (스로틀 + 제한 재시도) ──
    def _request(self, rqname, trcode, screen="9100", prevnext=0):
        for _ in range(6):
            if self.abort: return -1
            self._throttle()
            self.limit_hit = False
            ret = self.dynamicCall("CommRqData(QString, QString, int, QString)",
                                   rqname, trcode, prevnext, screen)
            if ret in (-200, -201, -308):
                self._cooldown(f"CommRqData {ret}"); continue
            if ret != 0:
                return ret
            self._tr_loop = QEventLoop(); QTimer.singleShot(8000, self._tr_loop.quit); self._tr_loop.exec_()
            if self.limit_hit:
                self._cooldown("OnReceiveMsg"); continue
            return 0
        return -999

    def _on_tr(self, scr, rqname, trcode, record, prevnext, *a):
        self._prevnext = prevnext
        if trcode == "opt10081":
            cnt = self.dynamicCall("GetRepeatCnt(QString, QString)", trcode, rqname); rows = []
            for i in range(cnt):
                g = lambda f: self.dynamicCall("GetCommData(QString,QString,int,QString)", trcode, rqname, i, f).strip()
                try: rows.append((g("일자"), abs(int(g("현재가"))), abs(int(g("거래량")))))
                except ValueError: pass
            self.tr_data = rows
        elif trcode == "opt10001":
            g = lambda f: self.dynamicCall("GetCommData(QString,QString,int,QString)", trcode, rqname, 0, f).strip()
            self.tr_data = {k: (_dec(g(k)) if k == "종목명" else g(k)) for k in ("종목명","유통주식","상장주식","유통비율","시가총액","거래량","현재가","상한가","하한가")}
        if self._tr_loop: self._tr_loop.exit()

    def daily(self, code):
        self.dynamicCall("SetInputValue(QString, QString)", "종목코드", code)
        self.dynamicCall("SetInputValue(QString, QString)", "기준일자", datetime.date.today().strftime("%Y%m%d"))
        self.dynamicCall("SetInputValue(QString, QString)", "수정주가구분", "1")
        self.tr_data = None
        if self._request("일봉", "opt10081") != 0: return None
        rows = self.tr_data or []
        if len(rows) < NEED_BARS and str(self._prevnext).strip() == "2":
            self.dynamicCall("SetInputValue(QString, QString)", "종목코드", code)
            self.dynamicCall("SetInputValue(QString, QString)", "수정주가구분", "1")
            self.tr_data = None
            if self._request("일봉", "opt10081", prevnext=2) == 0 and self.tr_data:
                rows = rows + self.tr_data
        return rows
    def basic(self, code):
        self.dynamicCall("SetInputValue(QString, QString)", "종목코드", code)
        self.tr_data = None
        if self._request("기본정보", "opt10001") != 0: return None
        return self.tr_data

    # ── 실시간 체결(SetRealReg) ── TR 아닌 이벤트 푸시라 시간당 제한 없음. 매 틱 현재가 갱신 ──
    def _on_real(self, code, real_type, real_data):
        """OCX 실시간 푸시. FID10=현재가(부호포함). 주식체결이 아니면 FID10이 비어 무시됨."""
        try:
            raw = self.dynamicCall("GetCommRealData(QString, int)", code, 10)
            px = abs(int(raw)) if raw not in (None, "") else 0
            if px <= 0:
                return
            self.real_prices[code] = px
            h = self.real_hi.get(code); l = self.real_lo.get(code)
            self.real_hi[code] = px if h is None else (px if px > h else h)
            self.real_lo[code] = px if l is None else (px if px < l else l)
            cb = self._real_cb
            if cb:
                try: cb(code, px)
                except Exception: pass
        except Exception:
            pass

    def set_real(self, codes, cb=None):
        """실시간 시세 등록. codes=리스트, cb(code,price)=매 틱 호출(±손익절 즉시판정용)."""
        try:
            self._real_cb = cb
            lst = ";".join([c for c in codes if c])
            if not lst:
                return False
            self.dynamicCall("SetRealReg(QString, QString, QString, QString)",
                             self._real_screen, lst, "10", "0")
            return True
        except Exception as e:
            if self.on_log: self.on_log(f"SetRealReg 오류 {e}")
            return False

    def clear_real(self):
        """실시간 등록 해제."""
        try:
            self._real_cb = None
            self.dynamicCall("SetRealRemove(QString, QString)", self._real_screen, "ALL")
        except Exception:
            pass

QSS = """
* { font-family: 'Malgun Gothic','Segoe UI'; font-size: 12px; }
QMainWindow, QWidget { background: #0b0e16; color: #e8e6ef; }
QLabel { color: #cbd0dd; }
QGroupBox { border: 1px solid #262a38; border-radius: 12px; margin-top: 16px; padding: 10px;
            background: #12151f; font-weight: bold; color: #c084fc; }
QGroupBox::title { subcontrol-origin: margin; left: 14px; padding: 0 6px; }
QPushButton { background: #7c3aed; color: white; border: none; border-radius: 10px; padding: 9px 14px; font-weight: bold; }
QPushButton:hover { background: #9560f0; } QPushButton:pressed { background: #6d28d9; }
QPushButton:disabled { background: #2a2d3a; color: #6b7280; }
QComboBox, QSpinBox { background: #1a1e2b; color: #e8e6ef; border: 1px solid #2e3346; border-radius: 8px; padding: 5px 8px; }
QComboBox QAbstractItemView { background: #1a1e2b; color: #e8e6ef; selection-background-color: #7c3aed; }
QCheckBox { color: #cbd0dd; }
QTableWidget { background: #12151f; alternate-background-color: #151a26; gridline-color: #262a38;
               border: 1px solid #262a38; border-radius: 10px; }
QHeaderView::section { background: #1c2130; color: #c084fc; padding: 8px; border: none;
                       border-right: 1px solid #262a38; font-weight: bold; }
QPlainTextEdit { background: #0e1119; color: #93c5b0; border: 1px solid #262a38; border-radius: 8px;
                 font-family: Consolas; font-size: 11px; }
QProgressBar { background: #1a1e2b; border: 1px solid #2e3346; border-radius: 8px; text-align: center; color: #e8e6ef; height: 18px; }
QProgressBar::chunk { background: #7c3aed; border-radius: 7px; }
QScrollBar:vertical { background: #12151f; width: 10px; }
QScrollBar::handle:vertical { background: #2e3346; border-radius: 5px; }
"""

class MainWindow(QMainWindow):
    COLS = ["코드", "종목명", "💰종가", "📊거래량", "🔓유통주식", "🔄회전율",
            "LRL20", "LRL40", "MA200", "MA400", "①세력", "②돌파", "③거래량", "🎯종합"]

    def __init__(self):
        super().__init__()
        self.setWindowTitle("🐷 종가배팅 스캐너 · 세력 따라잡기")
        self.resize(1220, 780)
        self.kiwoom = Kiwoom()
        self.kiwoom.on_pause = self._on_pause
        self.kiwoom.on_log = self.logmsg
        self.stop_flag = False; self.results = []
        self._build(); self.setStyleSheet(QSS)

    def _build(self):
        cw = QWidget(); self.setCentralWidget(cw)
        root = QVBoxLayout(cw); root.setContentsMargins(14, 12, 14, 12); root.setSpacing(10)
        head = QLabel("🐷  <b>종가배팅 스캐너</b>  🚀")
        head.setStyleSheet("font-size: 24px; color: #c084fc; padding: 4px;")
        sub = QLabel("세력 따라잡기 · <b>①</b>빨간선(LRL20&gt;40) <b>②</b>200·400일선 돌파 "
                     "<b>③</b>거래량&gt;유통주식  → 3조건 종가매수 후보만 스캔 + 텔레그램 전송")
        sub.setStyleSheet("font-size: 12px; color: #8b93a7;")
        root.addWidget(head); root.addWidget(sub)

        top = QHBoxLayout()
        self.btn_login = QPushButton("🔑 ① 키움 로그인"); self.btn_login.clicked.connect(self.on_login)
        self.lbl_status = QLabel("● 미접속")
        self.lbl_status.setStyleSheet("color:#ef4444; font-weight:bold; font-size:13px;")
        top.addWidget(self.btn_login); top.addWidget(self.lbl_status); top.addStretch()
        root.addLayout(top)

        gb = QGroupBox("⚙️ 스캔 설정"); g = QGridLayout(gb)
        self.cmb_universe = QComboBox()
        self.cmb_universe.addItems(["KOSPI+KOSDAQ 전체", "KOSPI만", "KOSDAQ만", "조건검색식 사용(권장)"])
        self.cmb_universe.setCurrentIndex(3)
        self.cmb_cond = QComboBox()
        self.cmb_universe.currentIndexChanged.connect(lambda i: self.cmb_cond.setEnabled(i == 3))
        self.sp_lrl1 = QSpinBox(); self.sp_lrl1.setRange(2,200); self.sp_lrl1.setValue(DEF_LRL1)
        self.sp_lrl2 = QSpinBox(); self.sp_lrl2.setRange(2,400); self.sp_lrl2.setValue(DEF_LRL2)
        self.sp_maa = QSpinBox(); self.sp_maa.setRange(5,600); self.sp_maa.setValue(DEF_MA_A)
        self.sp_mab = QSpinBox(); self.sp_mab.setRange(5,600); self.sp_mab.setValue(DEF_MA_B)
        self.sp_req = QSpinBox(); self.sp_req.setRange(200,3000); self.sp_req.setValue(DEF_REQ_MS)
        self.sp_permin = QSpinBox(); self.sp_permin.setRange(20,300); self.sp_permin.setValue(DEF_PER_MIN)
        self.chk_tg = QCheckBox("✅ 스캔완료 시 텔레그램 자동전송"); self.chk_tg.setChecked(True)
        self.chk_showall = QCheckBox("🔎 탈락종목도 표시(사유확인)"); self.chk_showall.setChecked(True)
        g.addWidget(QLabel("대상"),0,0); g.addWidget(self.cmb_universe,0,1)
        g.addWidget(QLabel("조건검색식"),0,2); g.addWidget(self.cmb_cond,0,3)
        g.addWidget(QLabel("LRL 단기/장기"),1,0)
        w1=QWidget(); h1=QHBoxLayout(w1); h1.setContentsMargins(0,0,0,0); h1.addWidget(self.sp_lrl1); h1.addWidget(self.sp_lrl2); g.addWidget(w1,1,1)
        g.addWidget(QLabel("MA A/B"),1,2)
        w2=QWidget(); h2=QHBoxLayout(w2); h2.setContentsMargins(0,0,0,0); h2.addWidget(self.sp_maa); h2.addWidget(self.sp_mab); g.addWidget(w2,1,3)
        g.addWidget(QLabel("요청간격(ms)"),2,0); g.addWidget(self.sp_req,2,1)
        g.addWidget(QLabel("분당 최대요청"),2,2); g.addWidget(self.sp_permin,2,3)
        g.addWidget(self.chk_tg,3,0,1,2)
        g.addWidget(self.chk_showall,3,2,1,2)
        root.addWidget(gb)

        btns = QHBoxLayout()
        self.btn_reload = QPushButton("🔄 조건식 새로고침"); self.btn_reload.clicked.connect(self.on_reload_cond)
        self.btn_test = QPushButton("🧪 ② 1종목 테스트(005930)"); self.btn_test.clicked.connect(self.on_test)
        self.btn_scan = QPushButton("🔍 ③ 스캔 시작"); self.btn_scan.clicked.connect(self.on_scan)
        self.btn_stop = QPushButton("⏹ 중지"); self.btn_stop.clicked.connect(self.on_stop)
        self.btn_tg   = QPushButton("📤 텔레그램 전송"); self.btn_tg.clicked.connect(self.on_tg)
        self.btn_csv  = QPushButton("💾 CSV 저장"); self.btn_csv.clicked.connect(self.on_csv)
        for b in (self.btn_reload,self.btn_test,self.btn_scan,self.btn_stop,self.btn_tg,self.btn_csv): btns.addWidget(b)
        root.addLayout(btns)

        self.pbar = QProgressBar(); root.addWidget(self.pbar)
        self.lbl_count = QLabel("🎯 후보 0종목")
        self.lbl_count.setStyleSheet("color:#22c55e; font-weight:bold; font-size:14px;")
        root.addWidget(self.lbl_count)

        self.table = QTableWidget(0, len(self.COLS))
        self.table.setHorizontalHeaderLabels(self.COLS); self.table.setAlternatingRowColors(True)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        root.addWidget(self.table, 1)
        self.log = QPlainTextEdit(); self.log.setReadOnly(True); self.log.setMaximumHeight(130)
        root.addWidget(self.log)

    def logmsg(self, s):
        self.log.appendPlainText(f"[{datetime.datetime.now():%H:%M:%S}] {s}")
        self.log.ensureCursorVisible(); QApplication.processEvents()

    def _on_pause(self, secs_left, reason):
        self.lbl_count.setText(f"⏸ {reason} — {secs_left}초 대기 중…")
        self.lbl_count.setStyleSheet("color:#f59e0b; font-weight:bold; font-size:14px;")
        QApplication.processEvents()

    def on_login(self):
        self.logmsg("🔑 로그인 시도... (영웅문 로그인창)")
        self.kiwoom.login()
        if self.kiwoom.connected:
            self.lbl_status.setText(f"● 접속됨: {self.kiwoom.get('USER_ID')}")
            self.lbl_status.setStyleSheet("color:#22c55e; font-weight:bold; font-size:13px;")
            self.logmsg("✅ 로그인 성공. 조건검색식 로드중...")
            try:
                conds = self.kiwoom.load_conditions()
                self.cmb_cond.clear(); self.cmb_cond.addItems(list(conds.keys()))
                self.logmsg(f"📋 조건검색식 {len(conds)}개")
            except Exception as e:
                self.logmsg(f"조건검색식 로드 스킵: {e}")
        else:
            self.lbl_status.setText("● 로그인 실패"); self.logmsg("❌ 로그인 실패")

    def on_reload_cond(self):
        if not self.kiwoom.connected:
            QMessageBox.warning(self, "안내", "먼저 로그인하세요."); return
        try:
            conds = self.kiwoom.load_conditions()
            self.cmb_cond.clear(); self.cmb_cond.addItems(list(conds.keys()))
            self.logmsg(f"🔄 조건검색식 {len(conds)}개 새로고침: {', '.join(list(conds.keys())[:8])}")
        except Exception as e:
            self.logmsg(f"조건식 새로고침 실패: {e}")

    def universe(self):
        u = self.cmb_universe.currentIndex()
        if u == 3:
            nm = self.cmb_cond.currentText()
            if not nm: self.logmsg("조건검색식 없음 — 영웅문에서 조건식을 먼저 만드세요"); return []
            codes = self.kiwoom.send_condition(nm)
            self.logmsg(f"📋 조건검색 '{nm}' → {len(codes)}종목"); return codes
        codes = []
        if u in (0,1): codes += self.kiwoom.codes("0")
        if u in (0,2): codes += self.kiwoom.codes("10")
        return [c for c in codes if len(c) == 6]

    def fetch_eval(self, code, p1, p2, ma_a, ma_b, full=True):
        """full=True면 모든 종목 유통주식까지 조회(①②③ 전부 표시). False면 ①②통과분만(속도)."""
        rows = self.kiwoom.daily(code)
        if not rows or len(rows) < max(ma_b, p2) + 1: return None
        rs = sorted(rows, key=lambda x: x[0])
        closes = np.array([r[1] for r in rs], float)
        close = float(closes[-1])
        lrl1 = lrl_endpoint(closes[-p1:]); lrl2 = lrl_endpoint(closes[-p2:])
        ma200 = float(closes[-ma_a:].mean()); ma400 = float(closes[-ma_b:].mean())
        c1 = (lrl1 > lrl2) and (close > lrl1)
        c2 = (close > ma200) and (close > ma400)
        if not full and not (c1 and c2):
            return {"ok": False, "prefilter": True}      # 속도모드: 유통주식 조회 생략
        info = self.kiwoom.basic(code)
        if not info:
            float_shares, method, name = 0, "정보조회실패", self.kiwoom.name(code)
            vol = rs[-1][2]; c3 = False
        else:
            float_shares, method = smart_float(info)
            vol = rs[-1][2]; v2 = _int(info.get("거래량"))
            if v2 > 0: vol = v2
            c3 = (float_shares > 0) and (vol > float_shares)
            name = info.get("종목명") or self.kiwoom.name(code)
        return dict(code=code, name=name, close=close, vol=vol, lrl1=lrl1, lrl2=lrl2,
                    ma200=ma200, ma400=ma400, float=float_shares, c1=c1, c2=c2, c3=c3,
                    ok=(c1 and c2 and c3),
                    turnover=(vol/float_shares if float_shares else 0), method=method)

    def add_row(self, r):
        t = self.table; row = t.rowCount(); t.insertRow(row)
        def cell(v, color=None):
            it = QTableWidgetItem(str(v)); it.setTextAlignment(Qt.AlignCenter)
            if color: it.setForeground(QColor(color))
            return it
        mark = lambda b: ("✅","#22c55e") if b else ("❌","#ef4444")
        base = [r["code"], r["name"], f"{r['close']:,.0f}", f"{r['vol']:,}", f"{r['float']:,}",
                f"{r['turnover']:.2f}", f"{r['lrl1']:,.0f}", f"{r['lrl2']:,.0f}",
                f"{r['ma200']:,.0f}", f"{r['ma400']:,.0f}"]
        for i, v in enumerate(base): t.setItem(row, i, cell(v))
        for i, b in enumerate([r["c1"], r["c2"], r["c3"]]):
            txt, col = mark(b); t.setItem(row, 10+i, cell(txt, col))
        tot, col = ("🎯 매수","#22c55e") if r["ok"] else ("–","#6b7280")
        t.setItem(row, 13, cell(tot, col))
        if r["ok"]:
            for c in range(t.columnCount()):
                if t.item(row,c): t.item(row,c).setBackground(QColor("#132a1e"))

    def on_test(self):
        if not self.kiwoom.connected: QMessageBox.warning(self,"안내","먼저 로그인하세요."); return
        self.kiwoom.abort = False
        self.logmsg("🧪 삼성전자(005930) 테스트")
        # 테스트는 조건 무관하게 전체 표시
        rows = self.kiwoom.daily("005930")
        info = self.kiwoom.basic("005930")
        if not rows or not info: self.logmsg("❌ 수집 실패"); return
        rs = sorted(rows, key=lambda x: x[0]); closes = np.array([r[1] for r in rs], float)
        fs, method = smart_float(info); vol = _int(info.get("거래량")) or rs[-1][2]
        from_ev = dict(code="005930", name=info.get("종목명"),
            **{k: v for k, v in zip(("close","lrl1","lrl2","ma200","ma400"),
               (float(closes[-1]), lrl_endpoint(closes[-self.sp_lrl1.value():]),
                lrl_endpoint(closes[-self.sp_lrl2.value():]),
                float(closes[-self.sp_maa.value():].mean()), float(closes[-self.sp_mab.value():].mean())))},
            vol=vol, float=fs, method=method)
        from_ev["c1"] = (from_ev["lrl1"] > from_ev["lrl2"]) and (from_ev["close"] > from_ev["lrl1"])
        from_ev["c2"] = (from_ev["close"] > from_ev["ma200"]) and (from_ev["close"] > from_ev["ma400"])
        from_ev["c3"] = fs > 0 and vol > fs
        from_ev["ok"] = from_ev["c1"] and from_ev["c2"] and from_ev["c3"]
        from_ev["turnover"] = vol/fs if fs else 0
        self.add_row(from_ev)
        self.logmsg(f"🔓 유통주식={fs:,} ({method}) · 거래량={vol:,} · 종가={from_ev['close']:,.0f} · 회전율={from_ev['turnover']:.4f}")

    def on_stop(self):
        self.stop_flag = True; self.kiwoom.abort = True

    def on_scan(self):
        if not self.kiwoom.connected: QMessageBox.warning(self,"안내","먼저 로그인하세요."); return
        if getattr(self, "scanning", False):
            self.logmsg("⚠️ 이미 스캔 중입니다 (중복 실행 방지)"); return
        self.scanning = True; self.btn_scan.setEnabled(False)
        try:
            self.stop_flag = False; self.kiwoom.abort = False; self.results = []; self.table.setRowCount(0)
            self.kiwoom.min_interval = self.sp_req.value()/1000.0
            self.kiwoom.max_per_min = self.sp_permin.value()
            self.kiwoom._req_times = []; self.kiwoom._last_req = 0.0
            p1,p2 = self.sp_lrl1.value(), self.sp_lrl2.value()
            ma_a,ma_b = self.sp_maa.value(), self.sp_mab.value()
            codes = list(dict.fromkeys(self.universe()))   # ★중복 종목 제거
            if not codes: self.logmsg("대상 종목 없음"); return
            full = self.chk_showall.isChecked()
            self.pbar.setMaximum(len(codes)); self.pbar.setValue(0)
            self.logmsg(f"🔍 스캔 시작: {len(codes)}종목(중복제거) · {'모든종목표시' if full else '후보만'} "
                        f"(분당≤{self.sp_permin.value()}요청)")
            found = 0; seen = set()
            for i, code in enumerate(codes):
                if self.stop_flag: self.logmsg("⏹ 중지됨"); break
                if code in seen: continue
                seen.add(code)
                self.pbar.setValue(i+1)
                try: r = self.fetch_eval(code, p1, p2, ma_a, ma_b, full)
                except Exception as e: self.logmsg(f"{code} 오류: {e}"); r = None
                if r is None or r.get("prefilter"):
                    QApplication.processEvents(); continue
                self.results.append(r); self.add_row(r)   # ★모든 종목 표시
                if r["ok"]:
                    found += 1
                    self.logmsg(f"🎯 후보: {r['code']} {r['name']} (회전율 {r['turnover']:.2f})")
                else:
                    fail = "".join(n for n,c in [("①",r["c1"]),("②",r["c2"]),("③",r["c3"])] if not c)
                    self.logmsg(f"  {r['code']} {r['name']} 탈락 (❌{fail})")
                self.lbl_count.setText(f"🎯 후보 {found} · 검사 {len(self.results)}종목")
                self.table.scrollToBottom(); QApplication.processEvents()
            self.logmsg(f"✅ 완료. 검사 {len(self.results)}종목 · 후보 {found}종목")
            self.lbl_count.setText(f"🎯 후보 {found}종목 / 검사 {len(self.results)}종목 (완료)")
            if self.chk_tg.isChecked() and not self.stop_flag:
                self.on_tg()
        finally:
            self.scanning = False; self.btn_scan.setEnabled(True)

    def _matches(self): return [r for r in self.results if r.get("ok")]

    def tg_text(self):
        oks = self._matches()
        fails = [r for r in self.results if not r.get("ok")]
        fails.sort(key=lambda r: (r["c1"] + r["c2"] + r["c3"]), reverse=True)  # 2/3 통과 먼저
        today = datetime.date.today().strftime("%Y-%m-%d")
        L = [f"🐷 종가배팅 스캐너 결과 · {today}",
             f"검색기 {len(self.results)}종목 → 🎯선정 {len(oks)} · 탈락 {len(fails)}",
             "① 세력 ② 200·400 ③ 거래량>유통주식", "━━━━━━━━━━━━━━━"]
        if oks:
            L.append(f"🎯 선정 {len(oks)}종목")
            for i, r in enumerate(oks, 1):
                L += [f"{i}. {r['name']}({r['code']})  {cond_marks(r)}",
                      f"   💰 종가 {r['close']:,.0f}  🔄 회전율 {r['turnover']:.2f}",
                      f"   LRL20 {r['lrl1']:,.0f} > LRL40 {r['lrl2']:,.0f} · MA200 {r['ma200']:,.0f}·MA400 {r['ma400']:,.0f}",
                      f"   📊 거래량 {r['vol']:,} · 🔓 유통 {r['float']:,}", ""]
        else:
            L.append("😴 3조건 충족(선정) 종목 없음\n")
        if fails:
            L.append(f"❌ 탈락 {len(fails)}종목 (사유)")
            for i, r in enumerate(fails[:200], 1):
                L.append(f"{i}. {r['name']}({r['code']})  {cond_marks(r)}")
                L.append(f"     └ {' · '.join(fail_reasons(r))}")
            if len(fails) > 200: L.append(f"…외 {len(fails)-200}종목 생략")
        return "\n".join(L)

    def on_tg(self):
        oks = self._matches(); fails = sum(1 for r in self.results if not r.get("ok"))
        ok = send_telegram_long(self.tg_text())
        self.logmsg(f"📤 텔레그램 전송 {'성공' if ok else '실패'} (선정 {len(oks)} · 탈락 {fails}종목)")

    def on_csv(self):
        if not self.results: QMessageBox.information(self,"안내","결과 없음"); return
        path,_ = QFileDialog.getSaveFileName(self,"CSV 저장",
            f"종가배팅후보_{datetime.date.today():%Y%m%d}.csv","CSV (*.csv)")
        if not path: return
        with open(path,"w",newline="",encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(["코드","종목명","종가","거래량","유통주식수","회전율","LRL20","LRL40",
                        "MA200","MA400","①세력","②돌파","③거래량","종합","산출근거"])
            for r in self._matches():
                w.writerow([r["code"],r["name"],int(r["close"]),r["vol"],r["float"],round(r["turnover"],3),
                            int(r["lrl1"]),int(r["lrl2"]),int(r["ma200"]),int(r["ma400"]),
                            r["c1"],r["c2"],r["c3"],r["ok"],r.get("method","")])
        self.logmsg(f"💾 CSV 저장: {path}")

if __name__ == "__main__":
    app = QApplication(sys.argv); app.setStyleSheet(QSS)
    win = MainWindow(); win.show()
    sys.exit(app.exec_())
