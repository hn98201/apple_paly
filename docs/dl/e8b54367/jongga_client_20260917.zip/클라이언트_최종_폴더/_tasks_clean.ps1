﻿# 옛 설치가 남긴 예약작업을 지운다. (2026-09-17)
#
# 증상: 2분마다 'Windows Script Host — run_watchdog.vbs 을(를) 찾을 수 없습니다' 오류창
# 원인: 2026-09-16 부터 클라이언트는 예약작업을 쓰지 않는다. 그런데 그 전에 깔았던 PC 에는
#       `종가배팅_클라이언트감시`(2분마다)가 남아, 이미 지워진 파일을 계속 찾는다.
$ErrorActionPreference = "Continue"
Write-Host ""
Write-Host "  옛 예약작업 정리" -ForegroundColor Cyan
Write-Host "  ------------------------------------------------"
$n = 0
foreach ($t in @('종가배팅_클라이언트감시','종가배팅_클라이언트시작')) {
    if (Get-ScheduledTask -TaskName $t -ErrorAction SilentlyContinue) {
        schtasks /Delete /TN $t /F | Out-Null
        if (Get-ScheduledTask -TaskName $t -ErrorAction SilentlyContinue) {
            Write-Host "  [실패] $t — 관리자 권한이 필요합니다" -ForegroundColor Red
            Write-Host "         이 파일을 마우스 오른쪽 > [관리자 권한으로 실행] 해 주세요" -ForegroundColor Yellow
        } else {
            Write-Host "  [제거] $t" -ForegroundColor Green; $n++
        }
    } else {
        Write-Host "  [없음] $t"
    }
}
Write-Host ""
if ($n -gt 0) {
    Write-Host "  끝났습니다. 이제 그 오류창이 뜨지 않습니다." -ForegroundColor Green
} else {
    Write-Host "  지울 예약작업이 없었습니다." -ForegroundColor Green
}
Write-Host ""
Write-Host "  참고: 이제 클라이언트는 예약작업을 쓰지 않습니다."
Write-Host "        아침에 바탕화면 [▶ 종가배팅 클라이언트] 를 한 번 누르면"
Write-Host "        08:30 자동로그인 -> 15:25 종가매수 -> 17:00 대기 를 스스로 합니다."
Write-Host "        켜 둔 채로 두면 다음 평일 08:30 에 스스로 다시 로그인합니다."
