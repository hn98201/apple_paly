@echo off
title Fix - Remove Leftover Scheduled Tasks
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0_tasks_clean.ps1"
echo.
pause
