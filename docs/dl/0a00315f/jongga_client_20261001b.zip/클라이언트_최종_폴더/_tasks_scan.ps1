﻿# 종가배팅 클라이언트 - 옛 설치를 가리키는 예약작업 찾기·지우기 (2026-10-01 신설)
#
# 0단계(_uninstall.ps1) · 2단계(_install.ps1) · 오류났을때(_tasks_clean.ps1) 가 이 파일을 불러 쓴다(. 소스).
#
# 왜 만들었나 — 실사고 (2026-10-01)
#   다른 PC 에서 새 버전(20261001)으로 재설치하자 0단계가 옛 폴더(20260929)의 이름을 바꿨다.
#   그런데 그 PC 에는 사람이 따로 만든 `JonggaClientGuardian`(2분마다 감시) 예약작업이 있었고,
#   이 작업이 사라진 옛 경로의 스크립트를 계속 찾으면서
#   "스크립트 파일을 찾을 수 없습니다" 창을 **2분마다** 띄웠다(사람이 작업을 지워서 멈췄다).
#   우리 정리 스크립트는 **이름을 아는 작업 3개만** 지웠기 때문에 이 작업을 못 봤다.
#   → 이름이 아니라 **실행 경로**로 찾는다. 이름을 모르는 작업도 잡힌다.
#   (2026-09-17 의 run_watchdog.vbs 2분 오류창과 같은 종류다 — 그때는 이름을 알아서 목록에 넣었다)
#
# '옛 설치를 가리키는 작업' 으로 보는 것 — 셋 중 하나
#   ① 지금 정리할 옛 설치 폴더 **안**을 가리킨다
#      (곧 이름이 바뀌어 끊어진다 · 그대로 두면 옛 client.py 를 다시 띄워 이중매매가 날 수도 있다)
#   ② 가리키는 파일이 없고, 그 자리의 폴더가 `<이름>_구버전_<날짜>` 로 바뀌어 남아 있다(0단계가 남기는 흔적)
#   ③ 가리키는 파일이 없고, 그 파일이 클라이언트 실행 파일(run_client.vbs · client.py 등)이거나
#      작업 이름에 Jongga · 종가 가 들어 있다
# 건드리지 않는 것
#   · \Microsoft\ 아래 윈도우 작업
#   · 지금 설치하는 키트 안을 가리키는 경로
#   · 드라이브 자체가 없는 경로 — USB 를 뺀 상태일 수 있다. '없다' 고 단정하지 않는다
#   · 위 셋에 안 걸리는 작업 — 파일이 없어도 우리 것인지 모르면 지우지 않는다
#     (예: 이름에 Jongga 가 없고 실행 파일 이름도 낯선 작업이 통째로 지워진 폴더를 가리키는 경우)
#
# 속도 — `schtasks /Query /XML` **한 번**으로 전부 읽는다(작업 210개 PC 실측 2.2초).
#   Get-ScheduledTask 는 건당 2초라 쓰지 않는다(2026-09-29 '정리하면 렉 걸린다' 신고의 원인).

$JG_MARKERS = @('run_client.vbs', 'run_elevated.vbs', 'run_watchdog.vbs', 'run_client.bat', 'client.py')

function Get-JgTaskList {
    # 모든 예약작업의 이름과 실행 경로(Command · Arguments · WorkingDirectory)를 돌려준다.
    $raw = (schtasks /Query /XML 2>$null) -join "`n"
    $list = @()
    if (-not $raw) { return ,$list }
    # 출력은 '<!-- \작업이름 -->' 주석 뒤에 그 작업의 XML 이 오는 모양이다.
    $parts = [regex]::Split($raw, '<!--\s*(\\[^>]*?)\s*-->')
    for ($i = 1; $i + 1 -lt $parts.Count; $i += 2) {
        $name = $parts[$i].Trim()
        $body = $parts[$i + 1]
        $paths = @()
        foreach ($tag in 'Command', 'WorkingDirectory') {
            foreach ($m in [regex]::Matches($body, "<$tag>(.*?)</$tag>", 'Singleline')) {
                $v = [Net.WebUtility]::HtmlDecode($m.Groups[1].Value).Trim().Trim('"').Trim()
                $v = [Environment]::ExpandEnvironmentVariables($v)
                if ($v -match '^[A-Za-z]:\\') { $paths += $v }
            }
        }
        foreach ($m in [regex]::Matches($body, '<Arguments>(.*?)</Arguments>', 'Singleline')) {
            $a = [Environment]::ExpandEnvironmentVariables([Net.WebUtility]::HtmlDecode($m.Groups[1].Value))
            # 따옴표로 감싼 경로(공백 포함 가능)를 먼저, 그다음 따옴표 없는 경로
            foreach ($q in [regex]::Matches($a, '"([A-Za-z]:\\[^"]+)"')) { $paths += $q.Groups[1].Value.Trim() }
            $rest = [regex]::Replace($a, '"[^"]*"', ' ')
            foreach ($u in [regex]::Matches($rest, '(?<![\w/\\])([A-Za-z]:\\[^\s"]+)')) { $paths += $u.Groups[1].Value }
        }
        $list += [pscustomobject]@{ Name = $name; Paths = @($paths | Select-Object -Unique) }
    }
    return ,$list
}

function Test-JgUnder($p, $dir) {
    if (-not $p -or -not $dir) { return $false }
    $d = $dir.TrimEnd('\')
    return ($p -ieq $d) -or $p.StartsWith($d + '\', [StringComparison]::OrdinalIgnoreCase)
}

function Test-JgClientDir($d) {
    # 우리 클라이언트 설치 폴더인가 — client.py 하나만으로는 약하다(다른 프로그램도 그 이름을 쓴다).
    if (-not $d -or -not (Test-Path -LiteralPath $d)) { return $false }
    foreach ($f in 'client.py', 'run_client.vbs', 'kiwoom_trade.py') {
        if (-not (Test-Path -LiteralPath (Join-Path $d $f))) { return $false }
    }
    return $true
}

function Get-JgStaleReason($task, $oldDirs, $kitDir) {
    # 옛 설치를 가리키는 작업이면 그 이유를, 아니면 $null 을 돌려준다.
    if ($task.Name -like '\Microsoft\*') { return $null }
    foreach ($p in @($task.Paths)) {
        if (Test-JgUnder $p $kitDir) { continue }
        # ① 지금 정리할 옛 설치 폴더 안
        foreach ($od in @($oldDirs)) {
            if (Test-JgUnder $p $od) { return "정리할 옛 설치 폴더 안을 가리킴: $p" }
        }
        $drive = [IO.Path]::GetPathRoot($p)
        if (-not $drive -or -not (Test-Path -LiteralPath $drive)) { continue }   # 드라이브가 없으면 판단 보류
        if (Test-Path -LiteralPath $p) { continue }                              # 있는 파일이면 끊어진 게 아니다
        # ② 끊어진 자리의 폴더가 '_구버전_' 으로 이름이 바뀌어 남아 있다
        $a = $p
        while ($a) {
            $par = Split-Path -Parent $a
            if (-not $par) { break }
            if (Test-Path -LiteralPath $par) {
                # $a 가 처음으로 끊어진 자리다 — 그 옆에 '<이름>_구버전_*' 이 있나
                $leaf = Split-Path -Leaf $a
                foreach ($r in @(Get-ChildItem -LiteralPath $par -Directory -ErrorAction SilentlyContinue |
                                 Where-Object { $_.Name -like ($leaf + '_구버전_*') })) {
                    if ((Test-JgClientDir $r.FullName) -or (Test-JgClientDir (Join-Path $r.FullName '프로그램'))) {
                        return "이름이 바뀐 옛 설치 폴더를 가리킴: $p  (지금 이름: $($r.Name))"
                    }
                }
                break
            }
            $a = $par
        }
        # ③ 클라이언트 실행 파일이거나 우리 작업 이름인데 파일이 없다
        if ($JG_MARKERS -contains (Split-Path -Leaf $p)) { return "없는 클라이언트 파일을 가리킴: $p" }
        if ($task.Name -match '(?i)jongga|종가') { return "작업 이름이 Jongga·종가 인데 실행 파일이 없음: $p" }
    }
    return $null
}

function Find-JgStaleTasks($all, $oldDirs, $kitDir, $skipNames) {
    # $skipNames: 다른 곳에서 따로 처리하는 작업 이름(앞의 '\' 없이)
    $out = @()
    foreach ($t in @($all)) {
        if (@($skipNames) -contains $t.Name.TrimStart('\')) { continue }
        $why = Get-JgStaleReason $t $oldDirs $kitDir
        if ($why) { $out += [pscustomobject]@{ Name = $t.Name; Why = $why } }
    }
    return ,$out
}

function Remove-JgTask($name) {
    # 지우고, 정말 지워졌는지 확인한다(권한이 모자라면 조용히 남는다).
    # ★조회할 수 있던 작업이라(목록에서 봤다) 지운 뒤 조회가 실패하면 = 지워진 것이다.
    schtasks /Delete /TN "$name" /F 2>$null | Out-Null
    Start-Sleep -Milliseconds 300
    schtasks /Query /TN "$name" 2>$null | Out-Null
    return ($LASTEXITCODE -ne 0)
}
