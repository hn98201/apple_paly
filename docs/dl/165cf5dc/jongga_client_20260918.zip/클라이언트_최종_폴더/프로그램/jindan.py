# -*- coding: utf-8 -*-
"""환경 진단 — '왜 프로그램이 안 뜨는가' 를 한 번에 알려준다. (2026-09-15)

키움 OCX 는 QAxWidget 으로 **실제로 올려 봐야** 정상인지 알 수 있다.
레지스트리 ProgID 만 보는 점검은 옛 설치를 지운 PC 에서 통과해 버린다.
여기서는 진짜로 만들어 보고, 그 결과를 결론으로 삼는다.

결과는 화면에 찍고 [진단결과.txt] 로도 저장한다 — 관리자에게 그 파일을 보내면 된다.
"""
import io, os, sys, struct, datetime

try: sys.stdout.reconfigure(errors="replace")
except Exception: pass

DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, DIR)
LINE = "=" * 58
BUF = []


def say(s=""):
    print(s)
    BUF.append(s)


def head(s):
    say(); say(s)


def main():
    say(LINE)
    say("  종가배팅 클라이언트 — 환경 진단")
    say("  %s" % datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    say(LINE)

    fatal = []

    # ── ① 파이썬 ────────────────────────────────────────────────
    bits = struct.calcsize("P") * 8
    head("① 파이썬")
    say("   경로   : %s" % sys.executable)
    say("   버전   : %s" % sys.version.split()[0])
    say("   비트수 : %d비트" % bits)
    if bits == 32:
        say("   [OK] 32비트 — 키움 OpenAPI 를 쓸 수 있습니다")
    else:
        say("   [X] 64비트 — 키움 OpenAPI 는 32비트에서만 동작합니다")
        fatal.append("64비트 파이썬으로 실행되고 있습니다.\n"
                     "  python.org 에서 'Windows installer (32-bit)' 3.12.x 설치\n"
                     "  → [2_프로그램설치.bat] 다시 실행")

    # 실행에 실제로 쓰이는 파이썬 (바로가기/스케줄이 이걸 읽는다)
    pp = os.path.join(DIR, "python_path.txt")
    say()
    if os.path.isfile(pp):
        saved = io.open(pp, encoding="utf-8", errors="replace").read().strip()
        ok = os.path.isfile(saved)
        say("   실행용 경로(python_path.txt)")
        say("     %s" % saved)
        say("     %s" % ("[OK] 파일 있음" if ok else "[X] 그 경로에 파일이 없습니다"))
        if not ok:
            fatal.append("python_path.txt 가 없는 파이썬을 가리킵니다.\n"
                         "  [2_프로그램설치.bat] 을 다시 실행하세요.")
    else:
        say("   [X] python_path.txt 가 없습니다 — [2_프로그램설치.bat] 을 실행하세요")
        fatal.append("python_path.txt 가 없습니다. [2_프로그램설치.bat] 실행 필요.")

    # ── ② 라이브러리 ────────────────────────────────────────────
    head("② 라이브러리")
    for mod, how in (("PyQt5", "[2_프로그램설치.bat]"), ("numpy", "[2_프로그램설치.bat]")):
        try:
            __import__(mod)
            say("   [OK] %s" % mod)
        except Exception as e:
            say("   [X] %s 없음 (%s)" % (mod, e))
            fatal.append("%s 가 설치되지 않았습니다. %s 를 다시 실행하세요." % (mod, how))
    try:
        from PyQt5.QAxContainer import QAxWidget  # noqa
        say("   [OK] PyQt5.QAxContainer (OCX 컨테이너)")
    except Exception as e:
        say("   [X] PyQt5.QAxContainer 없음 (%s)" % e)
        fatal.append("PyQt5 설치가 불완전합니다. [2_프로그램설치.bat] 을 다시 실행하세요.")

    # ── ③ 키움 OpenAPI 등록 상태 ────────────────────────────────
    head("③ 키움 OpenAPI 등록 상태")
    info = None
    try:
        import kiwoom_ocx
        info = kiwoom_ocx.inspect()
        say("   ProgID  : %s" % kiwoom_ocx.PROGID)
        say("   CLSID   : %s" % (info["clsid"] or "(등록 없음)"))
        say("   ocx파일 : %s" % (info["server"] or "(등록 없음)"))
        say("   파일존재: %s" % ("예" if info["server_exists"] else "아니오  ← 이게 아니오면 로딩 실패"))
        say("   C:\\OpenAPI\\khopenapi.ocx : %s" % ("있음" if info["default_ocx"] else "없음"))
        p = kiwoom_ocx.problem()
        if p:
            say()
            for ln in p.splitlines():
                say("   " + ln)
    except Exception as e:
        say("   [X] 점검 모듈을 못 읽었습니다 : %s" % e)

    # ── ④ 진짜 로딩 테스트 (여기가 결론) ────────────────────────
    head("④ 키움 OCX 실제 로딩 테스트  ★이게 결론입니다")
    loaded = False
    try:
        from PyQt5.QtWidgets import QApplication
        from PyQt5.QAxContainer import QAxWidget
        _app = QApplication.instance() or QApplication(sys.argv)
        w = QAxWidget("KHOPENAPI.KHOpenAPICtrl.1")
        loaded = hasattr(w, "OnEventConnect")
        if loaded:
            say("   [OK] 로딩 성공 — 이 PC 에서 키움 OpenAPI 를 쓸 수 있습니다")
        else:
            say("   [X] 로딩 실패 — OnEventConnect 가 생기지 않았습니다")
            say("       (프로그램이 죽던 바로 그 지점입니다)")
    except Exception as e:
        say("   [X] 테스트 중 오류 : %s" % e)

    if not loaded:
        try:
            import kiwoom_ocx
            say()
            for ln in kiwoom_ocx.guide().splitlines():
                say("   " + ln)
        except Exception:
            pass
        fatal.append("키움 OCX 를 실제로 올리지 못했습니다. 위 ④ 안내를 따르세요.")

    # ── ⑤ 키움 자동로그인 설정 ──────────────────────────────────
    head("⑤ 키움 자동로그인 설정파일")
    al = r"C:\OpenAPI\system\Autologin.dat"
    if os.path.isfile(al):
        say("   [OK] 있음 — 자세한 점검은 [키움설정_점검.bat]")
    else:
        say("   [--] 없음 — 키움에 아직 한 번도 로그인하지 않았습니다")
        say("        (프로그램 실행 자체와는 무관. 무인운용에는 필요합니다)")

    # ── ⑥ 최근 실행오류 ─────────────────────────────────────────
    head("⑥ 최근 실행오류.txt")
    ef = os.path.join(DIR, "실행오류.txt")
    if os.path.isfile(ef):
        txt = io.open(ef, encoding="utf-8", errors="replace").read().strip()
        say("   (%s)" % datetime.datetime.fromtimestamp(os.path.getmtime(ef)).strftime("%Y-%m-%d %H:%M"))
        for ln in txt.splitlines()[-25:]:
            say("   | " + ln)
    else:
        say("   없음")

    # ── ⑦ 자동실행 · 자동매매 ───────────────────────────────────
    head("⑦ 자동실행 · 자동매매  ★08:30 에 안 켜졌다면 여기")

    def _ps(cmd):
        try:
            import subprocess
            r = subprocess.run(["powershell", "-NoProfile", "-Command", cmd],
                               capture_output=True, timeout=25, creationflags=0x08000000)
            return (r.stdout or b"").decode("cp949", "replace").strip()
        except Exception as e:
            return "ERR:%s" % e

    t = _ps("$t=Get-ScheduledTask -TaskName 'JonggaClientRun' -EA SilentlyContinue;"
            "if($t){$i=$t|Get-ScheduledTaskInfo;"
            "'{0}|{1}|{2}|{3}|{4}' -f $t.State,$t.Principal.RunLevel,"
            "$(if($t.Triggers){$t.Triggers[0].StartBoundary}else{'없음'}),$i.NextRunTime,$i.LastTaskResult}"
            "else{'NONE'}")
    if t.startswith("NONE") or not t or t.startswith("ERR"):
        say("   [X] 08:20 자동실행 예약작업이 없습니다 (JonggaClientRun)")
        say("       → PC 를 켜 둬도 프로그램이 스스로 뜨지 않습니다.")
        fatal.append("08:20 자동실행이 등록돼 있지 않습니다.\n"
                     "[2_프로그램설치.bat] 을 다시 실행하고, 파란 창이 뜨면 [예] 를 누르세요.")
    else:
        p = t.split("|")
        say("   [OK] 자동실행 등록됨 (JonggaClientRun)")
        say("        상태 %s · 권한 %s" % (p[0], p[1] if len(p) > 1 else "?"))
        if len(p) > 2: say("        트리거 %s" % p[2])
        if len(p) > 3: say("        다음 실행 %s" % p[3])
        if len(p) > 4 and p[4] not in ("0", "267011"):
            say("        ⚠️ 마지막 실행 결과 %s (0 이 아니면 실패)" % p[4])
        if len(p) > 1 and p[1] != "Highest":
            say("        ⚠️ 최고 권한이 아닙니다 — 키움 로그인 때 UAC 창이 뜹니다")

    old = _ps("(Get-ScheduledTask | Where-Object { $_.TaskName -match '종가배팅_클라이언트' } |"
              " ForEach-Object { $_.TaskName }) -join ','")
    if old and not old.startswith("ERR") and old.strip():
        say("   [!] 옛 예약작업이 남아 있습니다: %s" % old)
        say("       → [오류났을때_예약작업정리.bat] 을 한 번 실행하세요")

    say()
    cfg = {}
    try:
        import json
        cfg = json.load(io.open(os.path.join(DIR, "client_config.json"), encoding="utf-8"))
    except Exception as e:
        say("   [X] client_config.json 을 못 읽었습니다: %s" % e)
    if cfg:
        auto = bool(cfg.get("auto_start", True))
        acc = (cfg.get("account") or "").strip()
        nick = (cfg.get("nickname") or "").strip()
        say("   자동매매 계속(auto_start) : %s" % ("켜짐" if auto else "★꺼짐 — 08:30 에 안 켜집니다"))
        say("   계좌번호                  : %s" % (acc or "★비어 있음 — 로그인 후 계좌를 고르고 [저장]"))
        say("   닉네임                    : %s" % (nick or "★비어 있음 — 승인을 못 받습니다"))
        say("   모드                      : %s" % ("모의투자" if cfg.get("is_mock", True) else "실거래"))
        if not auto:
            fatal.append("자동매매가 꺼져 있습니다(auto_start).\n"
                         "프로그램에서 [자동매매 시작] 을 한 번 누르면 그 뒤로는 매일 자동입니다.")
        if not acc:
            fatal.append("계좌번호가 비어 있습니다.\n"
                         "설정 탭에서 키움 로그인 → 계좌 선택 → [저장] 하세요.\n"
                         "(재설치 때 [0_기존버전_정리.bat] 을 건너뛰면 계좌·닉네임이 인계되지 않습니다)")
        if not nick:
            fatal.append("닉네임이 비어 있습니다 — 관리자 승인을 받을 수 없습니다.\n"
                         "설정 탭에서 닉네임을 넣고 [승인 요청] 하세요.")

    say()
    lf = os.path.join(DIR, "client_log.txt")
    if os.path.isfile(lf):
        try:
            lines = io.open(lf, encoding="utf-8", errors="replace").read().splitlines()
        except Exception:
            lines = []
        today = datetime.datetime.now().strftime("%Y-%m-%d")
        keys = ("운영시간 진입", "자동 재개", "자동매매 시작", "미승인", "계좌가 설정되지",
                "안전정지", "로그인 실패", "자동매매 예약", "장 시작 전")
        hit = [l for l in lines if today in l and any(k in l for k in keys)]
        say("   오늘 로그에서 자동시작 흔적 (%s)" % today)
        if hit:
            for l in hit[-8:]: say("     | " + l.strip()[:150])
        else:
            say("     없음 — 08:30 에 프로그램이 안 떠 있었을 수 있습니다")
            say("     (PC 가 꺼져 있었거나, 자동실행 예약작업이 없거나)")
    else:
        say("   client_log.txt 가 없습니다 — 아직 한 번도 실행되지 않았습니다")

    # ── 결론 ────────────────────────────────────────────────────
    say(); say(LINE)
    if fatal:
        say("  결론 : 아래를 고치면 실행됩니다")
        say(LINE)
        for i, f in enumerate(fatal, 1):
            say()
            for j, ln in enumerate(f.splitlines()):
                say(("  %d) " % i if j == 0 else "     ") + ln)
    else:
        say("  결론 : 환경은 정상입니다")
        say(LINE)
        say("  이 상태에서도 안 뜨면 [오류확인_콘솔실행.bat] 로 실행해")
        say("  화면에 찍히는 메시지를 관리자에게 보내주세요.")
    say(); say(LINE)
    return 0 if not fatal else 1


if __name__ == "__main__":
    try:
        rc = main()
    except Exception as e:
        import traceback
        say("진단 중 오류: %s" % e); say(traceback.format_exc()); rc = 1
    try:
        out = os.path.join(DIR, "진단결과.txt")
        io.open(out, "w", encoding="utf-8").write("\n".join(BUF))
        print()
        print("저장했습니다 : %s" % out)
        print("이 파일을 관리자에게 보내주세요.")
    except Exception:
        pass
    try: input("\n엔터를 누르면 닫힙니다...")
    except Exception: pass
    sys.exit(rc)
