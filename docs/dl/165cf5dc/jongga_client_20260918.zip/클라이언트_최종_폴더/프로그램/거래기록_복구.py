# -*- coding: utf-8 -*-
"""거래기록 복구 — 재설치하면서 잃어버린 매매기록을 찾아 되살린다. (2026-09-18)

왜 필요한가
  재설치 때 [0_기존버전_정리.bat] 을 건너뛰거나 실패하면 `_이전설정` 폴더가 안 생긴다.
  그러면 _migrate.py 가 돌지 않아 **계좌·닉네임·거래기록이 전부 새 것으로 시작**한다.
  기록 자체가 지워진 건 아니다 — 옛 폴더(또는 _구버전_날짜)에 그대로 남아 있다.
  이 도구가 그걸 찾아 지금 쓰는 client_state.json 에 합친다.

무엇을 하나
  1. 이 PC 에서 client_state.json 을 전부 찾는다(옛 폴더·_구버전_·_이전설정·바탕화면 등)
  2. 지금 쓰는 파일보다 거래가 많은 것을 후보로 보여 준다
  3. 고르면 **합친다** — 같은 (날짜·종목·매도시각) 은 한 번만 넣어 중복을 막는다
  4. 합치기 전 지금 파일을 백업한다(client_state.json.bak_날짜)

★포지션(보유중)은 손대지 않는다.
  옛 포지션을 되살리면 이미 판 종목이 유령으로 남아 유령 청산주문을 낸다.
  보유는 로그인할 때 _adopt_holdings 가 실계좌에서 정확히 다시 채택한다.
"""
import io, os, sys, json, glob, shutil, datetime

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

DIR = os.path.dirname(os.path.abspath(__file__))
STATE = os.path.join(DIR, "client_state.json")


def load(p):
    try:
        return json.load(io.open(p, encoding="utf-8"))
    except Exception:
        return None


def key(t):
    """같은 거래인지 가리는 열쇠 — 날짜·종목코드·매도시각."""
    return (t.get("date"), t.get("code") or t.get("name"), t.get("sell_time"))


def candidates():
    """이 PC 에서 client_state.json 을 찾는다. 자기 자신은 뺀다."""
    pats = []
    home = os.path.expanduser("~")
    for base in (home, os.path.join(home, "OneDrive")):
        for sub in ("Desktop", "바탕 화면", "Documents"):
            pats.append(os.path.join(base, sub, "**", "client_state.json"))
    pats += [os.path.join("C:\\", "종가배팅*", "**", "client_state.json"),
             os.path.join(os.path.dirname(DIR), "**", "client_state.json"),
             os.path.join(os.path.dirname(os.path.dirname(DIR)), "**", "client_state.json")]
    seen, out = set(), []
    me = os.path.normcase(os.path.abspath(STATE))
    for p in pats:
        for f in glob.glob(p, recursive=True):
            a = os.path.normcase(os.path.abspath(f))
            if a == me or a in seen:
                continue
            seen.add(a)
            d = load(f)
            if not d:
                continue
            tr = d.get("trades") or []
            if tr:
                out.append((f, tr, os.path.getmtime(f)))
    out.sort(key=lambda x: -len(x[1]))
    return out


def main():
    cur = load(STATE) or {"date": "", "positions": [], "trades": []}
    curtr = cur.get("trades") or []
    print("=" * 66)
    print("  거래기록 복구")
    print("=" * 66)
    print("지금 쓰는 기록 : %d건   (%s)" % (len(curtr), STATE))
    print()

    cands = candidates()
    if not cands:
        print("다른 client_state.json 을 찾지 못했습니다.")
        print("옛 폴더가 다른 드라이브(D:, E:)나 특이한 위치에 있으면 이 도구가 못 찾습니다.")
        print("그 폴더의 client_state.json 을 이 폴더에 복사한 뒤 다시 실행하세요.")
        input("\nEnter 를 눌러 닫기")
        return 0

    print("찾은 기록들 :")
    for i, (f, tr, mt) in enumerate(cands, 1):
        new = len([t for t in tr if key(t) not in {key(x) for x in curtr}])
        print("  [%d] %d건 (이 중 새 것 %d건)  %s" % (i, len(tr), new,
              datetime.datetime.fromtimestamp(mt).strftime("%Y-%m-%d %H:%M")))
        print("      %s" % f)
    print("  [0] 아무것도 안 함")
    print()

    try:
        sel = input("합칠 번호를 고르세요 (여러 개면 1,2 처럼) : ").strip()
    except EOFError:
        sel = ""
    if not sel or sel == "0":
        print("취소했습니다."); input("\nEnter 를 눌러 닫기"); return 0

    picks = []
    for s in sel.replace(" ", "").split(","):
        if s.isdigit() and 1 <= int(s) <= len(cands):
            picks.append(cands[int(s) - 1])
    if not picks:
        print("고른 것이 없습니다."); input("\nEnter 를 눌러 닫기"); return 0

    merged = list(curtr)
    have = {key(t) for t in merged}
    added = 0
    for f, tr, _ in picks:
        for t in tr:
            if key(t) in have:
                continue
            have.add(key(t)); merged.append(t); added += 1

    merged.sort(key=lambda t: (t.get("date", ""), t.get("sell_time", "")))

    if added == 0:
        print("\n새로 넣을 기록이 없습니다(이미 다 있습니다).")
        input("\nEnter 를 눌러 닫기"); return 0

    bak = STATE + ".bak_" + datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    if os.path.isfile(STATE):
        shutil.copy2(STATE, bak)
    cur["trades"] = merged
    # ★포지션은 건드리지 않는다 — 옛 보유를 되살리면 유령 청산주문이 나간다
    io.open(STATE, "w", encoding="utf-8", newline="").write(
        json.dumps(cur, ensure_ascii=False, indent=1))

    print()
    print("[OK] %d건 추가 → 총 %d건" % (added, len(merged)))
    print("     백업 : %s" % os.path.basename(bak))
    print()
    print("프로그램을 다시 시작하면 거래내역 탭에 반영됩니다.")
    print("★보유중(포지션)은 손대지 않았습니다 — 로그인하면 실계좌에서 다시 채택합니다.")
    input("\nEnter 를 눌러 닫기")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        import traceback
        traceback.print_exc()
        input("\n오류가 났습니다. Enter 를 눌러 닫기")
        sys.exit(1)
