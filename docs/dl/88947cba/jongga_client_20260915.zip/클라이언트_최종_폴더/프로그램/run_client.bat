@echo off
cd /d "%~dp0"
rem use python path saved at install time (works even if PATH differs per PC)
set "PYW="
if exist "%~dp0python_path.txt" for /f "usebackq delims=" %%A in ("%~dp0python_path.txt") do set "PYW=%%A"
if defined PYW if exist "%PYW%" ( start "" "%PYW%" client.py %* & exit /b )
if exist "%LOCALAPPDATA%\Programs\Python\Python312-32\pythonw.exe" ( start "" "%LOCALAPPDATA%\Programs\Python\Python312-32\pythonw.exe" client.py %* & exit /b )
if exist "%LOCALAPPDATA%\Programs\Python\Python311-32\pythonw.exe" ( start "" "%LOCALAPPDATA%\Programs\Python\Python311-32\pythonw.exe" client.py %* & exit /b )
if exist "%LOCALAPPDATA%\Programs\Python\Python310-32\pythonw.exe" ( start "" "%LOCALAPPDATA%\Programs\Python\Python310-32\pythonw.exe" client.py %* & exit /b )
if exist "%LOCALAPPDATA%\Programs\Python\Python313-32\pythonw.exe" ( start "" "%LOCALAPPDATA%\Programs\Python\Python313-32\pythonw.exe" client.py %* & exit /b )
pyw -3-32 client.py %* 2>nul && exit /b
start "" pythonw client.py %*