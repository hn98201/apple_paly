﻿$ErrorActionPreference = "Continue"
$root  = $PSScriptRoot
$env0  = Join-Path $root "환경팩"
$prg   = Join-Path $root "프로그램"
$pydir = Join-Path $env:LOCALAPPDATA "Programs\Python\Python312-32"
$py    = Join-Path $pydir "python.exe"
$pyw   = Join-Path $pydir "pythonw.exe"

Write-Host "============================================"
Write-Host "  [2단계] 프로그램 설치 (파이썬+PyQt5+스케줄+바로가기)" -ForegroundColor Cyan
Write-Host "============================================`n"

# 1) 파이썬 32비트 (키움 OCX 필수) — 번들 설치본 우선, 없으면 온라인
if (Test-Path -LiteralPath $py) {
    Write-Host "[OK] 파이썬 32비트 이미 설치됨"
} else {
    Write-Host "[설치] 파이썬 32비트 설치 중... (1~2분, 창이 잠깐 멈춰도 정상)"
    $setup = Get-ChildItem -LiteralPath $env0 -Filter "python-*-32bit.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $setup) {
        Write-Host "  번들 설치본 없음 → 온라인 다운로드"
        $tmp = Join-Path $env:TEMP "python-32bit.exe"
        Invoke-WebRequest -Uri "https://www.python.org/ftp/python/3.12.10/python-3.12.10.exe" -OutFile $tmp -UseBasicParsing
        $setup = Get-Item $tmp
    }
    Start-Process -FilePath $setup.FullName -ArgumentList "/quiet","InstallAllUsers=0","PrependPath=1","Include_test=0","TargetDir=$pydir" -Wait
    if (Test-Path -LiteralPath $py) { Write-Host "[OK] 파이썬 설치 완료" } else { Write-Host "[경고] 파이썬 설치 확인 실패 — 다시 실행해 보세요." -ForegroundColor Yellow }
}

# 2) PyQt5 — 번들 휠(오프라인) 우선, 실패 시 온라인
Write-Host "[설치] PyQt5 설치 중..."
$wh = Join-Path $env0 "wheels"
if (Test-Path -LiteralPath $wh) { & $py -m pip install --no-index --find-links "$wh" PyQt5 2>&1 | Out-Null }
& $py -c "import PyQt5" 2>$null
if ($LASTEXITCODE -ne 0) { & $py -m pip install "PyQt5==5.15.11" 2>&1 | Out-Null; & $py -c "import PyQt5" 2>$null }
if ($LASTEXITCODE -eq 0) { Write-Host "[OK] PyQt5 설치 확인" } else { Write-Host "[경고] PyQt5 설치 실패 — 인터넷 연결 후 다시 실행하세요." -ForegroundColor Yellow }

# 3) 무창 실행용 파이썬 경로 저장 (BOM 없이)
[System.IO.File]::WriteAllText((Join-Path $prg "python_path.txt"), $pyw, (New-Object System.Text.ASCIIEncoding))
Write-Host "[OK] 파이썬 경로 저장"

# 3-1) 이전 설치 설정 병합 — [0_기존버전_정리.bat] 이 남긴 _이전설정 이 있을 때만
#      개인값(계좌·닉네임·원금·텔레그램)은 가져오고, 전략값(익절·손절·종목당)은 새 것을 강제한다.
#      옛 config 를 통째로 두면 익절3%/손절3% 옛 전략으로 조용히 매매한다.
if (Test-Path -LiteralPath (Join-Path $prg "_이전설정")) {
    Write-Host "[인계] 이전 설치 설정 병합 중..."
    & $py (Join-Path $prg "_migrate.py")
}

# 4) 자동 스케줄 등록 (평일 08:25 시작 + 2분 워치독, 전부 무창)
Write-Host "[등록] 자동 스케줄 등록 중..."
$sched = Join-Path $prg "클라이언트_스케줄등록.ps1"
if (Test-Path -LiteralPath $sched) {
    & powershell -NoProfile -ExecutionPolicy Bypass -File $sched
} else {
    # ★이게 없으면 조용히 넘어가 08:25 자동실행이 등록되지 않는다 — 반드시 눈에 보이게 알린다
    Write-Host "[오류] 클라이언트_스케줄등록.ps1 이 없습니다 — 자동실행이 등록되지 않았습니다!" -ForegroundColor Red
    Write-Host "       관리자에게 이 파일을 요청해 프로그램 폴더에 넣고 다시 실행하세요." -ForegroundColor Red
}

# 5) 바탕화면 바로가기 생성
Write-Host "[바로가기] 바탕화면 실행 아이콘 생성..."
$vbs = Join-Path $prg "run_client.vbs"
$lnk = Join-Path ([Environment]::GetFolderPath('Desktop')) "▶ 종가배팅 클라이언트.lnk"
$w = New-Object -ComObject WScript.Shell
$s = $w.CreateShortcut($lnk)
$s.TargetPath = "C:\Windows\System32\wscript.exe"
$s.Arguments = '"' + $vbs + '"'
$s.WorkingDirectory = $prg
$s.IconLocation = "$env:SystemRoot\System32\shell32.dll,137"
$s.Description = "종가배팅 클라이언트 실행"
$s.Save()
Write-Host "[OK] 바탕화면 바로가기 생성 (▶ 종가배팅 클라이언트)"

Write-Host "`n프로그램 설치 완료! 이제 [3_키움설치.bat] 를 실행하세요." -ForegroundColor Green
